# -*- coding: utf-8 -*-
from pathlib import Path
import json
from datetime import datetime
R=Path.cwd();O=R/'outputs/band_overlay';repo=R/'work/hudian-backtest-dashboard'
plan={'createdAt':datetime.now().astimezone().isoformat(),'question':'Can fixed band-small T be applied as a continuous-account overlay without assuming freecash/overnightinventory each morning?','variants':['off','all','gated'],'gate':'previous20day adjustedreturn>5% AND previous Shenzhenindexclose>MA60;fixed from prior discussion, not optimized. Allhistory previouslyseen.','entry':'Same batch26 day-reset20bar2sigma reentry, next5minopen,11:15..14:00,firstexecutable/day,onlyafterbaseorderwindow.10%currentnetequitynotional,maxavailableovernightshares,1%previousbarvolume. Dcash orLcurrentDallfull150buycaponly. No extraallocation/free dailyreset.','exit':'completedclose +0.35% favorable/-1.5%adverse versusactualentryfill,nextopen,deadline14:50. Restoreactualfilledquantity,notNAVtarget. Partialexitscontinue. Newbase/maintenanceinstructionscanceloverlayrestoration;residualinventorypersistsinrealaccount,markedseparately.','priority':'Baseandmaintenance first; notmorethanonefillperbar. Newmarginbuydebt<=50%netafterfees;passivedrifthold preserved. T+1sellonlyoldshares,limits,lots,commission.0001/min5,5/10bps,6%calendarinterest.', 'validation':'Disabled engine exactparity; allledger/T+1/volume/margincaps,tripreconciliation,futuresuffixinvariance,syntheticfunds/exit/partial/maintenance. Fixedtrain<=2024,later2025June2026,recentJulyon,3annual,olderhistory,quarterwalkforward prior252,noTbaseline. Completeaccount NAV,DD,cumulativeand63dayrelativelead; tripswinratesseparate.', 'publication':'Separate experimental backtest selectable page, originaldefault retained. No live execution, no80%label as predictivecertainty.'}
(O/'plan_before_results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
s=(repo/'docs/finance-engine.js').read_text();s=s.replace('export function financeBacktest','export function experimentalBacktest');s=s.replace('capital=1e6,commission=',"account='L',overlay='gated',overlayContext=[],capital=1e6,commission=")
s=s.replace(" if(!Number.isFinite(commission)"," if(!['D','L'].includes(account)||!['off','all','gated'].includes(overlay))throw Error('无效实验方案');\n if(account==='D'){level=1;rate=0;}\n if(!Number.isFinite(commission)",1)
s=s.replace('const nav=[],','const trips=[],overlayBlocks={funds:0,inventory:0,limits:0,volume:0};\n const nav=[],',1)
s=s.replace('for(let d=start;d<end;d++){','for(let d=start;d<end;d++){\n  const ctx=overlayContext[d],enabled=overlay===\'all\'||overlay===\'gated\'&&ctx?.date===data.dates[d]&&ctx.trend20>.05&&ctx.marketMA60>0;\n  const entries=overlay!==\'off\'&&enabled?bandEntries(data.bars[d]):{};let trip=null,used=false;')
s=s.replace('const bar=data.bars[d][j],sig=', 'const beforeBase=trades.length;let riskNow=false;\n   const bar=data.bars[d][j],sig=')
s=s.replace('forced=true;}','forced=true;riskNow=true;}')
s=s.replace('forced?1:0]);','forced?1:0,0]);')
needle='''   }
   if(j===47){const charge'''
extra='''
    // Base orders and maintenance instructions always take priority over experimental T.
    if(trip&&!trip.cancelled&&trip.remaining>0&&(riskNow||sig>=0)){trip.cancelled=true;trip.exitReason='cancelled_by_base_or_risk';}
    if(trades.length===beforeBase&&!(pending&&j<=deadline)&&!riskNow){
     let side=0,wanted=0,kind=0;
     if(trip&&trip.remaining>0&&!trip.cancelled){
      const gain=trip.side*(known/trip.entryPrice-1);
      if(!trip.exitReason){if(gain>=.0035)trip.exitReason='take_profit';else if(gain<=-.015)trip.exitReason='stop';else if(j>=46)trip.exitReason='time';}
      if(trip.exitReason){side=-trip.side;wanted=trip.remaining;kind=2;}
     }else if(!used&&!forced&&target>0&&j>=21&&j<=36&&entries[j]){
      side=entries[j];kind=1;
     }
     if(side){
      const px=bar[0],equity=cash+shares*px,cap=Math.trunc(data.bars[d][j-1][4]*.01/100)*100;
      const fill=side>0?Math.ceil(px*(1+slip)*100-1e-8)/100:Math.floor(px*(1-slip)*100+1e-8)/100;
      if(kind===1){wanted=Math.max(0,Math.trunc(equity*.1/fill/100)*100);if(available<wanted)overlayBlocks.inventory++;wanted=Math.min(wanted,available);}
      let qty=Math.floor(Math.min(wanted,cap)/100)*100;if(wanted>cap){caps++;overlayBlocks.volume++;}
      const upper=Math.floor(data.reference[d]*1.1*100+.5)/100,lower=Math.floor(data.reference[d]*.9*100+.5)/100;
      if((side>0&&(px>=upper-.005||fill>upper))||(side<0&&(px<=lower+.005||fill<lower))){if(qty>0){limits++;overlayBlocks.limits++;}qty=0;}
      if(side<0){if(qty>available)t1++;qty=Math.min(qty,available);}
      if(side>0){const allowed=account==='D'?1:Math.min(1.5,Math.max(1,target));
       const budget=allowed*cash+(allowed-1)*shares*px-allowed*minCommission;
       let aff=Math.max(0,Math.trunc(budget/(px+allowed*(fill-px)+allowed*fill*(commission+data.transfer[d]))/100)*100);
       if(credit!==null)aff=Math.min(aff,Math.max(0,Math.trunc((cash+credit-minCommission)/(fill*(1+commission+data.transfer[d]))/100)*100));
       if(qty>aff)overlayBlocks.funds++;qty=Math.min(qty,aff);
      }
      if(qty>0){const gross=qty*fill,fee=Math.max(minCommission,gross*commission)+gross*(data.transfer[d]+(side<0?data.stamp[d]:0)),oldAvail=available,oldShares=shares;
       cash-=side*gross+fee;shares+=side*qty;if(side<0)available-=qty;fees+=fee;turnover+=gross/Math.max(equity,1);dayBorrow=Math.max(dayBorrow,-cash);
       if(kind===1){used=true;trip={day:d,date:data.dates[d],entryBar:j,side,entryPrice:fill,quantity:qty,remaining:qty,netCash:0,exitReason:'',cancelled:false};}
       else trip.remaining-=qty;
       trip.netCash-=side*gross+fee;
       trades.push([d,j,side,qty,fill,fee,cash,shares,available,oldAvail,target,cap,oldShares,-1,Math.max(-cash,0),0,kind]);
      }
     }
    }
'''
assert needle in s;s=s.replace(needle,extra+needle,1)
s=s.replace('const eq=cash+shares*data.close[d];nav.push(eq);',"if(trip){trip.complete=trip.remaining===0&&!trip.cancelled;trip.markedNet=trip.netCash+trip.side*trip.remaining*data.close[d];trips.push(trip);}\n  const eq=cash+shares*data.close[d];nav.push(eq);")
s=s.replace("return {commission,minCommission,feeVersion:","return {account,overlay,trips,overlayBlocks,commission,minCommission,feeVersion:")
s+='''
// Only the prefix through bar j-1 participates in an entry at j.
export function bandEntries(bars){
 const cl=bars.map(b=>b[3]),lo=[],hi=[],out={};
 for(let k=19;k<cl.length;k++){const a=cl.slice(k-19,k+1),mean=a.reduce((s,v)=>s+v,0)/20,sd=Math.sqrt(a.reduce((s,v)=>s+(v-mean)**2,0)/20);lo[k]=mean-2*sd;hi[k]=mean+2*sd;}
 for(let j=21;j<Math.min(37,bars.length);j++){if(cl[j-2]<lo[j-2]&&cl[j-1]>=lo[j-1])out[j]=1;else if(cl[j-2]>hi[j-2]&&cl[j-1]<=hi[j-1])out[j]=-1;}
 return out;
}
'''
(repo/'docs/experimental-engine.js').write_text(s)
print('Registered fixed continuous-account experiment and built separate engine.')
