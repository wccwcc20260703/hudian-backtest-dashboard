# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,numpy as np,ast
R=Path.cwd();sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
e=f.e;P=np.load(R/'work/leverage/plans.npz');s=P['D'];signals=[]
for row in s:
 j=np.flatnonzero(row>=0);assert len(j)==1;signals.append([int(j[0]),float(row[j[0]])])
data=dict(dates=e.DATES.tolist(),bars=e.B.tolist(),close=e.C.tolist(),dividend=e.DIV.tolist(),bonus=e.BONUS.tolist(),reference=e.REF.tolist(),stamp=e.STAMP.tolist(),transfer=e.TRANSFER.tolist(),signals={'D':signals})
(R/'work/band_overlay/data.json').write_text(json.dumps(data,separators=(',',':')))
trend=e.Q.close.pct_change(20).shift().reindex(e.DATES);m=(e.SZ/e.SZ.rolling(60).mean()-1).shift().reindex(e.DATES)
ctx=[dict(date=str(d),trend20=None if np.isnan(t) else float(t),marketMA60=None if np.isnan(z) else float(z)) for d,t,z in zip(e.DATES,trend,m)]
(R/'work/band_overlay/context.json').write_text(json.dumps(ctx,separators=(',',':')))
web=json.loads((R/'work/hudian-backtest-dashboard/docs/data.json').read_text());assert signals[e.START:]==web['signals']['D'];assert data['dates'][e.START:]==web['dates']
(R/'work/hudian-backtest-dashboard/docs/research/band-overlay-context.json').write_text(json.dumps(ctx[e.START:],separators=(',',':')))
source=(R/'work/high_winrate/study.py').read_text();ns={'np':np,'pd':f.e.pd};n=next(x for x in ast.parse(source).body if isinstance(x,ast.FunctionDef) and x.name=='choices');exec(ast.get_source_segment(source,n),ns)
(R/'work/band_overlay/band-reference.json').write_text(json.dumps([ns['choices'](b,'band') for b in e.B],separators=(',',':')))
print('Full historical model and lagged contexts reused; 727 web plans match.')
