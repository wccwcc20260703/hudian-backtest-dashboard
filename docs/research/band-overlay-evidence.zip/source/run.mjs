import fs from 'node:fs';import assert from 'node:assert/strict';
import {experimentalBacktest,bandEntries} from '../hudian-backtest-dashboard/docs/experimental-engine.js';
import {financeBacktest} from '../hudian-backtest-dashboard/docs/finance-engine.js';
import {backtest} from '../hudian-backtest-dashboard/docs/engine.js';
import {attribution} from '../hudian-backtest-dashboard/docs/attribution.js';
const read=p=>JSON.parse(fs.readFileSync(p)),out='outputs/band_overlay/',data=read('work/band_overlay/data.json'),context=read('work/band_overlay/context.json'),ref=read('work/band_overlay/band-reference.json'),n=data.dates.length,gates={D:{all_full:Array(n).fill(1)}};
const index=x=>{let i=data.dates.findIndex(d=>d>=x);return i<0?n:i;},begin=index('2023-10-09'),freeze=index('2025-01-01'),cut=index('2026-07-01');
const periods={full:[begin,n],train:[begin,freeze],later:[freeze,cut],julyOn:[cut,n],older:[0,begin]};for(let y=0;y<3;y++)periods['year'+(y+1)]=[index(`${2023+y}-10-09`),index(`${2024+y}-10-09`)];
const run=(account,overlay,a,z,slip=.0005)=>experimentalBacktest(data,gates,a,z,{account,overlay,overlayContext:context,slip});
let parity=0,prefix=0,ledger=0,tripChecks=0;const full={},rows=[],lead=(r,b,a,z)=>{let x=attribution(r,b,data.dates.slice(a,z));delete x.relative;const nav=[r.capital,...r.nav],hold=[b.capital,...b.nav];let yes=0,total=0;for(let k=63;k<nav.length;k++){yes+=nav[k]/nav[k-63]>hold[k]/hold[k-63]?1:0;total++;}return {...x,rolling63Lead:total?yes/total:null};};
const csv=(name,rows)=>{if(!rows.length)return;let keys=Object.keys(rows[0]);fs.writeFileSync(out+name,[keys.join(','),...rows.map(r=>keys.map(k=>JSON.stringify(r[k]??'')).join(','))].join('\n'));};
function audit(r){let cash=r.capital,shares=0;for(let d=r.start;d<r.end;d++){
 const carry=d>r.start?Math.max(0,(Date.parse(data.dates[d])-Date.parse(data.dates[d-1]))/86400000-1):0;let intr=Math.max(-cash,0)*r.config.rate/365*carry;cash-=intr;cash+=shares*data.dividend[d]*.8;if(data.bonus[d]>0)shares=Math.round(shares*(1+data.bonus[d]));let av=shares,maxDebt=Math.max(-cash,0);let same=new Set();
 for(const t of r.trades.filter(t=>t[0]===d)){assert(!same.has(t[1]),'base and T cannot both consume volume at same bar');same.add(t[1]);const gross=t[3]*t[4],fee=Math.max(5,gross*.0001)+gross*(data.transfer[d]+(t[2]<0?data.stamp[d]:0));assert.equal(shares,t[12]);assert.equal(av,t[9]);cash-=t[2]*gross+fee;shares+=t[2]*t[3];if(t[2]<0)av-=t[3];maxDebt=Math.max(maxDebt,-cash);assert.ok(Math.abs(cash-t[6])<1e-6);assert.equal(shares,t[7]);assert.equal(av,t[8]);assert(av>=0&&t[3]<=t[11]);if(t[2]>0){const eq=cash+shares*data.bars[d][t[1]][0];assert.ok(-cash<=(r.account==='D'?0:.5*eq)+1e-6);}ledger++;}
 cash-=maxDebt*r.config.rate/365;assert.ok(Math.abs(cash+shares*data.close[d]-r.nav[d-r.start])<1e-6);
 }
 for(const t of r.trips){const fills=r.trades.filter(x=>x[0]===t.day&&x[16]>0);assert.equal(fills[0][3],t.quantity);assert.equal(fills.slice(1).reduce((s,x)=>s+x[3],0)+t.remaining,t.quantity);const cashflow=fills.reduce((s,x)=>s-x[2]*x[3]*x[4]-x[5],0);assert.ok(Math.abs(cashflow-t.netCash)<1e-6);assert.ok(Math.abs(cashflow+t.side*t.remaining*data.close[t.day]-t.markedNet)<1e-6);tripChecks++;}
}
for(let d=0;d<n;d++){const ent=bandEntries(data.bars[d]);assert.deepEqual(ent,ref[d]);for(const [j,s] of Object.entries(ent)){assert.equal(bandEntries(data.bars[d].slice(0,+j+1))[j],s);prefix++;}}
for(const account of ['D','L'])for(const [period,[a,z]] of Object.entries(periods))for(const slip of [.0005,.001]){
 const b=backtest(data,'B',a,z,{slip});const baseline=account==='L'?financeBacktest(data,gates,a,z,{slip}):backtest(data,'D',a,z,{slip});
 for(const overlay of ['off','all','gated']){
 const r=run(account,overlay,a,z,slip);if(overlay==='off'){for(const key of ['nav','exposure','curve']){assert.deepEqual(r[key],baseline[key],`${account}/${period}/${key}`);parity+=r[key].length;}assert.deepEqual(r.trades.map(t=>t.slice(0,account==='L'?16:14)),baseline.trades);}
 const done=r.trips.filter(t=>t.complete),wins=done.filter(t=>t.netCash>0);let row={account,overlay,period,slip,...r.metrics,...lead(r,b,a,z),trips:r.trips.length,completed:done.length,winRate:done.length?wins.length/done.length:null,tripNet:done.reduce((s,t)=>s+t.netCash,0),unfinished:r.trips.length-done.length,tripMarked:r.trips.reduce((s,t)=>s+t.markedNet,0),fundsBlocks:r.overlayBlocks.funds};rows.push(row);
 if(period==='full'&&slip===.0005){full[account+'_'+overlay]=r;audit(r);}
 }
}
csv('metrics.csv',rows);fs.writeFileSync(out+'metrics.json',JSON.stringify(rows));
for(const [name,r] of Object.entries(full)){csv(name+'_trips.csv',r.trips.map(t=>({...t})));csv(name+'_fills.csv',r.trades.map(t=>({date:data.dates[t[0]],bar:t[1],side:t[2],qty:t[3],price:t[4],fee:t[5],cash:t[6],shares:t[7],available:t[8],beforeShares:t[12],kind:t[16]})));}
// Selection on preceding 252 days, then a SINGLE continuous path across held-out quarters.
const rolling=[];for(const account of ['D','L']){
 const allowed=Array(n).fill(false);for(let y=2025;y<=2026;y++)for(let q=1;q<=4;q++){
 const a=index(`${y}-${String((q-1)*3+1).padStart(2,'0')}-01`);if(a>=n)continue;const z=q===4?index(`${y+1}-01-01`):index(`${y}-${String(q*3+1).padStart(2,'0')}-01`),train=Math.max(0,a-252),base=run(account,'off',train,a);let chosen='off',score=-Infinity;
 for(const overlay of ['off','all','gated']){const r=run(account,overlay,train,a),scoreNow=Math.log1p(r.metrics.return_)/((a-train)/242)-1.5*Math.abs(r.metrics.mdd5);if(Math.abs(r.metrics.mdd5)<=Math.abs(base.metrics.mdd5)+.02&&scoreNow>score){score=scoreNow;chosen=overlay;}}
 for(let d=a;d<z;d++)allowed[d]=chosen==='all'||chosen==='gated'&&context[d].trend20>.05&&context[d].marketMA60>0;
 rolling.push({account,quarter:`${y}Q${q}`,trainThrough:data.dates[a-1],chosen});
 }
 // Convert rolling choice to a causal context gate; before2025 leave overlayoff.
 const ctx=context.map((c,d)=>({...c,trend20:allowed[d]?.1:0,marketMA60:allowed[d]?1:0}));const r=experimentalBacktest(data,gates,begin,n,{account,overlay:'gated',overlayContext:ctx});const b=backtest(data,'B',begin,n);rows.push({account,overlay:'rolling',period:'full',slip:.0005,...r.metrics,...lead(r,b,begin,n),trips:r.trips.length,completed:r.trips.filter(t=>t.complete).length});audit(r);
}
csv('metrics.csv',rows);fs.writeFileSync(out+'metrics.json',JSON.stringify(rows));csv('rolling_choices.csv',rolling);
const verdict={};for(const account of ['D','L'])for(const overlay of ['all','gated']){
 const get=(o,p,s=.0005)=>rows.find(r=>r.account===account&&r.overlay===o&&r.period===p&&r.slip===s),annualWins=[1,2,3].filter(y=>get(overlay,'year'+y).return_>=get('off','year'+y).return_).length;
 verdict[account+'_'+overlay]={annualWins,laterAndJulyBetter:['later','julyOn'].every(p=>get(overlay,p).return_>get('off',p).return_&&Math.abs(get(overlay,p).mdd5)<=Math.abs(get('off',p).mdd5)+.02),olderBetter:get(overlay,'older').return_>=get('off','older').return_,stressBetter:['later','julyOn'].every(p=>get(overlay,p,.001).return_>get('off',p,.001).return_),independentEvidence:false};
}
fs.writeFileSync(out+'audit.json',JSON.stringify({parity,prefix,ledger,tripChecks,verdict,defaultChanged:false},null,2));console.log(JSON.stringify({full:rows.filter(r=>r.period==='full'&&r.slip===.0005).map(r=>({account:r.account,overlay:r.overlay,return:r.return_,mdd:r.mdd5,trips:r.trips,winRate:r.winRate,unfinished:r.unfinished,fundsBlocks:r.fundsBlocks})),verdict,parity,prefix,ledger,tripChecks}));
