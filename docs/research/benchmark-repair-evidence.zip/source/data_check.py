import json,urllib.request,datetime
from pathlib import Path
import pandas as pd
r=Path.cwd();p=r/'work/benchmark_repair';o=r/'outputs/benchmark_repair';receipts=json.loads((o/'source-receipts.json').read_text())
u='https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=sz002463,day,,,800,'
try:
 with urllib.request.urlopen(u,timeout=20) as f:b=f.read()
 (p/'tencent_daily_retry.json').write_bytes(b);j=json.loads(b);receipts['sources'].append({'name':'tencent_daily_blank_adjustment','url':u,'bytes':len(b),'code':j.get('code'),'keys':list(j.get('data',{}).get('sz002463',{}))})
except Exception as e:receipts['sources'].append({'url':u,'error':str(e)})
(o/'source-receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2))
t=json.loads((p/'tencent_m5.json').read_text())['data']['sz002463']['m5'];records=[]
for x in t:records.append({'date':x[0][:4]+'-'+x[0][4:6]+'-'+x[0][6:8],'time':x[0][8:],'open':float(x[1]),'close':float(x[2]),'high':float(x[3]),'low':float(x[4]),'volume':float(x[5])*100})
t=pd.DataFrame(records);d=json.load(open('work/hudian-backtest-dashboard/docs/data.json'));daily={date:vals for date,vals in zip(d['dates'],d['daily'])};bars={date:vals for date,vals in zip(d['dates'],d['bars'])}
f=json.load(open('work/tail_attribution/daily_oct9.json'));v=dict(zip(f['fields'],f['rows'][0]));daily[v['date']]=[float(v[k]) for k in ['open','high','low','close','volume']]
f=json.load(open('work/tail_attribution/minute5_oct9.json'));b=pd.DataFrame(f['rows'],columns=f['fields']);bars['2026-10-09']=b[['open','high','low','close','volume','amount']].astype(float).values.tolist()
res=[]
for date,g in t.groupby('date'):
 if len(g)!=48 or date not in daily:continue
 q=daily[date];ba=bars[date];ag=[g.open.iloc[0],g.high.max(),g.low.min(),g.close.iloc[-1],g.volume.sum()];bg=[ba[0][0],max(v[1] for v in ba),min(v[2] for v in ba),ba[-1][3],sum(v[4] for v in ba)]
 res.append({'date':date,'daily':q,'tencentAggregated':ag,'baostockAggregated':bg,'tencentDailyDiff':[round(x-y,5) for x,y in zip(ag,q)],'baostockDailyDiff':[round(x-y,5) for x,y in zip(bg,q)],'tencentBarCount':48})
a={'checkedAt':datetime.datetime.now().astimezone().isoformat(),'tencentVolumeConversion':'source lots ×100 shares; verified against daily totals below, not assumed transferable to other APIs','comparison':res,'interpretation':'Cross-source evidence only. Does not certify all 3-year intraday data, exact bar alignment, amount/VWAP or historical point-in-time availability.'};(o/'cross-source.json').write_text(json.dumps(a,ensure_ascii=False,indent=2));print(json.dumps({'dailyRequest':receipts['sources'][-1],'comparison':res},ensure_ascii=False))
