import json
from pathlib import Path
p=Path('outputs/benchmark_repair');d=json.load(open('work/hudian-backtest-dashboard/docs/data.json'));rows=[]
for date,b,day in zip(d['dates'],d['bars'],d['daily']):
 agg=[b[0][0],max(x[1] for x in b),min(x[2] for x in b),b[-1][3],sum(x[4] for x in b)];diff=[round(a-c,7) for a,c in zip(agg,day)];flags=[]
 if abs(diff[0])>.011 or abs(diff[3])>.011:flags.append('open_or_close_conflict')
 if abs(diff[1])>.011 or abs(diff[2])>.011:flags.append('intraday_extrema_unconfirmed')
 if abs(diff[4])>1:flags.append('volume_sum_conflict')
 if abs(diff[4])/day[4]>.01:flags.append('volume_difference_above_1pct')
 rows.append({'date':date,'daily':day,'intradayAggregate':agg,'difference':diff,'flags':flags,'exactTouchValidated':False,'researchOnly':True})
(p/'data-quality.json').write_text(json.dumps({'policy':'Record all days; no deletion or invented extrema/volume correction. Lack of a flag does not certify tick-level truth.','days':rows},ensure_ascii=False,indent=2))
print('Stored quality flags for',len(rows),'days')
