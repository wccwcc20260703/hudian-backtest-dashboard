# -*- coding: utf-8 -*-
import json,hashlib,zipfile,re
from pathlib import Path
from datetime import datetime
r=Path.cwd();o=r/'outputs/benchmark_repair';repo=r/'work/hudian-backtest-dashboard';read=lambda p:json.loads(p.read_text());rows=read(o/'comparison.json');cross=read(o/'cross-source.json');daily=read(o/'daily-crosscheck.json');redo=read(o/'redownload-comparison.json');now=datetime.now().astimezone().isoformat();pct=lambda v:f'{v*100:.2f}%'
selected=[x for x in rows if x['start']=='2023-10-09' and x['slip']==.0005]
style=re.search(r'<style>(.*?)</style>',(r/'outputs/strict_audit/report.html').read_text(),re.S).group(1)
parts=['<h1>审查后整改：修复持有基准，核验历史量价</h1>',f'<p>生成时间：{now}。本轮只处理已发现缺陷，不挑选新因子、不替换默认融资方案、不宣称样本外达标。</p>',
'<div class="warning"><b>已完成：持有基准v2已修复并更新看板；默认策略的买卖规则没有改变。</b><p>未完成：五分钟极值与日线不一致的源头机制。近期腾讯五分钟数据出现同样缺口，更换这一个接口不能解决；不能补画极值或据此声称精准触价。</p></div>',
'<h2>1．持有基准从一次短暂尝试，改为持续建仓</h2><p>旧版首日09:35—09:55之后不再补仓，即使资金尚未用完。新版每个可执行五分钟时点继续使用初始本金，必要时跨交易日；单笔仍限上一根成交量1%，执行不利滑点、整手、费用和涨停限制。暂时无量或涨停不能取消后续建仓。待当时剩余初始预算不足一手时结束；剩余现金保留，分红不再投入。买入时当日新增股份不可卖出，基准本身不卖出。</p><p>看板显示首日仓位、建仓结束时间、剩余初始预算。另外展示同起点09:35立即买入的理想全仓参考：允许零股，不计费用、滑点和容量约束，税前分红留现金。它是理论参考，不是成交记录，也不是收益上界；逐步建仓遇到下跌可能买得更便宜。</p>',
'<table><tr><th>初始本金</th><th>旧基准收益</th><th>修复后基准收益</th><th>默认融资收益</th><th>融资累计领先日占比：旧→新</th><th>新基准首日仓位</th></tr>']
for x in selected:parts.append(f'<tr><td>{x["capital"]/10000:g}万元</td><td>{pct(x["legacy"]["return_"])}</td><td>{pct(x["repaired"]["return_"])}</td><td>{pct(x["L"]["return_"])}</td><td>{pct(x["oldAttribution"]["leadFraction"])} → {pct(x["newAttribution"]["leadFraction"])}</td><td>{pct(x["repaired"]["firstDayExposure"])}</td></tr>')
parts.extend(['</table><p>表格统一为2023-10-09至2026-10-08、佣金万1/最低5元、单边5bp。100万元旧基准原本已基本买足，收益423.59%、默认融资1226.51%、各自回撤均未因此改变。1000万元基准在第二个交易日2023-10-10 10:05完成建仓，旧版相对优势明显被夸大。1亿元场景只是极端容量压力，不是建议资金规模。各场景都仍依赖尚未完全核实的历史分钟数据。</p>',
'<h2>2．数据问题已经定位到来源返回，但根本机制仍未解释</h2>',
'<ul><li>新取得腾讯800根日线，其中覆盖既有回测727天；开、高、低、收全部与存量日线一致。日成交量换算成股后最大相差50股，与按整手显示的四舍五入精度相容，不是1%以上的历史分钟量差。</li><li>新取得腾讯320根五分钟数据，其中有六个可比较的完整48根交易日。这六天的聚合OHLC与BaoStock聚合OHLC完全相同，仍缺少日线记录的部分极值。</li><li>重新下载2023-11-14至11-20五个交易日、以及量差最大的2024-09-03，共288根；与存量1728个数值字段完全一致。重复下载未修好四天收盘差异或量差，因此不能归咎于本地拼接或缓存，并不能证明源端统计定义正确。</li></ul>',
'<table><tr><th>日期</th><th>日线最高/最低</th><th>腾讯五分钟汇总</th><th>BaoStock五分钟汇总</th></tr>'])
for x in cross['comparison']:parts.append(f'<tr><td>{x["date"]}</td><td>{x["daily"][1]:.2f} / {x["daily"][2]:.2f}</td><td>{x["tencentAggregated"][1]:.2f} / {x["tencentAggregated"][2]:.2f}</td><td>{x["baostockAggregated"][1]:.2f} / {x["baostockAggregated"][2]:.2f}</td></tr>')
parts.extend(['</table><p>两个接口是否使用共同上游尚不清楚，因此不能把一致性称为两份独立行情认证。五分钟分段边界、采样频率、集合竞价统计均是待核实解释；目前没有足够证据选定其中一个。腾讯五分钟返回没有本次可核实的成交额字段，也不能用它认证VWAP。</p>',
'<p>2026-10-09继续不并入已核验回测。没有用日线高低价伪造分钟触价，也没有按比例改写分钟成交量。历史数据保持原样并保存727天的逐日质量标签；没有异常标签也不代表逐笔行情已认证。看板新增醒目的口径说明，极值和量能研究结论仍待复核。</p>',
'<h2>3．核验覆盖与明确保留的问题</h2><p>预先登记4个起点（2023-10-09、2024-01-02、2025-01-02、2026-07-01）、4种本金（1万/100万/1000万/1亿元）和5/10bp两种滑点，共32组。现金D/H的全部结果对象与改动前逐项一致，融资引擎及信号数据未修改。全套既有测试通过；新增19项合成及历史账本案例，覆盖跨日建仓、涨停后恢复、零量、整手最低费、分红预算隔离等。旧Python快照显式以legacy模式校验，没有把旧基准错误当成新规则验收标准。</p>',
'<p>已在浏览器实际切换至1000万元并运行，显示基准427.87%、默认融资529.08%、累计领先21.6%、基准次日10:05建仓结束；100万元页面仍显示原结果。基准补仓与策略最多5根重试的不同，是买入持有初始指令与主动择时信号的不同有效期；费用、单笔量限制及涨停条件相同。</p>',
'<p>尚未解决：分钟数据真正的采样机制；盘口成交与冲击成本；分红按持股批次和实际税期结算；融资真实券商折算率/额度；S/R与默认模型的分开归因及强弱概率校准。20%、0%的分红税简化仍存在，本轮没有悄悄同时修正这些假设。最新已核验财报沿用此前记录，没有新增独立财务证据。</p>',
'<h2>4．下一步研究顺序</h2><ol><li>先核验五分钟端点/成交量的来源定义与更细粒度数据；如果无法取得可靠免费数据，明确停留在较粗粒度研究，不购买数据、不绕过限制。</li><li>对不依赖极值的固定时点规则，分别测量信号、成交和完整账户风险；数据敏感的支撑触价/VWAP规则在质量问题解除前不能升级默认。</li><li>在已纠正基准下重新评价风险退出与恢复仓位，保留未平仓和单腿损失，避免以合并周期制造高胜率。既有历史仍非新盲测。</li></ol>',
'<h2>来源与留证</h2><p>接口访问时间2026-10-10；来源响应、错误响应、重试参数和时间都包含于证据包。首次腾讯日线请求缺少末尾复权参数返回bad params，补足空参数后成功；没有反复重试失败请求。</p><ul><li><a href="https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=sz002463,day,,,800,">腾讯不复权日线</a></li><li><a href="https://ifzq.gtimg.cn/appstock/app/kline/mkline?param=sz002463,m5,,320">腾讯五分钟行情</a></li><li><a href="https://baostock.com/">BaoStock行情源</a></li></ul><p><a href="benchmark-repair-evidence.zip">下载32组比较、逐日质量标签、原始响应与脚本</a> · <a href="strict-audit.html">上一轮严格审查（当时尚未修复）</a> · <a href="archive.html">研究归档</a></p>'])
page='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>基准修复与历史数据核验</title><style>'+style+'</style><main>'+''.join(parts)+'</main></html>'
(o/'report.html').write_text(page);(repo/'docs/research/benchmark-repair.html').write_text(page)
verify={'at':now,'newTests':19,'fullTestSuitePassed':True,'browserChecks':{'capital1000000':'baseline423.59 default1226.51 unchanged','capital10000000':'baseline427.87 default529.08 lead21.6% completion2023-10-10T10:05'},'dailyOHLCMatched':727,'recentFullMinuteSessions':6,'redownloadBars':288,'changedStoredValues':sum(x['differentStoredValues'] for x in redo),'strategySelectionUnchanged':True,'newBlindTest':False}
(o/'verification.json').write_text(json.dumps(verify,ensure_ascii=False,indent=2))
with zipfile.ZipFile(o/'benchmark-repair-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in o.glob('*.json'):z.write(f,f.name)
 for f in (r/'work/benchmark_repair').glob('*'):
  if f.suffix in ['.py','.mjs','.json']:z.write(f,'source/'+f.name)
 for name in ['benchmark.js','engine.js']:z.write(repo/'docs'/name,'engine/'+name)
 z.write(repo/'tests/benchmark.test.js','tests/benchmark.test.js')
(repo/'docs/research/benchmark-repair-evidence.zip').write_bytes((o/'benchmark-repair-evidence.zip').read_bytes())
p=repo/'docs/research/archive.html';s=p.read_text();needle='<h1>研究归档</h1>';assert 'benchmark-repair.html' not in s;s=s.replace(needle,needle+'<p><a href="benchmark-repair.html">审查后整改：基准持续建仓、32组复算与行情来源核验 ↗</a></p>');p.write_text(s)
print('Report and evidence bundle ready')
