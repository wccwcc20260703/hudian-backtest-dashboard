import baostock as bs,socket,json,signal,datetime
from pathlib import Path
p=Path('work/benchmark_repair');out=[];socket.setdefaulttimeout(10)
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('40s audit request limit')));signal.alarm(40)
try:
 lg=bs.login();assert lg.error_code=='0',lg.error_msg
 for name,a,z in [('minute_close_mismatch','2023-11-14','2023-11-20'),('minute_volume_mismatch','2024-09-03','2024-09-03')]:
  rs=bs.query_history_k_data_plus('sz.002463','date,time,open,high,low,close,volume,amount',start_date=a,end_date=z,frequency='5',adjustflag='3');rows=[]
  while rs.error_code=='0' and rs.next():rows.append(rs.get_row_data())
  (p/(name+'.json')).write_text(json.dumps({'fields':rs.fields,'rows':rows}));out.append({'name':name,'start':a,'end':z,'code':rs.error_code,'rows':len(rows)})
 bs.logout()
except Exception as e:out.append({'error':str(e)})
finally:
 signal.alarm(0);v={'checkedAt':datetime.datetime.now().astimezone().isoformat(),'requests':out};Path('outputs/benchmark_repair/baostock-receipts.json').write_text(json.dumps(v,indent=2));print(json.dumps(v))
