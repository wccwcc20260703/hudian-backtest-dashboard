import urllib.request,json,concurrent.futures,datetime
from pathlib import Path
p=Path('work/benchmark_repair'); urls={'tencent_daily':'https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=sz002463,day,2023-10-09,2026-10-09,800','tencent_m5':'https://ifzq.gtimg.cn/appstock/app/kline/mkline?param=sz002463,m5,,320'}
def get(k,u):
 try:
  with urllib.request.urlopen(u,timeout=20) as f:b=f.read()
  (p/(k+'.json')).write_bytes(b);j=json.loads(b);return {'name':k,'url':u,'bytes':len(b),'code':j.get('code'),'keys':list(j.get('data',{}).get('sz002463',{}))}
 except Exception as e:return {'name':k,'url':u,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:out=list(ex.map(lambda kv:get(*kv),urls.items()))
a={'checkedAt':datetime.datetime.now().astimezone().isoformat(),'sources':out};Path('outputs/benchmark_repair/source-receipts.json').write_text(json.dumps(a,ensure_ascii=False,indent=2));print(json.dumps(a,ensure_ascii=False))
