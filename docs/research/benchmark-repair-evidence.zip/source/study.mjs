import fs from 'node:fs';import assert from 'node:assert/strict';
import {backtest} from '../hudian-backtest-dashboard/docs/engine.js';import {backtest as old} from './old-engine.mjs';
import {financeBacktest} from '../hudian-backtest-dashboard/docs/finance-engine.js';import {attribution} from '../hudian-backtest-dashboard/docs/attribution.js';
const read=p=>JSON.parse(fs.readFileSync(p)),d=read('work/risk_priority/data.json'),g=read('work/risk_priority/gates.json');const out='outputs/benchmark_repair/';
const starts=['2023-10-09','2024-01-02','2025-01-02','2026-07-01'];fs.writeFileSync(out+'plan.json',JSON.stringify({createdAt:new Date().toISOString(),question:'Repair benchmark initial allocation; evaluate effect on comparison without modifying strategy signals.',starts,capitals:[1e4,1e6,1e7,1e8],slip:[.0005,.001],rules:'Initial funds only, persistent eligible5m retry; same fees/limits/priorvolume cap. Cash dividends not reinvested. End when cash budget cannot afford one100sharelot. Ideal reference ignores costs/capacity, fractional shares, same09:35start. Legacy retained for version comparison.',knownHistory:true,noParameterSearch:true},null,2));
let parity=0;const rows=[];
for(const date of starts)for(const capital of [1e4,1e6,1e7,1e8])for(const slip of [.0005,.001]){
 const a=d.dates.findIndex(x=>x>=date),z=d.dates.length,opts={capital,slip};const b0=old(d,'B',a,z,opts),b=backtest(d,'B',a,z,opts),ideal=backtest(d,'B',a,z,{...opts,benchmarkMode:'ideal'});
 const dr=backtest(d,'D',a,z,opts),lr=financeBacktest(d,g,a,z,{...opts,base:'D',gate:'all_full',level:1.5});
 for(const model of ['D','H']){const x=backtest(d,model,a,z,opts),y=old(d,model,a,z,opts);assert.deepEqual(x,y);parity+=x.nav.length+x.curve.length+x.trades.length;}
 rows.push({start:date,end:d.dates.at(-1),capital,slip,legacy:{...b0.metrics,firstDayExposure:b0.exposure[0]},repaired:{...b.metrics,...b.benchmark},ideal:{...ideal.metrics},D:{...dr.metrics},L:{...lr.metrics},oldAttribution:attribution(lr,b0,d.dates.slice(a,z)),newAttribution:attribution(lr,b,d.dates.slice(a,z))});
}
fs.writeFileSync(out+'comparison.json',JSON.stringify(rows,null,2));fs.writeFileSync(out+'strategy-parity.json',JSON.stringify({scenarios:rows.length,cashDHAllResultObjectsExact:true,valuesAtLeast:parity,financeEngineUnchanged:true,sourceSnapshotsUnchanged:true},null,2));
console.log(JSON.stringify(rows.filter(r=>r.start===starts[0]&&r.slip===.0005).map(r=>({capital:r.capital,old:r.legacy.return_,new:r.repaired.return_,ideal:r.ideal.return_,oldFirst:r.legacy.firstDayExposure,newFirst:r.repaired.firstDayExposure,completion:r.repaired.completion,L:r.L.return_,oldLead:r.oldAttribution.leadFraction,newLead:r.newAttribution.leadFraction})),null,2));
