from pathlib import Path
import sys,json
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/chase_guard';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
e=f.e;P=np.load(R/'work/leverage/plans.npz');new=np.load(R/'work/chase_guard/plans.npz');checks=0

def decision(b,j):
 h=b[:j];last=h[-1,3];op=h[0,0]
 return bool(last>=op*1.02) if j==6 else bool(h[:,3].max()>=op*1.02 and last<=h[:,3].max()*.99 and last<h[:,5].sum()/h[:,4].sum())
for d in range(e.N):
 if P['D'][d].max()!=1:continue
 flags={j:decision(e.B[d],j) for j in [6,9,12]}
 for j in [6,9,12]:
  bad=e.B[d].copy();bad[j:]*=1000;assert decision(bad,j)==flags[j];assert decision(e.B[d,:j],j)==flags[j];checks+=1
 for base,key in [('D','D'),('L','D_all_full_1.5')]:
  for name in ['skip_chase','fade','combined']:
   expected=P[key][d].copy()
   if flags[6] and name!='fade':expected[6]=-1
   if name!='skip_chase':
    for j in [9,12]:
     if flags[j]:expected[j]=.5;break
   assert np.array_equal(expected,new[base+'_'+name][d])
# Compare old known baseline metrics independently to last completed batch.
old=pd.read_csv(R/'outputs/support_factors/metrics.csv').set_index(['name','period']);m=pd.read_csv(O/'metrics.csv').set_index(['name','period']);parity=0
for name in ['D_base','L_base']:
 for period in ['full','train','validation','recent','older','year1','year2','year3']:
  for k in ['return_','mdd5','orders','fees']:assert abs(old.loc[(name,period),k]-m.loc[(name,period),k])<1e-7;parity+=1
out=dict(fullDecisionPrefixChecks=checks,baselineMetricsParity=parity,oct8={j:decision(e.B[-1],j) for j in [6,9,12]},note='Rules examine completed closes not vendor disputed high/low; Oct8 known motivating example, no independent validation.')
(O/'additional_audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
daily=pd.read_csv(O/'daily.csv');episodes=[]
for name,df in daily.groupby('name'):
 held=df.exposure.to_numpy()>1e-12;starts=np.flatnonzero(held&~np.r_[False,held[:-1]]);ends=np.flatnonzero(~held&np.r_[False,held[:-1]]);nav=np.r_[1e6,df.nav.to_numpy()];wins=[]
 for a in starts:
  nextend=ends[ends>a]
  if not len(nextend):continue
  z=nextend[0];ret=nav[z+1]/nav[a]-1;wins.append(ret);episodes.append(dict(name=name,start=df.iloc[a].date,end=df.iloc[z].date,netReturn=ret))
 assert len(wins)==int(m.loc[(name,'full'),'episodeCount'])
 assert abs(np.mean(np.array(wins)>0)-m.loc[(name,'full'),'episodeWinRate'])<1e-12
pd.DataFrame(episodes).to_csv(O/'closed_episodes.csv',index=False);out['independentEpisodeChecks']=len(episodes);(O/'additional_audit.json').write_text(json.dumps(out,indent=2));print('Verified completedepisodes',len(episodes))
