from pathlib import Path
W=Path('work/combo_exit');s=Path('work/combo_trend/finance_hold.mjs').read_text()
s=s.replace('holdSessions=20}={})','holdSessions=20,exitContext=null}={})').replace('let firstBuyDay=null;','let firstBuyDay=null,floor=null,exitLatched=false,blockedThrough=-1;')
s=s.replace('if(entryMask&&shares===0)firstBuyDay=null;', '''if(entryMask&&shares===0){firstBuyDay=null;floor=null;exitLatched=false;}
  if(exitContext&&shares>0&&exitContext.previousClose[d]<floor)exitLatched=true;''')
s=s.replace('d>=firstBuyDay+holdSessions?[6,0]','(d>=firstBuyDay+holdSessions||exitLatched)?[6,0]').replace('(entryMask[d]?[6,1]', '(entryMask[d]&&d>blockedThrough?[6,1]')
s=s.replace('if(entryMask&&side>0&&firstBuyDay===null)firstBuyDay=d;', 'if(entryMask&&side>0&&firstBuyDay===null){firstBuyDay=d;if(exitContext){floor=exitContext.priorLow[d];blockedThrough=d+holdSessions;}}')
(W/'finance_exit.mjs').write_text(s)
s=Path('work/combo_trend/run.mjs').read_text().replace("'./finance_hold.mjs'","'./finance_exit.mjs'").replace("O='outputs/combo_trend/'","O='outputs/combo_exit/'").replace("read('outputs/regime_policy/metrics.json')","read('outputs/combo_trend/metrics.json')").replace("['B','D','L','F50','UC','UL','TC','TL','MC','ML']","['B','D','L','UC','UL','XC','XL']").replace('holdSessions:20});','holdSessions:20,exitContext:name.startsWith(\'X\')?masks:null});')
s=s.replace("if(['B','D','L','F50'].includes(name)){","if(['B','D','L','UC','UL'].includes(name)){")
start=s.index('   }else{\n    let first=null;');end=s.index("   if(period==='full'",start)
s=s[:start]+'''   }
   if(name.length===2){
    let first=null,floor=null,latched=false,blocked=-1;const ctx=name.startsWith('X');const byday=new Map();for(const t of r.trades){if(!byday.has(t[0]))byday.set(t[0],[]);byday.get(t[0]).push(t);}
    for(let day=a;day<z;day++){
     const atStart=day===a?0:r.daily[day-a-1].shares;
     if(!atStart){first=null;floor=null;latched=false;}
     if(ctx&&atStart&&masks.previousClose[day]<floor)latched=true;
     const expected=atStart?((day>=first+20||latched)?[6,0]:[-1,-1]):masks[name[0]][day]&&day>blocked?[6,name.endsWith('L')?1.5:1]:[-1,-1];assert.deepEqual(r.targets[day-a],expected);
     for(const t of byday.get(day)||[]){
      if(t[2]>0){assert(masks[name[0]][day]);assert(first===null||first===day);if(first===null){first=day;if(ctx){floor=masks.priorLow[day];blocked=day+20;}}}
      else if(!t[15])assert(day>=first+20||latched);holdChecks++;
     }
    }
   }
''' +s[end:]
s=s.replace('assert.equal(rows.length,320)','assert.equal(rows.length,224)');(W/'run.mjs').write_text(s)
print('Exit engine and224account runner generated')
