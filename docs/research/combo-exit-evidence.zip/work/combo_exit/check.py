# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
import json,hashlib
import pandas as pd
R=Path.cwd();O=R/'outputs/combo_exit';m=pd.read_json(O/'metrics.json');ep=pd.read_json(O/'episodes.json');d=pd.read_json(O/'daily.json');a=json.loads((O/'audit.json').read_text())
for p,sha in json.loads((O/'manifest.json').read_text()).items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==sha,p
for x in m[(m.period=='full')&(m.slip==.0005)].itertuples():
 e=ep[(ep.stock==x.stock)&(ep.name==x.name)];c=e[e.complete];v=d[(d.stock==x.stock)&(d.name==x.name)]
 assert len(c)==x.closedEpisodes and(c.pnl>0).sum()==x.episodeWins;assert abs(e.pnl.sum()-x.return_*1e6)<.01
 assert abs((1+v.return_).prod()-1-x.return_)<1e-9
for stock in ['hudian','shenghong']:
 ctx=json.loads((O/f'{stock}-masks.json').read_text());states=dict(zip(ctx['dates'],ctx['MA3']));mask=ep.stock==stock
 ep.loc[mask,'entryState']=ep.loc[mask,'start'].map(states)
closed=ep[ep.complete&ep.name.isin(['UC','UL','XC','XL'])]
branches=closed.groupby(['stock','name','entryState']).agg(n=('pnl','size'),wins=('pnl',lambda x:int((x>0).sum())),meanReturn=('return_','mean'),meanDays=('days','mean')).reset_index();branches['winRate']=branches.wins/branches.n
paired=[]
for stock in ['hudian','shenghong']:
 for cash,stop in [('UC','XC'),('UL','XL')]:
  u=closed[(closed.stock==stock)&(closed.name==cash)];x=closed[(closed.stock==stock)&(closed.name==stop)];z=x.merge(u,on=['stock','start'],suffixes=('_x','_u'))
  for row in z.itertuples():
   paired.append({'stock':stock,'name':stop,'start':row.start,'entryState':row.entryState_x,'exitX':row.end_x,'exitU':row.end_u,'earlierExit':row.end_x<row.end_u,'returnX':row.return__x,'returnU':row.return__u,'difference':row.return__x-row.return__u})
for k,df in [('metrics',m),('episodes',ep),('daily',d),('branches',branches),('paired',pd.DataFrame(paired)),('quarters',pd.read_json(O/'quarters.json'))]:df.to_csv(O/(k+'.csv'),index=False)
a.update({'episodeReconciliations':14,'strictPriorDayChecks':3274,'manifestMatches':True});(O/'audit.json').write_text(json.dumps(a,indent=2))
f=json.loads((O/'freshness.json').read_text());calendar=json.loads((O/'plan-before-results.json').read_text())['calendar'];f['calendar']=calendar
if (R/'work/combo_exit/daily_oct9.json').exists()and(R/'work/combo_exit/minute5_oct9.json').exists():
 dj=json.loads((R/'work/combo_exit/daily_oct9.json').read_text());mj=json.loads((R/'work/combo_exit/minute5_oct9.json').read_text());day=pd.DataFrame(dj['rows'],columns=dj['fields']);mi=pd.DataFrame(mj['rows'],columns=mj['fields'])
 if len(day)==1 and len(mi):
  f['extremaCheck']={'dailyHigh':float(day.high.iloc[0]),'minuteHigh':float(mi.high.astype(float).max()),'dailyLow':float(day.low.iloc[0]),'minuteLow':float(mi.low.astype(float).min()),'dailyClose':float(day.close.iloc[0]),'minuteClose':float(mi.close.iloc[-1]),'dailyVolume':float(day.volume.iloc[0]),'minuteVolumeSum':float(mi.volume.astype(float).sum())};v=f['extremaCheck'];f['extremaMatch']=abs(v['dailyHigh']-v['minuteHigh'])<.005 and abs(v['dailyLow']-v['minuteLow'])<.005
f['certifiedThrough']='2026-10-08';f['executableNewPlans']='paused pending Oct9 reconciliation and calendar-aligned context';f['quarter3GrowthNote']='0rows means unavailable in source, not zero growth or proof of no disclosure';(O/'freshness.json').write_text(json.dumps(f,ensure_ascii=False,indent=2))
print('AUDIT',a);print('FRESHNESS',f)
print(m[(m.period.isin(['full','older']))&(m.slip==.0005)][['stock','name','period','return_','mdd5','episodeWinRate','episodeWins','closedEpisodes','exposure','worst5pctDayMean']].round(4).to_string(index=False));print(branches.round(4).to_string(index=False));print(pd.DataFrame(paired).query('earlierExit').groupby(['stock','name']).difference.agg(['count','mean',lambda x:(x>0).sum()]).to_string())
