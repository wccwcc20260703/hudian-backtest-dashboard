import assert from 'node:assert/strict';
import {financeBacktest} from './finance_exit.mjs';
const n=30,day0=Date.parse('2026-01-01'),d={dates:Array.from({length:n},(_,i)=>new Date(day0+i*86400000).toISOString().slice(0,10)),bars:Array.from({length:n},()=>Array.from({length:48},()=>[10,10,10,10,20000,200000])),close:Array(n).fill(10),dividend:Array(n).fill(0),bonus:Array(n).fill(0),reference:Array(n).fill(10),stamp:Array(n).fill(.0005),transfer:Array(n).fill(.00001),signals:{D:Array.from({length:n},()=>[6,1])}};
const g={D:{all_full:Array(n).fill(1)}},mask=Array(n).fill(true),ctx={priorLow:Array(n).fill(9.5),previousClose:Array(n).fill(10)};ctx.previousClose[5]=9.4;
const r=financeBacktest(d,g,0,n,{entryMask:mask,exitContext:ctx,level:1,rate:0});assert(r.trades.filter(t=>t[2]<0).every(t=>t[0]===5));assert(r.daily.slice(5,21).every(x=>x.shares===0));assert(r.daily[21].shares>0);
const partial=structuredClone(d);partial.bars[5].forEach(b=>b[4]=10000);const p=financeBacktest(partial,g,0,n,{entryMask:mask,exitContext:ctx,level:1,rate:0});assert(p.daily[5].shares>0);assert.equal(p.daily[6].shares,0);assert(p.trades.some(t=>t[0]===6&&t[2]<0));
console.log('PASS causal nextday exit; no reentry throughoriginalwindow; exit latched despite subsequent recovery and partial fill.');
