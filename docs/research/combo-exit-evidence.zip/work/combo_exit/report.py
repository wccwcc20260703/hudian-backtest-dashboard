# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
import json,html,zipfile,shutil
import pandas as pd
R=Path.cwd();O=R/'outputs/combo_exit';repo=R/'work/hudian-backtest-dashboard';m=pd.read_json(O/'metrics.json');b=pd.read_csv(O/'branches.csv');p=pd.read_csv(O/'paired.csv');a=json.loads((O/'audit.json').read_text());f=json.loads((O/'freshness.json').read_text());a['syntheticExitChecks']='PASS: nextday causal exit, cooldown throughoriginalwindow, partialfill exit latching';(O/'audit.json').write_text(json.dumps(a,indent=2))
pct=lambda x:'—'if pd.isna(x)else f'{x*100:.2f}%';stocks={'hudian':'沪电','shenghong':'胜宏'};names={'B':'全仓持有','D':'原D现金','L':'原L融资默认','UC':'U原组合现金','UL':'U原组合融资','XC':'X跌破低点退出现金','XL':'X跌破低点退出融资'}
def table(head,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>'for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>'for x in row)+'</tr>'for row in rows)+'</tbody></table></div>'
def wins(x):return f'{x.episodeWins}/{x.closedEpisodes} · '+pct(x.episodeWinRate)if x.closedEpisodes else '无已结束周期'
body='''<nav><a href="../index.html">← 看板</a> · <a href="archive.html">研究归档</a></nav><h1>跌破买入前一日低点，提前退出是否更好？</h1><p>224组完整账户 · 只修改退出处理 · 趋势延续／下行反弹分别诊断 · 默认保持不变</p>
<section><h2>结论：这个简单失效标准未通过沪电检验</h2><p>沪电近三年现金完整周期胜率从13/20＝65.00%降至6/21＝28.57%；最大回撤从25.12%扩大到27.72%，累计净收益从+257.46%降至+6.83%。融资胜率同样下降至28.57%，回撤从30.46%扩大到39.46%。它不是因收益略降被淘汰，而是胜率与回撤都未改善。</p><p>胜宏近期回撤下降，但胜率也下降；更早沪电亏损加重。两类入场分支均未形成可直接采用的优势。此次否定的是这条具体退出＋等待规则，不能推出所有止损都无用，也不能推出下跌后应该一直持有。</p></section>
<section><h2>本轮固定规则</h2><p>入场不变：前一日MA3处于上行或下行，且5日均量不低于20日均量，空仓时10:00尝试入场。MA3为此前固定的MA20/60方向、MA20五日斜率及3日确认。现金目标100%，融资目标150%；同日建仓最多5根5分钟K线，之后不加仓。</p><p>原U：首次实际模拟买入后持有20个交易日，第21日10:00开始清仓。新X：在首次买入时固定<strong>买入前一天的已完成日线最低价</strong>；如果之后某个已完成交易日收盘低于该价，次日10:00尝试提前清仓。清仓指令持续到完成，不因下一天反弹撤销。提前卖出后，等原20日持有窗口及原计划退出日结束，下一日才能再次入场。</p><p>这样不会用当天最终收盘价在当天提前成交，也不会刚止损就马上重复买回。本轮评估包含这条等待规则的机会成本，不把结果单独归因于低点门槛。维持担保比例风控继续保留，持有期间被动超过150%不自动减仓。期末未平仓按市值计入，不伪造平仓。</p><p>低点与后续收盘使用同一复权口径比较；指标来自严格历史前缀，但仍受当前版本复权序列限制。两只股票没有分别调参数，全部历史已见过，不是新盲测。这里不是日内做T。</p></section>
<section><h2>近三年账户，单边5基点滑点</h2>'''
v=m[(m.period=='full')&(m.slip==.0005)]
body+=table(['股票／账户','净收益','最大回撤','完整周期盈利／总数','平均实际仓位','盈利日占全部日','最差5%日均收益','未平仓损益（元）'],[[stocks[x.stock]+'／'+names[x.name],pct(x.return_),pct(-x.mdd5),wins(x),pct(x.exposure),pct(x.winningDayFraction),pct(x.worst5pctDayMean),f'{x.openEpisodeMarked:,.2f}']for x in v.itertuples()])
body+='''<p>新X减少了持仓时间，最差5%日收益的均值有所缓和，但频繁提前确认亏损、错过修复，可使账户最大回撤反而扩大。较小的日尾部亏损与较低的完整周期胜率可以同时发生，必须看整个净值路径。</p><p>全仓持有没有已完成清仓周期，胜率不写成0%或100%。空仓和平盘不算盈利日；未平仓损益已包含在净值、总收益与回撤中。胜率分母是完整持仓周期，不是买卖委托数或未来上涨日期。</p></section>
<section><h2>分开看趋势延续和下行反弹</h2>'''
body+=table(['股票／账户','建仓时分支','盈利／完整周期','周期胜率','平均周期收益','平均交易日数'],[[stocks[x.stock]+'／'+names[x.name],'下行反弹'if x.entryState==0 else '趋势延续',f'{x.wins}/{x.n}',pct(x.winRate),pct(x.meanReturn),f'{x.meanDays:.1f}']for x in b.itertuples()])
body+='''<p>沪电现金反弹分支从4/5＝80%变成2/5＝40%；趋势延续分支从9/15＝60%变成4/16＝25%。原反弹分支只有5个完整周期，不能称稳定80%。分类依据建仓当天之前已知的MA3，不是按最终盈亏或最高最低点重分。</p></section>
<section><h2>提前退出的配对代价</h2>'''
rows=[]
for (stock,name),v in p[p.earlierExit].groupby(['stock','name']):rows.append([stocks[stock]+'／'+names[name],len(v),int((v.difference>0).sum()),int((v.difference<0).sum()),pct(v.difference.mean())])
body+=table(['股票／新规则','同日建仓且提前退出配对数','提前退出改善','提前退出变差','周期净收益率差均值'],rows)
body+='''<p>沪电现金15个配对中，5个改善、10个变差，周期收益率差平均−8.83个百分点；融资16个中6个改善、10个变差，平均−11.04个百分点。胜宏改善与变差更接近，仍没有稳定优势。</p><p>只配对同股票、同实际建仓日、两边均完整结束且X更早退出的周期；不把未结束或不匹配周期硬配对。不同账户此前资本和成交量约束可能不同，因此这是账户轨迹诊断，不是完全相同资本的独立事件试验。不能把均值差直接乘以总本金作为损益。</p></section>
<section><h2>年度、更早行情与滑点压力</h2>'''
v=m[m.period.isin(['older','year1','year2','year3'])&(m.slip==.0005)&m.name.isin(['UC','UL','XC','XL'])]
body+=table(['股票／时期／账户','净收益','最大回撤','完整周期盈利／总数','平均仓位'],[[stocks[x.stock]+'／'+x.period+'／'+names[x.name],pct(x.return_),pct(-x.mdd5),wins(x),pct(x.exposure)]for x in v.itertuples()])
body+='''<p>older＝2020-01-02至2023-09-28；年度1／2／3从2023／2024／2025年10月9日起各一年。各分段独立从100万元开始，不能相加或拼接成三年账户。更早沪电X现金回撤62.19%，高于U的49.43%，也没有跨时期稳定减险证据。</p>'''
v=m[(m.period=='full')&(m.slip==.001)&m.name.isin(['UC','UL','XC','XL'])]
body+=table(['股票／账户：单边10基点','净收益','最大回撤','周期胜率'],[[stocks[x.stock]+'／'+names[x.name],pct(x.return_),pct(-x.mdd5),wins(x)]for x in v.itertuples()])
body+='</section><section><h2>7月前后及持续领先</h2>'
v=m[(m.period=='full')&(m.slip==.0005)&m.name.isin(['UC','UL','XC','XL','B'])]
body+=table(['股票／账户','6月30日前收益','7月起承接持仓收益','累计领先持有日占比','最长落后交易日','滚动63日领先占比'],[[stocks[x.stock]+'／'+names[x.name],pct(x.preJuly),pct(x.postJuly),'基准'if x.name=='B'else pct(x.leadFraction),'—'if x.name=='B'else x.longestBehind,'—'if x.name=='B'else pct(x.rolling63Lead)]for x in v.itertuples()])
body+='''<p>本表用三年连续账户，7月不重新建仓；滚动窗口相互重叠，不能当成独立试验。完整early/later/July独立分段、各季度数据都保存在证据包，没有只选有利区间展示。</p></section>
<section><h2>今日时效核验及执行审计</h2><p>10月10日是周末休市，依据<a href="https://investor.szse.cn/disclosure/notice/general/t20260917_622911.html">深交所通知</a>，不生成今天的盘后交易报告。本次重新获取10月9日1行日线、48根5分钟线，两者收盘112.29及总成交量一致，但日线最高113.50／最低106.31，分钟最高113.14／最低106.38，仍无法对齐。因此本轮历史仍截止10月8日，10月9日不补造模拟成交。</p><p>2026年三季报增长接口返回0行，表示该来源未提供可用记录，不代表增长为0，也不能证明没有任何新公告。本轮没有可靠的新财务输入。现有实时信号代码在行情日期不是北京时间今日时会暂停计划；不把10月9日的历史回看当作10月10日可执行信号。</p>'''
body+=f'<p>审计：{a["strictPriorDayChecks"]:,}个日期核验昨日低点和昨日收盘；{a["ledger"]:,}笔成交重建资金、费用、T+1和成交量约束；{a["loanChecks"]:,}次买入校验融资上限；{a["accountDays"]:,}个账户日资产核对；800个原指标复算一致。合成测试核验次日退出、冷却期以及部分成交后保持退出指令。</p>'
body+='''<p>费用为股票万1、每笔最低5元，按日期计印花税及过户费，融资年息6%；保留100股买入、前一根5分钟成交量1%、单笔30万股上限、T+1和涨跌停限制。每笔融资买入后欠款不超过当前净资产50%。分红税简化口径及历史融资资格、额度和财报版本未经逐日核验的限制不变。回撤按5分钟收盘估计，非逐笔最坏损失。</p><p>本轮不替换默认，不宣称旧收益目标达标，不是真实交易。已保存明确失败记录：后续不要重复调同一低点退出门槛来追逐历史赢家。下一步先诊断“跌破后延续”与“跌破后迅速收复”的当时可知差别，再决定是否值得另行冻结一个退出确认条件。</p><p><a href="combo-exit-evidence.zip">下载固定计划、224组结果、分支／配对诊断、逐笔账本、数据时效和脚本</a> · <a href="combo-trend.html">上一轮入场趋势过滤</a></p></section>'''
style='body{font:16px/1.8 system-ui,sans-serif;color:#1b304a;background:#f3f6fa;margin:0}main{max-width:1280px;margin:30px auto;padding:20px}section{background:white;border:1px solid #dce5ee;border-radius:14px;padding:26px;margin:22px 0}h1{font-size:30px}h2{font-size:22px}a{color:#147f85}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:11px;white-space:nowrap;text-align:left;border-bottom:1px solid #e2eaf1}th{background:#f4f7fa}'
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>低点失效退出检验｜沪电研究</title><style>'+style+'</style></head><body><main>'+body+'</main></body></html>'
(O/'report.html').write_text(page);(repo/'docs/research/combo-exit.html').write_text(page)
ar=repo/'docs/research/archive.html';v=ar.read_text();link='<p><a href="combo-exit.html">跌破前一日低点就退出：224组账户、反弹错失与分支失败诊断 ↗</a></p>'
if 'href="combo-exit.html"'not in v:ar.write_text(v.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+link))
(O/'README.txt').write_text('Reproduce in fresh workspace using pandas/numpy Node: prepare.py -> build_runner.py -> node run.mjs -> node engine-check.mjs -> check.py -> report.py. Prepare refuses to overwrite frozen plan. check_freshness.py fetches external data separately and must not silently replace frozen history. Original default unchanged. No same-day T win claim.\n')
inputs=list(json.loads((O/'manifest.json').read_text()))+['work/shenghong/finance.mjs','work/shenghong/benchmark.mjs','work/opening_guard/metrics.mjs','work/hudian-backtest-dashboard/docs/fees.js','work/hudian-backtest-dashboard/docs/attribution.js']
with zipfile.ZipFile(O/'evidence.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in list(O.iterdir())+list((R/'work/combo_exit').iterdir())+[R/p for p in inputs]:
  if p.is_file()and p.name not in ['evidence.zip','publication.json','deployment.log']:z.write(p,str(p.relative_to(R)))
shutil.copyfile(O/'evidence.zip',repo/'docs/research/combo-exit-evidence.zip')
cp=R/'work/research-checkpoint.json';c=json.loads(cp.read_text());now=datetime.now().astimezone().isoformat();c['comboExit']={'updatedAt':now,'outputs':'outputs/combo_exit','status':'verified locally, publication pending','audit':a,'freshness':f,'finding':'Priorentrydaylow fixedfloor nextdayexit+waitoriginalwindow fails H: cash cycle65to28.57%,DD25.12to27.72,return257.46to6.83; marginDD30.46to39.46. Hmatchedearlyexits cash5/15improve; bothbranchesworse. ShDDimproves butwinsfall; earlierHDD62.19. No defaultchange.','nextQuestion':'Diagnose causal differences between breakdown continuation and prompt recovery before preregistering another exit. No repeated thresholdsearch of this failed priorlow rule.','defaultChanged':False,'newBlindTest':False};c['updatedAt']=now;cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print('Saved report/evidence/checkpoint; bytes', (O/'evidence.zip').stat().st_size)
