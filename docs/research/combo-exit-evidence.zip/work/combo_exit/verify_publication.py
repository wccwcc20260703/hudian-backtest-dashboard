# -*- coding: utf-8 -*-
from pathlib import Path
import urllib.request,hashlib,json,subprocess
from datetime import datetime
r=Path.cwd();repo=r/'work/hudian-backtest-dashboard';sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();files=[]
for path in ['research/combo-exit.html','research/combo-exit-evidence.zip','research/archive.html']:
 url='https://wccwcc20260703.github.io/hudian-backtest-dashboard/'+path+'?v='+sha[:12]
 with urllib.request.urlopen(url,timeout=25) as response:b=response.read()
 local=(repo/'docs'/path).read_bytes();assert b==local,path
 files.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
a={'commit':sha,'verifiedAt':datetime.now().astimezone().isoformat(),'files':files,'url':'https://wccwcc20260703.github.io/hudian-backtest-dashboard/research/combo-exit.html?v='+sha[:12]}
(r/'outputs/combo_exit/publication.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
p=r/'work/research-checkpoint.json';c=json.loads(p.read_text());c['comboExit']['publication']=a;c['comboExit']['status']='published and remote verified';c['latestPublishedCommit']=sha;c['updatedAt']=a['verifiedAt'];p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print(json.dumps(a,ensure_ascii=False))
