from pathlib import Path
w=Path('work/combo_trend');src=Path('work/shenghong/finance.mjs').read_text()
src=src.replace('maintenance=1.5}={})','maintenance=1.5,entryMask=null,holdSessions=20}={})')
src=src.replace('const nav=[],','let firstBuyDay=null;\n const nav=[],',1)
src=src.replace('const orig=data.signals[base][d],plan=',"if(entryMask&&shares===0)firstBuyDay=null;\n  const orig=entryMask?(shares>0?(d>=firstBuyDay+holdSessions?[6,0]:[-1,-1]):(entryMask[d]?[6,1]:[-1,-1])):data.signals[base][d],plan=")
src=src.replace('const gross=qty*fill,fee=', 'if(entryMask&&side>0&&firstBuyDay===null)firstBuyDay=d;\n       const gross=qty*fill,fee=')
src=src.replace('tol=target>=1?.004:.035','tol=entryMask&&target===0?0:target>=1?.004:.035')
(w/'finance_hold.mjs').write_text(src)
old=Path('work/regime_policy/run.mjs').read_text();audit=old[old.index(' function audit(r){'):old.index(' for(const [period,[a,z]]')]
# Retain independently reconstructed ledger and relative statistics unchanged.
head="""import fs from 'node:fs';
import assert from 'node:assert/strict';
import {financeBacktest} from './finance_hold.mjs';
import {financeBacktest as originalEngine} from '../shenghong/finance.mjs';
import {holdBenchmark} from '../shenghong/benchmark.mjs';
import {stats} from '../opening_guard/metrics.mjs';
import {attribution} from '../hudian-backtest-dashboard/docs/attribution.js';
const read=p=>JSON.parse(fs.readFileSync(p)),O='outputs/combo_trend/',rows=[],daily=[],episodes=[],quarters=[];
const baseline=read('outputs/regime_policy/metrics.json');let parity=0,ledger=0,loan=0,accountDays=0,holdChecks=0;
const names=['B','D','L','F50','UC','UL','TC','TL','MC','ML'];
for(const [stock,path] of [['hudian','work/risk_priority/data.json'],['shenghong','work/shenghong/data.json']]){
 const d=read(path),masks=read(O+stock+'-masks.json');assert.deepEqual(masks.dates,d.dates);const n=d.dates.length,main=d.dates.indexOf('2023-10-09');
 const idx=s=>{const i=d.dates.findIndex(x=>x>=s);return i<0?n:i},g={D:{all_full:Array(n).fill(1)}};
 const periods={full:[main,n],older:[0,main],early:[main,idx('2025-01-01')],later:[idx('2025-01-01'),idx('2026-07-01')],julyOn:[idx('2026-07-01'),n]};
 for(let y=0;y<3;y++)periods['year'+(y+1)]=[idx(`${2023+y}-10-09`),idx(`${2024+y}-10-09`)];
 const run=(name,a,z,slip)=>name==='B'?holdBenchmark(d,a,z,{slip}):financeBacktest(name==='F50'?{...d,signals:{D:d.dates.map(()=>[6,.5])}}:d,g,a,z,{slip,level:name==='L'||name.endsWith('L')?1.5:1,rate:name==='L'||name.endsWith('L')?.06:0,entryMask:name.length===2?masks[name[0]]:null,holdSessions:20});
"""
tail="""
 for(const [period,[a,z]] of Object.entries(periods))for(const slip of [.0005,.001]){
  const rr=Object.fromEntries(names.map(name=>[name,run(name,a,z,slip)]));
  for(const [name,r]of Object.entries(rr)){
   const row={stock,name,period,slip,...r.metrics,...stats(r),tradeDays:new Set(r.trades.map(t=>t[0])).size,...relative(r,rr.B)};rows.push(row);audit(r);
   if(['B','D','L','F50'].includes(name)){
    const b=baseline.find(x=>x.stock===stock&&x.name===name&&x.period===period&&x.slip===slip);
    for(const k of ['return_','mdd5','exposure','fees','interest']){assert(Math.abs((row[k]??0)-(b[k]??0))<1e-9,[stock,name,period,k]);parity++;}
    if(name==='L')assert.deepEqual(r,originalEngine(d,g,a,z,{slip}));
   }else{
    let first=null;const byday=new Map();for(const t of r.trades){if(!byday.has(t[0]))byday.set(t[0],[]);byday.get(t[0]).push(t);}
    for(let day=a;day<z;day++){
     const atStart=day===a?0:r.daily[day-a-1].shares;if(!atStart)first=null;
     const expected=atStart?(day>=first+20?[6,0]:[-1,-1]):masks[name[0]][day]?[6,name.endsWith('L')?1.5:1]:[-1,-1];assert.deepEqual(r.targets[day-a],expected);
     for(const t of byday.get(day)||[]){if(t[2]>0){assert(masks[name[0]][day]);assert(first===null||first===day);first=day;}else if(!t[15])assert(day>=first+20);holdChecks++;}
    }
   }
   if(period==='full'&&slip===.0005){
    let first=null,initial=null,prev=r.capital;
    for(let i=0;i<r.nav.length;i++){
     daily.push({stock,name,date:d.dates[a+i],nav:r.nav[i],exposure:r.exposure[i],shares:r.daily[i].shares,debt:r.debt?.[i]??0,return_:r.nav[i]/prev-1});
     if(initial===null&&(r.daily[i].shares>0||Math.abs(r.nav[i]-prev)>1e-7)){initial=prev;first=i;}
     if(initial!==null&&r.daily[i].shares===0){episodes.push({stock,name,start:d.dates[a+first],end:d.dates[a+i],days:i-first+1,pnl:r.nav[i]-initial,return_:r.nav[i]/initial-1,complete:true});initial=null;}prev=r.nav[i];
    }
    if(initial!==null)episodes.push({stock,name,start:d.dates[a+first],end:d.dates[z-1],days:r.nav.length-first,pnl:r.nav.at(-1)-initial,return_:r.nav.at(-1)/initial-1,complete:false});
    fs.writeFileSync(O+stock+'-'+name+'-trades.json',JSON.stringify(r.trades));
   }
   if(period==='full'){
    const buckets={};d.dates.slice(a,z).forEach((date,i)=>{const q=date.slice(0,4)+'Q'+Math.ceil(+date.slice(5,7)/3);(buckets[q]??=[]).push(i);});
    for(const [quarter,ix]of Object.entries(buckets)){const first=ix[0],last=ix.at(-1),before=first?r.nav[first-1]:r.capital;let peak=before,dd=0;for(const i of ix){peak=Math.max(peak,r.nav[i]);dd=Math.min(dd,r.nav[i]/peak-1);}quarters.push({stock,name,slip,quarter,return_:r.nav[last]/before-1,mddDaily:dd,days:ix.length});}
   }
  }
 }
}
for(const [k,v]of Object.entries({metrics:rows,daily,episodes,quarters}))fs.writeFileSync(O+k+'.json',JSON.stringify(v));
const audit={scenarios:rows.length,originalMetricParity:parity,ledger,loanChecks:loan,accountDays,holdChecks,engineDefaultIdentical:true,defaultChanged:false,forwardEvidence:false};assert.equal(rows.length,320);fs.writeFileSync(O+'audit.json',JSON.stringify(audit,null,2));console.log(JSON.stringify(audit));
"""
(w/'run.mjs').write_text(head+audit+tail)
print('Added only fixed holding branch; account runner ready')
