# -*- coding: utf-8 -*-
from pathlib import Path
import json,hashlib,math
import pandas as pd,numpy as np
R=Path.cwd();O=R/'outputs/combo_trend';m=pd.read_json(O/'metrics.json');ep=pd.read_json(O/'episodes.json');daily=pd.read_json(O/'daily.json');a=json.loads((O/'audit.json').read_text())
for p,sha in json.loads((O/'manifest.json').read_text()).items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==sha,p
periods={'full':('2023-10-09','2026-10-08'),'older':('2020-01-02','2023-09-28'),'early':('2023-10-09','2024-12-31'),'later':('2025-01-01','2026-06-30'),'julyOn':('2026-07-01','2026-10-08'),'year1':('2023-10-09','2024-10-08'),'year2':('2024-10-09','2025-10-08'),'year3':('2025-10-09','2026-10-08')}
ss=[];checks=0;old=pd.read_csv(R/'outputs/regime_combo/metrics.csv')
for stock in ['hudian','shenghong']:
 f=pd.read_csv(O/f'{stock}-daily.csv');f['Rejected']=f.U&~f.trend
 for period,(start,end)in periods.items():
  for h in [5,20]:
   t0=f[(f.date>=start)&(f.date<=end)&f[f'return{h}'].notna()&(f[f'end{h}']<=end)]
   for sampling in ['all','nonoverlap']:
    t=t0 if sampling=='all' else t0.iloc[::h]
    for rule in ['U','T','M','Rejected']:
     ret=t.loc[t[rule],f'return{h}'];n=len(ret);w=int((ret>0).sum());bad=int((ret < -t.loc[t[rule],f'threshold{h}']).sum())
     ss.append(dict(stock=stock,period=period,horizon=h,sampling=sampling,rule=rule,n=n,wins=w,precision=w/n if n else None,coverage=n/len(t)if len(t)else None,meanReturn=ret.mean()if n else None,tail5=ret.nsmallest(max(1,math.ceil(n*.05))).mean()if n else None,strongOpposite=bad/n if n else None))
     if rule=='U':
      b=old[(old.stock==stock)&(old.period==period)&(old.horizon==h)&(old.sampling==sampling)&(old.model=='DUALUP')].iloc[0];assert n==b.issued and w==b.hits;checks+=1
summary=[]
for x in m[(m.period=='full')&(m.slip==.0005)].itertuples():
 e=ep[(ep.stock==x.stock)&(ep.name==x.name)];c=e[e.complete];v=daily[(daily.stock==x.stock)&(daily.name==x.name)]
 assert len(c)==x.closedEpisodes;assert(c.pnl>0).sum()==x.episodeWins;assert abs(e.pnl.sum()-x.return_*1e6)<.01
 assert abs((v.return_+1).prod()-1-x.return_)<1e-9;assert abs(v.exposure.mean()-x.exposure)<1e-9
 n=len(c);w=int((c.pnl>0).sum());z=1.96
 if n:p=w/n;cen=(p+z*z/(2*n))/(1+z*z/n);half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n);lo,hi=cen-half,cen+half
 else:lo=hi=None
 summary.append(dict(stock=x.stock,name=x.name,closed=n,wins=w,medianDays=c.days.median(),meanReturn=c.return_.mean(),wilsonLow=lo,wilsonHigh=hi,openCount=len(e)-n,openMarked=e.loc[~e.complete,'pnl'].sum()))
for k,df in [('metrics',m),('episodes',ep),('daily',daily),('quarters',pd.read_json(O/'quarters.json')),('signal-scores',pd.DataFrame(ss)),('episode-summary',pd.DataFrame(summary))]:df.to_csv(O/(k+'.csv'),index=False)
a.update({'signalScores':len(ss),'previousSignalParity':checks,'independentEpisodeReconciliation':len(summary),'manifestMatches':True,**json.loads((O/'feature-audit.json').read_text())})
(O/'audit.json').write_text(json.dumps(a,indent=2));print(json.dumps(a))
print('ACCOUNTS');print(m[(m.period.isin(['full','older']))&(m.slip==.0005)][['stock','name','period','return_','mdd5','episodeWins','closedEpisodes','episodeWinRate','exposure','winningDayFraction','worst5pctDayMean','openEpisodeMarked']].round(4).to_string(index=False))
print('SIGNAL20');print(pd.DataFrame(ss).query("period in ['full','older'] and horizon==20 and sampling=='all'").round(4).to_string(index=False))
