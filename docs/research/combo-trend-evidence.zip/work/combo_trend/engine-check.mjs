import assert from 'node:assert/strict';
import {financeBacktest} from './finance_hold.mjs';
const n=30,day0=Date.parse('2026-01-01'),d={dates:Array.from({length:n},(_,i)=>new Date(day0+i*86400000).toISOString().slice(0,10)),bars:Array.from({length:n},()=>Array.from({length:48},()=>[10,10,10,10,20000,200000])),close:Array(n).fill(10),dividend:Array(n).fill(0),bonus:Array(n).fill(0),reference:Array(n).fill(10),stamp:Array(n).fill(.0005),transfer:Array(n).fill(.00001),signals:{D:Array.from({length:n},()=>[6,1])}};
const g={D:{all_full:Array(n).fill(1)}},mask=Array(n).fill(false);mask[0]=true;
const run=(data,entryMask)=>financeBacktest(data,g,0,n,{entryMask,holdSessions:20,level:1,rate:0});
const r=run(d,mask);assert(r.daily[0].shares>0&&r.exposure[0]<.035);assert.equal(r.daily[19].shares,r.daily[0].shares);assert.equal(r.daily[20].shares,0);assert(r.trades.filter(t=>t[2]<0).every(t=>t[0]===20));
const delayed=structuredClone(d);delayed.bars[0].forEach(b=>b[4]=0);mask[3]=true;const s=run(delayed,mask);assert.equal(s.daily[0].shares,0);assert(s.daily[3].shares>0);assert.equal(s.daily[22].shares,s.daily[3].shares);assert.equal(s.daily[23].shares,0);assert(s.trades.filter(t=>t[2]<0).every(t=>t[0]===23));
console.log('PASS: sub3.5pct position fully exits; no-fill does not start holding clock; first actual fill starts20session clock.');
