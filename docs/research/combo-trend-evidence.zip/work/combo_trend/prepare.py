# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
import json,hashlib
import pandas as pd,numpy as np
R=Path.cwd();O=R/'outputs/combo_trend'
plan={'registeredAt':datetime.now().astimezone().isoformat(),'question':'Does the already-known prior medium-term trend separate useful DUALUP opportunities from failure? Does improvement survive a fully specified 20-session account?','rules':{'U':'Existing DUALUP: prior MA3 in {up,down}, prior V5/V20>=1','T':'U AND prior adjustedclose>MA60 AND prior MA120>MA12020sessions earlier','M':'Trend filter alone, to isolate whether volume/state adds value'},'newParameters':'None searched. Reuse 60,120,20; only change entry mask, same holding and exit in every candidate. Rules inspired by seen history, NOT fresh blind discovery.','signals':'5/20day price sign: overlap and fixed nonoverlap; kept/rejected conditions separately; outcome must finish within segment. Unknown is no entry, not proven sideways.','account':'Cash100%,margin150% (borrow cap50%net only on eachbuy). Flat plus qualifying prior-known signal enters at10:00, up to5bars respectingcaps. Clock starts on FIRST ACTUAL BUY, same-day partial fills allowed; no later adds/rebalance during hold. Earliest planned exit at10:00 on session firstBuy+20 (after20sessions holding); repeat next day untilflat; newentry only after a flat day-start. Mandatory maintenance exits retained. End-period position marked, not forcibly closed. No per-episode reset. This exit nextday10 differs from signal20thclose metric. No intradayTclaim.','comparisons':['B','D','L','F50','UC','UL','TC','TL','MC','ML'],'tests':'2stocks*8periods*2slips*10models=320 accounts; fixedyear1/2/3,earlier2020..2023,early/later/July/full. No fitted selector. All pastalreadyseen. Only conditional engine addition; original no-entryMask behavior checked identical.','execution':'Commission.0001 min5; historical stamp/transfer,T1,lots100,1%priorbarvolume,300kshares/fill,5/10bp slips,price limits,6%financing,maintenance1.5. Passiveover150held. Dividends20%taxsimplification; benchmarklongterm0.','risk':'Closedflat-to-flat net wins and total; openmarkedPnL; winaccountdays inclflatdenominator; DD5mclose,taildaily,return,exposure,lead,rolling63,longestlag. No T win rate, no stable/optimalclaim.','data':'Through2026-10-08;Oct9minute/dailyextremamismatchunresolved. Existing historical minutequality and financialvintage/eligibility limitations retained. No newprice fetching needed for frozenhistorical comparison. Weekend no newforward evidence.','defaultChanged':False}
p=O/'plan-before-results.json'
assert not p.exists(),'Do not overwrite preregistration'
p.write_text(json.dumps(plan,ensure_ascii=False,indent=2))
paths=['outputs/regime_combo/hudian-daily.csv','outputs/regime_combo/shenghong-daily.csv','outputs/trend_floor/signal-ledger.csv','work/risk_priority/data.json','work/shenghong/data.json','work/shenghong/finance.mjs','work/shenghong/benchmark.mjs','work/opening_guard/metrics.mjs','work/hudian-backtest-dashboard/docs/fees.js','work/hudian-backtest-dashboard/docs/default-selection.json','work/regime_combo/research.py','work/round2/data/daily_qfq_early.csv','work/data/daily_qfq.csv','work/shenghong/data/daily_qfq.csv']
(O/'manifest.json').write_text(json.dumps({s:hashlib.sha256((R/s).read_bytes()).hexdigest()for s in paths},indent=2))
old=pd.read_csv(R/'outputs/trend_floor/signal-ledger.csv');checks=0
for stock in ['hudian','shenghong']:
 f=pd.read_csv(R/f'outputs/regime_combo/{stock}-daily.csv'); t=old[old.stock==stock].set_index('date').loc[f.date]
 f['trend']=t.trend.to_numpy();f['U']=(f.DUALUP==2);f['T']=f.U&f.trend;f['M']=f.trend
 if stock=='hudian':q=pd.concat([pd.read_csv(R/'work/round2/data/daily_qfq_early.csv'),pd.read_csv(R/'work/data/daily_qfq.csv')]).sort_values('date').drop_duplicates('date',keep='last')
 else:q=pd.read_csv(R/'work/shenghong/data/daily_qfq.csv').sort_values('date')
 q=q.set_index('date')
 for x in f.itertuples():
  past=q.loc[q.index<x.date].close
  val=len(past)>=140 and past.iloc[-1]>past.iloc[-60:].mean() and past.iloc[-120:].mean()>past.iloc[-140:-20].mean()
  assert bool(x.trend)==val;assert x.knownThrough==past.index[-1];checks+=1
 f.to_csv(O/f'{stock}-daily.csv',index=False)
 (O/f'{stock}-masks.json').write_text(json.dumps({'dates':f.date.tolist(),**{k:f[k].tolist()for k in ['U','T','M']}}))
(O/'feature-audit.json').write_text(json.dumps({'priorPrefixTrendChecks':checks,'defaultChanged':False},indent=2))
print('Plan frozen; masks saved; strict prefix checks',checks)
