# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
import json,html,zipfile,shutil
import pandas as pd
R=Path.cwd();O=R/'outputs/combo_trend';repo=R/'work/hudian-backtest-dashboard'
m=pd.read_json(O/'metrics.json');s=pd.read_csv(O/'signal-scores.csv');e=pd.read_csv(O/'episode-summary.csv');a=json.loads((O/'audit.json').read_text());a['syntheticExecutionChecks']='PASS sub3.5pct completeexit; nofillclock; firstactualfill20sessions';a['discardedRun']='Initial candidate reused baseline allocation tolerance and did not liquidate tiny positions. Rejected; candidate-only exit0 tolerance fixed0, original baseline unchanged.';(O/'audit.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
names={'B':'全仓持有','D':'原D现金','L':'原L融资（默认）','F50':'固定50%现金','UC':'U组合／现金100%','UL':'U组合／融资150%','TC':'T加趋势过滤／现金100%','TL':'T加趋势过滤／融资150%','MC':'M仅趋势／现金100%','ML':'M仅趋势／融资150%'};stocks={'hudian':'沪电','shenghong':'胜宏'};per={'full':'近三年','older':'2020至2023年9月','year1':'年度1','year2':'年度2','year3':'年度3','early':'2023年10月至2024末','later':'2025初至2026年6月','julyOn':'2026年7月起重置账户'}
pct=lambda x:'—'if pd.isna(x)else f'{x*100:.2f}%'
def table(head,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(v))+'</th>'for v in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>'for v in row)+'</tr>'for row in rows)+'</tbody></table></div>'
def wins(x):return f'{int(x.episodeWins)}/{int(x.closedEpisodes)} · '+pct(x.episodeWinRate)if x.closedEpisodes else '无已结束周期'
body='''<nav><a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a></nav><h1>组合信号加趋势过滤，是否更可靠？</h1><p class="muted">256组信号评分＋320组完整账户 · 固定参数、现金与融资分开 · 数据截至2026-10-08 · 默认未变</p>
<section><h2>结论：不能把慢趋势作为两类买点的统一准入门槛</h2><p>本轮只检验一个既有条件：前一天收盘高于60日均线，且120日均线比20个交易日前高。它没有稳定提高组合的上涨识别率；沪电三年现金完整周期胜率只从65.00%升至66.67%，最大回撤反而从25.12%扩大到27.45%。融资回撤从30.46%扩大到38.71%。候选不接入默认。</p><p>被挡掉的沪电日期有54/65在后20日上涨，其中包括全部38个下行反弹日期（31个后来上涨）。这说明慢趋势条件与反弹入场可能存在时机冲突。它不能证明“反过来专买弱趋势”有效，更不能在事后把这些反弹重新涂成上行区。</p></section>
<section><h2>只改变入场过滤，先固定其他规则</h2>'''
body+=table(['规则','前一天即可知道的条件','意义'],[['U原组合','MA3上行或下行，且5日均量≥20日均量','趋势延续与下行反弹两类看涨观察；不含看跌专家'],['T趋势过滤','U成立，并且前收盘>MA60、MA120>20日前MA120','本轮待验证的统一准入条件'],['M仅趋势对照','仅要求同一MA60/MA120条件','检验是否只是趋势本身的作用']])
body+='''<p>MA3沿用MA20/60、MA20五日斜率及连续3日确认，不重画过去；量均线沿用5/20日并处理已知送转股。所有指标滞后一日。没有按结果搜索参数或挑选年度赢家。两只股票使用相同规则。</p><p>账户规则：空仓且当天满足条件，10:00开始尝试买入；实际首次成交开始计时，同日最多5根5分钟K线尝试，随后不再补仓。经过20个交易日，下一交易日10:00尝试全部退出；若成交量或涨跌停限制未能卖完，之后每日继续退出，只有日初已经空仓才允许下一轮买入。保留维持担保比例风控，不因被动超150%自动减仓。区间结束仍持有则按市值计入盈亏和回撤，不强行平仓、不计为已完成胜利。</p><p>因此，账户退出是首次实际买入后第21个交易日10:00；信号评分仍是决策日开盘至第20个交易日收盘，两者不是同一个指标。新规则不是日内做T；完整周期通常21个交易日，不能称日内胜率。</p></section>
<section><h2>趋势过滤挡掉了什么？后20日价格方向</h2>'''
v=s[(s.period.isin(['full','older']))&(s.horizon==20)&(s.sampling=='all')]
body+=table(['股票／时期','规则','上涨／日期','上涨比例','日期覆盖率','最差5%窗口均值'],[[stocks[x.stock]+'／'+per[x.period],{'U':'U原组合','T':'T保留','M':'M仅趋势','Rejected':'被T过滤'}[x.rule],f'{x.wins}/{x.n}',pct(x.precision),pct(x.coverage),pct(x.tail5)]for x in v.itertuples()])
body+='''<p>近期沪电U：138/185＝74.59%；T：84/120＝70.00%；被过滤：54/65＝83.08%。胜宏也从61.88%降至56.49%。更早行情中，T分别只有40.91%、39.62%。这些是允许重叠的未来价格窗口；未扣费、不是独立交易胜率。5日和固定间隔不重叠评分全部保存在证据包，未因结果不好删除。</p><p>沪电被过滤的65个日期分为：MA3下行38个，31个随后上涨；MA3上行27个，23个随后上涨。后者也提示短期转强可能早于更慢的趋势确认。这是现有样本的解释，还不足以决定何时加仓。</p></section>
<section><h2>完整账户：近三年，单边5基点滑点</h2>'''
v=m[(m.period=='full')&(m.slip==.0005)]
body+=table(['股票／账户','净收益','最大回撤','已结束周期盈利／总数','平均实际仓位','盈利日／全部交易日','最差5%日均亏损'],[[stocks[x.stock]+'／'+names[x.name],pct(x.return_),pct(-x.mdd5),wins(x),pct(x.exposure),f'{x.winningDays}/{x.days} · '+pct(x.winningDayFraction),pct(x.worst5pctDayMean)]for x in v.itertuples()])
body+='''<p>沪电T现金收益+143.72%，低于U现金+257.46%，同时回撤更大；T融资收益+257.82%、回撤38.71%，也不如原L的+1226.51%、25.20%。这不是因为不接受收益下降而淘汰：本轮首先比较胜率和回撤，它们没有同时形成可靠改善。</p><p>胜宏T现金比U现金回撤下降，但完整周期胜率从13/23＝56.52%降至8/17＝47.06%；不能称普适改善。M仅趋势亦没有提供稳定优势。半仓对照保留，避免将降低参与度本身误称为买点更准确。</p></section>
<section><h2>未平仓亏损没有被藏起来</h2>'''
v=e[e.name.isin(['UC','TC','UL','TL'])]
body+=table(['股票／账户','完成周期数','周期中位交易日数','胜率95%区间（参考）','未结束周期数','未结束累计盈亏（元）'],[[stocks[x.stock]+'／'+names[x.name],x.closed,x.medianDays,pct(x.wilsonLow)+'—'+pct(x.wilsonHigh),x.openCount,f'{x.openMarked:,.2f}']for x in v.itertuples()])
body+='''<p>沪电T为10/15＝66.67%，Wilson区间约41.71%至84.82%；它只是小样本精度提示，周期仍受市场环境相关性影响。沪电T现金期末未平仓亏损约21.12万元、融资约48.02万元，均已包含在总收益与回撤。空仓日、平盘日不是盈利日；全仓持有尚未卖出，完整周期胜率显示无样本，不写成0%或100%。</p></section>
<section><h2>三个固定年度、更早行情及滑点压力</h2>'''
v=m[(m.period.isin(['older','year1','year2','year3']))&(m.slip==.0005)&m.name.isin(['UC','TC','UL','TL'])]
body+=table(['股票／时期／账户','净收益','最大回撤','已结束周期盈利／总数','平均实际仓位'],[[stocks[x.stock]+'／'+per[x.period]+'／'+names[x.name],pct(x.return_),pct(-x.mdd5),wins(x),pct(x.exposure)]for x in v.itertuples()])
body+='''<p>沪电过滤后的回撤仅在第一个固定年度下降，第二年变差，第三年相同，未形成至少2/3年度严格改善。更早沪电现金回撤从49.43%降到34.49%，但胜宏更早阶段反而从33.24%扩大到39.29%、收益转负。更早沪电的平均仓位也大幅降低，减险不能全归功于识别准确。</p>'''
v=m[(m.period=='full')&(m.slip==.001)&m.name.isin(['UC','TC','UL','TL','D','L'])]
body+=table(['股票／账户：10基点滑点','净收益','最大回撤','已结束周期盈利／总数'],[[stocks[x.stock]+'／'+names[x.name],pct(x.return_),pct(-x.mdd5),wins(x)]for x in v.itertuples()])
body+='''<p>年度1／2／3从2023／2024／2025年10月9日起各一年；更早阶段为2020-01-02至2023-09-28。各分段独立从100万元开始，不能直接把分段收益拼成三年账户。10基点压力没有改变趋势过滤未稳定改善的结论。</p></section>
<section><h2>7月前后、长期落后与滚动领先</h2>'''
v=m[(m.period=='full')&(m.slip==.0005)&m.name.isin(['B','D','L','UC','TC','UL','TL'])]
body+=table(['股票／账户','至6月30日收益','7月起连续账户收益','累计领先持有日比例','最长连续落后','滚动63日领先比例'],[[stocks[x.stock]+'／'+names[x.name],pct(x.preJuly),pct(x.postJuly),'基准'if x.name=='B'else pct(x.leadFraction),'—'if x.name=='B'else f'{x.longestBehind}日','—'if x.name=='B'else pct(x.rolling63Lead)]for x in v.itertuples()])
body+='''<p>这里承接全期账户7月前的仓位，不在7月1日重置。沪电T现金累计领先比例只有25.03%，最长连续落后326个交易日。T融资累计领先比例较高，却同时承受更大回撤，因此“更多时间领先”不代表风险更低。胜宏T在7月起空仓，收益0，不算预测命中或盈利。63日窗口相互重叠，不视为独立样本。</p></section>
<section><h2>执行核验、数据限制与下一步</h2><p>核验时发现：原调仓引擎的3.5个百分点容差可能留下小额仓位，这符合旧调仓容差，却不符合本轮“到期全部清仓”的规则。第一遍候选结果已作废归档；仅新候选退出清仓使用零容差，旧D/L和基准保持原实现，640个原指标复算一致。合成样例确认小额仓位可清完、未成交不启动持有计时、首笔模拟成交才启动20日时钟。此处并未悄悄修正主看板原策略。</p>'''
body+=f'<p>最终账本核验{a["ledger"]:,}笔模拟成交、{a["loanChecks"]:,}次买入资金约束、{a["accountDays"]:,}个账户日；3,274个日期严格用历史前缀重建趋势。20份全期账户逐周期盈亏与净资产变化一致。新引擎关闭该候选功能时与原引擎输出完全相同。</p>'
body+='''<p>按用户股票佣金万1、每笔最低5元，加历史印花税和过户费、双边滑点、融资年息6%；约束T+1、100股买入、前一根5分钟成交量1%、每次最多30万股、涨跌停、每笔融资买入后欠款不超净资产50%。未验证历史融资标的资格、券商额度和财报修订版本；分红税按原简化口径。分钟与日线价格、成交量存在既有差异，最大回撤按5分钟收盘估计而非逐笔最坏值，结果仍属于研究估算。</p><p>行情截止2026-10-08；10月9日分钟极值与日线不一致尚未解决，未新增虚构成交。10月10日休市，没有冻结后的新独立证据。全部历史已见过，本轮没有训练后新盲测，也不宣称原收益门槛达标。研究不代表真实下单。</p><p>下一批应分别研究趋势延续与反弹分支的失败条件，特别是入场后是否迅速转弱；先固定一个可在当时观察的退出规则，再比较卖错后反弹的损失。不能继续单靠增加入场均线条件追求高胜率，也不能根据这次被过滤日期的83.08%反向拟合新赢家。</p><p><a href="combo-trend-evidence.zip">下载计划、全部320组账户、256组信号、逐笔账本与复跑脚本</a> · <a href="regime-combo.html">上一轮组合信号</a></p></section>'''
style='body{font:16px/1.8 system-ui,sans-serif;color:#1b304a;background:#f3f6fa;margin:0}main{max-width:1280px;margin:30px auto;padding:20px}section{background:white;border:1px solid #dce5ee;border-radius:14px;padding:26px;margin:22px 0}h1{font-size:30px}h2{font-size:22px}a{color:#147f85}.muted{color:#697b8c;font-size:14px}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:11px;white-space:nowrap;text-align:left;border-bottom:1px solid #e2eaf1}th{background:#f4f7fa}'
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>组合信号加趋势过滤｜沪电研究</title><style>'+style+'</style></head><body><main>'+body+'</main></body></html>'
(O/'report.html').write_text(page);(repo/'docs/research/combo-trend.html').write_text(page)
archive=repo/'docs/research/archive.html';v=archive.read_text();link='<p><a href="combo-trend.html">组合加趋势过滤：挡掉反弹后，320组完整账户的胜率与回撤检验 ↗</a></p>'
if 'href="combo-trend.html"'not in v:archive.write_text(v.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+link))
(O/'README.txt').write_text('Historical research only. Reproduce from workspace root with pandas/numpy and Node: prepare.py (only in fresh output dir; preserves preregistration), build_runner.py, node run.mjs, node engine-check.mjs, check.py. report.py generates report. Archive contains original data and engine dependencies. See discarded-tolerance-run/REJECTED.json for invalid initial implementation. No default edits or real orders. Completed cycles not intraday T.\n')
inputs=list(json.loads((O/'manifest.json').read_text()))+['work/hudian-backtest-dashboard/docs/attribution.js','outputs/regime_policy/metrics.json','outputs/regime_combo/metrics.csv']
with zipfile.ZipFile(O/'evidence.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in list(O.iterdir())+list((R/'work/combo_trend').iterdir())+[R/p for p in inputs]+[O/'discarded-tolerance-run/REJECTED.json',O/'discarded-tolerance-run/metrics.json']:
  if p.is_file()and p.name not in ['evidence.zip','publication.json','deployment.log']:z.write(p,str(p.relative_to(R)))
shutil.copyfile(O/'evidence.zip',repo/'docs/research/combo-trend-evidence.zip')
cp=R/'work/research-checkpoint.json';c=json.loads(cp.read_text());now=datetime.now().astimezone().isoformat();c['comboTrend']={'updatedAt':now,'outputs':'outputs/combo_trend','status':'verified locally, publication pending','audit':a,'finding':'Prior mediumtrend filter reduces H20day precision74.59to70; filtered54/65up includes31/38downrebound. H cash cycle65to66.67 butDD25.12to27.45; marginDD30.46to38.71. Shenghong cycle56.52to47.06 despite recentDDreduction, earlierDDworse. Reject unified trend hardentryfilter. No defaultchange.','nextQuestion':'Separate continuation and rebound failure conditions; preregister one causal exit treatment and account for rebound missed afterselling. Do not invert filtered83pct ex post. Audit residual tolerance if future work changes default engine.','defaultChanged':False,'newBlindTest':False};c['updatedAt']=now;cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print('Saved report, evidence, checkpoint. Zip bytes', (O/'evidence.zip').stat().st_size)
