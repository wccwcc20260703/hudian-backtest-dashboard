import fs from 'node:fs';
import assert from 'node:assert/strict';
import {financeBacktest} from './finance_hold.mjs';
import {financeBacktest as originalEngine} from '../shenghong/finance.mjs';
import {holdBenchmark} from '../shenghong/benchmark.mjs';
import {stats} from '../opening_guard/metrics.mjs';
import {attribution} from '../hudian-backtest-dashboard/docs/attribution.js';
const read=p=>JSON.parse(fs.readFileSync(p)),O='outputs/combo_trend/',rows=[],daily=[],episodes=[],quarters=[];
const baseline=read('outputs/regime_policy/metrics.json');let parity=0,ledger=0,loan=0,accountDays=0,holdChecks=0;
const names=['B','D','L','F50','UC','UL','TC','TL','MC','ML'];
for(const [stock,path] of [['hudian','work/risk_priority/data.json'],['shenghong','work/shenghong/data.json']]){
 const d=read(path),masks=read(O+stock+'-masks.json');assert.deepEqual(masks.dates,d.dates);const n=d.dates.length,main=d.dates.indexOf('2023-10-09');
 const idx=s=>{const i=d.dates.findIndex(x=>x>=s);return i<0?n:i},g={D:{all_full:Array(n).fill(1)}};
 const periods={full:[main,n],older:[0,main],early:[main,idx('2025-01-01')],later:[idx('2025-01-01'),idx('2026-07-01')],julyOn:[idx('2026-07-01'),n]};
 for(let y=0;y<3;y++)periods['year'+(y+1)]=[idx(`${2023+y}-10-09`),idx(`${2024+y}-10-09`)];
 const run=(name,a,z,slip)=>name==='B'?holdBenchmark(d,a,z,{slip}):financeBacktest(name==='F50'?{...d,signals:{D:d.dates.map(()=>[6,.5])}}:d,g,a,z,{slip,level:name==='L'||name.endsWith('L')?1.5:1,rate:name==='L'||name.endsWith('L')?.06:0,entryMask:name.length===2?masks[name[0]]:null,holdSessions:20});
 function audit(r){
  let cash=r.capital,shares=0;const rate=r.config?.rate??0,byday=new Map();for(const t of r.trades){if(!byday.has(t[0]))byday.set(t[0],[]);byday.get(t[0]).push(t);}
  for(let day=r.start;day<r.end;day++){
   const carry=day>r.start?Math.max(0,(Date.parse(d.dates[day])-Date.parse(d.dates[day-1]))/86400000-1):0;
   cash-=Math.max(0,-cash)*rate/365*carry;cash+=shares*d.dividend[day]*(r.model==='B'?1:.8);if(d.bonus[day])shares=Math.round(shares*(1+d.bonus[day]));let av=shares,maxDebt=Math.max(-cash,0);
   for(const t of byday.get(day)||[]){assert.equal(shares,t[12]);assert.equal(av,t[9]);assert(t[3]<=t[11]&&t[3]<=300000);assert.equal(t[11],Math.min(300000,Math.trunc(d.bars[day][t[1]-1][4]*.01/100)*100));
    const gross=t[3]*t[4],fee=Math.max(5,gross*.0001)+gross*(d.transfer[day]+(t[2]<0?d.stamp[day]:0));assert(Math.abs(fee-t[5])<1e-6);cash-=t[2]*gross+fee;shares+=t[2]*t[3];if(t[2]<0)av-=t[3];assert(av>=0);assert(Math.abs(cash-t[6])<1e-5);
    if(t[2]>0){const eq=cash+shares*d.bars[day][t[1]][0];assert(-cash<=(r.config?.level===1.5?.5*eq:0)+1e-6);loan++;}maxDebt=Math.max(maxDebt,-cash);ledger++;
   }
   cash-=maxDebt*rate/365;assert(Math.abs(cash+shares*d.close[day]-r.nav[day-r.start])<1e-4);accountDays++;
  }
 }
 const relative=(r,b)=>{const at=attribution(r,b,d.dates.slice(r.start,r.end));delete at.relative;const rv=[r.capital,...r.nav],bv=[b.capital,...b.nav];let wins=0,ct=0;for(let i=63;i<rv.length;i++){ct++;wins+=rv[i]/rv[i-63]>bv[i]/bv[i-63]?1:0;}return {...at,rolling63Lead:ct?wins/ct:null,relativeWealth:r.nav.at(-1)/b.nav.at(-1)};};

 for(const [period,[a,z]] of Object.entries(periods))for(const slip of [.0005,.001]){
  const rr=Object.fromEntries(names.map(name=>[name,run(name,a,z,slip)]));
  for(const [name,r]of Object.entries(rr)){
   const row={stock,name,period,slip,...r.metrics,...stats(r),tradeDays:new Set(r.trades.map(t=>t[0])).size,...relative(r,rr.B)};rows.push(row);audit(r);
   if(['B','D','L','F50'].includes(name)){
    const b=baseline.find(x=>x.stock===stock&&x.name===name&&x.period===period&&x.slip===slip);
    for(const k of ['return_','mdd5','exposure','fees','interest']){assert(Math.abs((row[k]??0)-(b[k]??0))<1e-9,[stock,name,period,k]);parity++;}
    if(name==='L')assert.deepEqual(r,originalEngine(d,g,a,z,{slip}));
   }else{
    let first=null;const byday=new Map();for(const t of r.trades){if(!byday.has(t[0]))byday.set(t[0],[]);byday.get(t[0]).push(t);}
    for(let day=a;day<z;day++){
     const atStart=day===a?0:r.daily[day-a-1].shares;if(!atStart)first=null;
     const expected=atStart?(day>=first+20?[6,0]:[-1,-1]):masks[name[0]][day]?[6,name.endsWith('L')?1.5:1]:[-1,-1];assert.deepEqual(r.targets[day-a],expected);
     for(const t of byday.get(day)||[]){if(t[2]>0){assert(masks[name[0]][day]);assert(first===null||first===day);first=day;}else if(!t[15])assert(day>=first+20);holdChecks++;}
    }
   }
   if(period==='full'&&slip===.0005){
    let first=null,initial=null,prev=r.capital;
    for(let i=0;i<r.nav.length;i++){
     daily.push({stock,name,date:d.dates[a+i],nav:r.nav[i],exposure:r.exposure[i],shares:r.daily[i].shares,debt:r.debt?.[i]??0,return_:r.nav[i]/prev-1});
     if(initial===null&&(r.daily[i].shares>0||Math.abs(r.nav[i]-prev)>1e-7)){initial=prev;first=i;}
     if(initial!==null&&r.daily[i].shares===0){episodes.push({stock,name,start:d.dates[a+first],end:d.dates[a+i],days:i-first+1,pnl:r.nav[i]-initial,return_:r.nav[i]/initial-1,complete:true});initial=null;}prev=r.nav[i];
    }
    if(initial!==null)episodes.push({stock,name,start:d.dates[a+first],end:d.dates[z-1],days:r.nav.length-first,pnl:r.nav.at(-1)-initial,return_:r.nav.at(-1)/initial-1,complete:false});
    fs.writeFileSync(O+stock+'-'+name+'-trades.json',JSON.stringify(r.trades));
   }
   if(period==='full'){
    const buckets={};d.dates.slice(a,z).forEach((date,i)=>{const q=date.slice(0,4)+'Q'+Math.ceil(+date.slice(5,7)/3);(buckets[q]??=[]).push(i);});
    for(const [quarter,ix]of Object.entries(buckets)){const first=ix[0],last=ix.at(-1),before=first?r.nav[first-1]:r.capital;let peak=before,dd=0;for(const i of ix){peak=Math.max(peak,r.nav[i]);dd=Math.min(dd,r.nav[i]/peak-1);}quarters.push({stock,name,slip,quarter,return_:r.nav[last]/before-1,mddDaily:dd,days:ix.length});}
   }
  }
 }
}
for(const [k,v]of Object.entries({metrics:rows,daily,episodes,quarters}))fs.writeFileSync(O+k+'.json',JSON.stringify(v));
const audit={scenarios:rows.length,originalMetricParity:parity,ledger,loanChecks:loan,accountDays,holdChecks,engineDefaultIdentical:true,defaultChanged:false,forwardEvidence:false};assert.equal(rows.length,320);fs.writeFileSync(O+'audit.json',JSON.stringify(audit,null,2));console.log(JSON.stringify(audit));
