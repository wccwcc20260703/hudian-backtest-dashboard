# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
import json,hashlib,math
import pandas as pd,numpy as np
R=Path.cwd();O=R/'outputs/regime_combo';O.mkdir(parents=True,exist_ok=True)
plan={'registeredAt':datetime.now().astimezone().isoformat(),'question':'Combine directional experts or combine trendbuy with downstaterebound? Distinguish user premise from actual prior evidence.','priorEvidence':'H20day up precision MA3=.6589,VMA=.7279,OBV=.6409; down=.3625,.1842,.2222. There is no strong down expert. Rules motivated by seen history, NOT fresh preregistration before seeing any outcomes. Freeze now before combination tests.','rules':{'MA3':'Existing price-state directional hypothesis','VMA':'Existing volume-confirmed directional hypothesis','OBV':'Existing OBV-confirmed directional hypothesis','ASYM':'If MA3up and V5V20>=1 predictup; if MA3down predictdown without volume gate; other dates abstain. Up usesVMA,downusesMA3. Never route byfuturelabel.','DUALUP':'If MA3up ordown and V5V20>=1 predictup: upstate trendcontinuation + downstate rebound. Two bullish branches, NO bearish predictor.','ALLUP':'Every eligible date predictup, prior-period broad upward drift control.'},'parameters':'All inherited, no additional threshold/fitting/grid.5/20horizons both retained. Each dayknownThrough<date. Unknown notsideways.','evaluation':'2stocks*8periods*2horizons*2sampling*6models=384; sameeligible fixedphase beforegating; coverage,signprecision,up/downprecision,strongopposite,mean/tailprice return; allup on same issued dates and all dates. Branch-specific checks separate trend/rebound. No newblindhistory.','episodes':'For DUALUP causal dates, also greedy nonoverlap: takefirstsignaldate,skipnext h-1sessions, useevaluationonlyfuturelabel withno carrypolicy; noexecution/portfolio/tradeclaims. Standard nonoverlapphase startsperiodfirstdatebeforegating.','accountBoundary':'No orderbacktest: no simulatedprofits or Tsuccess. Future close signs notnetfees, T+1 account untested. Do not activate default/livebuyorders.', 'nextEvidence':'Only a stable signal advantage could justify independently preregistered accountentry/exit/moneyrules. Original defaults unchanged.'}
p=O/'plan-before-results.json'
if not p.exists():p.write_text(json.dumps(plan,ensure_ascii=False,indent=2))
inputs=['outputs/volume_regime/hudian-daily.csv','outputs/volume_regime/shenghong-daily.csv','outputs/volume_regime/metrics.csv','work/hudian-backtest-dashboard/docs/default-selection.json']
(O/'manifest.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest()for p in inputs},indent=2))
periods={'full':('2023-10-09','2026-10-08'),'older':('2020-01-02','2023-09-28'),'early':('2023-10-09','2024-12-31'),'later':('2025-01-01','2026-06-30'),'julyOn':('2026-07-01','2026-10-08'),'year1':('2023-10-09','2024-10-08'),'year2':('2024-10-09','2025-10-08'),'year3':('2025-10-09','2026-10-08')}
rows=[];branches=[];events=[];checks=0;parity=0;old=pd.read_csv(R/'outputs/volume_regime/metrics.csv')
def score(t,model,h):
 pred=t[model];r=t['return'+str(h)];label=t['label'+str(h)];up=pred==2;down=pred==0;issued=up|down;win=(up&(r>0))|(down&(r<0));n=int(issued.sum());op=((up&(label==0))|(down&(label==2)));directional=r[issued]*np.where(pred[issued]==2,1,-1)
 return {'n':len(t),'issued':n,'upN':int(up.sum()),'upHits':int((up&(r>0)).sum()),'downN':int(down.sum()),'downHits':int((down&(r<0)).sum()),'hits':int(win.sum()),'signAccuracy':float(win.sum()/n)if n else None,'coverage':n/len(t)if len(t)else None,'oppositeStrong':int(op.sum()),'oppositeStrongRate':float(op.sum()/n)if n else None,'alwaysUpSameDates':float((r[issued]>0).mean())if n else None,'meanDirectionalReturn':float(directional.mean())if n else None,'worst5pctDirectionalReturn':float(directional.nsmallest(max(1,math.ceil(n*.05))).mean())if n else None}
for stock in ['hudian','shenghong']:
 f=pd.read_csv(R/f'outputs/volume_regime/{stock}-daily.csv');f['ASYM']=np.where((f.MA3==2)&(f.V5V20>=1),2,np.where(f.MA3==0,0,1));f['DUALUP']=np.where((f.MA3!=1)&(f.V5V20>=1),2,1);f['ALLUP']=2
 for x in f.itertuples():
  assert x.knownThrough<x.date
  expected=2 if x.MA3==2 and x.V5V20>=1 else 0 if x.MA3==0 else 1
  assert x.ASYM==expected;assert x.DUALUP==(2 if x.MA3 in [0,2]and x.V5V20>=1 else 1);checks+=1
 f.to_csv(O/f'{stock}-daily.csv',index=False)
 for period,(a,z)in periods.items():
  for h in [5,20]:
   t0=f[(f.date>=a)&(f.date<=z)&f['return'+str(h)].notna()&(f['end'+str(h)]<=z)]
   for sampling in ['all','nonoverlap']:
    t=t0 if sampling=='all' else t0.iloc[::h]
    for model in ['MA3','VMA','OBV','ASYM','DUALUP','ALLUP']:
     s=score(t,model,h);rows.append(dict(stock=stock,period=period,horizon=h,sampling=sampling,model=model,**s))
     if model in ['MA3','VMA','OBV']:
      b=old[(old.stock==stock)&(old.period==period)&(old.horizon==h)&(old.sampling==sampling)&(old.model==model)].iloc[0]
      assert s['issued']==b.issued and s['hits']==b.signHits and s['oppositeStrong']==b.oppositeStrong;parity+=3
   for state in [0,2]:
    t=t0[(t0.DUALUP==2)&(t0.MA3==state)];branches.append(dict(stock=stock,period=period,horizon=h,state=state,**score(t,'DUALUP',h)))
   chosen=[];nextIndex=-1
   for i,x in t0.iterrows():
    if i>=nextIndex and x.DUALUP==2:chosen.append(i);nextIndex=i+h
   t=f.loc[chosen];s=score(t,'DUALUP',h);s['coverage']=None;s['eligibleDates']=len(t0)
   assert all(chosen[j]-chosen[j-1]>=h for j in range(1,len(chosen)))
   rows.append(dict(stock=stock,period=period,horizon=h,sampling='greedy_disjoint',model='DUALUP',**s))
   if period=='full':
    for i,x in t.iterrows():events.append({'stock':stock,'horizon':h,'date':x.date,'knownThrough':x.knownThrough,'state':int(x.MA3),'V5V20':x.V5V20,'end':x['end'+str(h)],'return_':x['return'+str(h)],'isTrade':False})
pd.DataFrame(rows).to_csv(O/'metrics.csv',index=False);pd.DataFrame(branches).to_csv(O/'branches.csv',index=False);pd.DataFrame(events).to_csv(O/'disjoint-events.csv',index=False)
audit={'ruleDateChecks':checks,'oldCountParity':parity,'evaluations':len(rows),'primaryEvaluations':384,'additionalDisjointEvaluations':32,'defaultChanged':False,'accountBacktest':False,'futureBlindEvidence':False};assert len(rows)==416
(O/'audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit));print(pd.DataFrame(rows).query("period=='full' and horizon==20").round(4).to_string(index=False))
