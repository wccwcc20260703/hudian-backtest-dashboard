# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/daily_qa';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
import risk_engine as eng
e=f.e;plans=np.load(R/'work/daily_qa/plans.npz');modes=np.full(e.N,2);gates=pd.read_csv(O/'events.csv').set_index('date');foreign=pd.read_csv(O/'foreign.csv').set_index('date');growth=pd.read_csv(R/'outputs/round2/fundamental_point_in_time_map.csv').set_index('date').yoy_netprofit
def clock(j):
 minute=570+5*j if j<24 else 780+5*(j-24)
 return f'{minute//60:02d}:{minute%60:02d}'
def trades_data(ts):
 out=[]
 for t in ts:
  d,j,side,qty=int(t[0]),int(t[1]),int(t[2]),int(t[3]);px=e.B[d,j,0];cashBefore=t[6]+side*qty*t[4]+t[5];eqBefore=cashBefore+t[12]*px;eqAfter=t[6]+t[7]*px
  out.append(dict(time=clock(j),side=side,qty=qty,price=float(t[4]),fee=float(t[5]),before=float(t[12]*px/eqBefore),after=float(t[7]*px/eqAfter),target=float(t[10]),oldAvailable=int(t[9])))
 return out
raw={b:np.load(O/(b+'_base_raw.npz')) for b in ['D','L']};starts={};same=[];records=[];pairedChecks=0
for b,r in raw.items():
 cash=1e6;sh=0;rows=[]
 for i,d in enumerate(range(e.START,e.N)):
  carry=max(0,f.DAYNUM[d]-f.DAYNUM[d-1]-1) if i else 0;opCash=cash-max(-cash,0)*.06/365*carry+sh*e.DIV[d]*.8;opShares=round(sh*(1+e.BONUS[d]));eq=opCash+opShares*e.B[d,0,0];ts=r['trades'][r['trades'][:,0]==d]
  rows.append(dict(cash=float(opCash),shares=int(opShares),oldAvailable=int(opShares),openingExposure=float(opShares*e.B[d,0,0]/eq),equity=float(eq)))
  sh=ts[-1,7] if len(ts) else opShares;cash=r['nav'][i]-sh*e.C[d]
 starts[b]=rows
for d in range(np.searchsorted(e.DATES,'2026-01-01'),e.N):
 date=str(e.DATES[d]);i=d-e.START;fo=foreign.loc[date];ga=gates.loc[date];rec=dict(date=date,status='historical5min',overseas={s:float(fo[s]) for s in ['QQQ','SMH','NVDA','TTMI']},foreignDate=fo.QQQ_date,foreignNew=bool(fo['new']),externalRisk=bool(fo.risk),previousRSI=float(e.LAG.rsi2.iloc[d]),growth=float(growth.loc[date]),gap=float(e.B[d,0,0]/e.REF[d]-1),dayReturn=float(e.C[d]/e.REF[d]-1),open=float(e.B[d,0,0]),close=float(e.C[d]),trigger={n:clock(int(ga[n])) if ga[n]>=0 else None for n in ['external','failure','combined']},accounts={})
 for b,r in raw.items():
  prev=r['nav'][i-1] if i else 1e6;ts=r['trades'][r['trades'][:,0]==d];ps=plans[b+'_base'][d];j=int(np.flatnonzero(ps>=0)[0]);account=dict(**starts[b][i],scheduled=clock(j),target=float(ps[j]),trades=trades_data(ts),baseDayReturn=float(r['nav'][i]/prev-1),variants={})
  for name in ['external','failure','combined']:
   j=int(ga[name]);nav=r['nav'][i];tt=ts
   if j>=0:
    p=plans[b+'_base'].copy();p[d]=plans[b+'_'+name][d];rr=eng.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,p,e.START,d+1,modes)
    assert np.allclose(rr[0][:-1],r['nav'][:i],rtol=0,atol=1e-6);pairedChecks+=1;nav=rr[0][-1];tt=rr[3][rr[3][:,0]==d]
   effect=float((nav-r['nav'][i])/prev);variant=dict(trades=trades_data(tt),dayReturn=float(nav/prev-1),sameStartDayEffect=effect,changedFills=not np.array_equal(tt,ts))
   account['variants'][name]=variant;same.append(dict(date=date,base=b,rule=name,triggerBar=j,dayEffect=effect,changedFills=variant['changedFills']))
  rec['accounts'][b]=account
 records.append(rec)
# Oct9 remains an explicitly separate observed case; never appended to performance.
obs=json.loads((O/'oct9_observations.json').read_text());cx=json.loads((R/'work/hudian-backtest-dashboard/docs/live-context.json').read_text());fo=foreign.loc['2026-10-09']
q=json.loads((R/'work/hudian-backtest-dashboard/docs/latest-quote.json').read_text())['quote']
today=dict(date='2026-10-09',status='observedReplayPartial',foreignDate=fo.QQQ_date,externalRisk=bool(fo.risk),overseas={s:float(fo[s]) for s in ['QQQ','SMH','NVDA','TTMI']},previousRSI=cx['rsi'],growth=cx['growth'],signals=obs['signals'],open=q['open'],close=q['price'],accounts={})
for b,r in raw.items():
 ts=r['trades'];sh=ts[-1,7];cash=r['nav'][-1]-sh*e.C[-1];px=111.5;eq=cash+sh*px
 today['accounts'][b]=dict(shares=int(sh),cash=float(cash),oldAvailable=int(sh),target=1.5 if b=='L' else 1.,referenceExposure=float(sh*px/eq),scheduled='10:00')
(O/'daily_review.json').write_text(json.dumps(dict(days=records,today=today),ensure_ascii=False,separators=(',',':')));pd.DataFrame(same).to_csv(O/'same_start_daily.csv',index=False)
# Independent no-risk regression, synthetic sell-only / lower-target / T+1 safeguards.
mi=pd.read_csv(O/'metrics.csv').set_index(['name','period']);old=pd.read_csv(R/'outputs/ma_geometry/metrics.csv').set_index(['name','period']);parity=0
for b in ['D','L']:
 for p in old.index.get_level_values('period').unique():
  for k in ['return_','mdd5','orders','fees','episodeCount','episodeWinRate']:
   assert np.isclose(mi.loc[(b+'_base',p),k],old.loc[(b+'_base',p),k],rtol=0,atol=1e-7);parity+=1
b=np.ones((2,48,6))*100;b[:,:,4]=1e7;b[:,:,5]=1e9;s=np.full((2,48),-1.);zeros=np.zeros(2);ones=np.ones(2)
def synthetic(signals):return eng.execute(b,ones*100,zeros,zeros,ones*100,ones*.0005,ones*.00001,np.array([0,1]),signals,0,2,np.full(2,2))
s[0,2]=-200;assert len(synthetic(s)[3])==0
s[0,6]=1.5;r=synthetic(s);assert all(t[10]<=1 for t in r[3]) and r[1].max()<=1
s[:]=-1;s[0,6]=1.5;s[0,7]=-200;r=synthetic(s);assert not any(t[2]<0 for t in r[3]) and r[1][0]>1.4
s[:]=-1;s[0,6]=1.5;s[1,2]=-201;r=synthetic(s);assert r[1][-1]==0 and any(t[2]<0 and t[10]==0 for t in r[3])
s[1,2]=-200;r=synthetic(s);assert .99<r[1][-1]<1.01 and any(t[2]<0 for t in r[3])
# No synthetic cap or new original order silently increases an earlier reduction target.
assert len(records)==sum(e.DATES>='2026-01-01') and len({x['date'] for x in records})==len(records)
audit=dict(reviewDays=len(records),todaySeparate=True,sameStartCases=len(same),changedDayPrefixChecks=pairedChecks,noRiskBaselineMetrics=parity,syntheticChecks=5,overseasSingleSource=True,minuteHistoryResolution=5,minute3ReversalBacktested=False,defaultChanged=False)
(O/'review_audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit));ss=pd.DataFrame(same);print(ss.groupby(['base','rule']).agg(triggerDays=('triggerBar',lambda x:(x>=0).sum()),changedDays=('changedFills','sum'),positive=('dayEffect',lambda x:(x>1e-10).sum()),negative=('dayEffect',lambda x:(x< -1e-10).sum()),meanEffect=('dayEffect','mean')).to_string());print(json.dumps(today['accounts']))
