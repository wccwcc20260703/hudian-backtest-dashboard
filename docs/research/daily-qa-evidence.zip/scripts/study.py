from pathlib import Path
import sys,json,hashlib,datetime
from zoneinfo import ZoneInfo
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/daily_qa';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
import risk_engine as engine
e=f.e;P=np.load(R/'work/leverage/plans.npz');freeze=np.searchsorted(e.DATES,'2025-01-01');cut=np.searchsorted(e.DATES,'2026-07-01')
manifest=dict(createdAt=pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),question='Why can a local buy observation coexist with overnight US risk, and can a sell-only morning risk cap improve the model?',rules={'external':'New completed US session available by China09:25, latest single-session QQQ<=-1% AND SMH<=-2%; first09:40..10:30 checkpoint with last2 completed5min closes below their corresponding cumulativeVWAP*0.999 and latestclose<open.', 'failure':'Regardless overseas: two consecutive completed5mincloses above their own cumulativeVWAP*1.001, followed later by two below their own VWAP*.999 before10:30.', 'combined':'First of external or failure. No threshold search.'},execution='Risk caps cash at50%, financing at100%,sellonly when inherited exposure exceeds cap; subsequent original orders thatday capped too. Does not buy merely because risk appeared; reset cap nextday. Preserve genuine original lower target inclzero,maintenance,T+1,volume,fees,buydebt<=50%equity. No automatic upgrade.',timing='5min proxies cannot reconstruct3min reversal. j2=09:40 usesfirst2completebars; no Oct9one-minute live historical efficacy claim. All archivedhistory alreadyseen. Freeze/train through2024,2025and2026halfyear separately,quarterlypreceding252days.',data='US Yahoo single source not independently verified; QQQ broad Nasdaq100proxy,SMH sectorproxy, not actual indices. Most recent singleUSsession contrasted with accumulated holidayreturn, no same-day USfutureclose. Historical throughOct8; Oct9separate observed case, dataextrema discrepancy remains.',freezeSHA256=hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest())
(O/'plan_before_results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
allDates=list(map(str,e.DATES))+['2026-10-09'];align=[];us={};levelchecks=0
for symbol in ['QQQ','SMH','NVDA','TTMI']:
 df=pd.read_csv(R/'outputs/overseas'/(symbol+'_clean.csv'));sec=df.knownSec.to_numpy();price=df.adjclose.to_numpy();items=[]
 for date in allDates:
  cutoff=datetime.datetime.combine(datetime.date.fromisoformat(date),datetime.time(9,25),ZoneInfo('Asia/Shanghai')).timestamp();ix=int(np.searchsorted(sec,cutoff,side='left')-1);valid=np.flatnonzero(sec<cutoff);assert ix==valid[-1];levelchecks+=1
  val=dict(date=date,symbol=symbol,foreignDate=df.date.iloc[ix],knownUTC=df.knownUTC.iloc[ix],return_=float(price[ix]/price[ix-1]-1),cutoffUTC=datetime.datetime.fromtimestamp(cutoff,datetime.timezone.utc).isoformat(),index=ix)
  align.append(val);items.append(val)
 us[symbol]=items
foreign=pd.DataFrame({'date':allDates})
for s in us:
 foreign[s]=[r['return_'] for r in us[s]];foreign[s+'_date']=[r['foreignDate'] for r in us[s]]
foreign['new']=foreign.QQQ_date.ne(foreign.QQQ_date.shift());foreign.loc[0,'new']=False
foreign['risk']=(foreign.QQQ<=-.01)&(foreign.SMH<=-.02)&foreign.new
foreign.to_csv(O/'foreign.csv',index=False);pd.DataFrame(align).to_csv(O/'alignment.csv',index=False)
def flags(b,j):
 h=b[:j];vw=np.cumsum(h[:,5])/np.cumsum(h[:,4]);above=h[:,3]>vw*1.001;below=h[:,3]<vw*.999
 weak=bool(below[-2:].all() and h[-1,3]<h[0,0]);failure=False
 if j>=4 and below[-2:].all():failure=bool(np.any(above[:-3]&above[1:-2]))
 return weak,failure
gates={n:np.full(e.N,-1,int) for n in manifest['rules']};events=[];prefix=0
for d in range(e.N):
 for j in range(2,13):
  weak,fail=flags(e.B[d],j);ext=bool(foreign.risk.iloc[d] and weak)
  for n,flag in [('external',ext),('failure',fail),('combined',ext or fail)]:
   if flag and gates[n][d]<0:gates[n][d]=j
  bad=e.B[d].copy();bad[j:]*=1000;assert flags(bad,j)==(weak,fail) and flags(e.B[d,:j],j)==(weak,fail);prefix+=1
 events.append(dict(date=str(e.DATES[d]),overseasRisk=bool(foreign.risk.iloc[d]),external=int(gates['external'][d]),failure=int(gates['failure'][d]),combined=int(gates['combined'][d])))
pd.DataFrame(events).to_csv(O/'events.csv',index=False)
plans={}
for b,key in [('D','D'),('L','D_all_full_1.5')]:
 plans[b+'_base']=P[key].copy();cap=.5 if b=='D' else 1.
 for name,gate in gates.items():
  p=P[key].copy()
  for d in np.flatnonzero(gate>=0):
   j=gate[d];p[d,j]=-100-cap*100-(p[d,j]+1)
  plans[b+'_'+name]=p
src=(R/'work/chase_guard/study.py').read_text();exec(src[src.index('original_metrics=f.metrics'):src.index('exec(tail)')])
src=(R/'work/support_factors/study.py').read_text();tail=src[src.index('modes=np.full(e.N,2)'):]
tail=tail.replace("R/'work/support_factors/plans.npz'","R/'work/daily_qa/plans.npz'")
tail=tail.replace("for y in range(3):periods", "periods.update(ytd=(np.searchsorted(e.DATES,'2026-01-01'),e.N),h1=(np.searchsorted(e.DATES,'2026-01-01'),cut),year2025=(freeze,np.searchsorted(e.DATES,'2026-01-01')))\nfor y in range(3):periods")
tail=tail.replace("['full','validation','recent','older']", "['full','validation','recent','older','ytd','h1','year2025']")
exec(tail)
for name,r in results.items():np.savez_compressed(O/(name+'_raw.npz'),nav=r[0],exposure=r[1],trades=r[3],debt=r[5],interest=r[6])
# Every2026session gets a same-inherited-state one-day counterfactual for V2 combined.
paired=[]
for b in ['D','L']:
 base=results[b+'_base'];ix=np.searchsorted(e.DATES,'2026-01-01')
 for d in range(ix,e.N):
  j=gates['combined'][d];local=d-e.START;prev=base[0][local-1] if local else 1e6
  if j<0:nav=base[0][local];tr=base[3][base[3][:,0]==d]
  else:
   p=plans[b+'_base'].copy();p[d]=plans[b+'_combined'][d];rr=run(b+'_base',e.START,d+1) if False else engine.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,p,e.START,d+1,modes)
   assert np.allclose(rr[0][:-1],base[0][:local],rtol=0,atol=1e-6);nav=rr[0][-1];tr=rr[3][rr[3][:,0]==d]
  paired.append(dict(date=str(e.DATES[d]),base=b,triggerBar=int(j),baseClose=base[0][local],alternativeClose=nav,dayEffect=(nav-base[0][local])/prev,trades=tr.tolist()))
(O/'paired_days.json').write_text(json.dumps(paired,separators=(',',':')))
print('Paired2026days',len(paired))
