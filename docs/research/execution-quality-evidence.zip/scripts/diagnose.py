# -*- coding: utf-8 -*-
from pathlib import Path
import json,numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/execution_quality';data=json.loads((R/'work/hudian-backtest-dashboard/docs/data.json').read_text());plan=np.load(R/'work/execution_quality/plans.npz');results=np.load(R/'work/execution_quality/full_results.npz');start=len(plan['D_base'])-len(data['dates']);rows=[]
for base in ['D','L']:
 weights=plan[base+'_base'].max(axis=1)
 for t in results[base+'_base_trades']:
  d=int(t[0]);prev=weights[d-1] if d else 0;category='目标增加' if weights[d]>prev else '目标降低' if weights[d]<prev else '目标不变的补仓或调整';side='买入' if t[2]>0 else '卖出';net=t[2]*t[3]*(data['close'][d-start]-t[4])-t[5];rows.append(dict(base=base,date=data['dates'][d-start],side=side,category=category,qty=t[3],net=net,notional=t[3]*t[4]))
df=pd.DataFrame(rows);groups=df.groupby(['base','date','side','category'])[['net','notional']].sum().reset_index();groups['success']=groups.net>0
res=groups.groupby(['base','side','category']).agg(days=('net','size'),wins=('success','sum'),rate=('success','mean'));res.to_csv(O/'original_order_types.csv');print(res.to_string())
x=pd.read_csv(O/'events.csv');x=x[x.date>='2023-10-09'];print(x.groupby(['base','direction','reason']).size());(O/'modified_schedule_counts.json').write_text(json.dumps({b:int(((x.base==b)&(x.newBar!=x.oldBar)).sum()) for b in ['D','L']},indent=2))
