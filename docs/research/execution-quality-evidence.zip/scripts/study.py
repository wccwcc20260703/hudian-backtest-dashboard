# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/execution_quality';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
sys.path.insert(0,str(R/'work/drift'));import drift_engine as engine
e=f.e;P=np.load(R/'work/leverage/plans.npz');freeze=int(np.searchsorted(e.DATES,'2025-01-01'));cut=int(np.searchsorted(e.DATES,'2026-07-01'));modes=np.full(e.N,2)
manifest={'at':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'Can bounded price-improvement waiting or splitting improve intraday closing-direction hit rate AND portfolio returns with the original daily final targets?','novelty':'Earlier unconditional VWAP/10:30/opening-break waiting and fade/skip-chase already failed. This batch tests bounded reference-price improvement conditional on gap/volume and staged targets; no repeat grid search.','rules':{'buy_guard':'On an original target increase only, at scheduled time: stretched if last completed close > VWAP+0.25 lagged ATR, or panic if gap<=-1%, cumulative volume>=1.2 prior20same-time mean and close<VWAP. Wait at most30min; stretched recovers when close<=initial anchor-0.25ATR and last2closes rise; panic recovers when above contemporaneous VWAP and last2closes rise. Execute next open; mandatory original final target at deadline if absent.','sell_guard':'On original target decrease only, if gap>=0, lastclose>VWAP and same-time volume>=1.2: wait at most30min for close>=anchor+0.25ATR and last2closes fall, OR last2closes below their VWAPs. Execute next open, deadline fallback.','both_guard':'Apply buy_guard and sell_guard separately.','split15':'On target changes schedule midpoint of prior and current DAILY target at original time and final original target15minutes later; equal targets unchanged. This is target-path splitting, not exact half of filled shares.'},'fixed':{'cash':'D','financing':'D/all_full150/buy_cap_only; new buy debt<=50%net equity','same':['T+1','100-share lots','prior5minvolume1%','5/10bp adverse slip','fees','6%calendarinterest','assumed maintenance floor150%'],'unconditionalTarget':'Final scheduled target remains original; realized holding may differ under constraints.'},'selection':'Train2023Oct9..2024Dec31; at least10 modified scheduled days, maxDD<=base+2pp, rank annual logwealth-1.5absDD; base always eligible. Freeze separately cash/finance; 2025Jan..2026Jun validation and Jul..Oct8 recent. Quarterly prior252day selection, no future candidates or threshold tuning.','success':'Buy qty*(close-fill)-fee>0; sell qty*(fill-close)-fee>0, group date+side to prevent split-order inflation; financing interest in portfolio return but not perfill classification. Not T+0 realized profit.','acceptance':'Incremental must beat base return both validation/recent, DD<=base+2pp, >=2/3fixedannual, older return>=base, 10bp both validation/recent; original cash return>=hold and DD<=75%hold +2/3annual+older+independent evidence kept; wealth1.20 separate. No forward evidence.','data':'All history2020..2026Oct8 already examined, retrospective chronological evidence. Oct9 acquired bars still have provider extreme mismatch and remain excluded. New features use completed closes, not intrabar high/low touch fills. ATR from prior completed days; revisions of adjusted data not independently PIT audited.','priorFreezeSHA':hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(O/'plan_before_results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
cv=np.cumsum(e.B[:,:,4],axis=1);vw=np.cumsum(e.B[:,:,5],axis=1)/np.maximum(cv,1);expected=pd.DataFrame(cv).rolling(20,min_periods=20).mean().shift().to_numpy();atr=(e.ATR/e.Q.close).shift().loc[e.DATES].to_numpy()*e.REF
def decisions(b,ref,aa,expect,j,direction):
 h=b[:j];volume=h[:,4].sum();vwap=h[:,5].sum()/max(volume,1);anchor=h[-1,3];gap=b[0,0]/ref-1;vr=volume/expect[j-1] if expect[j-1]>0 else 0
 stretch=direction>0 and anchor>vwap+.25*aa;panic=direction>0 and gap<=-.01 and vr>=1.2 and anchor<vwap;strong=direction<0 and gap>=0 and vr>=1.2 and anchor>vwap;eligible=stretch or panic or strong
 if not eligible:return j,'unchanged'
 for k in range(j+1,min(j+6,len(b)-1)+1):
  h=b[:k];pc=h[-1,3];pv=h[-2,3];v=h[:,5].sum()/max(h[:,4].sum(),1);vprev=h[:-1,5].sum()/max(h[:-1,4].sum(),1)
  ok=(pc<=anchor-.25*aa and pc>pv) if stretch else (pc>v and pc>pv) if panic else ((pc>=anchor+.25*aa and pc<pv) or (pc<v and pv<vprev))
  if ok:return k,'stretch' if stretch else 'panic' if panic else 'strong'
 return j+6,'deadline'
plans={};events=[];checks=0
for base,key in [('D','D'),('L','D_all_full_1.5')]:
 original=P[key];weights=original.max(axis=1);plans[base+'_base']=original.copy()
 for rule in manifest['rules']:plans[base+'_'+rule]=original.copy()
 for d in range(e.N):
  j=int(np.flatnonzero(original[d]>=0)[0]);w=weights[d];prev=weights[d-1] if d else 0;direction=int(np.sign(w-prev))
  if not direction:continue
  bar,reason=decisions(e.B[d],e.REF[d],atr[d],expected[d],j,direction)
  # Poison every not-yet-completed bar after the final decision; schedule must be invariant.
  poisoned=e.B[d].copy();poisoned[bar:]*=19
  assert decisions(poisoned,e.REF[d],atr[d],expected[d],j,direction)==(bar,reason);checks+=1
  if d>=20:assert np.isclose(expected[d,j-1],e.B[d-20:d,:j,4].sum(axis=1).mean());checks+=1
  for rule in ['buy_guard','sell_guard','both_guard']:
   if rule=='both_guard' or rule=='buy_guard' and direction>0 or rule=='sell_guard' and direction<0:plans[base+'_'+rule][d,j]=-1;plans[base+'_'+rule][d,bar]=w
  s=plans[base+'_split15'];s[d,j]=(prev+w)/2;s[d,j+3]=w
  events.append(dict(base=base,date=str(e.DATES[d]),oldBar=j,newBar=bar,reason=reason,direction=direction,originalTarget=w,priorTarget=prev))
pd.DataFrame(events).to_csv(O/'events.csv',index=False);np.savez_compressed(R/'work/execution_quality/plans.npz',**plans)
def run(name,a,z,slip=.0005):return engine.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,plans[name],a,z,modes,slip=slip)
def hit(r):
 t=r[3];out={}
 for sign,label in [(1,'buy'),(-1,'sell')]:
  tr=t[t[:,2]==sign];amounts={};returns=[]
  for v in tr:
   d=int(v[0]);net=sign*v[3]*(e.C[d]-v[4])-v[5];amounts[d]=amounts.get(d,0)+net;returns.append(net/(v[3]*v[4]))
  out[label+'Days']=len(amounts);out[label+'Wins']=sum(v>1e-8 for v in amounts.values());out[label+'Hit']=float(np.mean(np.array(list(amounts.values()))>1e-8)) if amounts else None;out[label+'Fills']=len(tr)
 return out
periods={'train':(e.START,freeze),'validation':(freeze,cut),'recent':(cut,e.N),'full':(e.START,e.N),'older':(0,e.START)}
for y in range(3):periods['year'+str(y+1)]=(int(np.searchsorted(e.DATES,f'{2023+y}-10-09')),int(np.searchsorted(e.DATES,f'{2024+y}-10-09')))
selection=[]
def select(base,a,z):
 bm=f.metrics(run(base+'_base',a,z));eligible=[]
 for rule in ['base',*manifest['rules']]:
  name=base+'_'+rule;r=run(name,a,z);m=f.metrics(r);changed=int(np.any(plans[name][a:z]!=plans[base+'_base'][a:z],axis=1).sum());ok=rule=='base' or (changed>=10 and abs(m['mdd5'])<=abs(bm['mdd5'])+.02);score=np.log1p(m['return_'])/((z-a)/242)-1.5*abs(m['mdd5']);selection.append(dict(base=base,fromDate=str(e.DATES[a]),toDate=str(e.DATES[z-1]),name=name,eligible=ok,score=score))
  if ok:eligible.append((score,name))
 return max(eligible)[1]
choices={b:select(b,e.START,freeze) for b in ['D','L']};rolling=[];quarters=pd.PeriodIndex(e.DATES,freq='Q')
for b in ['D','L']:
 sig=plans[b+'_base'].copy()
 for q in quarters[freeze:].unique():
  ix=np.flatnonzero(quarters==q);a=max(freeze,int(ix[0]));z=int(ix[-1]+1);n=select(b,max(0,a-252),a);sig[a:z]=plans[n][a:z];rolling.append(dict(base=b,start=str(e.DATES[a]),end=str(e.DATES[z-1]),choice=n))
 plans[b+'_rolling']=sig
holds={p:e.run(np.ones((e.N,48)),a,z,hold=True,tax=0) for p,(a,z) in periods.items()};rows=[];stress=[];full={};continuous=[]
def leads(nav,h):
 lag=longest=0
 for flag in nav<h:lag=lag+1 if flag else 0;longest=max(longest,lag)
 n=np.r_[1e6,nav];hh=np.r_[1e6,h];return dict(cumulativeLead=float(np.mean(nav>h)),rolling63Lead=float(np.mean(n[63:]/n[:-63]>hh[63:]/hh[:-63])),longestLag=longest)
for name in plans:
 for p,(a,z) in periods.items():
  r=run(name,a,z);rows.append(dict(name=name,period=p,**f.metrics(r),**hit(r),**leads(r[0],holds[p][0])))
  if p=='full':full[name]=r;n=np.r_[1e6,r[0]];continuous.extend([dict(name=name,period='preJuly',return_=float(n[cut-e.START]/n[0]-1)),dict(name=name,period='postJuly',return_=float(n[-1]/n[cut-e.START]-1))])
  if p in ['validation','recent','full','older']:rr=run(name,a,z,.001);stress.append(dict(name=name,period=p,**f.metrics(rr),**hit(rr)))
for p,h in holds.items():rows.append(dict(name='hold',period=p,**e.metrics(h)))
metrics=pd.DataFrame(rows);metrics.to_csv(O/'metrics.csv',index=False);pd.DataFrame(stress).to_csv(O/'stress10bp.csv',index=False);pd.DataFrame(selection).to_csv(O/'selection.csv',index=False);pd.DataFrame(rolling).to_csv(O/'rolling_choices.csv',index=False);pd.DataFrame(continuous).to_csv(O/'continuous.csv',index=False)
# Reuse independently reconciled accounting: no execution-engine modifications this batch.
src=(R/'work/underperformance/study.py').read_text();ledgerCount=0;maxerr=0.;maxpnlerr=0.;exec(src[src.index('def accounting('):src.index('\nhc,ht=')]);paired=[]
def averages(r):
 groups={}
 for t in r[3]:
  key=(int(t[0]),int(t[2]));qty,gross,fees=groups.get(key,(0,0,0));groups[key]=(qty+t[3],gross+t[3]*t[4],fees+t[5])
 return {k:(g+k[1]*fee)/qty for k,(qty,g,fee) in groups.items()}
for name,r in full.items():
 _,ts=accounting(r);pd.DataFrame(ts).to_csv(O/(name+'_trades.csv'),index=False)
 if name.endswith('_base'):continue
 base=name[0]+'_base';a=averages(full[base]);b=averages(r)
 for key in a.keys()&b.keys():paired.append(dict(name=name,date=str(e.DATES[key[0]]),side=key[1],baselinePrice=a[key],newPrice=b[key],improvement=key[1]*(a[key]-b[key])/a[key]))
pd.DataFrame(paired).to_csv(O/'matched_execution.csv',index=False)
# Dashboard parity establishes current default and cash reference exactly.
js=json.loads((R/'work/hudian-backtest-dashboard/docs/data.json').read_text());assert list(e.DATES[e.START:])==js['dates'];assert np.isclose(f.metrics(full['D_base'])['return_'],5.141711216279998);assert np.isclose(f.metrics(full['L_base'])['return_'],11.852893569539711)
mi=metrics.set_index(['name','period']);st=pd.DataFrame(stress).set_index(['name','period']);accept={}
for b in ['D','L']:
 for rule in manifest['rules']:
  name=b+'_'+rule;base=b+'_base';wins=sum(mi.loc[(name,'year'+str(y)),'return_']>=mi.loc[(base,'year'+str(y)),'return_'] for y in range(1,4));ok=all(mi.loc[(name,p),'return_']>mi.loc[(base,p),'return_'] and abs(mi.loc[(name,p),'mdd5'])<=abs(mi.loc[(base,p),'mdd5'])+.02 for p in ['validation','recent']) and wins>=2 and mi.loc[(name,'older'),'return_']>=mi.loc[(base,'older'),'return_'] and all(st.loc[(name,p),'return_']>st.loc[(base,p),'return_'] for p in ['validation','recent']);accept[name]={'incrementalPass':bool(ok),'annualWins':int(wins),'independentEvidence':False}
audit=dict(prefixChecks=checks,verifiedFills=ledgerCount,maxLedgerError=maxerr,maxDailyPnLError=maxpnlerr,choices=choices,acceptance=accept,defaultChanged=False,independentEvidence=False,originalFreezeSHA=manifest['priorFreezeSHA']);(O/'audit.json').write_text(json.dumps(audit,indent=2));np.savez_compressed(R/'work/execution_quality/full_results.npz',**{n+'_'+k:r[i] for n,r in full.items() for i,k in enumerate(['nav','exposure','curve','trades'])})
print(metrics[metrics.period=='full'][['name','return_','mdd5','buyHit','sellHit','longestLag']].to_string(index=False));print(json.dumps(audit));print(metrics[metrics.name.isin(list(choices.values())+['D_base','L_base'])&metrics.period.isin(['validation','recent','older'])][['name','period','return_','mdd5','buyHit','sellHit']].to_string(index=False))
