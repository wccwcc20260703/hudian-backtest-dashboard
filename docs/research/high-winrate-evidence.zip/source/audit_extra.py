# -*- coding: utf-8 -*-
from pathlib import Path
import ast,json,sys,math,numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/high_winrate';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
e=f.e;COM=.0001;MIN=5
src=(R/'work/high_winrate/study.py').read_text();ns=globals()
for x in ast.parse(src).body:
 if isinstance(x,ast.FunctionDef):exec(ast.get_source_segment(src,x),ns)
d=e.START;ref=e.REF[d];close=e.C[d];e.REF[d]=100;e.C[d]=100
checks=[]
def bbase():
 b=np.full((48,6),100.);b[:,4]=1e8;b[:,5]=b[:,4]*100;return b
b=bbase();r,t=episode(d,{1:1},.0005,'small',b);assert r['complete'] and t[-1]['bar']==46 and r['net']<0;checks.append('flat roundtrip costs loss and forced14:50 exit')
b=bbase();b[2:,:4]=100.5;r,t=episode(d,{1:1},.0005,'small',b);assert t[-1]['bar']==3 and t[-1]['reason']=='take_profit' and t[-1]['triggerBar']==2;assert t[-1]['qty']<=5000;checks.append('buy target waits completedbar thennextopen,oldshares sold')
b=bbase();b[2:,:4]=99.5;r,t=episode(d,{1:-1},.0005,'small',b);assert t[-1]['bar']==3 and t[-1]['side']==1 and t[-1]['reason']=='take_profit';checks.append('reverseT exit buys sharesback,nextopen')
b=bbase();b[2:,:4]=98;r,t=episode(d,{1:1},.0005,'small',b);assert t[-1]['reason']=='stop' and t[-1]['bar']==3;checks.append('stop not omitted toinflate wins')
b=bbase();b[2:,:4]=100.5;b[2,4]=10000;r,t=episode(d,{1:1},.0005,'small',b);assert t[1]['qty']==100 and t[-1]['bar']==4 and r['complete'];checks.append('partial target exit respects previousvolume andpersists')
b=bbase();b[2:,:4]=90;r,t=episode(d,{1:1},.0005,'small',b);assert not r['complete'] and r['remaining']>0;checks.append('limitdown keeps unclosedinventory')
b=bbase();b[:,4]=0;r,t=episode(d,{1:1},.0005,'small',b);assert not r['traded'] and not t;checks.append('zero liquidity preventsorders')
e.REF[d]=ref;e.C[d]=close
# Window clusters are only deduplication descriptions; no new trading criteria.
a=pd.read_csv(O/'daily_execution.csv');win=pd.read_csv(O/'rolling60_80plus.csv');dateidx={str(v):i for i,v in enumerate(e.DATES)};clusters=[]
for variant,q in win.groupby('variant'):
 q=q.sort_values('end');q['block']=(q.end.map(dateidx).diff()!=1).cumsum()
 for block,z in q.groupby('block'):
  clusters.append(dict(variant=variant,firstWindowStart=z.start.iloc[0],lastWindowEnd=z.end.iloc[-1],overlappingWindows=len(z),peakHit=z.winRate.max(),minComplete=z.completed.min(),maxComplete=z.completed.max(),nextFullWindows=int((z.nextDays==60).sum()),nextMeanMin=z[z.nextDays==60].nextMean.min(),nextMeanMax=z[z.nextDays==60].nextMean.max()))
pd.DataFrame(clusters).to_csv(O/'high_window_clusters.csv',index=False)
# Profile robustness: all bin definitions were fixed before execution; later results kept regardless of success.
p=pd.read_csv(O/'condition_profiles.csv');w=p[(p.period=='early')&(p.slip==.0005)&(p.completed>=30)&(p.winRate>=.8)&(p.meanNet>0)][['variant','condition']]
follow=p.merge(w,on=['variant','condition']).sort_values(['variant','condition','slip','period']);follow.to_csv(O/'early_candidate_followthrough.csv',index=False)
# Marginal comparisons ofthe80%quarter vs all other dates (not an inference ofcausation).
q=a[(a.variant=='band_small')&(a.slip==.0005)&a.traded&(a.date>='2023-10-09')].copy();inside=(q.date>='2026-04-01')&(q.date<='2026-06-30');desc=[]
for label,x in [('highQuarter',q[inside]),('otherDates',q[~inside])]:
 for feature in ['gap','relVolume','vwapDistance','trend20','efficiency','marketMA60']:
  desc.append(dict(group=label,feature=feature,n=len(x),median=x[feature].median(),mean=x[feature].mean()))
 for feature,mask in [('sellFirst',x.side==-1),('afternoon',x.timeGroup=='afternoon'),('marketPositive',x.marketMA60>0),('trend20Up5',x.trend20>.05),('rangeER',x.efficiency<=.35)]:desc.append(dict(group=label,feature=feature,n=len(x),median=np.nan,mean=mask.mean()))
pd.DataFrame(desc).to_csv(O/'high_quarter_comparison.csv',index=False)
# Reconcile any reported complete win numerator directly from entry/exit fills.
fills=pd.read_csv(O/'fills.csv');checksPnL=0
for (date,variant,slip),t in fills.groupby(['date','variant','slip']):
 r=a[(a.date==date)&(a.variant==variant)&(a.slip==slip)].iloc[0]
 if r.complete:
  pnl=-(t.side*t.qty*t.price+t.fee).sum();assert abs(pnl-r.net)<1e-6;checksPnL+=1
p=O/'audit.json';audit=json.loads(p.read_text());audit.update(syntheticChecks=checks,completedPnLReconciliations=checksPnL,rollingClusters=len(clusters));p.write_text(json.dumps(audit,indent=2));print(json.dumps({'synthetics':len(checks),'completedPnLReconciliations':checksPnL,'clusters':len(clusters)}))
