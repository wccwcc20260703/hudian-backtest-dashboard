# -*- coding: utf-8 -*-
from pathlib import Path
import json
from datetime import datetime
R=Path.cwd();p=R/'work/research-checkpoint.json';c=json.loads(p.read_text());O=R/'outputs/high_winrate'
c['updatedAt']=datetime.now().astimezone().isoformat();c['activeBatch']='26_publication_verification';c['currentQuestion']='Batch26: actualcommission applied tostock/margin/ETF; 6newfixed Tvariants allnegative over3years. Band_small2026Q2 24/30=80%,+193.89/episode butfull62.53%,-142.19. 77/4008overlapping60daywindows>=80%withn20; earlyrange_small volume_low/trend_up80%fail later/older/10bp. No promotion.'
c['completed'].append('第二十六批：按实际佣金重算看板股票万1、ETF万0.6/最低5元，现金D537.26%、融资默认1226.51%/回撤25.20%，40,810项Python/JS一致。网络补测布林回归/早盘突破失败/单层网格×小止盈与对称退出6组；三年全负，胜率45.5-68.1%。布林小止盈2026Q224/30=80%均+194元，但10bp降73.3%；4008滚动窗77个>=80%/n20，重叠非独立。早期缩量与强势两个80%条件后期失败。6629前缀、29195账本、13242完整损益、72未来修改、7合成、192网页组合。outputs/high_winrate。')
c['userDefault']=json.loads((R/'work/hudian-backtest-dashboard/docs/default-selection.json').read_text())
c['userFeeProfile'].update(mainDashboardRecomputed=True,etfDashboardRecomputed=True,instruction='后续新研究显式加载work/user-fee-profile.json：股票/信用万1、ETF万0.6、每笔最低5元。主看板已更新；旧Python冻结引擎及历史研究仍保留万2.5以复现原结果，不得直接当新研究成本。新研究使用实际费率的独立执行层；若复用旧引擎需显式传入/版本化佣金并核对。')
c['highWinrate']={'output':'outputs/high_winrate','audit':json.loads((O/'audit.json').read_text()),'defaultRulesChanged':False,'highQuarter':'2026Q2 band_small24/30=80%,mean193.887362;95%Wilson62.7-90.5%;10bps73.33%,mean57.34','earlyConditionsFailLater':['range_small vol_low early80%,later70.49%/-117','range_small trend_up early80.43%,later63.71%/-269'],'reportURL':'https://wccwcc20260703.github.io/hudian-backtest-dashboard/research/high-winrate.html'}
c['networkLearning']['latestBatchSources']=str(O/'sources.json');c['networkLearning']['latestOutcomes']='Band reentry,opening range failure,single-grid 6fixedrules tested; allfullnegative.80%localwindowsdescriptiveonly,early80%conditionsfailedlater. No guaranteed hitrate ordefaultpromotion.'
c['next']=['以实际费率继续：股票/信用万1、ETF万0.6、最低5元，佣金不等于融资利息。旧冻结引擎及旧报告保留原费率，新实验不得误用万2.5。','不再搜索80%历史窗口；本轮已列全4008窗与77个重叠成功窗。优先预登记较强日线/大盘背景与局部过度偏离的少量交互，区分布林回归与沿轨趋势；先验证买卖方向是否不同。','2026Q2股性画像：前20日涨幅中位19.7%、大盘高于MA60占83.3%、量比约1；午后占86.7%与其他日期83.8%接近、ER也未更低，不能把午后/震荡当作已证实因子。早期缩量/强势两个80%条件已在后期及10bp失效，保留失败。','如后续候选跨期、费用、概率校准通过，再进入独立现金和融资连续账户；保留原收益/回撤、2/3固定年度、更早、10bp及冻结后独立证据要求，不放宽到只看胜率。']
p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print('Research checkpoint saved; awaiting publication receipt.')
