# -*- coding: utf-8 -*-
from pathlib import Path
import json,ast,math,numpy as np
R=Path.cwd();O=R/'outputs/high_winrate';d=json.loads((R/'work/hudian-backtest-dashboard/docs/data.json').read_text());g=json.loads((R/'work/hudian-backtest-dashboard/docs/finance-gates.json').read_text())
n=len(d['dates']);args=[np.array(d[k],float) for k in ['bars','close','dividend','bonus','reference','stamp','transfer']]
ns={'np':np,'math':math}
def get(path):
 s=Path(path).read_text();t=next(x for x in ast.parse(s).body if isinstance(x,ast.FunctionDef) and x.name=='execute');code=ast.get_source_segment(s,t).replace('.00025','.0001');exec(code,ns);return ns['execute']
cash=get('work/round2/engine.py');fin=get('work/drift/drift_engine.py');results={}
for name in ['D','H','B','L']:
 sig=np.full((n,48),-1.)
 for i,(j,v) in enumerate(d['signals']['D' if name in ['B','L'] else name]):sig[i][j]=v*(1.5 if name=='L' and v==1 and g['D']['all_full'][i] else 1)
 r=fin(*args,np.array(d['dates'],dtype='datetime64[D]').astype(np.int64),sig,0,n,np.full(n,2)) if name=='L' else cash(*args,sig,0,n,hold=name=='B',tax=0 if name=='B' else .2)
 results[name]={'nav':r[0].tolist(),'trades':r[3].tolist(),'fees':float(r[4][0])}
(O/'actual_fee_python.json').write_text(json.dumps(results,separators=(',',':')))
print('Independent Python: 4 full-history accounts at actual commission')
