# -*- coding: utf-8 -*-
from pathlib import Path
import json,sys,math,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/high_winrate';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
e=f.e;profile=json.loads((R/'work/user-fee-profile.json').read_text());COM=profile['stockCommission'];MIN=profile['stockMinimumPerOrder']
plan={'createdAt':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'Do previously untested band reentry, opening range failure, and single-grid reversal produce >=80% net wins in identifiable Hudian periods? Distinguish high hit rate from positive expectancy.', 'methods':{'band':'20 completed same-day 5min closes, population standard deviation*2. Previous close outside its own band then latest close reenters; buy lower/sell upper. No cross-day warmup; earliest 11:15 entry.', 'range':'First30min high/low frozen at10:00. A subsequent completed close breaks that range and the next completed close reenters; buy lower/sell upper. Earliest10:10.', 'grid':'First completed-close crossing of dayopen +/-0.75%; buy down/sell up. One layer, one cycle per day; NOT a reproduction of multi-layer resting-limit or auction strategy.'}, 'exits':{'small':'Completed close relative to actual entryfill reaches gross+0.35% favorable or -1.5% adverse; exit nextopen, otherwise14:50.', 'balanced':'Completed close relative to actual entryfill reaches gross+0.75% favorable or -0.75% adverse; exit nextopen, otherwise14:50.'}, 'execution':'First executable signal only, entry through14:00, no new roundtrip same day. Independent1m account with50%overnightstock,100kTbudget,200kcashreserve. No borrowing; T+1 sellonlyoldshares;100lots,1%priorbarvolume,price limits,adverse tickrounding,5/10bps each side. At exit persist attempts to14:50, unfinished markclose andretain. Completed-close triggers canmiss intrabar touches; no fabricated tickfills.', 'feeProfile':profile, 'evaluation':'All6 fixed variants. Full3years, earlythrough2024, later2025-June2026, Julyon, fixedannual, olderdata. Fixedcalendarquarters and every60tradingdayrollingwindow, at least20complete for80%flag; smallerreported separately. Windows overlap and are descriptive posthoc, not independent tests. Wilson95% is marginal,notmultiplicityadjusted. Allwindows retained. Outcome after flaggedwindow is mechanical next60days continuation, not virginholdout.', 'profiles':'Entry known only: buy/sell,morning/afternoon,gap +/-0.5%,prior20dayreturn +/-5%,volume ratio .8/1.5 vs prior20same-time,price/VWAP +/-0.2priorATR,ER fromopen<=.35,currentER<=.35 AND volume<1.5,priorSZindexvsMA60. No full-dayrange classification.', 'selection':'Train2023Oct-through2024 then keep rule; qualify >=30completed,win>=80%,netmean>0, choose netmean. Include noT. Quarterly walkforward prior252days same gate. No lower threshold ifnone. Train-defined profile candidates require >=30 and80%, then inspectlater/older.', 'noClaims':'Allhistoryseen. Cash research daily diagnostic, no continuousportfolio or financedalphaclaim. Main cash/margin dashboards repriced separately; no promotion of researchrules.', 'freezeSHA':hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(O/'plan_before_results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
p=R/'work/research-checkpoint.json';cp=json.loads(p.read_text());cp['activeBatch']='26_high_winrate';cp['currentQuestion']=plan['question'];p.write_text(json.dumps(cp,ensure_ascii=False,indent=2))
sources=[{'method':'band_reentry','url':'https://www.bollingerbands.com/bollinger-band-rules','evidence':'Primary creator rules: tags are not signals; trend can walk bands;20/2 default, not80%proof. Adaptation own fixed reentry rule.'},{'method':'range_failure','url':'https://www.fidelity.com/learning-center/trading-investing/trading/range-trading','evidence':'Broker range/support/volume educational guide. Our30min failed-breakout rule is an adaptation, not sourced verified80%system.'},{'method':'single_grid','url':'https://www.futunn.com/hk/learn/detail-grid-trading-strategy-53384-220487050','evidence':'Broker grid education, fixedintervalconcept; one-layer5minconfirmed adaptation, no claim fullbrokerstrategy replicated.'},{'method':'winrate_definition','url':'https://www.fidelity.com/research/backtesting/glossary.html','evidence':'Winrate and payoff evaluated separately. Socialclaims80-100% lack full dated ledger incl failedopenpositions.'}]
(O/'sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2))
def choices(b,method):
 cl=b[:,3];out={}
 if method=='band':
  ma=pd.Series(cl).rolling(20).mean().to_numpy();sd=pd.Series(cl).rolling(20).std(ddof=0).to_numpy();lower=ma-2*sd;upper=ma+2*sd
  for j in range(21,min(37,len(b))):
   if cl[j-2]<lower[j-2] and cl[j-1]>=lower[j-1]:out[j]=1
   elif cl[j-2]>upper[j-2] and cl[j-1]<=upper[j-1]:out[j]=-1
 elif method=='range':
  if len(b)<8:return out
  lo=b[:6,2].min();hi=b[:6,1].max()
  for j in range(8,min(37,len(b))):
   if cl[j-2]<lo and lo<=cl[j-1]<=hi:out[j]=1
   elif cl[j-2]>hi and lo<=cl[j-1]<=hi:out[j]=-1
 else:
  lo=b[0,0]*.9925;hi=b[0,0]*1.0075
  for j in range(1,min(37,len(b))):
   prev=cl[j-2] if j>=2 else b[0,0]
   if prev>lo and cl[j-1]<=lo:out[j]=1
   elif prev<hi and cl[j-1]>=hi:out[j]=-1
 return out

def fee(d,q,p,s):return max(MIN,q*p*COM)+q*p*(e.TRANSFER[d]+(e.STAMP[d] if s<0 else 0))
def px(p,s,slip):return math.ceil(p*(1+slip)*100-1e-8)/100 if s>0 else math.floor(p*(1-slip)*100+1e-8)/100

def episode(d,cc,slip,style,b=None):
 b=e.B[d] if b is None else b;old=int(500000/e.REF[d]/100)*100;cash0=1e6-old*e.REF[d];cash=cash0;sh=old;avail=old;left=0;first=-1;side0=0;entry=0.;q0=0;pending=False;reason='';fills=[];trigger=-1
 tp,stop=(.0035,.015) if style=='small' else (.0075,.0075)
 lo=round(e.REF[d]*.9+1e-8,2);hi=round(e.REF[d]*1.1+1e-8,2)
 for j in range(1,47):
  s=0;q=0;cap=int(b[j-1,4]*.01/100)*100;raw=b[j,0]
  if left:
   gain=side0*(b[j-1,3]/entry-1)
   if not pending:
    if gain>=tp:pending=True;reason='take_profit';trigger=j-1
    elif gain<=-stop:pending=True;reason='stop';trigger=j-1
    elif j>=46:pending=True;reason='time';trigger=j-1
   if pending:s=-side0;q=min(left,cap)
  elif first<0 and j in cc:s=cc[j];q=min(int(100000/px(raw,s,slip)/100)*100,cap,avail)
  if not s or q<=0:continue
  fill=px(raw,s,slip)
  if (s>0 and (raw>=hi-.005 or fill>hi)) or (s<0 and (raw<=lo+.005 or fill<lo)):continue
  if s<0:q=min(q,avail)
  if s>0:
   while q>0 and cash-q*fill-fee(d,q,fill,s)<200000-1e-8:q-=100
  if q<=0:continue
  cost=fee(d,q,fill,s);cash-=s*q*fill+cost;sh+=s*q
  if s<0:avail-=q
  if first<0:first=j;side0=s;entry=fill;left=q;q0=q;typ='entry'
  else:left-=q;typ=reason
  fills.append(dict(date=str(e.DATES[d]),bar=j,side=s,qty=q,price=fill,fee=cost,cash=cash,shares=sh,available=avail,reason=typ,triggerBar=trigger))
  assert avail>=0 and cash>=200000-1e-6
  if first>=0 and left==0:break
 net=cash+sh*e.C[d]-(cash0+old*e.C[d]);return dict(date=str(e.DATES[d]),day=d,traded=first>=0,entryBar=first,side=side0,quantity=q0,complete=first>=0 and left==0,remaining=left,net=net,exitReason=reason,fees=sum(t['fee'] for t in fills)),fills

cv=e.B[:,:,4].cumsum(axis=1);vw=e.B[:,:,5].cumsum(axis=1)/np.maximum(cv,1);exp=pd.DataFrame(cv).rolling(20,min_periods=20).mean().shift().to_numpy();rv=cv/exp
atr=(e.ATR/e.Q.close).shift().reindex(e.DATES).to_numpy()*e.REF
trend=e.Q.close.pct_change(20).shift().reindex(e.DATES).to_numpy();mkt=(e.SZ/e.SZ.rolling(60).mean()-1).shift().reindex(e.DATES).to_numpy()
def features(d,j):
 if j<1:return {}
 b=e.B[d];cl=b[j-1,3];gap=b[0,0]/e.REF[d]-1;den=np.abs(np.diff(np.r_[b[0,0],b[:j,3]])).sum();er=abs(cl-b[0,0])/den if den else 0
 return dict(gap=gap,relVolume=rv[d,j-1],vwapDistance=(cl-vw[d,j-1])/atr[d],trend20=trend[d],efficiency=er,marketMA60=mkt[d],timeGroup='morning' if j<24 else 'afternoon')
records=[];allfills=[];prefix=0
for d in range(e.N):
 for method in ['band','range','grid']:
  cc=choices(e.B[d],method)
  for j,s in cc.items():assert choices(e.B[d,:j+1],method).get(j)==s;prefix+=1
  for slip in [.0005,.001]:
   for style in ['small','balanced']:
    r,tt=episode(d,cc,slip,style);r.update(method=method,style=style,variant=method+'_'+style,slip=slip);r.update(features(d,r['entryBar']));records.append(r)
    for t in tt:t.update(variant=r['variant'],slip=slip);allfills.append(t)
a=pd.DataFrame(records);a.to_csv(O/'daily_execution.csv',index=False);tr=pd.DataFrame(allfills);tr.to_csv(O/'fills.csv',index=False)
def summary(q):
 b=q[q.traded];done=b[b.complete];w=done[done.net>0];loss=done[done.net<=0];n=len(done);p=len(w)/n if n else np.nan;z=1.96
 lo=((p+z*z/(2*n))-z*np.sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n) if n else np.nan
 hi=((p+z*z/(2*n))+z*np.sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n) if n else np.nan
 wins=b[b.net>0].net.sum();los=-b[b.net<0].net.sum()
 return dict(days=len(q),traded=len(b),completed=n,wins=len(w),winRate=p,wilsonLow=lo,wilsonHigh=hi,meanNet=b.net.mean(),sumNet=b.net.sum(),worst=b.net.min(),meanWin=w.net.mean(),meanLoss=loss.net.mean(),profitFactor=wins/los if los else np.nan,unfinished=int((~b.complete).sum()),targetExits=int((done.exitReason=='take_profit').sum()),stopExits=int((done.exitReason=='stop').sum()),timeExits=int((done.exitReason=='time').sum()))
periods={'full':('2023-10-09','2026-10-09'),'early':('2023-10-09','2025-01-01'),'later':('2025-01-01','2026-07-01'),'julyOn':('2026-07-01','2026-10-09'),'older':('1900','2023-10-09')}
for y in range(3):periods['year'+str(y+1)]=(f'{2023+y}-10-09',f'{2024+y}-10-09')
rows=[]
for per,(start,end) in periods.items():
 for (v,slip),q in a[(a.date>=start)&(a.date<end)].groupby(['variant','slip']):rows.append(dict(period=per,variant=v,slip=slip,**summary(q)))
metrics=pd.DataFrame(rows);metrics.to_csv(O/'metrics.csv',index=False)
# All predefined one-factor cells and one fixed interaction; never add bins after seeing hits.
def cells(q):
 return {'all':np.ones(len(q),bool),'buy':q.side==1,'sell':q.side==-1,'morning':q.timeGroup=='morning','afternoon':q.timeGroup=='afternoon','gap_down':q.gap<-.005,'gap_flat':q.gap.abs()<=.005,'gap_up':q.gap>.005,'vol_low':q.relVolume<.8,'vol_mid':(q.relVolume>=.8)&(q.relVolume<1.5),'vol_high':q.relVolume>=1.5,'trend_down':q.trend20<-.05,'trend_flat':q.trend20.abs()<=.05,'trend_up':q.trend20>.05,'vwap_below':q.vwapDistance<-.2,'vwap_near':q.vwapDistance.abs()<=.2,'vwap_above':q.vwapDistance>.2,'er_range':q.efficiency<=.35,'er_trend':q.efficiency>.35,'range_nonheavy':(q.efficiency<=.35)&(q.relVolume<1.5),'market_above':q.marketMA60>0,'market_below':q.marketMA60<=0}
profiles=[]
for per,(start,end) in periods.items():
 for (v,slip),q in a[(a.date>=start)&(a.date<end)&a.traded].groupby(['variant','slip']):
  for label,mask in cells(q).items():profiles.append(dict(period=per,variant=v,slip=slip,condition=label,**summary(q[mask])))
pr=pd.DataFrame(profiles);pr.to_csv(O/'condition_profiles.csv',index=False)
full=a[(a.date>='2023-10-09')&(a.slip==.0005)];quarter=[];windows=[]
for (v,quarterName),q in full.groupby(['variant',pd.PeriodIndex(full.date,freq='Q').astype(str)]):quarter.append(dict(variant=v,quarter=quarterName,start=q.date.min(),end=q.date.max(),**summary(q)))
qs=pd.DataFrame(quarter);qs.to_csv(O/'quarters.csv',index=False)
for v,q in full.groupby('variant'):
 q=q.sort_values('date').reset_index(drop=True)
 for last in range(59,len(q)):
  z=q.iloc[last-59:last+1];sm=summary(z);future=q.iloc[last+1:last+61];fm=summary(future)
  windows.append(dict(variant=v,start=z.date.min(),end=z.date.max(),**sm,nextDays=len(future),nextCompleted=fm['completed'],nextWin=fm['winRate'],nextMean=fm['meanNet']))
ws=pd.DataFrame(windows);ws.to_csv(O/'rolling60_all.csv',index=False)
ws[(ws.completed>=20)&(ws.winRate>=.8)].to_csv(O/'rolling60_80plus.csv',index=False)
qs[(qs.completed>=20)&(qs.winRate>=.8)].to_csv(O/'quarters_80plus.csv',index=False)
# Describe the features of every high-hit calendar quarter. Descriptive, not a trained filter.
qq=qs[(qs.completed>=20)&(qs.winRate>=.8)];desc=[]
for r in qq.itertuples():
 q=full[(full.variant==r.variant)&(full.date>=r.start)&(full.date<=r.end)&full.traded]
 for k in ['gap','relVolume','vwapDistance','trend20','efficiency','marketMA60']:
  desc.append(dict(variant=r.variant,quarter=r.quarter,feature=k,mean=q[k].mean(),median=q[k].median()))
pd.DataFrame(desc,columns=['variant','quarter','feature','mean','median']).to_csv(O/'high_quarter_features.csv',index=False)
# Chronological selection; no response-dependent thresholds.
walk=[]
for quarterName in sorted(set(pd.PeriodIndex(full.date,freq='Q').astype(str))):
 start=str(pd.Period(quarterName,freq='Q').start_time.date());end=str((pd.Period(quarterName,freq='Q')+1).start_time.date())
 if start<'2025-01-01':continue
 idx=int(np.searchsorted(e.DATES,start));first=str(e.DATES[max(0,idx-252)]);train=a[(a.date>=first)&(a.date<start)&(a.slip==.0005)];cand=[]
 for v,q in train.groupby('variant'):
  s=summary(q)
  if s['completed']>=30 and s['winRate']>=.8 and s['meanNet']>0:cand.append((s['meanNet'],v))
 chosen=max(cand)[1] if cand else 'none';test=full[(full.date>=start)&(full.date<end)&(full.variant==chosen)];walk.append(dict(quarter=quarterName,trainThrough=str(e.DATES[idx-1]),chosen=chosen,**summary(test)))
pd.DataFrame(walk).to_csv(O/'walkforward.csv',index=False)
trainCandidates=pr[(pr.period=='early')&(pr.slip==.0005)&(pr.completed>=30)&(pr.winRate>=.8)&(pr.meanNet>0)];trainCandidates.to_csv(O/'early_80_candidates.csv',index=False)
# Reconcile saved ledgers independently, with both entry directions and partial exits.
ledger=0
for (date,v,slip),q in tr.groupby(['date','variant','slip']):
 d=int(np.searchsorted(e.DATES,date));old=int(500000/e.REF[d]/100)*100;cash=1e6-old*e.REF[d];sh=old;av=old
 for t in q.itertuples():
  cash-=t.side*t.qty*t.price+fee(d,t.qty,t.price,t.side);sh+=t.side*t.qty
  if t.side<0:av-=t.qty
  assert abs(cash-t.cash)<1e-6 and sh==t.shares and av==t.available and t.qty<=int(e.B[d,int(t.bar)-1,4]*.01/100)*100
  assert t.triggerBar<t.bar
  ledger+=1
# Full price-array mutations after a cutoff must not change earlier signals/fills.
futureChecks=0
for d in np.linspace(e.START,e.N-1,12,dtype=int):
 for method in ['band','range','grid']:
  b=e.B[d].copy();bb=b.copy();bb[30:,:4]*=1.04
  assert {j:s for j,s in choices(b,method).items() if j<=30}=={j:s for j,s in choices(bb,method).items() if j<=30}
  for style in ['small','balanced']:
   _,x=episode(d,choices(b,method),.0005,style,b);_,y=episode(d,choices(bb,method),.0005,style,bb)
   assert [t for t in x if t['bar']<30]==[t for t in y if t['bar']<30];futureChecks+=1
result={'signalPrefixChecks':prefix,'ledgerFills':ledger,'ledgerError':0,'futureMutationChecks':futureChecks,'variants':6,'allRollingWindows':len(ws),'rolling80n20':int(((ws.completed>=20)&(ws.winRate>=.8)).sum()),'quarterCells':len(qs),'quarters80n20':len(qq),'early80Candidates':len(trainCandidates),'cashOnlyIndependentDaily':True,'notNewBlindTest':True,'defaultRulesChanged':False,'fee':COM,'freezeSHA':plan['freezeSHA']}
(O/'audit.json').write_text(json.dumps(result,indent=2));print(metrics[(metrics.period=='full')&(metrics.slip==.0005)].to_string(index=False));print('QUARTERS80',qq.to_string(index=False));print('ROLL80',ws[(ws.completed>=20)&(ws.winRate>=.8)].head(12).to_string(index=False));print('EARLY80',trainCandidates.to_string(index=False));print(json.dumps(result))
