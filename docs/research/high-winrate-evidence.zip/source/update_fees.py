# -*- coding: utf-8 -*-
from pathlib import Path
import re
root=Path('work/hudian-backtest-dashboard')
(root/'docs/fees.js').write_text('''// User-provided current rates, 2026-10-09. Minimum applies to each fill/order.\nexport const STOCK_COMMISSION=.0001;\nexport const ETF_COMMISSION=.00006;\nexport const MIN_COMMISSION=5;\nexport const FEE_VERSION='actual-20261009';\n''')
for sub in ['', 'star50/']:
 for name in ['engine.js','finance-engine.js']:
  p=root/'docs'/sub/name;s=p.read_text();constant='ETF_COMMISSION' if sub else 'STOCK_COMMISSION';rel='../fees.js' if sub else './fees.js'
  s=f"import {{{constant},MIN_COMMISSION,FEE_VERSION}} from '{rel}';\n"+s
  s=s.replace('capital=1e6,slip=.0005','capital=1e6,commission='+constant+',minCommission=MIN_COMMISSION,slip=.0005')
  s=s.replace('.00025','commission').replace('cash-5','cash-minCommission').replace('cash+credit-5','cash+credit-minCommission').replace('allowed*5','allowed*minCommission').replace('Math.max(5,gross*commission)','Math.max(minCommission,gross*commission)')
  # Reject invalid fee settings before any execution.
  sig=s.index('\n',s.index('export function'))+1
  s=s[:sig]+" if(!Number.isFinite(commission)||commission<0||!Number.isFinite(minCommission)||minCommission<0)throw Error('无效佣金参数');\n"+s[sig:]
  s=s.replace('return {model,start','return {commission,minCommission,feeVersion:FEE_VERSION,model,start').replace("return {model:'L',config:{", "return {commission,minCommission,feeVersion:FEE_VERSION,model:'L',config:{commission,minCommission,")
  p.write_text(s)
p=root/'docs/live-presentation.js';s=p.read_text();s="import {STOCK_COMMISSION,MIN_COMMISSION} from './fees.js';\n"+s;s=s.replace("config={},slip", "config={},commission=STOCK_COMMISSION,minCommission=MIN_COMMISSION,slip").replace('.00025','commission').replace('allowed*5','allowed*minCommission').replace('cash+config.credit-5','cash+config.credit-minCommission').replace('Math.max(5,gross*commission)','Math.max(minCommission,gross*commission)');p.write_text(s)
# Explicit historical fees keep original independently generated fixtures meaningful.
p=root/'tests/parity.test.js';s=p.read_text().replace('f.start,f.end,f)','f.start,f.end,{...f,commission:.00025})');p.write_text(s)
p=root/'tests/finance.test.js';s=p.read_text().replace("{...f,driftPolicy:","{...f,commission:.00025,driftPolicy:");p.write_text(s)
p=root/'tests/star50.test.js';s=p.read_text().replace("{base:'H',gate:'trend',slip:f.slip}","{base:'H',gate:'trend',slip:f.slip,commission:.00025}").replace('{slip:f.slip}','{slip:f.slip,commission:.00025}');p.write_text(s)
p=root/'docs/index.html';s=p.read_text().replace('佣金万 2.5','佣金万 1（普通与信用账户一致）')
s=re.sub(r'<p>2023-10-09 至 2026-10-08：收益.*?</p>','<p id="default-cost-result">按实际佣金重新计算当前默认方案…</p>',s)
s=re.sub(r'例如同一融资方案：全期 .*?（显示值四舍五入）。','复利关系：（1＋7月前收益）×（1＋7月后收益）−1＝全期收益。',s)
s=re.sub(r'<p>2023-10-09 至 2026-06-30，D 的所有满仓信号.*?</p>','<p id="default-prejuly-result">按实际佣金重新计算7月前表现…</p>',s)
s=s.replace('<p id="range-note"','<p class="footnote">当前成本：股票佣金万1，每笔最低5元；印花税、过户费与滑点另计，融资年息仍为独立假设。历史研究归档保留当时费率，勿与当前结果混用。</p><p id="range-note"')
p.write_text(s)
p=root/'docs/star50/index.html';s=p.read_text().replace('佣金假设万2.5','按用户ETF佣金万0.6');p.write_text(s)
# Replace static performance claims with fresh default runs under the same fee assumptions.
p=root/'docs/app.js';s=p.read_text();where=' if(liveMarket)renderLive(liveMarket,liveCached);'
addition='''
 const dc={...options,base:'D',gate:'all_full',driftPolicy:'buy_cap_only',level:1.5,rate:.06,credit:null};
 const fullDefault=financeBacktest(data,financeGates,0,data.dates.length,dc),fb=liveResults.B;
 const fullA=attribution(fullDefault,fb,data.dates),cut=data.dates.findIndex(d=>d>='2026-07-01');
 $('default-cost-result').textContent=`${data.dates[0]} 至 ${data.dates.at(-1)}，默认组合按当前本金与滑点、佣金万1计算：收益 ${pct(fullDefault.metrics.return_)}，最大回撤 ${fmt(-fullDefault.metrics.mdd5*100)}%，最长累计落后 ${fullA.longestBehind} 个交易日。历史研究归档保留旧费率。`;
 if(cut>0){const pre=financeBacktest(data,financeGates,0,cut,dc),pb=backtest(data,'B',0,cut,options),pa=attribution(pre,pb,data.dates.slice(0,cut));
 $('default-prejuly-result').textContent=`${data.dates[0]} 至 ${data.dates[cut-1]}，当前默认组合：收益 ${pct(pre.metrics.return_)}，最大回撤 ${fmt(-pre.metrics.mdd5*100)}%，累计领先持有 ${fmt(pa.leadFraction*100,1)}%；同期持有 ${pct(pb.metrics.return_)} / 回撤 ${fmt(-pb.metrics.mdd5*100)}%。佣金万1；这不是独立验证。`;}
'''
assert where in s;s=s.replace(where,addition+where,1);p.write_text(s)
print('Updated cash/margin/ETF engines and estimates; historical fixtures use explicit old fee.')
