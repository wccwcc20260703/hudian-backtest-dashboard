# -*- coding: utf-8 -*-
from pathlib import Path
import json,subprocess,hashlib,concurrent.futures,requests
from datetime import datetime
R=Path.cwd();repo=R/'work/hudian-backtest-dashboard';O=R/'outputs/high_winrate';sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();paths=subprocess.check_output(['git','show','--pretty=format:','--name-only','HEAD'],cwd=repo,text=True).splitlines();paths=[p for p in paths if p.startswith('docs/')];base='https://wccwcc20260703.github.io/hudian-backtest-dashboard/'
def check(p):
 rel=p[len('docs/'):];resp=requests.get(base+rel+'?v='+sha,timeout=30);resp.raise_for_status();actual=hashlib.sha256(resp.content).hexdigest();want=hashlib.sha256((repo/p).read_bytes()).hexdigest();assert actual==want,(rel,actual,want);return {'path':rel,'sha256':actual,'bytes':len(resp.content)}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:files=list(pool.map(check,paths))
receipt={'commit':sha,'verifiedAt':datetime.now().astimezone().isoformat(),'files':files,'feeStock':.0001,'feeETF':.00006,'minCommission':5,'testSummary':'Cash/margin current Python parity40810; stock2527/ETF297feeledgers; legacy suite andSTAR5040cases;192researchUIcombinations; HTML/JS/ZIPchecks','url':base+'?v='+sha[:12],'researchURL':base+'research/high-winrate.html?v='+sha[:12]}
(O/'publication.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));p=R/'work/research-checkpoint.json';c=json.loads(p.read_text());c['activeBatch']=None;c['updatedAt']=receipt['verifiedAt'];c['latestPublishedCommit']=sha;c['latestCommit']=sha;c['publicationVerification']=receipt;c['highWinrate']['publication']=receipt;c['latestDashboardChange']='实际佣金：股票/信用万1、ETF万0.6、最低5元；完整账户与买卖数量试算重算，静态收益说明改为动态；默认交易规则保留。';c['latestDashboardVerifiedAt']=receipt['verifiedAt'];p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'commit':sha,'filesVerified':len(files),'url':receipt['url'],'researchURL':receipt['researchURL']}))
