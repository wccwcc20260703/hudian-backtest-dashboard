# -*- coding: utf-8 -*-
from pathlib import Path
import pandas as pd
O=Path('outputs/high_winrate');a=pd.read_csv(O/'daily_execution.csv');w=pd.read_csv(O/'rolling60_80plus.csv');rows=[]
for r in w.itertuples():
 q=a[(a.variant==r.variant)&(a.slip==.0005)&a.traded&(a.date>=r.start)&(a.date<=r.end)]
 rows.append(dict(variant=r.variant,start=r.start,end=r.end,tradeDays=len(q),medianTrend20=q.trend20.median(),medianVolume=q.relVolume.median(),marketAboveFraction=(q.marketMA60>0).mean(),afternoonFraction=(q.timeGroup=='afternoon').mean(),sellFirstFraction=(q.side==-1).mean(),rangeEfficiencyFraction=(q.efficiency<=.35).mean(),medianVwapDistance=q.vwapDistance.median()))
pd.DataFrame(rows).to_csv(O/'high_window_features.csv',index=False)
