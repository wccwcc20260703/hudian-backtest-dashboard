from pathlib import Path
import pandas as pd,json,math
O=Path('outputs/late_entry');p=pd.read_json(O/'paired.json');m=pd.read_json(O/'metrics.json');q=pd.read_json(O/'quarters.json');r=[]
for (stock,name,bar),g in p.groupby(['stock','name','delayBar']):
 for subset,h in [('all',g),('flatEntry',g[g.flatEntry])]:
  n=len(h);k=int((h.priceImprovement>0).sum());z=1.96;ph=k/n;den=1+z*z/n;center=(ph+z*z/(2*n))/den;span=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
  r.append(dict(stock=stock,name=name,delayBar=int(bar),subset=subset,n=n,cheaper=k,cheaperRate=k/n,wilsonLow=center-span,wilsonHigh=center+span,meanPrice=h.priceImprovement.mean(),medianPrice=h.priceImprovement.median(),meanQuantityRatio=h.quantityRatio.mean(),below95pctQty=int((h.quantityRatio<.95).sum()),noFill=int(h.noFill.sum()),dayImproved=int((h.dayNavDifference>0).sum()),nextDayImproved=int((h.nextNavDifference>0).sum()),baseDayWins=int((h.baseEntryDayReturn>0).sum()),lateDayWins=int((h.lateEntryDayReturn>0).sum()),meanDayGain=h.dayNavDifference.mean(),meanNextGain=h.nextNavDifference.mean()))
pd.DataFrame(r).to_csv(O/'paired-summary.csv',index=False)
for name in ['metrics','daily','episodes','quarters','paired']:pd.read_json(O/(name+'.json')).to_csv(O/(name+'.csv'),index=False)
# Reconcile the earlier fourteen episodes without filtering on their final P&L.
a=p[(p.stock=='hudian')&(p.name=='L')&(p.delayBar==42)&p.flatEntry]
assert len(a)==14 and a.baselineEpisodeWin.sum()==13 and (a.baseEntryDayReturn>0).sum()==4
assert (a.priceImprovement>0).sum()==10
# Every non-forced buy on a delayed-state date occurs no earlier than the registered late window.
masks=json.loads(Path('work/late_entry/masks.json').read_text());count=0
for stock in ['hudian','shenghong']:
 for name in ['D30','L30','D45','L45']:
  trades=json.loads((O/(stock+'-'+name+'-trades.json')).read_text());events=json.loads((O/(stock+'-'+name+'-delays.json')).read_text());eventdays={e['day'] for e in events};bar=42 if name.endswith('30') else 45
  for e in events:assert masks[stock][e['day']] and e['from']<bar and e['to']==bar
  for t in trades:
   if t[0] in eventdays and t[2]>0 and not t[15]:assert t[1]>=bar;count+=1
# Check complete/unclosed cycles' total P&L equals end account P&L.
e=pd.read_json(O/'episodes.json');checks=0
for (stock,name),g in e.groupby(['stock','name']):
 row=m[(m.stock==stock)&(m.name==name)&(m.period=='full')&(m.slip==.0005)].iloc[0]
 assert abs(g.pnl.sum()-row.return_*1e6)<1e-4;checks+=1
au=json.loads((O/'audit.json').read_text());au.update(delayedBuyTimeChecks=count,cyclePnlReconciliations=checks,prior14EpisodeReconciliation=True);(O/'audit.json').write_text(json.dumps(au,indent=2));print(pd.DataFrame(r).query("stock=='hudian' and name=='L'").to_string(index=False))
