from pathlib import Path
s=Path('work/regime_routing/run.mjs').read_text()
s=s.replace("import {financeBacktest} from '../shenghong/finance.mjs';","import {financeBacktest} from '../shenghong/finance.mjs';import {lateBacktest} from './engine.mjs';")
s=s.replace("O='outputs/regime_routing/'","O='outputs/late_entry/'").replace("plans=read('work/regime_routing/plans.json')","masks=read('work/late_entry/masks.json')")
a=s.index(' const run=');b=s.index('\n function audit',a)
s=s[:a]+''' const run=(name,a,z,slip)=>name==='B'?holdBenchmark(d,a,z,{slip}):lateBacktest(name==='F50'?{...d,signals:{D:d.dates.map(()=>[6,.5])}}:d,g,a,z,{slip,level:name.startsWith('L')?1.5:1,rate:name.startsWith('L')?.06:0,delayMask:['D30','L30','D45','L45'].includes(name)?masks[stock]:[],delayBar:name.endsWith('45')?45:42});
 const old=read('outputs/regime_routing/metrics.json');'''+s[b:]
s=s.replace("['FD','FL','WD','WL']","['D30','L30','D45','L45']").replace("'FD','FL','WD','WL'","'D30','L30','D45','L45'").replace("name.at(-1)","name[0]")
s=s.replace("rows.push({stock,name,period,slip,","rows.push({stock,name,period,slip,delayDays:new Set((r.delayEvents??[]).map(e=>e.day)).size,")
s=s.replace("fs.writeFileSync(O+stock+'-'+name+'-trades.json',JSON.stringify(r.trades));","fs.writeFileSync(O+stock+'-'+name+'-trades.json',JSON.stringify(r.trades));fs.writeFileSync(O+stock+'-'+name+'-delays.json',JSON.stringify(r.delayEvents??[]));")
s=s[:s.index('console.log(JSON.stringify(rows.filter')]+"console.log(JSON.stringify({scenarios:rows.length,parity,ledger,loan}));\n"
Path('work/late_entry/run.mjs').write_text(s)
