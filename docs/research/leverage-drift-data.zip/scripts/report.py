# -*- coding: utf-8 -*-
from pathlib import Path
import json,html,shutil,zipfile
import pandas as pd,numpy as np
R=Path.cwd();O=R/'outputs/drift';D=R/'work/hudian-backtest-dashboard/docs';m=pd.read_csv(O/'metrics.csv');st=pd.read_csv(O/'stress.csv');c=pd.read_csv(O/'continuous.csv');daily=pd.read_csv(O/'daily.csv');audit=json.loads((O/'audit.json').read_text());mi=m.set_index(['name','period']);si=st.set_index(['name','period'])
names={'base':'当前默认：每日回调150% + 超160%减杠杆','no_rebalance':'仅取消回调150%，保留160%规则','buy_cap_only':'买入限150%，持有允许漂移','rolling':'按过去252日选择规则','cash':'现金 D（独立对照）','hold':'全仓持有'}
pct=lambda v:f'{v*100:+.2f}%';dd=lambda v:f'{abs(v)*100:.2f}%'
checks={}
for n in ['no_rebalance','buy_cap_only']:
 checks[n]={'laterReturnsBothImprove':all(mi.loc[(n,p),'return_']>mi.loc[('base',p),'return_'] for p in ['validation','recent']),'threeYearImprovements':sum(mi.loc[(n,'year'+str(y)),'return_']>mi.loc[('base','year'+str(y)),'return_'] for y in [1,2,3]),'stressLaterBothImprove':all(si.loc[(n,p),'return_']>si.loc[('base',p),'return_'] for p in ['validation','recent']),'olderReturnNotWorse':bool(mi.loc[(n,'older'),'return_']>=mi.loc[('base','older'),'return_']),'independentEvidence':False}
checks['cashOriginalGoal']={'full':bool(mi.loc[('cash','full'),'return_']>=mi.loc[('hold','full'),'return_'] and abs(mi.loc[('cash','full'),'mdd5'])<=.75*abs(mi.loc[('hold','full'),'mdd5'])),'annualPasses':sum(mi.loc[('cash','year'+str(y)),'return_']>=mi.loc[('hold','year'+str(y)),'return_'] and abs(mi.loc[('cash','year'+str(y)),'mdd5'])<=.75*abs(mi.loc[('hold','year'+str(y)),'mdd5']) for y in [1,2,3]),'older':False,'independent':False,'wealth120Separate':bool((1+mi.loc[('cash','full'),'return_'])/(1+mi.loc[('hold','full'),'return_'])>=1.2)}
(O/'acceptance.json').write_text(json.dumps(checks,indent=2,default=lambda x:x.item()));rows=''
for n in names:
 t=mi.loc[(n,'full')];rows+=f'<tr><td>{names[n]}</td><td>{pct(t.return_)}</td><td>{dd(t.mdd5)}</td><td>{int(t.longestLag)}天</td><td>{t.cumulativeLead*100:.2f}%</td><td>{t.rolling63Lead*100:.2f}%</td></tr>'
segments=''
labels={'train':'训练 2023-10-09—2024-12-31','validation':'后段 2025-01-01—2026-06-30','recent':'近期 2026-07-01—10-08','older':'更早 2020-01-02—2023-10-08','year1':'固定年度1','year2':'固定年度2','year3':'固定年度3'}
for p,label in labels.items():
 a,b=mi.loc[('base',p)],mi.loc[('buy_cap_only',p)];segments+=f'<tr><td>{label}</td><td>{pct(a.return_)} / {dd(a.mdd5)}</td><td>{pct(b.return_)} / {dd(b.mdd5)}</td></tr>'
stress=''.join(f'<tr><td>{p}</td><td>{pct(si.loc[("base",p),"return_"])} / {dd(si.loc[("base",p),"mdd5"])}</td><td>{pct(si.loc[("buy_cap_only",p),"return_"])} / {dd(si.loc[("buy_cap_only",p),"mdd5"])}</td></tr>' for p in ['full','validation','recent','older'])
risk=''
for n in ['base','no_rebalance','buy_cap_only']:
 t=mi.loc[(n,'full')];v=daily[daily.name==n];risk+=f'<tr><td>{names[n]}</td><td>{int(t.orders)}</td><td>¥{t.interest:,.0f}</td><td>{t.max_exposure*100:.2f}%</td><td>{t.min_maintenance*100:.2f}%</td><td>{(v.exposure>1.5).sum()} / {(v.exposure>1.6).sum()}</td></tr>'
style=(D/'research/overseas-factors.html').read_text().split('<style>')[1].split('</style>')[0];q=daily[daily.name=='base'];chart={'dates':q.date.tolist(),'series':{n:((daily[daily.name==n].nav/daily[daily.name==n].holdNAV-1)*100).tolist() for n in ['base','no_rebalance','buy_cap_only','rolling']}}
# Pandas index alignment must not leak into chart rows across strategy groups.
chart['series']={n:((daily[daily.name==n].nav.to_numpy()/daily[daily.name==n].holdNAV.to_numpy()-1)*100).tolist() for n in chart['series']}
assert all(len(v)==len(chart['dates']) and np.isfinite(v).all() for v in chart['series'].values())
page=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>沪电股份 · 杠杆被动漂移检验</title><script src="../vendor/echarts.min.js"></script><style>{style}</style></head><body><main><a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a><div class="eyebrow">LEVERAGE / PASSIVE DRIFT</div><h1>150%只限制买入，持有期间允许漂移，会更好吗？</h1><p class="callout">本段历史有改善：收益 +1141.47% → +1185.29%，最大回撤 25.77% → 25.45%。终值提高约3.53%，并不是收益提高43.82%。最长累计落后仍为235天。当前默认未改，新增方案作为候选继续核验。</p><p class="note">数据截至2026-10-08。全部为已经见过的历史，未称为新盲测。100万元本金，年息6%，5bp单边滑点；0/50/150%策略信号完全一致。</p>
<section><h2>只改变两项与仓位漂移有关的卖出规则</h2><p>当前模型在每日满仓融资目标下，实际仓位高于150%约0.4个百分点时会尝试回调；上一根5分钟价格测得仓位超过160%时，另行尝试减到100%。第一种是计划调仓，第二种是额外减杠杆。</p><p>新方案取消这两类被动减仓。每笔融资买入仍严格检验：买入后欠款 ≤ 当时净资产50%（含成本）。策略目标变为50%或0%时照常减仓；保留模型假设的150%维持担保线。该担保线与150%持仓比例不是同一概念，实际券商合同也可能不同。<a href="https://investor.szse.cn/knowledge/stock/margin/t20220105_590508.html">深交所维持担保比例说明</a></p><p>例如净资产100万元、持股150万元、欠款50万元，股价下跌10%后，净资产为85万元，持股为135万元，仓位约158.82%。新方案此时不单因仓位升高卖出，但也不允许继续融资买入。T+1、涨跌停、手续费、日历计息和上一根成交量1%限额均保留。</p></section>
<section><h2>全期收益、回撤与持续领先</h2><div class="scroll"><table><thead><tr><th>方案</th><th>收益</th><th>5分钟最大回撤</th><th>最长落后</th><th>累计领先日占比</th><th>滚动63日领先</th></tr></thead><tbody>{rows}</tbody></table></div><div id="relative"></div></section>
<section><h2>分段独立起算：改善并不等于没有代价</h2><div class="scroll"><table><tr><th>区间</th><th>当前默认 收益 / 回撤</th><th>仅买入限150% 收益 / 回撤</th></tr>{segments}</table></div><p>三个固定年度均提高收益；两个后续时段也提高收益。但近期独立起算最大回撤从22.30%升至22.93%。更早行情虽从亏损26.95%改善至亏损25.35%，最大回撤仍高达72.90%，没有解决长期风险问题。</p><p>连续账户：7月前收益723.81% → 750.64%；7月后50.70% → 51.10%。这里承接原持仓，与上表“每段100万元空仓起算”不同，不应混用。</p></section>
<section><h2>10bp滑点压力检验</h2><div class="scroll"><table><tr><th>区间</th><th>当前默认 收益 / 回撤</th><th>仅买入限150% 收益 / 回撤</th></tr>{stress}</table></div></section>
<section><h2>债务、换手与仓位风险</h2><div class="scroll"><table><tr><th>方案</th><th>成交笔数</th><th>总利息</th><th>仓位峰值</th><th>最低维持担保比例</th><th>收盘超过150% / 160%天数</th></tr>{risk}</table></div><p>全期峰值仓位160.17%；更早独立起算峰值166.56%。本次历史没有触及保留的担保线，不代表取消仓位上限就没有追保风险。费用下降或持股增加都不能单独解释收益变化；新旧持仓轨迹会连锁改变。</p></section>
<section><h2>时间顺序与失败结果</h2><p>只比较预先登记的三种规则，没有搜索阈值。2024年末训练选择“仅取消150%回调，保留160%规则”；它与全部放开的候选在训练段结果完全相同，不能借后续表现反过来选择全部放开。每季度用过去252个交易日选择的连续方案全期收益+1157.13%、回撤26.70%，较当前默认收益略高但回撤更大。</p><p>现金D保持独立对照，原达标标准未放宽：保留持有收益且回撤降低至少25%，至少2/3固定年度、10bp、更早行情和冻结后独立证据。现金D只通过1/3固定年度，较早行情与独立证据仍未通过；财富1.20倍单列，不能替代原标准。融资新候选尚无冻结后的独立证据，因此不自动更改默认。</p><p>独立重算核对{audit['verifiedFills']:,}笔成交，账本误差0，最大单日损益归因误差低于0.000001元；基准引擎逐项完全一致。另用合成行情验证被动超仓不卖、真实降目标仍卖、每笔融资买入50%额度约束仍有效。历史持股基准税前分红、主动策略扣20%红利税的原口径保留。</p><a href="leverage-drift-data.zip">下载结果、逐笔操作、研究登记与核验记录 ↗</a></section></main><script>const c={json.dumps(chart,ensure_ascii=False)},names={json.dumps(names,ensure_ascii=False)};const chart=echarts.init(document.getElementById('relative'));chart.setOption({{tooltip:{{trigger:'axis',valueFormatter:v=>v.toFixed(2)+'%'}},legend:{{type:'scroll',bottom:0}},grid:{{left:70,right:25,top:25,bottom:80}},xAxis:{{type:'category',data:c.dates}},yAxis:{{type:'value',axisLabel:{{formatter:'{{value}}%'}}}},dataZoom:[{{type:'inside'}}],series:Object.entries(c.series).map(([n,data])=>({{name:names[n],type:'line',showSymbol:false,data}}))}});window.addEventListener('resize',()=>chart.resize());</script></body></html>'''
(D/'research/leverage-drift.html').write_text(page);(O/'leverage-drift.html').write_text(page)
with zipfile.ZipFile(D/'research/leverage-drift-data.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in O.iterdir():
  if p.suffix in ['.json','.csv']:z.write(p,p.name)
 for p in (R/'work/drift').glob('*.py'):z.write(p,'scripts/'+p.name)
print(json.dumps(checks,indent=2,default=lambda x:x.item()))
