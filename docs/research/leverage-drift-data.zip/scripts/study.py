# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/drift';sys.path.insert(0,str(ROOT/'work/leverage'));import finance_engine as f
e=f.e
manifest={'createdAt':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'Does removing passive leverage drift selling improve the user-selected D/all_full150 strategy?','variants':{'base':'Daily rebalance to150%; above160% extra deleveraging to100%.','no_rebalance':'No sells merely above150% at scheduled full target; keep160% deleveraging.','buy_cap_only':'No scheduled full-target drift sells and no160% exposure trigger; keep genuine strategy targets0/50 and assumed150% maintenance liquidation.'},'constant':'Every financing buy debt<=50% current equity incl costs. Same D signals,6% calendar interest,T+1,limits,1% priorbar volume,5/10bp. Assumed maintenance floor is model assumption, not broker-specific rule. No parameter search. All history already seen.','validation':'Train through2024; fixed2025-Jun26/recentJul26; 3fixedyears; older2020-Oct23; quarterly select prior252 sessions score annual loggrowth-1.5absDD, modified rule eligible maxDD<=base+2pp. Cash unchanged and separately compared.','default':'No automatic replacement.','forwardSHA256':hashlib.sha256((ROOT/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(OUT/'plan_before_results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
src=(ROOT/'work/leverage/finance_engine.py').read_text();src=src.replace("parents[1]/'round2'","parents[1]/'round2'")
src=src.replace('dates,signals,start,end,rate=', 'dates,signals,start,end,modes,rate=')
src=src.replace('or sh*known/max(known_eq,1)>1.6', 'or (modes[d]<2 and sh*known/max(known_eq,1)>1.6)')
src=src.replace('if abs(target-weight)>tol:', 'if abs(target-weight)>tol and not (modes[d]>=1 and not forced and target==1.5 and weight>target):')
src=src[:src.index('\ndef run(')]
(ROOT/'work/drift/drift_engine.py').write_text(src)
sys.path.insert(0,str(ROOT/'work/drift'));import drift_engine as x
P=np.load(ROOT/'work/leverage/plans.npz');sig=P['D_all_full_1.5'];modes={n:np.full(e.N,i,dtype=np.int64) for i,n in enumerate(['base','no_rebalance','buy_cap_only'])}
def run(n,a,z,slip=.0005):return x.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,sig,a,z,modes[n],slip=slip)
base=f.run(sig)
for a,b in zip(base,run('base',e.START,e.N)):assert np.array_equal(a,b)
freeze=int(np.searchsorted(e.DATES,'2025-01-01'));cut=int(np.searchsorted(e.DATES,'2026-07-01'));periods={'train':(e.START,freeze),'validation':(freeze,cut),'recent':(cut,e.N),'full':(e.START,e.N),'older':(0,e.START)}
for y in range(3):periods['year'+str(y+1)]=(int(np.searchsorted(e.DATES,f'{2023+y}-10-09')),int(np.searchsorted(e.DATES,f'{2024+y}-10-09')))
selections=[]
def select(a,z):
 bm=f.metrics(run('base',a,z));eligible=[]
 for n in ['base','no_rebalance','buy_cap_only']:
  m=f.metrics(run(n,a,z));ok=n=='base' or abs(m['mdd5'])<=abs(bm['mdd5'])+.02;score=np.log1p(m['return_'])/((z-a)/242)-1.5*abs(m['mdd5']);selections.append(dict(start=str(e.DATES[a]),end=str(e.DATES[z-1]),name=n,eligible=ok,score=score))
  if ok:eligible.append((score,n))
 return max(eligible)[1]
choice=select(e.START,freeze);modes['rolling']=modes['base'].copy();q=pd.PeriodIndex(e.DATES,freq='Q');quarters=[]
for quarter in q[freeze:].unique():
 ix=np.flatnonzero(q==quarter);a=max(freeze,int(ix[0]));z=int(ix[-1]+1);n=select(max(0,a-252),a);modes['rolling'][a:z]=modes[n][a:z];quarters.append(dict(start=str(e.DATES[a]),end=str(e.DATES[z-1]),choice=n))
metrics=[];stress=[];results={};daily=[];continuous=[]
def lead(nav,h):
 cnt=longest=0
 for flag in nav<h:cnt=cnt+1 if flag else 0;longest=max(cnt,longest)
 n=np.r_[1e6,nav];hh=np.r_[1e6,h]
 return dict(longestLag=longest,cumulativeLead=float(np.mean(nav>h)),rolling63Lead=float(np.mean(n[63:]/n[:-63]>hh[63:]/hh[:-63])))
for p,(a,z) in periods.items():
 hold=e.run(np.ones((e.N,48)),a,z,hold=True,tax=0);cash=f.run(P['D'],a,z)
 for n in list(modes)+['cash','hold']:
  r=run(n,a,z) if n in modes else cash if n=='cash' else hold
  m=f.metrics(r) if n!='hold' else e.metrics(r);metrics.append(dict(name=n,period=p,**m,**lead(r[0],hold[0])))
  if n!='hold' and p=='full':results[n]=r
  if p in ['full','validation','recent','older']:
   rr=run(n,a,z,.001) if n in modes else f.run(P['D'],a,z,slip=.001) if n=='cash' else e.run(np.ones((e.N,48)),a,z,hold=True,tax=0,slip=.001)
   stress.append(dict(name=n,period=p,**(f.metrics(rr) if n!='hold' else e.metrics(rr))))
 for n,r in results.items() if p=='full' else []:
  assert np.isfinite(r[2]).all() and r[2].min()>0
  nv=np.r_[1e6,r[0]]
  for seg,lo,hi in [('preJuly',0,cut-e.START),('postJuly',cut-e.START,e.N-e.START)]:continuous.append(dict(name=n,period=seg,return_=float(nv[hi]/nv[lo]-1)))
  for i,d in enumerate(range(e.START,e.N)):daily.append(dict(name=n,date=str(e.DATES[d]),nav=r[0][i],exposure=r[1][i],debt=r[5][i],holdNAV=hold[0][i]))
# Independent accounting verifies every buy's 50% debt cap and all fills including T+1 and volume.
src=(ROOT/'work/underperformance/study.py').read_text();ledgerCount=0;maxerr=0.;maxpnlerr=0.;columns=['overnight','inheritedIntraday','tradeTiming','adverseFill','fees','dividend','interest'];exec(src[src.index('def accounting('):src.index('\nhc,ht=')]);trades={}
for n,r in results.items():_,trades[n]=accounting(r);pd.DataFrame(trades[n]).to_csv(OUT/(n+'_trades.csv'),index=False)
m=pd.DataFrame(metrics);m.to_csv(OUT/'metrics.csv',index=False);pd.DataFrame(stress).to_csv(OUT/'stress.csv',index=False);pd.DataFrame(daily).to_csv(OUT/'daily.csv',index=False);pd.DataFrame(continuous).to_csv(OUT/'continuous.csv',index=False);pd.DataFrame(selections).to_csv(OUT/'selection.csv',index=False);pd.DataFrame(quarters).to_csv(OUT/'quarter_choices.csv',index=False)
audit={'baselineExactParity':True,'verifiedFills':ledgerCount,'maxLedgerError':maxerr,'maxDailyPnLError':maxpnlerr,'trainSelected':choice,'independentEvidence':False,'defaultChanged':False,'forwardSHA256':manifest['forwardSHA256']}
(OUT/'audit.json').write_text(json.dumps(audit,indent=2));np.savez_compressed(ROOT/'work/drift/results.npz',**{n+'_'+k:r[i] for n,r in results.items() for i,k in enumerate(['nav','exposure','curve','trades','extras','debt','interest'])})
print(m[m.period=='full'][['name','return_','mdd5','longestLag','max_exposure','risk_orders']].to_string(index=False));print(json.dumps(audit))
