# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'work/drift'));import drift_engine as x
N=3;b=np.zeros((N,48,6));b[:,:,:4]=np.array([100,90,90])[:,None,None];b[:,:,4]=1e8;b[:,:,5]=b[:,:,4]*b[:,:,3];zero=np.zeros(N);ref=np.array([100.,90,90]);signals=np.full((N,48),-1.);signals[:,6]=[1.5,1.5,.5]
def run(mode,bb=b,s=signals):return x.execute(bb,bb[:,-1,3],zero,zero,ref,zero,zero,np.arange(N),s,0,N,np.full(N,mode),slip=0)
a=run(0);c=run(2)
assert np.any((a[3][:,0]==1)&(a[3][:,2]==-1))
assert not np.any((c[3][:,0]==1)&(c[3][:,2]==-1))
assert np.any((c[3][:,0]==2)&(c[3][:,2]==-1)&(c[3][:,10]==.5))
for t in c[3]:
 if t[2]>0:assert t[14]<=.5*(t[6]+t[7]*b[int(t[0]),int(t[1]),0])+1e-6
assert c[1][1]>1.5
bb=b.copy();bb[1:,:,:4]=40;ref[1:]=40;maintenance=run(2,bb)
assert np.any((maintenance[3][:,0]==1)&(maintenance[3][:,2]==-1)&(maintenance[3][:,15]==1)&(maintenance[3][:,10]==0))
( ROOT/'outputs/drift/synthetic_checks.json').write_text(json.dumps({'maintenanceLiquidationPreserved':True,'passiveDriftHeld':True,'strategyReductionPreserved':True,'financingBuyCapPreserved':True,'driftExposure':float(c[1][1])},indent=2))
print('Synthetic drift, reduction and buy cap checks passed.')
