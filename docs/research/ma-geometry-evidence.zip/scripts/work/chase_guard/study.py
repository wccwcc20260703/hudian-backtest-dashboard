# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/chase_guard';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
sys.path.insert(0,str(R/'work/drift'));import drift_engine as engine
e=f.e;P=np.load(R/'work/leverage/plans.npz');freeze=np.searchsorted(e.DATES,'2025-01-01');cut=np.searchsorted(e.DATES,'2026-07-01')
manifest=dict(createdAt=pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),question='Can fixed anti-chase or confirmed morning fade rules improve completed holding-episode win rate and returns?',rules={'skip_chase':'At10:00 prior completed5minclose>=open*1.02 and originalDtarget1: cancel scheduled full-target buy/add for thatday; hold inheritedposition, keep maintenance. No extra thresholds.','fade':'For originalDtarget1 days, check10:15 and10:30; priorcompletedclose peak>=open*1.02, latestclose<=peak*.99 and latestclose<VWAP: firstconfirmation sets50%target; oldsharesonlyT+1,100lot,1%priorbarvolume,5/10bps.','combined':'bothabove: cancel10orderifchase; maylaterreduce50 onfade.'},data='Existing2020..2026Oct8 archive; allseen; Oct8 motivateshypothesis,notunseen. Uses completedcloses,not disputedintradayhigh/low extrema for newrules. Underlyingfilldata stillhasproviderlimitations.',selection='Train through2024,>=10changedtrainingdays,DD<=base+2pp,annual loggrowth-1.5absDD;2025+quarterly prior252days;no gridsearch. Originalcashcriteria unchanged;wealth1.20 separate.',winRate='Completed close-to-close holding episodes, zero closing shares to positive through next zero closing shares. NetNAVreturn inclcosts/interest; lastopenepisode excluded. Intradayflatandrebuywithinoneday countsasoneepisode. Not perfillhit rate or signal probability.',freezeSHA256=hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest())
(O/'plan_before_results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));gates={k:None for k in manifest['rules']};plans={};prefix=0;levelchecks=0;events=[]
def flags(b):
 chase=b[5,3]>=b[0,0]*1.02;fade=-1
 for j in [9,12]:
  h=b[:j];vwap=h[:,5].sum()/h[:,4].sum();peak=h[:,3].max()
  if peak>=b[0,0]*1.02 and h[-1,3]<=peak*.99 and h[-1,3]<vwap:fade=j;break
 return chase,fade
for base,key in [('D','D'),('L','D_all_full_1.5')]:
 plans[base+'_base']=P[key].copy()
 for name in gates:plans[base+'_'+name]=P[key].copy()
for d in range(e.N):
 if P['D'][d].max()!=1:continue
 chase,fade=flags(e.B[d]);events.append(dict(date=str(e.DATES[d]),chase=bool(chase),fadeBar=int(fade)))
 for j in [6,9,12]:
  poison=e.B[d].copy();poison[j:]*=100
  if j==6:assert (poison[5,3]>=poison[0,0]*1.02)==chase
  else:
   h=e.B[d,:j];hp=poison[:j];assert np.array_equal(h,hp)
  prefix+=1
 for b in ['D','L']:
  if chase:
   for n in ['skip_chase','combined']:plans[b+'_'+n][d,6]=-1
  if fade>=0:
   for n in ['fade','combined']:plans[b+'_'+n][d,fade]=.5
pd.DataFrame(events).to_csv(O/'events.csv',index=False)
# Reuse the checked chronological comparisons and independent accounting without rerunning any earlier hypotheses.
src=(R/'work/support_factors/study.py').read_text();tail=src[src.index('modes=np.full(e.N,2)'):]
tail=tail.replace("'indexIntradayAvailable':False", "'indexIntradayAvailable':False")
tail=tail.replace("R/'work/support_factors/plans.npz'", "R/'work/chase_guard/plans.npz'")
# All interval metrics include a defined, cost-inclusive win rate rather than perfill counting.
original_metrics=f.metrics
def win_metrics(r):
 m=original_metrics(r);n=len(r[0]);start=int(r[3][0,0]) if len(r[3]) else 0
 # The caller range is available from run; cache mapping byreturnedarray identity.
 a,z=ranges[id(r[0])];shares=0;opening=None;wins=[];previous=1e6
 byday={int(d):t for d,t in []}
 for i,d in enumerate(range(a,z)):
  ts=r[3][r[3][:,0]==d];old=shares
  if len(ts):shares=ts[-1,7]
  if shares>0 and old==0:opening=previous
  if shares==0 and old>0 and opening is not None:wins.append(r[0][i]/opening-1);opening=None
  previous=r[0][i]
 m.update(episodeCount=len(wins),episodeWinRate=float(np.mean(np.array(wins)>0)) if wins else None,episodeMean=float(np.mean(wins)) if wins else None)
 return m
ranges={};original_execute=engine.execute
def execute(*args,**kw):
 r=original_execute(*args,**kw);ranges[id(r[0])]=(args[9],args[10]);return r
engine.execute=execute;f.metrics=win_metrics
exec(tail)
