from pathlib import Path
import json,sys,hashlib
import pandas as pd,numpy as np
R=Path.cwd();O=R/'outputs/ma_geometry';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
sys.path.insert(0,str(R/'work/drift'));import drift_engine as eng
e=f.e;events=pd.read_csv(O/'events.csv');metrics=pd.read_csv(O/'metrics.csv');features=pd.read_csv(O/'features.csv');rng=np.random.default_rng(20261009)
periods={'train':('2023-10-09','2025-01-01'),'validation':('2025-01-01','2026-07-01'),'recent':('2026-07-01','2026-10-09'),'older':('2020-01-01','2023-10-09'),'full':('2023-10-09','2026-10-09')}
# Separate the first-event selection from filtering the SAME event and time.
paired=[];first=events[events.rule=='reclaim']
for name in ['reclaim','rising','confluence','turnover']:
 x=first if name=='reclaim' else first[first[name]]
 paired.append(x.assign(rule=name))
paired=pd.concat(paired,ignore_index=True);paired.to_csv(O/'same_event_filters.csv',index=False)
def summary(df):
 out=[]
 for p,(a,z) in periods.items():
  for rule in ['reclaim','rising','confluence','turnover']:
   for eligible in ['all','eligible']:
    sub=df[(df.date>=a)&(df.date<z)&(df.rule==rule)]
    if eligible=='eligible':sub=sub[sub.eligible]
    n=len(sub)
    if not n:out.append(dict(period=p,rule=rule,subset=eligible,n=0));continue
    r=sub.nextCostProxy.to_numpy();wins=(r>0).mean();mo=pd.to_datetime(sub.date).dt.to_period('M');blocks=[sub.loc[mo==m,'nextCostProxy'].to_numpy() for m in mo.unique()]
    boot=np.array([[v.mean(),(v>0).mean()] for _ in range(1000) for v in [np.concatenate([blocks[i] for i in rng.integers(len(blocks),size=len(blocks))])]])
    meanCI=np.quantile(boot[:,0],[.025,.975]);winCI=np.quantile(boot[:,1],[.025,.975])
    out.append(dict(period=p,rule=rule,subset=eligible,n=n,months=len(blocks),mean=r.mean(),median=np.median(r),win=wins,meanLow=meanCI[0],meanHigh=meanCI[1],winLow=winCI[0],winHigh=winCI[1],sameDayMean=sub.closeReturn.mean(),overnightMean=((1+sub.nextGross)/(1+sub.closeReturn)-1).mean(),grossMean=sub.nextGross.mean(),meanWin=float(r[r>0].mean()) if (r>0).any() else None,meanLoss=float(r[r<=0].mean()) if (r<=0).any() else None))
 return out
pd.DataFrame(summary(events)).to_csv(O/'event_summary.csv',index=False);pd.DataFrame(summary(paired)).to_csv(O/'paired_summary.csv',index=False)
# Post-result robustness check, NOT a new optimized trading variant: isolated 10% cash entry,
# following session09:35 sell attempt; incomplete exits counted separately, not filled by fiat.
signals=np.full((e.N,48),-1.);modes=np.full(e.N,2);eventfills=[];out=[];count=0
for date,j in events[['date','bar']].drop_duplicates().itertuples(index=False,name=None):
 d=int(np.searchsorted(e.DATES,date));signals[d,j]=.1;signals[d+1,1]=0
 r=eng.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,signals,d,d+2,modes)
 signals[d,j]=-1;signals[d+1,1]=-1
 tr=r[3];buy=tr[tr[:,2]>0];cost=(buy[:,3]*buy[:,4]+buy[:,5]).sum();closed=bool(r[1][-1]<1e-12);bought=bool(len(buy));profit=r[0][-1]-1e6
 out.append(dict(date=date,bar=j,bought=bought,closed=bool(closed and bought),returnOnBuyCost=float(profit/cost) if bought and closed else None,accountReturn=r[0][-1]/1e6-1,buyCost=cost,endExposure=r[1][-1],fills=len(tr),lastSellBar=int(tr[-1,1]) if len(tr) and tr[-1,2]<0 else None))
 cash=1e6;sh=0.;avail=0.;oldDay=-1
 for t in tr:
  day,bar,side,qty=int(t[0]),int(t[1]),int(t[2]),int(t[3]);px=t[4]
  if day!=oldDay:
   if day==d+1:cash+=sh*e.DIV[day]*.8;sh=round(sh*(1+e.BONUS[day]))
   avail=sh;oldDay=day
  fee=max(5,qty*px*.00025)+qty*px*(e.TRANSFER[day]+(e.STAMP[day] if side<0 else 0))
  assert abs(fee-t[5])<1e-6 and qty<=int(e.B[day,bar-1,4]*.01/100)*100
  if side<0:assert qty<=avail;avail-=qty
  cash-=side*qty*px+fee;sh+=side*qty
  assert abs(cash-t[6])<1e-6 and sh==t[7] and avail==t[8] and cash>=-1e-6 and t[14]==0
  eventfills.append(dict(eventDate=date,eventBar=j,date=str(e.DATES[day]),bar=bar,side=side,qty=qty,price=px,fee=fee,cash=cash,shares=sh));count+=1
test=pd.DataFrame(out);test.to_csv(O/'isolated_events.csv',index=False);pd.DataFrame(eventfills).to_csv(O/'isolated_fills.csv',index=False)
ev=events.merge(test,on=['date','bar'],validate='many_to_one');iso=[]
for p,(a,z) in periods.items():
 for rule in ['reclaim','rising','confluence','turnover']:
  for subset in ['all','eligible']:
   df=ev[(ev.date>=a)&(ev.date<z)&(ev.rule==rule)]
   if subset=='eligible':df=df[df.eligible]
   rr=df[df.closed].returnOnBuyCost
   iso.append(dict(period=p,rule=rule,subset=subset,events=len(df),bought=int(df.bought.sum()),closed=int(df.closed.sum()),incomplete=int((df.bought&~df.closed).sum()),mean=float(rr.mean()) if len(rr) else None,win=float((rr>0).mean()) if len(rr) else None))
pd.DataFrame(iso).to_csv(O/'isolated_summary.csv',index=False)
# Baseline parity and independent episode definition.
old=pd.read_csv(R/'outputs/chase_guard/metrics.csv').set_index(['name','period']);mi=metrics.set_index(['name','period']);parity=0
for b in ['D_base','L_base']:
 for p in metrics.period.unique():
  for k in ['return_','mdd5','orders','fees','episodeCount','episodeWinRate']:
   assert np.isclose(old.loc[(b,p),k],mi.loc[(b,p),k],rtol=0,atol=1e-7);parity+=1
daily=pd.read_csv(O/'daily.csv');episodes=[]
for name,df in daily.groupby('name'):
 held=df.exposure.to_numpy()>1e-12;starts=np.flatnonzero(held&~np.r_[False,held[:-1]]);ends=np.flatnonzero(~held&np.r_[False,held[:-1]]);nav=np.r_[1e6,df.nav.to_numpy()];wins=[]
 for a in starts:
  nex=ends[ends>a]
  if not len(nex):continue
  z=nex[0];ret=nav[z+1]/nav[a]-1;wins.append(ret);episodes.append(dict(name=name,start=df.iloc[a].date,end=df.iloc[z].date,netReturn=ret))
 assert len(wins)==mi.loc[(name,'full'),'episodeCount'] and np.isclose(np.mean(np.array(wins)>0),mi.loc[(name,'full'),'episodeWinRate'])
pd.DataFrame(episodes).to_csv(O/'closed_episodes.csv',index=False)
freeze=hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest();assert freeze==json.loads((O/'audit.json').read_text())['forwardSHA256']
audit=dict(baselineMetricParity=parity,independentEpisodes=len(episodes),isolatedUniqueEvents=len(test),isolatedFillChecks=count,forwardUnchanged=freeze,postResultRobustness='Isolated10%cash execution added AFTER preliminary factor outcomes. Not a preregistered new candidate; no threshold retune.',bootstrap='1000 calendar-month cluster resamples,seed20261009; descriptive95%interval,not corrected for repeated history/rule testing. Sparse-month confidence unreliable.',indexIntradayAvailable=False)
(O/'additional_audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit));print(pd.DataFrame(iso).query("period=='full'").to_string(index=False));print(pd.read_csv(O/'event_summary.csv').query("period=='full'")[['rule','subset','n','mean','win','sameDayMean','overnightMean','winLow','winHigh']].to_string(index=False))
