from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/ma_geometry';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
sys.path.insert(0,str(R/'work/drift'));import drift_engine as engine
e=f.e;P=np.load(R/'work/leverage/plans.npz');freeze=np.searchsorted(e.DATES,'2025-01-01');cut=np.searchsorted(e.DATES,'2026-07-01')
specs=[('day',10),('day',20),('day',60),('W-FRI',5),('W-FRI',10),('W-FRI',20),('M',5),('M',10)]
times=[6,12,30,42]
manifest=dict(createdAt=pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),question='Does generalizing dynamic MA support into slope, cross-timeframe confluence and turnover confirmation improve entry outcomes?',levels=specs,times=times,rules={'reclaim':'At10:00/10:30/13:30/14:30: at least one of last6 completed5min closes within0.25 prior-day ATR of dynamic MA crossing level; last2 closes above same level, last rising, current no more than0.75 ATR above level, above cumulativeVWAP. First eligible event perday.', 'rising':'reclaim and same level crossing threshold greater than previous completed period threshold.', 'confluence':'rising plus a second eligible rising/reclaimed level from a different day/week/month family within0.25 ATR.', 'turnover':'rising plus last3bar turnover >=1.2x prior20session mean for identical3bars and normalized turnover higher than preceding3bars.'},levelDefinition='Dynamic SMA N=(previous N-1 completed period closes + current completed5minclose)/N. Price>=SMA equivalent to price>=mean(previousN-1closes). Slopes compare this crossing threshold with previous completed period threshold. No current day/week/month finalclose used. Qfq converted to raw units; historical factor vintages not independently archived.',execution='Only originalD target0 and positive announced growth: first qualifying checkpoint sets50% target. CashD and current all_full150 financingL separately; no incremental leverage for this new entry. T+1,100lot,prior5minvolume1%,5/10bps,fees,price limits,buycap debt<=50%equity unchanged.',outcome='Independent of model position: first qualifying event perday/rule. Next session09:35 opening quote including dividend/bonus, gross price outcome and cost-proxy outcome. Proxy uses5bp perleg adverse tick rounding,2.5bp commission,transfers,stamp,20%dividendtax, ignores minimum commission/volume/limit execution; not executable winrate. Strategy results use full constrained engine.',selection='Train through2024; >=10changedtrainingdays,DD<=base+2pp,annual loggrowth-1.5absDD. Quarterly2025+ previous252sessions. Fixed4variants; no threshold search.',data='2020..2026Oct8 already seen; Oct9 motivating case excluded. Decisions use completedcloses not disputed minute extrema. Dollar turnover avoids raw-share split-count discontinuity, not a guarantee of comparable liquidity.',freezeSHA256=hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest())
(O/'plan_before_results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
factor=(e.Q.close/e.D.close).loc[e.DATES].to_numpy();lv=np.zeros((e.N,len(specs)));old=lv.copy()
for k,(freq,n) in enumerate(specs):
 if freq=='day':
  lv[:,k]=e.Q.close.shift(1).rolling(n-1).mean().loc[e.DATES]/factor
  old[:,k]=e.Q.close.shift(2).rolling(n-1).mean().loc[e.DATES]/factor
 else:
  per=pd.to_datetime(e.Q.index).to_period(freq);s=e.Q.close.groupby(per).last()
  for d,date in enumerate(e.DATES):
   past=s[s.index<pd.Timestamp(str(date)).to_period(freq)]
   lv[d,k]=past.iloc[-(n-1):].mean()/factor[d] if len(past)>=n-1 else np.nan
   old[d,k]=past.iloc[-n:-1].mean()/factor[d] if len(past)>=n else np.nan
families=np.array([x[0] for x in specs]);atr=e.AR
turn={j:pd.Series(e.B[:,j-3:j,5].sum(axis=1)).rolling(20).mean().shift(1).to_numpy() for j in sorted(set(times+[j-3 for j in times]))}
def features(b,levels,previous,ar,j,current_mean,earlier_mean):
 h=b[:j];p=h[-1,3];cl=h[:,3];vwap=h[:,5].sum()/h[:,4].sum()
 touch=(np.abs(cl[-6:,None]-levels[None,:])<=.25*ar).any(axis=0)
 rec=touch & np.all(cl[-2:,None]>=levels[None,:],axis=0)&(p-levels<=.75*ar)&(p>cl[-2])&(p>vwap)&np.isfinite(levels)&(ar>0)
 rise=rec&(levels>previous);ids=np.flatnonzero(rise)
 con=any(families[a]!=families[z] and abs(levels[a]-levels[z])<=.25*ar for a in ids for z in ids if a<z)
 now=h[-3:,5].sum()/current_mean if current_mean>0 else np.nan
 before=h[-6:-3,5].sum()/earlier_mean if earlier_mean>0 else np.nan
 return dict(reclaim=bool(rec.any()),rising=bool(rise.any()),confluence=bool(con),turnover=bool(rise.any() and now>=1.2 and now>before),maCount=int(rec.sum()),risingCount=int(rise.sum()),levels='|'.join(f'{specs[k][0]}{specs[k][1]}' for k in np.flatnonzero(rec)),turnoverRatio=float(now),previousTurnoverRatio=float(before),price=float(p),vwap=float(vwap))
g=pd.read_csv(R/'outputs/round2/fundamental_point_in_time_map.csv',index_col='date').yoy_netprofit.reindex(e.DATES).to_numpy();eligible=(P['D'].max(axis=1)==0)&(g>0)
gates={n:np.full(e.N,-1,int) for n in manifest['rules']};independent={n:np.full(e.N,-1,int) for n in gates};rows=[];prefix=0;levelchecks=0
for d in range(e.N):
 for j in times:
  args=(lv[d],old[d],atr[d],j,turn[j][d],turn[j-3][d]);v=features(e.B[d],*args)
  rows.append(dict(date=str(e.DATES[d]),bar=j,eligible=bool(eligible[d]),**v))
  for name in gates:
   if v[name]:
    if independent[name][d]<0:independent[name][d]=j
    if eligible[d] and gates[name][d]<0:gates[name][d]=j
  if d>=20:
   poison=e.B[d].copy();poison[j:]*=1000
   for vv in [features(poison,*args),features(e.B[d,:j],*args)]:
    for k in v:assert vv[k]==v[k] or isinstance(v[k],float) and np.isnan(vv[k]) and np.isnan(v[k])
   prefix+=1
# Every level re-derived literally from historical data available before each session.
for d,date in enumerate(e.DATES):
 past=e.Q[e.Q.index<date]
 for k,(freq,n) in enumerate(specs):
  if freq=='day':a=past.close
  else:
   per=pd.to_datetime(past.index).to_period(freq);key=pd.Timestamp(str(date)).to_period(freq)
   a=past.loc[per<key].close.groupby(per[per<key]).last()
  for shift,got in [(0,lv[d,k]),(1,old[d,k])]:
   x=a.iloc[:-1] if shift else a
   expected=x.iloc[-(n-1):].mean()/factor[d] if len(x)>=n-1 else np.nan
   assert np.isclose(expected,got,equal_nan=True);levelchecks+=1
ff=pd.DataFrame(rows);ff.to_csv(O/'features.csv',index=False)
events=[]
for name,arr in independent.items():
 for d in np.flatnonzero(arr>=0):
  if d+1>=e.N:continue
  j=arr[d];px=e.B[d,j,0];exitpx=e.B[d+1,1,0];buy=np.ceil(px*1.0005*100-1e-8)/100;sell=np.floor(exitpx*.9995*100+1e-8)/100
  net=(sell*(1+e.BONUS[d+1])*(1-.00025-e.STAMP[d+1]-e.TRANSFER[d+1])+.8*e.DIV[d+1])/(buy*(1+.00025+e.TRANSFER[d]))-1
  row=ff[(ff.date==e.DATES[d])&(ff.bar==j)].iloc[0].to_dict()
  row.update(rule=name,entry=px,exit=exitpx,closeReturn=e.C[d]/px-1,nextGross=(exitpx*(1+e.BONUS[d+1])+e.DIV[d+1])/px-1,nextCostProxy=net)
  events.append(row)
pd.DataFrame(events).to_csv(O/'events.csv',index=False)
pd.DataFrame([dict(date=str(date),**{f'{freq}_{n}':lv[d,k] for k,(freq,n) in enumerate(specs)}) for d,date in enumerate(e.DATES)]).to_csv(O/'levels.csv',index=False)
plans={}
for b,key in [('D','D'),('L','D_all_full_1.5')]:
 plans[b+'_base']=P[key].copy()
 for name in gates:
  p=P[key].copy()
  for d in np.flatnonzero(gates[name]>=0):p[d,gates[name][d]]=.5
  plans[b+'_'+name]=p
# Reuse audited metrics, chronological selection and independent fill accounting.
src=(R/'work/chase_guard/study.py').read_text();helper=src[src.index('original_metrics=f.metrics'):src.index('exec(tail)')];exec(helper)
src=(R/'work/support_factors/study.py').read_text();tail=src[src.index('modes=np.full(e.N,2)'):].replace("R/'work/support_factors/plans.npz'","R/'work/ma_geometry/plans.npz'")
exec(tail)
