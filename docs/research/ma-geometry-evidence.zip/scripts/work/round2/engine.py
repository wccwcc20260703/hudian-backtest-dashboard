from pathlib import Path
import json,itertools,math,hashlib
import numpy as np
import pandas as pd
from numba import njit
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent;OUT=ROOT.parent.parent/'outputs'/'round2';OUT.mkdir(exist_ok=True)
def merged(name):
 a=pd.read_csv(ROOT/'data'/f'{name}_early.csv',index_col='date');b=pd.read_csv(OLD/'data'/f'{name}.csv',index_col='date')
 return pd.concat([a,b]).sort_index().loc[lambda x:~x.index.duplicated(keep='last')]
D=merged('daily_raw');Q=merged('daily_qfq')
M=pd.concat([pd.read_csv(p,dtype={'time':str}) for p in list((ROOT/'data').glob('minute*'))+list((OLD/'data').glob('minute_*.csv'))],ignore_index=True).sort_values(['date','time']).drop_duplicates(['date','time'])
DATES=np.array(sorted(M.date.unique()));N=len(DATES)
counts=M.groupby('date').size();assert (counts==48).all(),counts[counts!=48]
B=M[['open','high','low','close','volume','amount']].to_numpy(float).reshape(N,48,6)
C=D.loc[DATES,'close'].to_numpy(float);DIV=np.zeros(N);BONUS=np.zeros(N)
divid=pd.concat([pd.read_csv(p) for p in list((ROOT/'data').glob('dividend*'))+list((OLD/'data').glob('dividend*'))]).drop_duplicates('dividOperateDate')
for _,r in divid.iterrows():
 if r.dividOperateDate in DATES:
  i=np.flatnonzero(DATES==r.dividOperateDate)[0];DIV[i]=r.dividCashPsBeforeTax;BONUS[i]=r[['dividStocksPs','dividReserveToStockPs']].fillna(0).sum()
REF=(D.close.shift().loc[DATES].to_numpy()-DIV)/(1+BONUS)
STAMP=np.where(DATES<'2023-08-28',.001,.0005)
TRANSFER=np.where(DATES<'2022-04-29',.00002,.00001)
TR=pd.concat([Q.high-Q.low,(Q.high-Q.close.shift()).abs(),(Q.low-Q.close.shift()).abs()],axis=1).max(axis=1)
ATR=TR.rolling(14).mean();AR=(ATR.shift()*D.close/Q.close).loc[DATES].to_numpy()
START=int(np.searchsorted(DATES,'2023-10-09'))
SZ=pd.read_csv(ROOT/'data'/'index_sz.csv',index_col='date').close.reindex(Q.index).ffill()
PEER=pd.read_csv(ROOT/'data'/'shennan.csv',index_col='date').close.reindex(Q.index).ffill()
F=pd.DataFrame(index=Q.index)
for n in [2,5,14]:
 ch=Q.close.diff();gain=ch.clip(lower=0).ewm(alpha=1/n,adjust=False).mean();loss=(-ch.clip(upper=0)).ewm(alpha=1/n,adjust=False).mean()
 F[f'rsi{n}']=100-100/(1+gain/loss.replace(0,np.nan));F[f'rsi{n}']=F[f'rsi{n}'].fillna(50)
for n in [5,10,20,40,60,120]:
 ma=Q.close.rolling(n).mean();F[f'z{n}']=(Q.close-ma)/ATR;F[f'ret{n}']=Q.close.pct_change(n)
F['dayret']=Q.close.pct_change();F['atrpct']=ATR/Q.close
F['volratio']=Q.volume/Q.volume.rolling(20).mean();F['clv']=(Q.close-Q.low)/(Q.high-Q.low).replace(0,np.nan)
F['rs20']=Q.close.pct_change(20)-SZ.pct_change(20);F['peer_rs20']=Q.close.pct_change(20)-PEER.pct_change(20)
F['market']=SZ/SZ.rolling(60).mean()-1;F['marketret5']=SZ.pct_change(5)
F['gap']=Q.open/Q.close.shift()-1;F['day']=Q.close/Q.open-1
F['gap5']=np.log1p(F.gap).rolling(5).sum();F['day5']=np.log1p(F.day).rolling(5).sum()
F['rv20']=F.dayret.rolling(20).std();F['dd20']=Q.close/Q.close.rolling(20).max()-1
# Every feature in LAG is available before that session opens.
LAG=F.shift(1).loc[DATES].fillna(0)
@njit(cache=True)
def execute(b,cl,div,bonus,ref,stamp,transfer,signals,start,end,slip=.0005,capital=1e6,tax=.2,hold=False):
 cash=capital;sh=0;eq=np.zeros(end-start);expo=np.zeros(end-start);curve=np.zeros((end-start)*48)
 tr=np.zeros(((end-start)*48,14));nt=0;fees=0.;divtax=0.;t1blocks=0;limitblocks=0;caps=0;turnover=0.;pending=False;deadline=-1;target=0.
 for d in range(start,end):
  if div[d]>0:cash+=sh*div[d]*(1-tax);divtax+=sh*div[d]*tax
  if bonus[d]>0:sh=int(round(sh*(1+bonus[d])))
  avail=sh;pending=False
  for j in range(48):
   sig=signals[d,j]
   if hold:
    sig=1. if (d==start and j==1) else -1.
   if j>=1 and j<=46:
    if sig>=0:
     target=sig;pending=True;deadline=min(j+4,46)
    if pending and j<=deadline:
     px=b[d,j,0];equity=cash+sh*px;weight=sh*px/equity
     tol=.004 if target==1 else .035
     if abs(target-weight)>tol:
      desired=int(equity*target/px/100)*100;delta=desired-sh;side=1 if delta>0 else -1
      cap=int(b[d,j-1,4]*.01/100)*100
      if abs(delta)>cap:caps+=1
      qty=int(min(abs(delta),cap)/100)*100
      if side<0 and target==0 and sh<cap:qty=sh # liquidate residual odd lot from bonus shares
      upper=math.floor(ref[d]*1.1*100+.5)/100;lower=math.floor(ref[d]*.9*100+.5)/100
      fill=math.ceil(px*(1+slip)*100-1e-8)/100 if side>0 else math.floor(px*(1-slip)*100+1e-8)/100
      if (side>0 and (px>=upper-.005 or fill>upper)) or (side<0 and (px<=lower+.005 or fill<lower)):
       if qty>0:limitblocks+=1
       qty=0
      if side<0:
       if qty>avail:t1blocks+=1
       qty=min(qty,avail)
      if side>0:qty=min(qty,max(0,int((cash-5)/(fill*(1+.00025+transfer[d]))/100)*100))
      if qty>0:
       gross=qty*fill;fee=max(5.,gross*.00025)+gross*(transfer[d]+(stamp[d] if side<0 else 0.))
       oldavail=avail;oldsh=sh;cash-=side*gross+fee;sh+=side*qty
       if side<0:avail-=qty
       fees+=fee;turnover+=gross/equity
       tr[nt,0]=d;tr[nt,1]=j;tr[nt,2]=side;tr[nt,3]=qty;tr[nt,4]=fill;tr[nt,5]=fee;tr[nt,6]=cash;tr[nt,7]=sh;tr[nt,8]=avail;tr[nt,9]=oldavail;tr[nt,10]=target;tr[nt,11]=cap;tr[nt,12]=oldsh;tr[nt,13]=sig;nt+=1
      else:pending=False
     else:pending=False
   mark=cl[d] if j==47 else b[d,j,3];curve[(d-start)*48+j]=cash+sh*mark
  eq[d-start]=cash+sh*cl[d];expo[d-start]=sh*cl[d]/eq[d-start]
 return eq,expo,curve,tr[:nt],np.array([fees,divtax,t1blocks,limitblocks,caps,turnover])
def run(sig,a=START,z=N,slip=.0005,capital=1e6,tax=.2,hold=False):return execute(B,C,DIV,BONUS,REF,STAMP,TRANSFER,sig,a,z,slip,capital,tax,hold)
def metrics(res,capital=1e6):
 e,ex,c,tr,extra=res;x=np.r_[capital,e];daily=x[1:]/x[:-1]-1;bc=np.r_[capital,c];years=len(e)/242
 dd=np.min(x/np.maximum.accumulate(x)-1);dd5=np.min(bc/np.maximum.accumulate(bc)-1);growth=np.log(e[-1]/capital)/years
 return dict(return_=float(e[-1]/capital-1),cagr=float(np.exp(growth)-1),mdd=float(dd),mdd5=float(dd5),exposure=float(np.mean(ex)),orders=len(tr),fees=float(extra[0]),dividend_tax=float(extra[1]),t1_blocks=int(extra[2]),limit_blocks=int(extra[3]),volume_caps=int(extra[4]),turnover=float(extra[5]),sharpe=float(np.mean(daily)/max(np.std(daily),1e-9)*242**.5),score=float(growth-1.5*abs(dd5)))
def base_signal(p):
 fam=p['family'];x=LAG
 if fam=='hold':return np.ones(N)
 if fam=='rsi':
  r=x[f'rsi{p["n"]}'].to_numpy();w=np.where(r<p['lo'],1,np.where(r>p['hi'],p['highw'],p['mid']))
 elif fam=='stretch':
  z=x[f'z{p["n"]}'].to_numpy();w=np.where(z<p['lo'],1,np.where(z>p['hi'],p['highw'],p['mid']))
 elif fam=='diptrend':
  w=np.where((x[f'z{p["n"]}']>0)|(x.rs20>0),1,p['bearw']);r=x[f'rsi{p["rsi"]}']
  w=np.where(r<25,1,w);w=np.where((x.z20>p['stretch'])&(r>80),p['highw'],w)
  risk=(x.volratio>1.8)&(x.dayret<-x.atrpct)&(x.clv<.3)&(x.market<0)&(x.rs20<0)
  w=np.where(risk,p['bearw'],w)
 elif fam=='event':
  hot=(x.volratio>p['vol'])&(x.z20>p['stretch'])&(x.clv<.5)
  weak=(x.market<0)&(x.rs20<0)&(x.dayret<-x.atrpct)&(x.clv<.3)
  w=np.ones(N);until=-1
  for i in range(N):
   if hot.iloc[i] or weak.iloc[i]:until=i+p['days']
   if i<until:w[i]=p['loww']
   if x.rsi2.iloc[i]<15:w[i]=1.
 else:raise ValueError(fam)
 if p.get('gate',0):
  bear=(x.market<0)&(x.z120<0)&(x.rs20<0)
  w=np.where(bear,np.minimum(w,np.where(x.rsi5<20,.5,.2)),w)
 return np.asarray(w,float)
def plan(p):
 w=base_signal(p);s=np.full((N,48),-1.);s[:,p.get('time',1)]=w
 return s
def export(name,sig,a=START,z=N,**kw):
 res=run(sig,a,z,**kw);e,ex,c,tr,extra=res
 pd.DataFrame({'date':DATES[a:z],'nav':e,'exposure':ex}).to_csv(OUT/(name+'_daily.csv'),index=False)
 t=pd.DataFrame(tr,columns=['day','bar','side','shares','price','fee','cash','position','available','available_before','target','volume_cap','position_before','signal'])
 if len(t):
  t.insert(0,'date',DATES[t.day.astype(int)]);t.insert(1,'time',[('13:00' if j==24 else (M.time.to_numpy().reshape(N,48)[d,j-1][8:10]+':'+M.time.to_numpy().reshape(N,48)[d,j-1][10:12])) for d,j in zip(t.day.astype(int),t.bar.astype(int))])
 t.to_csv(OUT/(name+'_trades.csv'),index=False);np.save(ROOT/(name+'_curve.npy'),c)
 return metrics(res,kw.get('capital',1e6))
def configs():
 yield dict(family='hold')
 for n,lo,hi,mid,highw,gate in itertools.product([2,5,14],[20,35],[65,80],[.5,1.],[0.,.4,.7],[0,1]):
  yield dict(family='rsi',n=n,lo=lo,hi=hi,mid=mid,highw=highw,gate=gate)
 for n,lo,hi,mid,highw,gate in itertools.product([10,20,40],[-.5,-1.5],[1.,2.,3.],[.6,1.],[0.,.5],[0,1]):
  yield dict(family='stretch',n=n,lo=lo,hi=hi,mid=mid,highw=highw,gate=gate)
 for n,rsi,stretch,highw,bearw,gate in itertools.product([60,120],[2,5],[2.,3.,4.],[.5,.8],[0.,.3],[0,1]):
  yield dict(family='diptrend',n=n,rsi=rsi,stretch=stretch,highw=highw,bearw=bearw,gate=gate)
 for vol,stretch,days,loww in itertools.product([1.5,2.],[1.,2.],[2,5],[0.,.5]):
  yield dict(family='event',vol=vol,stretch=stretch,days=days,loww=loww)
if __name__=='__main__':
 print('days',N,'targetdays',N-START,'date',DATES[0],DATES[-1]);print('config count',len(list(configs())))
