# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/support_factors';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
sys.path.insert(0,str(R/'work/drift'));import drift_engine as engine
e=f.e;P=np.load(R/'work/leverage/plans.npz');freeze=np.searchsorted(e.DATES,'2025-01-01');cut=np.searchsorted(e.DATES,'2026-07-01')
manifest={'createdAt':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'Do weekly/monthly support, same-time volume and prior completed broad-market support improve dip entries?','known':'All2020-2026Oct8 history already seen. Oct9 example motivated hypothesis, excluded from efficacy study. No blindtest claim.','levels':'Stock dynamic20week and10month SMA: preceding19completedweekly or9completedmonthly closes plus current completed5minclose. Equivalent crossing level is mean of preceding19/9 closes. Completed-period boundaries exclude current week/month. Qfq levels converted to contemporaneous raw units, historical adjustment revisions not independently PIT audited.','times':[6,30],'timeLabels':['10:00','13:30'],'rules':{'touch':'last6completed5minbars intersect a support±1%, lastclose within2%; diagnostic touch strategy','reclaim':'touch + last2completedcloses>=same support and rising; price above cumulativeVWAP','volume':'reclaim + accumulated volume>=1.2times prior20sessions at identical checkpoint','market':'reclaim + previousday index support condition','combined':'reclaim+volume+market'},'market':'SZ399001 andHS300 broad proxies. All index input through previoussession only. Both latest closes>=99% of lower available weekly/monthly crossing level; at least one index touched either level±1% during previous5days and latest close>=that level. Not intraday-index confirmation.','execution':'For positive announced profit growth and D original target0 only, first qualifying10:00/13:30 raises targetto50%; preserve earlier baseorders and laterdays originalplan. No added financing on new signals. Cash and currentD_all_full150/buy_cap_only separately. T+1,volume1%previousbar,limits,fees,5/10bp,6%calendarinterest,perbuy debt<=50%equity.','selection':'Train2023Oct..2024Dec; modifiedrule eligible>=10changedtrainingdays and DD<=base+2pp, scoreannual loggrowth-1.5absDD; quarterly2025+prior252sessions samecriteria. No threshold search.','originalGoal':'Cash return>=hold,DD<=75%hold,>=2/3fixedyears,10bp,older,independentforward; wealth1.20 separate. Financing compareincrement and risks,notcashgoal substitution.','freezeSHA256':hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(O/'plan_before_results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
# Period groups are built once; literal prefix verification below confirms exclusion of current week/month.
def levels(frame,dates):
 idx=pd.to_datetime(frame.index);weeks=idx.to_period('W-FRI');months=idx.to_period('M');out=[]
 for freq,n in [('W-FRI',19),('M',9)]:
  periods=idx.to_period(freq);closes=pd.Series(frame.close.to_numpy(),index=periods).groupby(level=0).last();lev=[]
  for date in dates:
   key=pd.Timestamp(str(date)).to_period(freq);v=closes[closes.index<key].tail(n);lev.append(v.mean() if len(v)==n else np.nan)
  out.append(np.array(lev))
 return np.column_stack(out)
stock=levels(e.Q,e.DATES);factors=(e.Q.close/e.D.close).loc[e.DATES].to_numpy();stock/=factors[:,None]
indices={};market_checks=0
for name,file in [('SZ','index_sz.csv'),('HS300','index_hs300.csv')]:
 df=pd.read_csv(R/'work/round2/data'/file,index_col='date');lev=levels(df,e.DATES);aligned=df.reindex(e.DATES);assert aligned.close.notna().all();close=aligned.close.to_numpy();low=aligned.low.to_numpy();high=aligned.high.to_numpy();ok=np.zeros(e.N,bool);held=np.zeros(e.N,bool)
 for d in range(5,e.N):
  lv=lev[d-1];ok[d]=np.isfinite(lv).all() and close[d-1]>=np.min(lv)*.99
  held[d]=any(np.isfinite(l) and close[d-1]>=l and np.any((low[d-5:d]<=l*1.01)&(high[d-5:d]>=l*.99)) for l in lv)
 indices[name]=dict(lev=lev,ok=ok,held=held,close=close)
market=indices['SZ']['ok']&indices['HS300']['ok']&(indices['SZ']['held']|indices['HS300']['held'])
g=pd.read_csv(R/'outputs/round2/fundamental_point_in_time_map.csv',index_col='date').yoy_netprofit.reindex(e.DATES).to_numpy();baseD=P['D'];eligible=(baseD.max(axis=1)==0)&(g>0)
volume={j:pd.Series(e.B[:,:j,4].sum(axis=1)).rolling(20).mean().shift(1).to_numpy() for j in [6,30]}
def features(b,lv,j,vref):
 h=b[:j];price=h[-1,3];recent=h[-6:];touched=np.array([np.isfinite(l) and np.any((recent[:,2]<=l*1.01)&(recent[:,1]>=l*.99)) and abs(price/l-1)<=.02 for l in lv]);recover=np.array([touched[k] and np.all(h[-2:,3]>=l) and h[-1,3]>h[-2,3] for k,l in enumerate(lv)]);vwap=h[:,5].sum()/h[:,4].sum() if h[:,4].sum()>0 else np.nan;vr=h[:,4].sum()/vref if vref>0 else np.nan
 return dict(touch=bool(touched.any()),reclaim=bool(recover.any() and price>vwap),weekly=bool(touched[0]),monthly=bool(touched[1]),volume=bool(vr>=1.2),volumeRatio=float(vr),price=float(price),vwap=float(vwap))
features_rows=[];gates={n:np.full(e.N,-1,int) for n in ['touch','reclaim','volume','market','combined']};prefix=0
for d in range(e.N):
 for j in [6,30]:
  v=features(e.B[d],stock[d],j,volume[j][d]);v['market']=bool(market[d]);features_rows.append(dict(date=str(e.DATES[d]),bar=j,weeklyLevel=stock[d,0],monthlyLevel=stock[d,1],baseEligible=bool(eligible[d]),**v))
  booleans={'touch':v['touch'],'reclaim':v['reclaim'],'volume':v['reclaim'] and v['volume'],'market':v['reclaim'] and v['market'],'combined':v['reclaim'] and v['volume'] and v['market']}
  if eligible[d]:
   for n,flag in booleans.items():
    if flag and gates[n][d]<0:gates[n][d]=j
  # Every decision recomputed from literally truncated bar data; future mutation is irrelevant.
  if d>=20:
   poison=e.B[d].copy();poison[j:]*=100
   v2=features(poison,stock[d],j,volume[j][d]);assert all(v2[k]==v[k] or np.isnan(v2[k]) and np.isnan(v[k]) for k in v2);prefix+=1
# Independent period-boundary and same-time-volume checks; no unfinished period final close used.
levelchecks=0
for d,date in enumerate(e.DATES):
 for freq,n,k in [('W-FRI',19,0),('M',9,1)]:
  past=e.Q[e.Q.index<date];per=pd.to_datetime(past.index).to_period(freq);key=pd.Timestamp(str(date)).to_period(freq);q=past.loc[per<key];vals=q.close.groupby(pd.to_datetime(q.index).to_period(freq)).last().tail(n)
  expected=vals.mean()/factors[d] if len(vals)==n else np.nan;assert np.isclose(expected,stock[d,k],equal_nan=True);levelchecks+=1
 for j in [6,30]:
  if d>=20:assert np.isclose(volume[j][d],e.B[d-20:d,:j,4].sum(axis=1).mean())
# Causal outcome diagnostics: same-day return descriptive only, next-day sale is earliest T+1 observation.
ff=pd.DataFrame(features_rows);events=[]
for n in gates:
 for d in np.flatnonzero(gates[n]>=0):
  j=gates[n][d];row=ff[(ff.date==e.DATES[d])&(ff.bar==j)].iloc[0].to_dict();px=e.B[d,j,0]
  row.update(rule=n,entry=px,closeReturn=e.C[d]/px-1,nextOpenReturn=((e.B[d+1,1,0]*(1+e.BONUS[d+1])+e.DIV[d+1])/px-1) if d+1<e.N else np.nan,intradayAdverse=e.B[d,j:,2].min()/px-1,intradayFavorable=e.B[d,j:,1].max()/px-1);events.append(row)
ff.to_csv(O/'features.csv',index=False);pd.DataFrame(events).to_csv(O/'events.csv',index=False)
plans={}
for b,base in [('D',P['D']),('L',P['D_all_full_1.5'])]:
 plans[b+'_base']=base.copy()
 for n in gates:
  p=base.copy()
  for d in np.flatnonzero(gates[n]>=0):p[d,gates[n][d]]=.5
  plans[b+'_'+n]=p
modes=np.full(e.N,2)
def run(name,a,z,slip=.0005):return engine.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,plans[name],a,z,modes,slip=slip)
periods={'train':(e.START,freeze),'validation':(freeze,cut),'recent':(cut,e.N),'older':(0,e.START),'full':(e.START,e.N)}
for y in range(3):periods['year'+str(y+1)]=(np.searchsorted(e.DATES,f'{2023+y}-10-09'),np.searchsorted(e.DATES,f'{2024+y}-10-09'))
selections=[];choices={};rolling=[]
def choose(b,a,z):
 bm=f.metrics(run(b+'_base',a,z));candidates=[]
 for n in ['base',*gates]:
  name=b+'_'+n;r=run(name,a,z);m=f.metrics(r);changed=np.any(plans[name][a:z]!=plans[b+'_base'][a:z],axis=1).sum();ok=n=='base' or (changed>=10 and abs(m['mdd5'])<=abs(bm['mdd5'])+.02);score=np.log1p(m['return_'])/((z-a)/242)-1.5*abs(m['mdd5']);selections.append(dict(base=b,start=str(e.DATES[a]),end=str(e.DATES[z-1]),rule=n,changes=int(changed),eligible=bool(ok),score=score))
  if ok:candidates.append((score,name))
 return max(candidates)[1]
q=pd.PeriodIndex(e.DATES,freq='Q')
for b in ['D','L']:
 choices[b]=choose(b,e.START,freeze);s=plans[b+'_base'].copy()
 for quarter in q[freeze:].unique():
  ix=np.flatnonzero(q==quarter);a=max(freeze,int(ix[0]));z=int(ix[-1]+1);choice=choose(b,max(0,a-252),a);s[a:z]=plans[choice][a:z];rolling.append(dict(base=b,start=str(e.DATES[a]),end=str(e.DATES[z-1]),choice=choice))
 plans[b+'_rolling']=s
metrics=[];stress=[];results={};daily=[];continuous=[]
def leading(n,h):
 count=longest=0
 for flag in n<h:count=count+1 if flag else 0;longest=max(count,longest)
 nv=np.r_[1e6,n];hv=np.r_[1e6,h];return dict(longestLag=longest,cumulativeLead=float(np.mean(n>h)),rolling63Lead=float(np.mean(nv[63:]/nv[:-63]>hv[63:]/hv[:-63])))
for p,(a,z) in periods.items():
 h=e.run(np.ones((e.N,48)),a,z,hold=True,tax=0);metrics.append(dict(name='hold',period=p,**e.metrics(h)))
 if p in ['full','validation','recent','older']:stress.append(dict(name='hold',period=p,**e.metrics(e.run(np.ones((e.N,48)),a,z,hold=True,tax=0,slip=.001))))
 for name in plans:
  r=run(name,a,z);metrics.append(dict(name=name,period=p,changedDays=int(np.any(plans[name][a:z]!=plans[name[0]+'_base'][a:z],axis=1).sum()),**f.metrics(r),**leading(r[0],h[0])))
  if p in ['full','validation','recent','older']:stress.append(dict(name=name,period=p,**f.metrics(run(name,a,z,.001))))
  if p=='full':
   results[name]=r;nv=np.r_[1e6,r[0]]
   for seg,lo,hi in [('preJuly',0,cut-e.START),('postJuly',cut-e.START,e.N-e.START)]:continuous.append(dict(name=name,period=seg,return_=nv[hi]/nv[lo]-1))
   for i,d in enumerate(range(e.START,e.N)):daily.append(dict(name=name,date=str(e.DATES[d]),nav=r[0][i],exposure=r[1][i],holdNAV=h[0][i]))
# Keep inherited independent accounting validator; changed trade schedules cannot bypass constraints.
src=(R/'work/underperformance/study.py').read_text();ledgerCount=0;maxerr=0.;maxpnlerr=0.;columns=['overnight','inheritedIntraday','tradeTiming','adverseFill','fees','dividend','interest'];exec(src[src.index('def accounting('):src.index('\nhc,ht=')])
for name,r in results.items():_,trades=accounting(r);pd.DataFrame(trades).to_csv(O/(name+'_trades.csv'),index=False)
m=pd.DataFrame(metrics);st=pd.DataFrame(stress);m.to_csv(O/'metrics.csv',index=False);st.to_csv(O/'stress.csv',index=False);pd.DataFrame(daily).to_csv(O/'daily.csv',index=False);pd.DataFrame(continuous).to_csv(O/'continuous.csv',index=False);pd.DataFrame(rolling).to_csv(O/'rolling.csv',index=False);pd.DataFrame(selections).to_csv(O/'selection.csv',index=False)
mi=m.set_index(['name','period']);si=st.set_index(['name','period']);accept=[]
for name in plans:
 base=name[0]+'_base';row=dict(name=name,laterBothBetter=all(mi.loc[(name,p),'return_']>mi.loc[(base,p),'return_'] for p in ['validation','recent']),stressLaterBothBetter=all(si.loc[(name,p),'return_']>si.loc[(base,p),'return_'] for p in ['validation','recent']),olderNotWorse=bool(mi.loc[(name,'older'),'return_']>=mi.loc[(base,'older'),'return_']),improvedYears=int(sum(mi.loc[(name,'year'+str(y)),'return_']>mi.loc[(base,'year'+str(y)),'return_'] for y in [1,2,3])),independentEvidence=False,wealth120Separate=bool((1+mi.loc[(name,'full'),'return_'])/(1+mi.loc[('hold','full'),'return_'])>=1.2))
 if name.startswith('D'):
  goal=lambda p:bool(mi.loc[(name,p),'return_']>=mi.loc[('hold',p),'return_'] and abs(mi.loc[(name,p),'mdd5'])<=.75*abs(mi.loc[('hold',p),'mdd5']));row.update(cashFullGoal=goal('full'),cashAnnualPasses=sum(goal('year'+str(y)) for y in [1,2,3]),cashOlderGoal=goal('older'),cashStressGoal=bool(si.loc[(name,'full'),'return_']>=si.loc[('hold','full'),'return_'] and abs(si.loc[(name,'full'),'mdd5'])<=.75*abs(si.loc[('hold','full'),'mdd5'])))
 accept.append(row)
(O/'acceptance.json').write_text(json.dumps(accept,indent=2));audit=dict(prefixChecks=prefix,periodBoundaryChecks=levelchecks,verifiedFills=ledgerCount,maxLedgerError=maxerr,maxDailyPnLError=maxpnlerr,trainChoices=choices,defaultChanged=False,historyThrough=str(e.DATES[-1]),indexIntradayAvailable=False,forwardSHA256=manifest['freezeSHA256']);(O/'audit.json').write_text(json.dumps(audit,indent=2));np.savez_compressed(R/'work/support_factors/plans.npz',**plans)
print(m[m.period=='full'][['name','return_','mdd5','changedDays','longestLag']].to_string(index=False));print(json.dumps(audit))
