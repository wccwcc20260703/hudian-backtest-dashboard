# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/underperformance';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'work/leverage'));import finance_engine as f
e=f.e;prior=ROOT/'outputs/reentry/forward_freeze.json';priorhash=hashlib.sha256(prior.read_bytes()).hexdigest()
manifest=dict(recordedAt=pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),question='Why does the default D_trend150 lag cumulative buy-and-hold for277sessions? Can fixed trend-volume retention or morning persistent-volume reentry improve participation without abandoning risk goals?',known='277sessions2024-02-06..2025-04-03 already located. All historical data already seen. Two hypothesis tests, no threshold search, no new blind test.',rules={'retain':'Priorclose>MA20,MA20>MA20shift5, previous3session averagevolume>=previous20sessions excluding those3, announcedprofitgrowth>0. Retain previous effective cash target capped100% when baseD reduces. Otherwise baseD. Finance retains original borrowing events only; replace existing scheduled nonnegative target, no changed original ordertime.','morning':'At10:00 previous completed6bars: close>open and cumulativeVWAP, at least4bars volume>=prior20sessions samebar mean, announcedprofitgrowth>0 and baseDtarget<50%. Target50% at10:00, preserve earlier orders. No extra leverage, no combinedrule.'},selection='Train ends2024-12-31. Amongbase+2 rules, modified rules require>=10changedtrainingdays and maxDD<=base+2pp. Annual loggrowth minus1.5absDD. Apply selected frozenrule to2025..Jun26 andJul26..Oct8. Quarterly2025onward prior252sessions samecriteria; continuous account, dates selected only with pastdata.',acceptance='Improve return vs same base in BOTH latersegments, DD<=base+2pp each, earlier not worse,>=2of3fixedyears better,10bp improvesboth. Cash originalgoal unchanged: preserveholdreturn,DD<=75%hold,>=2of3fixedyears,10bp,earlier,independentforward. Wealth1.20separate.',accounting='Exact daily self-financing PnL: inherited overnight, inherited intraday, trade timing at rawbaropen, adversefill, fees, netdividend, financinginterest. Normalize by each accounts previousNAV and convert additively to logrelativewealth. Does not attribute news or infer alternate prices.',forwardSHA256=priorhash)
plan=OUT/'plan_before_results.json'
if not plan.exists():plan.write_text(json.dumps(manifest,indent=2))
P=np.load(ROOT/'work/leverage/plans.npz');base={'D':P['D'],'L':P['D_trend_1.5']};bw=P['D'].max(axis=1)
g=pd.read_csv(ROOT/'outputs/round2/fundamental_point_in_time_map.csv',index_col='date').yoy_netprofit.reindex(e.DATES).to_numpy()
q=e.Q;ma=q.close.rolling(20).mean();vol=q.volume
trend=((q.close>ma)&(ma>ma.shift(5))&(vol.rolling(3).mean()>=vol.shift(3).rolling(20).mean())).shift(1).reindex(e.DATES).fillna(False).to_numpy()&(g>0)
retained=bw.copy()
for d in range(1,e.N):
 if trend[d]:retained[d]=max(bw[d],min(retained[d-1],1.))
pastvol=np.zeros((e.N,6));pastvol[:]=np.nan
for j in range(6):pastvol[:,j]=pd.Series(e.B[:,j,4]).rolling(20).mean().shift(1).to_numpy()
def morning_prefix(b,pv):
 b=b[:6];return bool(b[-1,3]>b[0,0] and b[-1,3]>b[:,5].sum()/max(b[:,4].sum(),1) and (b[:,4]>=pv).sum()>=4)
morning=np.array([morning_prefix(e.B[d],pastvol[d]) for d in range(e.N)])&(g>0)&(bw<.5)
plans={}
for b in base:
 plans[b+'_base']=base[b].copy();s=base[b].copy();w=np.maximum(s.max(axis=1),retained)
 for d in range(e.N):s[d,s[d]>=0]=w[d]
 plans[b+'_retain']=s;s=base[b].copy();s[morning,6]=.5;plans[b+'_morning']=s
# Recompute point-in-time features from literal history for every eligible day.
for d in range(23,e.N):
 prev=e.Q.loc[:e.DATES[d]].iloc[:-1];c=prev.close.to_numpy();v=prev.volume.to_numpy()
 gate=bool(c[-1]>c[-20:].mean() and c[-20:].mean()>c[-25:-5].mean() and v[-3:].mean()>=v[-23:-3].mean() and g[d]>0)
 assert gate==bool(trend[d])
 assert np.allclose(pastvol[d],e.B[d-20:d,:6,4].mean(axis=0))
 poisoned=e.B[d].copy();poisoned[6:]*=100
 assert morning_prefix(poisoned,pastvol[d])==morning_prefix(e.B[d],pastvol[d])
freeze=int(np.searchsorted(e.DATES,'2025-01-01'));cut=int(np.searchsorted(e.DATES,'2026-07-01'))
periods={'train':(e.START,freeze),'validation':(freeze,cut),'recent':(cut,e.N),'preJuly':(e.START,cut),'full':(e.START,e.N),'older':(0,e.START)}
for y in range(3):periods['year'+str(y+1)]=(int(np.searchsorted(e.DATES,f'{2023+y}-10-09')),int(np.searchsorted(e.DATES,f'{2024+y}-10-09')))
selection=[]
def select(b,a,z):
 original=f.run(plans[b+'_base'],a,z);bm=f.metrics(original);eligible=[]
 for rule in ['base','retain','morning']:
  name=b+'_'+rule;r=f.run(plans[name],a,z);m=f.metrics(r);changed=int(np.any(plans[name][a:z]!=plans[b+'_base'][a:z],axis=1).sum());ok=rule=='base' or (changed>=10 and abs(m['mdd5'])<=abs(bm['mdd5'])+.02)
  score=np.log1p(m['return_'])/((z-a)/242)-1.5*abs(m['mdd5'])
  if ok:eligible.append((score,name))
  selection.append(dict(base=b,start=str(e.DATES[a]),end=str(e.DATES[z-1]),name=name,changedDays=changed,eligible=ok,score=score))
 return max(eligible)[1]
choices={};rolling=[]
for b in base:
 choices[b]=select(b,e.START,freeze);x=plans[b+'_base'].copy()
 dates=pd.Series(e.DATES);quarters=pd.PeriodIndex(e.DATES,freq='Q')
 for quarter in quarters[freeze:].unique():
  ix=np.flatnonzero(quarters==quarter);a=max(freeze,int(ix[0]));z=int(ix[-1]+1);name=select(b,max(0,a-252),a);x[a:z]=plans[name][a:z];rolling.append(dict(base=b,start=str(e.DATES[a]),end=str(e.DATES[z-1]),choice=name))
 plans[b+'_rolling']=x
holds={p:e.run(np.ones((e.N,48)),a,z,hold=True,tax=0) for p,(a,z) in periods.items()}
def streak(nav,h):
 rel=nav/h-1;best=(0,0);start=None
 for i,flag in enumerate(np.r_[rel<0,False]):
  if flag and start is None:start=i
  if not flag and start is not None:
   if i-start>best[1]-best[0]:best=(start,i)
   start=None
 return best
metrics=[];stress=[];continuous=[];results={};daily=[]
for name,sig in plans.items():
 for p,(a,z) in periods.items():
  r=f.run(sig,a,z);h=holds[p];m=f.metrics(r);lo,hi=streak(r[0],h[0]);nav=np.r_[1e6,r[0]];hn=np.r_[1e6,h[0]]
  m.update(cumulativeLead=float(np.mean(r[0]>h[0])),rolling63Lead=float(np.mean(nav[63:]/nav[:-63]>hn[63:]/hn[:-63])),longestLag=hi-lo,lagStart=str(e.DATES[a+lo]) if hi>lo else '',lagEnd=str(e.DATES[a+hi-1]) if hi>lo else '')
  metrics.append(dict(name=name,period=p,**m))
  if p=='full':results[name]=r
  if p in ['validation','recent','full','older']:stress.append(dict(name=name,period=p,**f.metrics(f.run(sig,a,z,slip=.001))))
for p,h in holds.items():metrics.append(dict(name='hold',period=p,**e.metrics(h)))
for p in ['validation','recent','full','older']:
 a,z=periods[p];stress.append(dict(name='hold',period=p,**e.metrics(e.run(np.ones((e.N,48)),a,z,hold=True,tax=0,slip=.001))))
for name,r in results.items():
 nav=np.r_[1e6,r[0]];hn=np.r_[1e6,holds['full'][0]]
 for p,a,z in [('preJuly',0,cut-e.START),('recent',cut-e.START,e.N-e.START)]:continuous.append(dict(name=name,period=p,return_=nav[z]/nav[a]-1,holdReturn=hn[z]/hn[a]-1))
 for i,d in enumerate(range(e.START,e.N)):daily.append(dict(name=name,date=str(e.DATES[d]),nav=r[0][i],holdNAV=holds['full'][0][i],exposure=r[1][i],baseTarget=bw[d],trendVolume=bool(trend[d]),morningVolume=bool(morning[d])))
# Independent transaction and financing accounting; exact attribution is not a hypothetical strategy.
columns=['overnight','inheritedIntraday','tradeTiming','adverseFill','fees','dividend','interest'];ledgerCount=0;maxerr=0.;maxpnlerr=0.
def accounting(r,fin=True):
 global ledgerCount,maxerr,maxpnlerr
 cash=1e6;sh=0;prevnav=1e6;rows=[];contrib=[]
 for i,d in enumerate(range(e.START,e.N)):
  oldsh=sh;carry=max(0,f.DAYNUM[d]-f.DAYNUM[d-1]-1) if d>e.START else 0;interest=max(-cash,0)*.06/365*carry if fin else 0;cash-=interest
  div=sh*e.DIV[d]*(.8 if fin else 1);cash+=div;sh=int(round(sh*(1+e.BONUS[d])));avail=sh;borrow=max(-cash,0);px=e.B[d,0,0]
  components=np.array([sh*px-oldsh*e.C[d-1],sh*(e.C[d]-px),0,0,0,div,0.]);ts=r[3][r[3][:,0]==d]
  for t in ts:
   j,side,qty=int(t[1]),int(t[2]),int(t[3]);mark=e.B[d,j,0];fill=t[4];fee=max(5,qty*fill*.00025)+qty*fill*(e.TRANSFER[d]+(e.STAMP[d] if side<0 else 0))
   assert sh==t[12] and avail==t[9] and abs(fee-t[5])<1e-7
   before=sh*mark/(cash+sh*mark);cash-=side*qty*fill+fee;sh+=side*qty
   if side<0:avail-=qty;assert avail>=0
   else:assert max(-cash,0)<=.5*(cash+sh*mark)+1e-6
   assert qty<=t[11] and abs(cash-t[6])<1e-6 and sh==t[7]
   upper=np.floor(e.REF[d]*1.1*100+.5)/100;lower=np.floor(e.REF[d]*.9*100+.5)/100
   assert lower-1e-8<=fill<=upper+1e-8
   components[2]+=side*qty*(e.C[d]-mark);components[3]+=side*qty*(mark-fill);components[4]-=fee;borrow=max(borrow,-cash);ledgerCount+=1
   rows.append(dict(date=str(e.DATES[d]),bar=j,side=side,qty=qty,price=fill,fee=fee,before=before,after=sh*mark/(cash+sh*mark),target=t[10]))
  charge=borrow*.06/365 if fin else 0;cash-=charge;interest+=charge;components[6]=-interest
  if fin:assert abs(interest-r[6][i])<1e-8
  err=abs(cash+sh*e.C[d]-r[0][i]);maxerr=max(maxerr,err);assert err<1e-6
  err=abs(components.sum()-(r[0][i]-prevnav));maxpnlerr=max(maxpnlerr,err);assert err<1e-6
  contrib.append(components/prevnav);prevnav=r[0][i]
 return np.array(contrib),rows
hc,ht=accounting(holds['full'],False);diagnosis={};attrs=[];alltrades={}
for name,r in results.items():
 sc,ts=accounting(r);alltrades[name]=ts
 if name not in ['D_base','L_base']:continue
 h=holds['full'][0];a,z=streak(r[0],h);dailyDiff=sc.sum(axis=1)-hc.sum(axis=1);ld=np.log1p(sc.sum(axis=1))-np.log1p(hc.sum(axis=1));factor=np.divide(ld,dailyDiff,out=1/(1+hc.sum(axis=1)),where=np.abs(dailyDiff)>1e-14);parts=(sc-hc)*factor[:,None];assert np.max(np.abs(parts.sum(axis=1)-ld))<1e-13
 nav=np.r_[1e6,r[0]];hn=np.r_[1e6,h];rel=r[0]/h-1;trough=a+int(np.argmin(rel[a:z]));dframe=pd.DataFrame(parts,columns=columns);dframe['date']=e.DATES[e.START:];dframe['relativeChange']=ld;dframe['inStreak']=(np.arange(len(h))>=a)&(np.arange(len(h))<z);dframe['baseTarget']=bw[e.START:];dframe['dailyStrategy']=sc.sum(axis=1);dframe['dailyHold']=hc.sum(axis=1);dframe.to_csv(OUT/(name+'_daily_attribution.csv'),index=False)
 for label,lo,hi in [('wholeStreak',a,z),('toTrough',a,trough+1),('recovery',trough+1,z)]:
  for j,c in enumerate(columns):attrs.append(dict(name=name,period=label,component=c,logRelativeContribution=parts[lo:hi,j].sum()))
 item=dict(days=z-a,start=str(e.DATES[e.START+a]),end=str(e.DATES[e.START+z-1]),previousRelative=nav[a]/hn[a]-1,startRelative=rel[a],endRelative=rel[z-1],troughDate=str(e.DATES[e.START+trough]),troughRelative=rel[trough],segmentReturn=nav[z]/nav[a]-1,holdSegmentReturn=hn[z]/hn[a]-1,meanExposure=r[1][a:z].mean(),dailyWins=int((sc.sum(axis=1)[a:z]>hc.sum(axis=1)[a:z]).sum()),cashDays=int((r[1][a:z]<.01).sum()),lowExposureUpDays=int(((hc.sum(axis=1)[a:z]>0)&(r[1][a:z]<.75)).sum()),segmentInterest=float(r[6][a:z].sum()),segmentFees=float(-np.sum(sc[a:z,4]*nav[a:z])),logAttributionSum=float(parts[a:z].sum()),exactLogRelativeChange=float(np.log((nav[z]/hn[z])/(nav[a]/hn[a]))))
 if z<len(h):item.update(catchupDate=str(e.DATES[e.START+z]),catchupStrategy=float(nav[z+1]/nav[z]-1),catchupHold=float(hn[z+1]/hn[z]-1),catchupRelative=rel[z])
 item['worstDays']=dframe.iloc[a:z].nsmallest(10,'relativeChange').to_dict('records');item['bestDays']=dframe.iloc[a:z].nlargest(5,'relativeChange').to_dict('records');diagnosis[name]=item
pd.DataFrame(metrics).to_csv(OUT/'metrics.csv',index=False);pd.DataFrame(stress).to_csv(OUT/'stress10bp.csv',index=False);pd.DataFrame(continuous).to_csv(OUT/'continuous_periods.csv',index=False);pd.DataFrame(daily).to_csv(OUT/'daily_nav.csv',index=False);pd.DataFrame(attrs).to_csv(OUT/'attribution.csv',index=False);pd.DataFrame(selection).to_csv(OUT/'selection.csv',index=False);pd.DataFrame(rolling).to_csv(OUT/'rolling_choices.csv',index=False)
(OUT/'diagnosis.json').write_text(json.dumps(diagnosis,indent=2));(OUT/'trades.json').write_text(json.dumps(alltrades,separators=(',',':')));(OUT/'frozen_choices.json').write_text(json.dumps(choices))
# Include only original-streak sessions in a compact replay file; all actual executions retained.
replays=[]
for d in range(int(np.searchsorted(e.DATES,'2024-02-06')),int(np.searchsorted(e.DATES,'2025-04-04'))):
 dt=str(e.DATES[d]);replays.append(dict(date=dt,bars=e.B[d,:,:4].tolist(),trades={n:[t for t in ts if t['date']==dt] for n,ts in alltrades.items() if not n.endswith('rolling')}))
(OUT/'replays.json').write_text(json.dumps(replays,separators=(',',':')))
m=pd.DataFrame(metrics).set_index(['name','period']);st=pd.DataFrame(stress).set_index(['name','period']);acceptance=[]
for name in plans:
 b=name[0]+'_base';goal=lambda p:bool(m.loc[(name,p),'return_']>=m.loc[('hold',p),'return_'] and abs(m.loc[(name,p),'mdd5'])<=.75*abs(m.loc[('hold',p),'mdd5']))
 checks=dict(name=name,laterBothBetter=all(m.loc[(name,p),'return_']>m.loc[(b,p),'return_'] for p in ['validation','recent']),laterDDBudget=all(abs(m.loc[(name,p),'mdd5'])<=abs(m.loc[(b,p),'mdd5'])+.02 for p in ['validation','recent']),olderNotWorse=bool(m.loc[(name,'older'),'return_']>=m.loc[(b,'older'),'return_']),improvedYears=sum(m.loc[(name,'year'+str(y)),'return_']>m.loc[(b,'year'+str(y)),'return_'] for y in [1,2,3]),stressBothBetter=all(st.loc[(name,p),'return_']>st.loc[(b,p),'return_'] for p in ['validation','recent']),wealth120Separate=bool((1+m.loc[(name,'full'),'return_'])/(1+m.loc[('hold','full'),'return_'])>=1.2),independentEvidence=False)
 if name[0]=='D':checks.update(cashFullGoal=goal('full'),cashYearsPassed=sum(goal('year'+str(y)) for y in [1,2,3]),cashOlderGoal=goal('older'),cashStressGoal=bool(st.loc[(name,'full'),'return_']>=st.loc[('hold','full'),'return_'] and abs(st.loc[(name,'full'),'mdd5'])<=.75*abs(st.loc[('hold','full'),'mdd5'])))
 acceptance.append(checks)
(OUT/'acceptance.json').write_text(json.dumps(acceptance,indent=2,default=lambda x:int(x)))
assert hashlib.sha256(prior.read_bytes()).hexdigest()==priorhash
verification=dict(ledgerTrades=ledgerCount,maxLedgerError=maxerr,maxDailyPnLError=maxpnlerr,featurePrefixChecks=e.N-23,futureBarPoisonChecks=e.N-23,T1=True,debtCap=True,volumeCap=True,priceLimits=True,independentForward=False,forwardUnchanged=True,forwardSHA256=priorhash)
(OUT/'verification.json').write_text(json.dumps(verification,indent=2));np.savez_compressed(ROOT/'work/underperformance/plans.npz',**plans)
print(m.xs('full',level='period')[['return_','mdd5','longestLag','cumulativeLead']].to_string());print('Training choices',choices);print(json.dumps(verification));print('Default diagnosis',json.dumps({k:v for k,v in diagnosis['L_base'].items() if k not in ['worstDays','bestDays']}))
