from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json, hashlib
import pandas as pd
import numpy as np
R=Path.cwd();O=R/'outputs/ma20_macd';W=R/'work/ma20_macd'
plan={'registeredAt':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'question':'Does standard positive MACD confirmation add useful entry discrimination to a rising MA20 setup, with the same exit and execution?','sourceStatus':'Generic preregistered implementation inspired by user title and primary indicator guides; NOT a verified reproduction of the Xiaohongshu video. Only its title/author and secondary AI comment were read.','rules':{'A':'At previous completed close: adjusted C>20-session SMA AND SMA20>=previous SMA20; at least130 prior bars for identical warmup.','X':'A AND EMA12-EMA26>0 AND (EMA12-EMA26)-EMA9(EMA12-EMA26)>0. A positive-state gate, NOT a same-day-cross requirement.','commonExit':'Previous completed adjusted C<SMA20. Once triggered and holding, sell at next10:00 and retry every session until flat even if price recovers. No maximum holding time and no MACD exit; only entry changes.','execution':'If flat at day start and gate true, begin buy10:00, up to5bars; cash100% or financing150%, no further adds/rebalances on later holding days. Actual fills subject to fees/slippage/T1/limit/volume. Existing maintenance exits retained. Complete exit uses zero tolerance, baseline D/L unchanged. End open position marked, excluded from completed win count but included in all account PnL/drawdown.'},'parameters':'20,12,26,9; no optimization. 130bar warmup, recursive EMA seeded first available close. Decisions lagged1session. Same formulas both stocks.','tests':'2stocks*8chronologicalperiods*2slips*8models=256 accounts. B,D,L,F50,AC,AL,XC,XL. Early<=2024, later2025..Jun2026,July; three fixed Oct9yearblocks; older2020..Sep2023. Quarterly attribution and rolling63day lead; all previously seen historical, not new blind test. No fitting/selection on later periods.','costs':'Actual user commission.0001,min5,historicalstamp/transfer,5/10bp eachside roundedtick,prior5mvolume1%,300kshares/fill,100sharelots,T1,6%annualinterest,borrow<=50%netasset afterbuy;passiveover150held. Existing dividend-tax assumptions retained.','metrics':'Net flat-to-flat completed cycle wins/denominator, no intraday T win claim; open marked profit, all-day profitability incl flat, net return, 5mclose DD, daily5%tail, exposure, periods pre/postJuly, cumulative and63day leading, longest lag.','limitations':'History through2026-10-08. Oct9 minute/daily extrema mismatch remains and is excluded. Historical minute coverage/price quality, financial vintages and financing eligibility limitations persist. No live orders, default unchanged.','sources':[{'url':'https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/macd','accessed':'2026-10-10','type':'primary brokerage education; indicator specification not efficacy proof','market':'general technical analysis','frequency':'period-dependent; here daily','rule':'12/26 EMA difference,9 EMA signal; signal/zero cross; range whipsaw','evidence':'No audited win-rate denominator or Hudian results supplied.'},{'url':'https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/macd-moving-average-convergence-divergence-oscillator','accessed':'2026-10-10','type':'primary charting-provider education','market':'general; examples US stocks','frequency':'daily examples','rule':'Standard12/26/9; example uses200day trend filter, NOT this MA20 rule','evidence':'Reference for formulas; does not establish this candidate profitability.'},{'url':'https://www.xiaohongshu.com/explore/6ac4f0ad000000000200f668','accessed':'2026-10-10','author':'良益','type':'title/page+secondaryAIcommentonly','evidence':'Original15:36video not verified; no verified trade denominator.'}]}
p=O/'plan-before-results.json'
if not p.exists():p.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
manifest={};checks=0;mutation=0
for stock,path in [('hudian','work/risk_priority/data.json'),('shenghong','work/shenghong/data.json')]:
 d=json.loads((R/path).read_text());paths=['work/round2/data/daily_qfq_early.csv','work/data/daily_qfq.csv']if stock=='hudian'else['work/shenghong/data/daily_qfq.csv']
 q=pd.concat([pd.read_csv(R/x)for x in paths]).sort_values('date').drop_duplicates('date',keep='last').reset_index(drop=True)
 def features(q):
  c=q.close;sma=c.rolling(20).mean();dif=c.ewm(span=12,adjust=False).mean()-c.ewm(span=26,adjust=False).mean();dea=dif.ewm(span=9,adjust=False).mean();ready=np.arange(len(q))>=129
  a=(c>sma)&(c>=c.shift(20))&ready;x=a&(dif>0)&(dif>dea);out=pd.DataFrame({'date':q.date,'knownThrough':q.date.shift(),'A':a.shift(fill_value=False),'X':x.shift(fill_value=False),'exit':(c<sma).shift(fill_value=False),'priorClose':c.shift(),'ma20':sma.shift(),'dif':dif.shift(),'dea':dea.shift(),'hist':(dif-dea).shift()});return out
 f=features(q).set_index('date').loc[d['dates']].reset_index()
 # Independent scalar EMA recurrence and strict yesterday-only rolling arrays.
 e12=e26=dea=None;past=[];last=None;lookup={}
 for row in q.itertuples():
  if last is not None:lookup[row.date]=last
  c=float(row.close);past.append(c);e12=c if e12 is None else (2/13)*c+(11/13)*e12;e26=c if e26 is None else(2/27)*c+(25/27)*e26;dif=e12-e26;dea=dif if dea is None else .2*dif+.8*dea
  ma=np.mean(past[-20:])if len(past)>=20 else np.nan;old=np.mean(past[-21:-1])if len(past)>=21 else np.nan;a=bool(len(past)>=130 and c>ma and len(past)>=21 and past[-1]>=past[-21]);last={'knownThrough':row.date,'A':a,'X':bool(a and dif>0 and dif>dea),'exit':bool(c<ma),'dif':dif,'dea':dea}
 for row in f.itertuples():
  z=lookup[row.date];assert row.knownThrough==z['knownThrough']
  for k in ['A','X','exit']:assert bool(getattr(row,k))==z[k],(stock,row.date,k)
  for k in ['dif','dea']:assert abs(getattr(row,k)-z[k])<1e-10
  checks+=1
 for date in d['dates'][::80]:
  changed=q.copy();changed.loc[changed.date>=date,'close']*=3.7
  a=features(changed).set_index('date').loc[date];b=f.set_index('date').loc[date]
  for k in ['A','X','exit','dif','dea','ma20']:assert a[k]==b[k]
  mutation+=1
 f.to_csv(O/f'{stock}-daily.csv',index=False);(O/f'{stock}-masks.json').write_text(json.dumps({'dates':d['dates'],**{k:f[k].astype(bool).tolist()for k in ['A','X','exit']}}))
 for p in [path]+paths:manifest[p]=hashlib.sha256((R/p).read_bytes()).hexdigest()
for p in ['work/shenghong/finance.mjs','work/shenghong/benchmark.mjs','work/opening_guard/metrics.mjs','work/hudian-backtest-dashboard/docs/fees.js','work/hudian-backtest-dashboard/docs/default-selection.json','outputs/regime_policy/metrics.json']:manifest[p]=hashlib.sha256((R/p).read_bytes()).hexdigest()
(O/'manifest.json').write_text(json.dumps(manifest,indent=2));(O/'feature-audit.json').write_text(json.dumps({'strictPrefixScalarChecks':checks,'futureMutationChecks':mutation},indent=2))
# Candidate-only optional entry/exit implementation. Original mode remains byte-equivalent in behavior.
s=(R/'work/shenghong/finance.mjs').read_text();assert 'maintenance=1.5}={})'in s
s=s.replace('maintenance=1.5}={})','maintenance=1.5,entryMask=null,exitMask=null}={})').replace(' const nav=[],',' let exitLatched=false;\n const nav=[],',1)
s=s.replace('const orig=data.signals[base][d],plan=',"if(entryMask&&shares===0)exitLatched=false;\n  if(entryMask&&shares>0&&exitMask[d])exitLatched=true;\n  const orig=entryMask?(shares>0?(exitLatched?[6,0]:[-1,-1]):(entryMask[d]?[6,1]:[-1,-1])):data.signals[base][d],plan=")
s=s.replace('tol=target>=1?.004:.035','tol=entryMask&&target===0?0:target>=1?.004:.035');(W/'finance.mjs').write_text(s)
s=(R/'work/combo_trend/run.mjs').read_text().replace("'./finance_hold.mjs'","'./finance.mjs'").replace("O='outputs/combo_trend/'","O='outputs/ma20_macd/'").replace("['B','D','L','F50','UC','UL','TC','TL','MC','ML']","['B','D','L','F50','AC','AL','XC','XL']").replace('holdSessions:20','exitMask:name.length===2?masks.exit:null')
beg=s.index('   }else{\n    let first=null;');end=s.index("   if(period==='full'",beg)
s=s[:beg]+'''   }else{
    let latched=false;const byday=new Map();for(const t of r.trades){if(!byday.has(t[0]))byday.set(t[0],[]);byday.get(t[0]).push(t);}
    for(let day=a;day<z;day++){
     const atStart=day===a?0:r.daily[day-a-1].shares;
     if(!atStart)latched=false;if(atStart&&masks.exit[day])latched=true;
     const expected=atStart?(latched?[6,0]:[-1,-1]):masks[name[0]][day]?[6,name.endsWith('L')?1.5:1]:[-1,-1];assert.deepEqual(r.targets[day-a],expected);
     for(const t of byday.get(day)||[]){if(t[2]>0){assert(!atStart);assert(masks[name[0]][day]);}else if(!t[15])assert(latched);holdChecks++;}
    }
   }
''' +s[end:]
s=s.replace('assert.equal(rows.length,320)','assert.equal(rows.length,256)');(W/'run.mjs').write_text(s)
print(json.dumps({'planFrozen':True,'prefixChecks':checks,'futureMutation':mutation,'engineGenerated':True}))
