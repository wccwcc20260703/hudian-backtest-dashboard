from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,html,zipfile,shutil,hashlib,math
import pandas as pd
R=Path.cwd();O=R/'outputs/ma20_macd';repo=R/'work/hudian-backtest-dashboard';m=pd.read_json(O/'metrics.json');e=pd.read_json(O/'episodes.json');q=pd.read_json(O/'quarters.json');a=json.loads((O/'audit.json').read_text());plan=json.loads((O/'plan-before-results.json').read_text())
names={'B':'全仓持有','D':'原D现金','L':'原L融资默认','F50':'固定50%现金','AC':'MA20现金','AL':'MA20融资','XC':'MA20＋MACD现金','XL':'MA20＋MACD融资'};stocks={'hudian':'沪电','shenghong':'胜宏'};periods={'full':'近三年','older':'2020—2023年9月','early':'2023年10月—2024末','later':'2025年初—2026年6月','julyOn':'2026年7月起重置','year1':'固定年度1','year2':'固定年度2','year3':'固定年度3'}
pct=lambda v:'—'if pd.isna(v)else f'{v*100:.2f}%'
def table(head,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>'for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>'for x in row)+'</tr>'for row in rows)+'</tbody></table></div>'
def wins(x):return f'{int(x.episodeWins)}/{int(x.closedEpisodes)} · '+pct(x.episodeWinRate)if x.closedEpisodes else '无已完成周期'
body='''<nav><a href="../index.html">← 策略看板</a> · <a href="archive.html">研究归档</a></nav><h1>20日均线＋MACD：共振能否提高胜率？</h1><p>256组完整账户 · 沪电与胜宏 · 现金与融资分开 · 截至2026-10-08 · 默认未改</p>
<section><h2>结论：这一明确化版本不适合直接接入</h2><p>沪电三年现金完整持仓周期胜率，MA20单独为12/42＝28.57%，增加MACD确认仍为8/28＝28.57%；净收益从+0.60%变为−17.25%，最大回撤由48.11%略降至44.72%。融资共振方案净收益−37.15%，回撤59.62%。这不满足用户优先胜率与控制回撤的偏好。</p><p>这次检验的是公开指标规则的固定组合，<strong>不是已经完整复现小红书作者视频</strong>。视频原声与全部画面未核验；页面作者、标题、时长及评论区AI摘要已读取。不能把本次失败扩大为“作者全部方法无效”，也不能为得到好结果临时改参数。</p></section>
<section><h2>网络资料提供了什么，没提供什么</h2><p>Fidelity与StockCharts给出标准MACD计算：12期EMA减26期EMA，信号线是差值的9期EMA。MACD在震荡区间可能反复穿越；资料没有提供沪电的可核验高胜率交易样本。StockCharts示例使用200日趋势过滤，并不是本实验的20日均线。</p><p>由公式可知，MA20与MACD都来自历史价格，因此“共振”并非两份独立证据，这是本研究的分析判断。要检验额外价值，需要比较加入前后的净胜率、尾部亏损、参与度及交易频次。</p>'''
for s in plan['sources']:body+=f'<p><a href="{html.escape(s["url"],quote=True)}">{html.escape(s.get("author",s["type"]))}</a> · 访问2026-10-10 · {html.escape(s["evidence"])}</p>'
body+='''</section><section><h2>冻结的可执行规则</h2>'''
body+=table(['项目','MA20对照A','共振候选X'],[['前一完整交易日条件','收盘价>MA20，MA20不下降','A成立，并且DIF>0、DIF>DEA'],['参数','日线SMA20','日线EMA12/26，DEA=EMA9(DIF)'],['买入','日初空仓且条件满足，10:00尝试','同左；只是增加入场过滤'],['卖出','前一天收盘价<MA20，次日10:00卖出','完全相同，不增加MACD退出'],['未卖完','退出指令持续到清仓，即使价格收回','同左'],['持有','后续持仓日不补仓、不再平衡，无最大持有期','同左'],['仓位','现金目标100%；融资目标150%','同左']])
body+='''<p>这是“正向状态确认”，不是要求均线突破、MACD金叉、零轴突破恰好发生在同一天。没有把“站稳”“有效跌破”“红柱最短”等模糊描述当作已确定规则。EMA从最早可得收盘递推，至少130根历史K线预热；所有当日交易仅使用前一日及更早数据。MA20斜率用等价的C[t]≥C[t−20]计算，避免均线恰好走平时浮点误差；该修正在账户结果产生前经独立检查发现并记录。</p><p>规则本身为波段候选，<strong>完整持仓周期胜率不是日内做T胜率</strong>。没有把当天终盘结果倒推成早盘信号。本轮固定参数直接顺序重放，按早/后期、年度、季度核验，没有滚动调参或把看过的历史称为新盲测。</p></section><section><h2>近三年：单边5基点滑点</h2>'''
v=m[(m.period=='full')&(m.slip==.0005)]
body+=table(['股票／策略','净收益','最大回撤','扣费完整周期胜率','平均仓位','盈利日／全部交易日','最差5%日均收益','成交笔数'],[[stocks[x.stock]+'／'+names[x.name],pct(x.return_),pct(-x.mdd5),wins(x),pct(x.exposure),f'{x.winningDays}/{x.days} · '+pct(x.winningDayFraction),pct(x.worst5pctDayMean),x.orders]for x in v.itertuples()])
body+='''<p>全仓持有与固定50%对照没有清仓结束的周期，因此不填0%或100%胜率。所有空仓、平盘日都在账户盈利日分母内，但不算盈利日。各候选本段期末均已空仓；原D/L未平仓亏损仍按市值计入收益和回撤。胜宏的共振现金周期胜率7/23＝30.43%，低于单独MA20的11/32＝34.38%；收益+99.68%，回撤55.28%。并未获得跨股票稳定高胜率。</p></section><section><h2>失败集中在哪里？逐周期诊断</h2>'''
diag=[]
for name in ['AC','XC','AL','XL']:
 z=e[(e.stock=='hudian')&(e.name==name)&e.complete];short=z[z.days<=5];wins_=z[z.pnl>0];loss=z[z.pnl<0];diag.append({'name':name,'closed':len(z),'medianDays':float(z.days.median()),'shortCount':len(short),'shortLosses':int((short.pnl<0).sum()),'avgWinnerReturn':float(wins_.return_.mean()),'avgLoserReturn':float(loss.return_.mean())})
body+=table(['沪电账户','周期中位交易日数','≤5交易日结束／亏损','盈利周期平均收益','亏损周期平均收益'],[[names[x['name']],x['medianDays'],f"{x['shortCount']}／{x['shortLosses']}",pct(x['avgWinnerReturn']),pct(x['avgLoserReturn'])]for x in diag])
body+='''<p>共振现金有8个周期在5个交易日内结束，8个全部亏损；单独MA20有18个，其中15个亏损。这是事后分组，交易开始时不知道最终持有多久，不能据此创造“剔除短周期”的未来函数。减少交易数量也没有自动提高胜率：现金完成周期从42降至28，比例不变，平均亏损周期反而更差。</p>'''
z=e[(e.stock=='hudian')&(e.name=='XC')&e.complete].sort_values('return_').head(3)
body+=table(['共振现金较差案例：买入日至清仓日','交易日数','完整周期净收益'],[[x.start+' → '+x.end,x.days,pct(x.return_)]for x in z.itertuples()])
body+='''<p>下一步应沿逐日档案核验这些反复穿越均线的过程，比较第一次站上、回踩后再站上、以及放量后无法保持强势的差别。需要先记录当时可知信息再冻结新条件；不能看到这几次亏损后逐个增加例外。</p></section><section><h2>更早行情、固定年度与先后时间段</h2>'''
v=m[(m.period!='full')&(m.slip==.0005)&m.name.isin(['AC','XC','AL','XL'])]
body+=table(['股票／时期／策略','净收益','最大回撤','完整周期胜率','平均仓位'],[[stocks[x.stock]+'／'+periods[x.period]+'／'+names[x.name],pct(x.return_),pct(-x.mdd5),wins(x),pct(x.exposure)]for x in v.itertuples()])
body+='''<p>沪电更早2020—2023年9月，共振现金净收益−28.76%、回撤43.02%；融资−43.89%、回撤57.33%。固定三年度中，共振现金回撤在第1和第3年度低于MA20对照，但第2年度更差；这只是相对弱对照的局部改善，不能称为原风险目标达标。完整周期胜率依然低。年度1/2/3分别从2023/2024/2025年10月9日开始；各段重新以100万元起步，不能直接拼接。</p></section><section><h2>滑点翻倍：单边10基点</h2>'''
v=m[(m.period=='full')&(m.slip==.001)&m.name.isin(['D','L','AC','XC','AL','XL'])]
body+=table(['股票／策略','净收益','最大回撤','完整周期胜率'],[[stocks[x.stock]+'／'+names[x.name],pct(x.return_),pct(-x.mdd5),wins(x)]for x in v.itertuples()])
body+='</section><section><h2>连续账户7月前后与滚动领先</h2>'
v=m[(m.period=='full')&(m.slip==.0005)&m.name.isin(['B','D','L','AC','XC','AL','XL'])]
body+=table(['股票／策略','截至6月30日','7月起承接持仓','累计领先持有日比例','最长连续落后','滚动63日领先比例'],[[stocks[x.stock]+'／'+names[x.name],pct(x.preJuly),pct(x.postJuly),'基准'if x.name=='B'else pct(x.leadFraction),'—'if x.name=='B'else x.longestBehind,'—'if x.name=='B'else pct(x.rolling63Lead)]for x in v.itertuples()])
body+='''<p>滚动63日窗口互相重叠，不是独立样本；这里的7月分段承接原账户，与上表“7月起重置”不同。季度归因明细和全部账户保存于证据包。</p></section><section><h2>成本、数据与核验</h2>'''
body+=f'''<p>已核验{a['ledger']:,}笔成交、{a['loanChecks']:,}次买入资金约束、{a['accountDays']:,}个账户日；{a['originalMetricParity']}个原策略指标复算一致。{a['strictPrefixScalarChecks']}个日期以独立递推公式核对，{a['futureMutationChecks']}次未来数据修改检查、{a['accountFuturePrefixChecks']}次账户前缀检查、{a['episodeReconciliations']}份周期盈亏与净值核对通过。合成样例覆盖零成交量导致卖出延期、卖出指令保持、细小剩余仓位清完及次日重新入场。</p>'''
body+='''<p>使用已确认佣金万1、每笔最低5元，历史印花税及过户费；融资年息6%，每笔买入后欠款≤当前净资产50%，被动超仓不主动削回150%。执行T+1、100股买入、前根5分钟成交量1%、每笔最多30万股、涨跌停、双边滑点与价格最小刻度。分红税保留原简化口径：策略20%、长期持有基准0%。</p><p>沿用截至2026-10-08的历史数据。10月9日分钟与日线极值差异未解决，不虚构该日成交。历史分钟价格质量、财报修订与融资资格未完全核验；回撤按5分钟收盘估计，不是逐笔最坏回撤。这些数据限制也适用于旧策略对照。全部历史已经被研究过，没有冻结后的独立证据。</p><p>当前优先胜率、回撤和尾部亏损，未以收益硬下限淘汰候选；但本轮仍未显示合格风险改善。原“保留持有收益＋回撤相对降低25%”及财富1.20倍仅作历史标准，没有宣称通过。默认策略不变、不下真实订单。</p><p><a href="ma20-macd-evidence.zip">下载全部结果、逐笔账本、冻结计划及复跑脚本</a></p></section>'''
style='body{font:16px/1.8 system-ui,sans-serif;background:#f3f6fa;color:#18304a;margin:0}main{max-width:1350px;margin:28px auto;padding:20px}section{background:white;border:1px solid #dce5ee;border-radius:14px;padding:26px;margin:20px 0}h1{font-size:30px}h2{font-size:21px}a{color:#127d85}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}td,th{padding:10px;border-bottom:1px solid #dce5ee;white-space:nowrap;text-align:left}th{background:#f3f6fa}'
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>20日均线＋MACD回测｜沪电研究</title><style>'+style+'</style></head><body><main>'+body+'</main></body></html>'
(O/'report.html').write_text(page);(O/'diagnosis.json').write_text(json.dumps(diag,ensure_ascii=False,indent=2));m.to_csv(O/'metrics.csv',index=False)
# Snapshot files needed for reproducibility; original sources retained, no raw personal browser data.
inputs=list(json.loads((O/'manifest.json').read_text()))+['work/hudian-backtest-dashboard/docs/attribution.js']
with zipfile.ZipFile(O/'evidence.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in list(O.iterdir())+list((R/'work/ma20_macd').iterdir())+[R/p for p in inputs]:
  if p.is_file()and p.name not in ['evidence.zip','publication.json','deployment.json']:z.write(p,str(p.relative_to(R)))
shutil.copyfile(O/'report.html',repo/'docs/research/ma20-macd.html');shutil.copyfile(O/'evidence.zip',repo/'docs/research/ma20-macd-evidence.zip')
ar=repo/'docs/research/archive.html';s=ar.read_text();link='<p><a href="ma20-macd.html">20日均线＋MACD：256组账户检验，共振是否真的提高胜率？ ↗</a></p>'
if 'href="ma20-macd.html"'not in s:ar.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+link))
cp=R/'work/research-checkpoint.json';c=json.loads(cp.read_text());now=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat();c['ma20Macd']={'updatedAt':now,'outputs':'outputs/ma20_macd','source':'Generic daily MA20+MACD gate; not original video reproduction','findings':'Hudian cash A12/42=28.57% X8/28=28.57%; return+0.60to-17.25; DD48.11to44.72. MarginX-37.15/DD59.62. OlderHcash-28.76/DD43.02. ShenghongX7/23=30.43%. Do not adopt. Eight short<=5session Xcycles all loss is descriptive, not a future-known filter.','audit':a,'defaultChanged':False,'nextQuestion':'Continue chronological behavior journal; compare transient MA20 reclaim vs persistent acceptance using only information available by decision time. Do not retune parameter grid against these failures.','publication':'pending'};c['updatedAt']=now;cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
assert '28.57%'in page and 'ma20-macd.html'in ar.read_text();print(json.dumps({'report':str(O/'report.html'),'zipBytes':(O/'evidence.zip').stat().st_size,'defaultHashUnchanged':hashlib.sha256((repo/'docs/default-selection.json').read_bytes()).hexdigest()==json.loads((O/'manifest.json').read_text())['work/hudian-backtest-dashboard/docs/default-selection.json']}))
