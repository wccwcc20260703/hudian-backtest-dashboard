# -*- coding: utf-8 -*-
from pathlib import Path
import json,hashlib
from datetime import datetime
r=Path.cwd();s=(r/'work/hudian-backtest-dashboard/docs/finance-engine.js').read_text()
plan={'createdAt':datetime.now().astimezone().isoformat(),'question':'Does a fixed09:45 high-volume continued-selloff cap lower loss tails without too many premature sells?','rule':'At09:45 use first3completed5minbars: bar2close<=dayopen*0.99; bars1and2close below their own cumulativeVWAP*0.999; first3barvolume>=1.2*mean(first3barvolume of previous20sessions). All four tests required. Fixed thresholds, no grid.','execution':'Sell-only new risk instruction at09:45: cashcap50%,margincap100%; cap all later ORIGINAL scheduledtargets same day, no standalone newbuy fromguard. Retainloweroriginaltargets,maintenance,vol1%,T+1,fees,borrow<=50%netafterbuy,passivedriftallowed. Capexpiresnextday,originalstrategyresumes; no forcedsame-dayrebuy.','variants':['off','guard'],'accounts':['Dcash','Dallfull150','Dtrend150'],'slippage':[.0005,.001],'commission':.0001,'minimumCommission':5,'interest':.06,'alreadySeenHistory':True,'previousTestsReviewed':['sell_latency:changes alreadyplanned reductiontiming,not newrisk','daily_qa:foreign shock or VWAPupthenfail, not fixedopeningdropandvolume','chase_guard:after10:15highthenfade,not earlyopeningdrop','support_factors:volume1.2 on dipbuy,not riskexit'],'selection':'No winner search; fixedsinglecandidate with early2023Oct..2024Dec, later2025..Jun2026, Julyon, older,3annual,10bp. Quarterly2025on use preceding252 sessions only: >=10triggerdays, lowerDD and no lowercompleteepisodewinrate than baseline, positiveportfolio netreturn; else off. Returnsnohardfloorvsbaseline.','paired':'For every fullperiodtrigger, rerunbaseline prefix with guardonlyonthatdate; identicalinheritedstate, comparedayclose neteffect. Pairedcounterfactualnotcontinuousstrategy and notTsuccessrate.'}
(r/'outputs/opening_guard/plan-before-results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
s=s.replace("'./fees.js?v=74745f12a7da'","'../hudian-backtest-dashboard/docs/fees.js'")
s=s.replace('export function financeBacktest','export function guardBacktest').replace('maintenance=1.5}={})','maintenance=1.5,riskMask=[],riskCap=1}={})')
s=s.replace('forced=false;\n  const orig','forced=false,dayCap=Infinity,reduceOnly=false;\n  const orig')
s=s.replace('target=sig;pending=true;deadline=Math.min(j+4,46);forced=false;','target=Math.min(sig,dayCap);pending=true;deadline=Math.min(j+4,46);forced=false;reduceOnly=false;')
needle='    if(loan>0&&';assert needle in s
s=s.replace(needle,"    if(j===3&&riskMask[d]){dayCap=riskCap;if(knownEq>0&&shares*known/knownEq>dayCap){target=pending?Math.min(target,dayCap):dayCap;pending=true;deadline=Math.min(j+4,46);reduceOnly=true;forced=false;}else if(pending)target=Math.min(target,dayCap);}\n"+needle)
s=s.replace('forced=true;}','forced=true;reduceOnly=true;}')
s=s.replace('qty=Math.min(qty,aff);','qty=Math.min(qty,aff);if(reduceOnly)qty=0;')
s=s.replace('forced?1:0]);','forced?1:0,reduceOnly?1:(Number.isFinite(dayCap)&&sig>dayCap?2:0)]);')
(r/'work/opening_guard/engine.mjs').write_text(s)
(r/'outputs/opening_guard/engine-sha.json').write_text(json.dumps({'sha256':hashlib.sha256(s.encode()).hexdigest()}))
print('Saved fixed plan and isolated risk engine')
