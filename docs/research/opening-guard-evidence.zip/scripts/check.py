# -*- coding: utf-8 -*-
from pathlib import Path
import json,numpy as np
r=Path.cwd();d=json.loads((r/'work/risk_priority/data.json').read_text());b=np.array(d['bars']);ref=json.loads((r/'outputs/opening_guard/events.json').read_text());cv=np.cumsum(b[:,:3,4],axis=1);vw=np.cumsum(b[:,:3,5],axis=1)/cv;count=0
for i,row in enumerate(ref):
 flag=False
 if i>=20:
  pv=b[i-20:i,:3,4].sum(axis=1).mean();assert abs(pv-row['priorVolume'])<1e-6
  flag=bool(b[i,2,3]<=b[i,0,0]*.99 and b[i,1,3]<vw[i,1]*.999 and b[i,2,3]<vw[i,2]*.999 and cv[i,2]>=pv*1.2)
 assert flag==row['trigger'];count+=1
p=r/'outputs/opening_guard/audit.json';a=json.loads(p.read_text());a['independentPythonTriggerChecks']=count;p.write_text(json.dumps(a,indent=2));print(count)
