from pathlib import Path
import json,requests,datetime,hashlib,concurrent.futures
P=Path('work/pcb_flow/raw');old=json.loads(Path('work/pcb_flow/receipts.json').read_text());base={x['name']:x for x in old}
items=[]
for pn in [2,3]:
 x=base['members'];items.append((f'members{pn}',x['url'],{**x['params'],'pn':str(pn)}))
x=base['daily'];items.append(('daily_extended',x['url'],{**x['params'],'lmt':'2000','beg':'20200101','end':'20261009'}));items.append(('daily_before_april',x['url'],{**x['params'],'lmt':'2000','beg':'20200101','end':'20260410'}))
x=base['minute'];items.append(('minute_oct8_request',x['url'],{**x['params'],'lmt':'10000','beg':'202610080930','end':'202610081500'}))
def run(item):
 name,url,params=item;r={'name':name,'url':url,'params':params,'requestedAt':datetime.datetime.now().astimezone().isoformat()}
 try:
  x=requests.get(url,params=params,headers={'Referer':'https://data.eastmoney.com/bkzj/BK0877.html'},timeout=(8,18));r.update(status=x.status_code,bytes=len(x.content),sha256=hashlib.sha256(x.content).hexdigest());(P/(name+'.json')).write_bytes(x.content);x.raise_for_status();j=x.json();d=j.get('data') or {};v=d.get('klines',d.get('diff',[]));r.update(rc=j.get('rc'),rows=len(v),first=v[0]if v else None,last=v[-1]if v else None)
 except Exception as e:r['error']=str(e)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:out=list(ex.map(run,items))
Path('work/pcb_flow/coverage-receipts.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps([{k:v for k,v in x.items()if k not in ['params','first','last']}|{'firstDate':x['first'].split(',')[0]if isinstance(x.get('first'),str)else None,'lastDate':x['last'].split(',')[0]if isinstance(x.get('last'),str)else None}for x in out],ensure_ascii=False))
