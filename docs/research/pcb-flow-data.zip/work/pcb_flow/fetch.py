from pathlib import Path
from datetime import datetime
import requests,json,hashlib,concurrent.futures,warnings
warnings.filterwarnings('ignore')
R=Path('work/pcb_flow');P=R/'raw';P.mkdir(exist_ok=True,parents=True)
base={'lmt':'0','klt':'101','fields1':'f1,f2,f3,f7','fields2':','.join('f'+str(i) for i in range(51,66)),'secid':'90.BK0877','ut':'b2884a393a59ad64002292a3e90d46a5'}
requests_=[('daily','https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get',base),('minute','https://push2.eastmoney.com/api/qt/stock/fflow/kline/get',{**base,'klt':'1'}),('snapshot','https://push2.eastmoney.com/api/qt/ulist.np/get',{'fltt':'2','secids':'90.BK0877','fields':'f12,f14,f62,f184,f66,f69,f72,f75,f78,f81,f84,f87,f64,f65,f70,f71,f76,f77,f82,f83,f124,f6','ut':base['ut']}),('members','https://push2.eastmoney.com/api/qt/clist/get',{'fid':'f62','po':'1','pz':'100','pn':'1','np':'1','fltt':'2','invt':'2','fs':'b:BK0877','fields':'f12,f14,f2,f3,f62,f184,f66,f69,f72,f75,f78,f81,f84,f87,f124,f6'})]
def fetch(x):
 name,url,params=x;receipt={'name':name,'requestedAt':datetime.now().astimezone().isoformat(),'url':url,'params':params}
 try:
  r=requests.get(url,params=params,headers={'Referer':'https://data.eastmoney.com/bkzj/BK0877.html'},timeout=(8,18));receipt.update(status=r.status_code,bytes=len(r.content),sha256=hashlib.sha256(r.content).hexdigest());(P/(name+'.json')).write_bytes(r.content);r.raise_for_status();j=r.json();d=j.get('data');receipt['rc']=j.get('rc');receipt['dataKeys']=list(d) if isinstance(d,dict) else type(d).__name__
  if isinstance(d,dict):
   rows=d.get('klines',d.get('diff',[]));receipt['rows']=len(rows);receipt['first']=rows[0] if isinstance(rows,list) and rows else None;receipt['last']=rows[-1] if isinstance(rows,list) and rows else None;receipt['meta']={k:v for k,v in d.items() if k not in ['klines','diff']}
 except Exception as e:receipt['error']=str(e)
 return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:results=list(ex.map(fetch,requests_))
(R/'receipts.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps(results,ensure_ascii=False,indent=2))
