from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,pandas as pd,numpy as np,hashlib,shutil
R=Path.cwd();W=R/'work/pcb_flow';P=W/'raw';O=R/'outputs/pcb_flow';O.mkdir(exist_ok=True,parents=True)
read=lambda n:json.loads((P/(n+'.json')).read_text())
rawD=read('daily')['data'];rawM=read('minute')['data'];snap=read('snapshot')['data']['diff'][0]
assert rawD['code']==rawM['code']==snap['f12']=='BK0877' and rawD['name']==rawM['name']==snap['f14']=='PCB'
dcols=['date','main_net_yuan','small_net_yuan','medium_net_yuan','large_net_yuan','superlarge_net_yuan','main_net_pct','small_net_pct','medium_net_pct','large_net_pct','superlarge_net_pct','board_close','board_change_pct','reserved1','reserved2']
mcols=['time','main_net_yuan','small_net_yuan','medium_net_yuan','large_net_yuan','superlarge_net_yuan']
d=pd.DataFrame([s.split(',')for s in rawD['klines']],columns=dcols);m=pd.DataFrame([s.split(',')for s in rawM['klines']],columns=mcols)
for frame in [d,m]:
 for col in frame.columns[1:]:frame[col]=pd.to_numeric(frame[col],errors='raise')
 assert np.isfinite(frame.iloc[:,1:].to_numpy(float)).all()
 assert frame.iloc[:,0].is_unique and frame.iloc[:,0].is_monotonic_increasing
expected=pd.date_range('2026-10-09 09:31','2026-10-09 11:30',freq='min').append(pd.date_range('2026-10-09 13:01','2026-10-09 15:00',freq='min'))
assert list(pd.to_datetime(m.time))==list(expected)
# Same source arithmetic reconciliation; cannot certify trader identity or original publication vintage.
flowmap={'main_net_yuan':'f62','small_net_yuan':'f84','medium_net_yuan':'f78','large_net_yuan':'f72','superlarge_net_yuan':'f66'}
last=d.iloc[-1];lastM=m.iloc[-1];reconciliation={k:{'daily':float(last[k]),'minuteClose':float(lastM[k]),'snapshot':snap[v],'minuteDailyGapYuan':float(lastM[k]-last[k])}for k,v in flowmap.items()}
assert all(x['daily']==x['snapshot'] for x in reconciliation.values())
assert max(abs(x['minuteDailyGapYuan'])for x in reconciliation.values())<300
main_identity_daily=(d.main_net_yuan-d.large_net_yuan-d.superlarge_net_yuan).abs().max();main_identity_min=(m.main_net_yuan-m.large_net_yuan-m.superlarge_net_yuan).abs().max();assert main_identity_daily<=2048 and main_identity_min<=.01
m['main_change_1min_yuan']=m.main_net_yuan.diff();m['main_change_5tradingmin_yuan']=m.main_net_yuan.diff(5)
# Never sum these cumulative minute balances; first difference missing, and lunch interval differs from wallclock minutes.
key=m[m.time.str[-5:].isin(['09:36','09:39','09:45','10:00','10:30','11:30','13:30','15:00'])]
d.drop(columns=['reserved1','reserved2']).to_csv(O/'pcb-daily-flow.csv',index=False,encoding='utf-8-sig');m.to_csv(O/'pcb-minute-flow-2026-10-09.csv',index=False,encoding='utf-8-sig');key.to_csv(O/'pcb-key-times-2026-10-09.csv',index=False,encoding='utf-8-sig')
known=json.loads((W/'receipts.json').read_text());allreceipts=known+json.loads((W/'coverage-receipts.json').read_text())+json.loads((W/'retry-receipts.json').read_text())
summary={'capturedAt':known[0]['requestedAt'],'normalizedAt':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'code':'BK0877','name':'PCB','classification':'Eastmoney concept board, vendor aggregate; not handpicked peer proxy','sourcePage':'https://data.eastmoney.com/bkzj/BK0877.html','daily':{'rows':len(d),'first':d.date.iloc[0],'last':d.date.iloc[-1],'requestedDefaultLimit':0,'extendedRangeStatus':'Additional limit/date requests failed with ProxyError/RemoteDisconnected; actual retention ceiling not established.'},'minute':{'rows':len(m),'first':m.time.iloc[0],'last':m.time.iloc[-1],'meaning':'Cumulative session net flow, not amount in each minute. Retrieved after close; original real-time vintage not verified.','historicalDateRequest':'Attempt for Oct8 failed connection; does not prove endpoint supports or forbids historical-date access.'},'snapshot':{'sourceTimestamp':datetime.fromtimestamp(snap['f124'],ZoneInfo('Asia/Shanghai')).isoformat(),'turnoverYuan':snap['f6'],'mainNetPct':snap['f184'],'mainNetYuan':snap['f62'],'superlargeNetYuan':snap['f66'],'largeNetYuan':snap['f72'],'mediumNetYuan':snap['f78'],'smallNetYuan':snap['f84']},'checks':{'minuteTimeGrid':True,'sortedUnique':True,'mainEqualsLargePlusSuperlargeMaxDailyGapYuan':float(main_identity_daily),'mainEqualsLargePlusSuperlargeMaxMinuteGapYuan':float(main_identity_min),'reconciliation':reconciliation,'allSizeNetResidualYuan':float(snap['f66']+snap['f72']+snap['f78']+snap['f84']),'allSizeNetResidualPctTurnover':float((snap['f66']+snap['f72']+snap['f78']+snap['f84'])/snap['f6']*100)},'members':{'reportedTotal':read('members')['data']['total'],'retrieved':len(read('members')['data']['diff']),'fullListVerified':False,'reason':'page2/3 connectionfailed twice; not used to construct or replace aggregate'},'limitations':['No3yrfundflowhistoryacquired','NohistoricalPITmembership','Nooriginalearlysessionvintage; afterclose revision possible','Publicinterface canfail, noSLA','Mainflow vendorcategory, not identified institutional owner','No strategy/backtest/default change in this acquisition batch']}
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));(O/'request-receipts.json').write_text(json.dumps(allreceipts,ensure_ascii=False,indent=2))
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in P.iterdir()if p.is_file()};(O/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'daily':summary['daily'],'minute':summary['minute'],'snapshot':summary['snapshot'],'checks':summary['checks']},ensure_ascii=False,indent=2))
