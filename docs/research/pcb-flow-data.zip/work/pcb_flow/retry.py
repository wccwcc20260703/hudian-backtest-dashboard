from pathlib import Path
import requests,json,datetime,time,hashlib
P=Path('work/pcb_flow/raw');original={x['name']:x for x in json.loads(Path('work/pcb_flow/receipts.json').read_text())};attempts=[]
items=[]
for pn in [2,3]:
 x=original['members'];items.append((f'members{pn}',x['url'],{**x['params'],'pn':str(pn)}))
x=original['daily'];items.append(('daily_lmt2000',x['url'],{**x['params'],'lmt':'2000'}))
for name,url,params in items:
 r={'name':name,'url':url,'params':params,'requestedAt':datetime.datetime.now().astimezone().isoformat()}
 try:
  x=requests.get(url,params=params,headers={'Referer':'https://data.eastmoney.com/bkzj/BK0877.html'},timeout=(6,12));r.update(status=x.status_code,bytes=len(x.content),sha256=hashlib.sha256(x.content).hexdigest());(P/(name+'.json')).write_bytes(x.content);x.raise_for_status();j=x.json();d=j.get('data')or{};rows=d.get('klines',d.get('diff',[]));r.update(rc=j.get('rc'),rows=len(rows),first=rows[0]if rows else None,last=rows[-1]if rows else None)
 except Exception as e:r['error']=str(e)
 attempts.append(r);print(name,r.get('rows',r.get('error')),flush=True);time.sleep(1)
Path('work/pcb_flow/retry-receipts.json').write_text(json.dumps(attempts,ensure_ascii=False,indent=2))
