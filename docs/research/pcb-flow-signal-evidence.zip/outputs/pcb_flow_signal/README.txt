PCB板块资金流固定规则探索。先读取 plan-before-results.json、report.html、audit.json。
账户覆盖118日，非三年验证；不改变默认；不代表真实成交。
复算：从压缩包根目录运行 node work/pcb_flow_signal/run.mjs，Python分析需pandas/scipy。prepare.py是登记脚本，已有登记不覆盖。
