# -*- coding: utf-8 -*-
from pathlib import Path
import pandas as pd,numpy as np,json,math
O=Path('outputs/pcb_flow_signal');df=pd.read_csv(O/'diagnostics.csv');m=pd.read_json(O/'metrics.json');out=[];corr=[]
def wilson(w,n):
 z=1.96;p=w/n;den=1+z*z/n;mid=(p+z*z/(2*n))/den;rad=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den;return mid-rad,mid+rad
for stock,all_ in df.groupby('stock'):
 for period,g in [('full',all_),('preJuly',all_[all_.date<'2026-07-01']),('postJuly',all_[all_.date>='2026-07-01'])]:
  corr.append({'stock':stock,'period':period,'n':len(g),'sameDayMain_vs_sameDayOpenClose':g.sameDayMainPct.corr(g.openClose,method='spearman'),'priorMain_vs_nextOpenClose':g.priorMainPct.corr(g.openClose,method='spearman'),'priorMain_vs_nextTenClose':g.priorMainPct.corr(g.tenClose,method='spearman')})
  for label,mask in [('priorPositive',g.priorPositive),('priorNonpositive',~g.priorPositive),('priorBothPositive',g.priorBothPositive),('priorBothNegative',g.priorBothNegative)]:
   h=g[mask];n=len(h)
   if not n:continue
   wins=int((h.openClose>0).sum());lo,hi=wilson(wins,n)
   out.append({'stock':stock,'period':period,'group':label,'n':n,'positiveOpenClose':wins,'positiveFraction':wins/n,'wilsonLow':lo,'wilsonHigh':hi,'meanOpenClose':h.openClose.mean(),'meanTenClose':h.tenClose.mean(),'loss3pctOpenClose':int((h.openClose<=-.03).sum()),'meanCloseReturn':h.closeReturn.mean()})
(O/'conditional.json').write_text(json.dumps(out,indent=2));(O/'correlations.json').write_text(json.dumps(corr,indent=2));m.to_csv(O/'metrics.csv',index=False)
print('Conditional H full');print(pd.DataFrame(out).query('stock=="hudian" and period=="full"').to_string(index=False));print('Correlations H');print(pd.DataFrame(corr).query('stock=="hudian"').to_string(index=False));print('Accounts');print(m[(m.slip==.0005)][['stock','period','name','return_','mdd5','episodeWins','closedEpisodes','exposure','borrow_days']].to_string(index=False))
