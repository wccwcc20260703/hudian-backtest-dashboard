# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
from html import escape
import json,hashlib,zipfile
R=Path.cwd();O=R/'outputs/pcb_flow_signal';W=R/'work/pcb_flow_signal';repo=R/'work/hudian-backtest-dashboard'
load=lambda p:json.loads((O/p).read_text())
ms=load('metrics.json');cs=load('conditional.json');ca=load('carry.json');audit=load('audit.json')
for p,h in load('manifest.json').items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==h,p
names={'B':'全仓持有','D':'原现金 D','L':'原融资 L','F':'昨日主力净流入才融资','Fboth':'昨日大单、超大单均流入才融资','Dcap':'现金：昨日净流出后目标封顶50%','Lcap':'融资：昨日净流出后目标封顶50%'}
pct=lambda x:'—'if x is None else f'{x*100:.2f}%'
win=lambda r:'—'if r['episodeWinRate']is None else f"{r['episodeWins']}/{r['closedEpisodes']}（{pct(r['episodeWinRate'])}）"
def table(headers,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+escape(str(x))+'</th>'for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+escape(str(x))+'</td>'for x in row)+'</tr>'for row in rows)+'</tbody></table></div>'
def metric_table(stock,slip=.0005,period='full'):
 return table(['方案','净收益','5分钟收盘估值最大回撤','完整周期盈利/结束','盈利日/全部118日'if period=='full'else'盈利日/全部交易日','平均仓位','融资天数'],[(names[r['name']],pct(r['return_']),pct(-r['mdd5']),win(r),f"{r['winningDays']}/{r['days']}（{pct(r['winningDayFraction'])}）",pct(r['exposure']),r.get('borrow_days',0))for r in ms if r['stock']==stock and r['slip']==slip and r['period']==period])
now=datetime.now().astimezone().isoformat()
body=f'''<p class="eyebrow">WHOLE PCB / 固定规则的小批验证</p><h1>PCB资金流：能降低风险，但尚未证明提高沪电胜率</h1><p>生成于 {now}。使用东方财富 PCB 概念板块 BK0877 的直接汇总资金流，不由少数同业股票拼接。历史探索，未通过冻结后的独立检验；主看板默认不变。</p>
<div class="callout"><b>主要发现：</b>118个交易日中，“昨日资金流入才允许融资”把沪电最大回撤从22.93%降至15.24%，但完整持仓周期胜率仍是17/22。这个改善尚不能归因于资金流预测：平均仓位同步从59.24%降至45.59%，融资天数从57天降至13天。原现金方案的回撤已经是15.27%。</div>
<h2>1. 先区分当天解释力和次日预测力</h2><p>同日最终主力净流入占比，与沪电当日开盘到收盘收益的 Spearman 相关为 +0.760；前一日占比与下一日开盘到收盘收益为 −0.143。前者只能作盘后描述，不能把盘后才完整的资金流倒填进早盘。净流入不等于新增外部资金，也不代表能识别机构身份。</p>'''
labels={'priorPositive':'昨日主力净流入','priorNonpositive':'昨日主力净流出或为零','priorBothPositive':'昨日大单、超大单均净流入','priorBothNegative':'昨日大单、超大单均净流出'}
body+=table(['前一交易日板块状态','次日收盘高于开盘/天数','比例与95%区间','次日开收盘均值','次日开收盘跌至少3%'],[(labels[r['group']],f"{r['positiveOpenClose']}/{r['n']}",f"{pct(r['positiveFraction'])} [{pct(r['wilsonLow'])}, {pct(r['wilsonHigh'])}]",pct(r['meanOpenClose']),f"{r['loss3pctOpenClose']}/{r['n']}")for r in cs if r['stock']=='hudian'and r['period']=='full'])
body+='''<p>这些是价格方向频率，既不是买卖成交胜率，也不是做T胜率。区间是未调整时间相关性的 Wilson 描述区间；样本少、区间重叠，不能据此改成“净流出就买”。本轮不按结果新增反向策略或调整阈值。</p>
<h2>2. 沪电：同一账户起点的现金与融资比较</h2><p>2026-04-14 至 2026-10-08，118个交易日，每个账户期初100万元，从空仓开始；单边滑点5基点。表内最大回撤按5分钟收盘估值，不能覆盖每根K线内部全部极值。</p>'''+metric_table('hudian')
body+='''<p>完整周期指从空仓建仓到再次空仓，扣除费用、融资利息；不是每笔减仓都算一次胜利。沪电各策略在基准滑点下均17/22，另有1个未结束周期，浮动损益已计入账户净值和回撤。全仓持有的周期尚未结束，因此不提供周期胜率。所有方案本批均无已识别完整日内做T往返，不报告“日内77%”。空仓和平盘不计为盈利日。</p>
<h2>3. 是否只是降低仓位？必须保留这个疑问</h2><p>融资条件 F 的回撤15.24%，接近原现金 D 的15.27%；这说明“少融资”本身就可能解释大部分改善。净流出后封顶50%的现金方案将回撤再降到7.71%，但平均仓位也降至29.07%。尚未完成同等仓位/风险预算的精确对照，不能声称资金流本身提供了新增择时优势。</p>'''
body+=table(['方案','最差交易日','最差5%交易日平均收益','完整周期盈亏比（总盈利/总亏损）','累计领先全仓天数占比','最长累计落后天数','滚动63日领先比例'],[(names[r['name']],pct(r['worstDay']),pct(r['worst5pctDayMean']),'—'if r['episodeProfitFactor']is None else f"{r['episodeProfitFactor']:.2f}",pct(r['leadFraction']),r['longestBehind'],pct(r['rolling63Lead']))for r in ms if r['stock']=='hudian'and r['period']=='full'and r['slip']==.0005])
body+='''<p>滚动63日窗口高度重叠；领先100%也不代表独立试验全部成功。账户净值领先与交易胜率含义不同。</p><h2>4. 7月前后及滑点压力</h2><p>以下两段收益承接4月14日起同一个账户，不在7月重置，复利相乘还原全段。证据包另附两段各自重置账户的压力检验，不能混用。</p>'''
body+=table(['方案','截至6月30日段内收益','7月1日起段内收益'],[(names[r['name']],pct(r['preJuly']),pct(r['postJuly']))for r in ms if r['stock']=='hudian'and r['period']=='full'and r['slip']==.0005])
body+='<p>单边滑点提高至10基点，回撤改善方向仍在，收益普遍降低：</p>'+metric_table('hudian',.001)
body+='''<p>10基点下 F 的周期分母变为21个（16胜），对应的成交路径也随滑点变化；不固定胜率分母。全部结果和成交保存在证据包。</p>
<h2>5. 承接旧账户与胜宏迁移</h2><p>再从2023-10-09运行原账户，到2026-04-14才启用资金流条件。此前各候选与所属原现金/融资账户净值逐日一致。以下只统计资金流覆盖期，绝不是三年资金流验证：</p>'''
body+=table(['沪电方案','4月14日前承接净资产','覆盖期收益','覆盖期5分钟回撤','期末财富/所属原方案'],[(names[r['name']],f"¥{r['initialMarkedNAV']:,.2f}",pct(r['returnAfterCoverage']),pct(-r['mddAfterCoverage']),f"{r['endingWealthRatio']:.4f}")for r in ca if r['stock']=='hudian'and r['slip']==.0005])
body+='<p>胜宏科技作为另一只股票的结果对照，仍使用同一整板块资金流，不用胜宏替代板块：</p>'+metric_table('shenghong')
body+='''<p>胜宏原融资周期胜率11/20，F为13/20，净流出后融资封顶50%为14/20；样本仅20个周期，且两只股票同属相关产业，不能当成独立跨市场证据。两只股票的低回撤结果值得保留，但胜率改善没有在沪电重现。</p>
<h2>6. 固定规则、数据边界与执行假设</h2><ul>
<li>规则在本轮结果生成前写入 plan-before-results.json。原D按前一日 RSI2 与已发布业绩条件产生0/50/100%目标，原L只把100%目标扩至150%；本轮不新增买入日期，不改原下单时点。</li>
<li>F：仅昨日主力净额&gt;0时允许原满仓信号使用150%，否则100%。Fboth要求昨日大单和超大单各自&gt;0。条件失效后在原计划时点降低目标，故不是“只约束新贷款、旧贷款无限持有”。Dcap/Lcap：昨日主力净额&lt;0时把原目标封顶50%，不是要求所有这些日期必持50%。</li>
<li>买入后融资欠款≤当前净资产50%；持有中被动超150%不主动归位。T+1、100股整手、前一根5分钟成交量1%及每次30万股上限、涨跌停限制、原引擎最多5个执行窗口保留。</li>
<li>股票佣金万1，最低5元；单边滑点5/10基点，按分取整；融资年息6%，按每日最大欠款计费并含跨周末利息；转让费及印花税按历史日历。股息税沿用原模型策略20%、持有基准0%的简化假设，未做个人税负精算。</li>
<li>资金流直接来自东方财富PCB概念板块 BK0877，120日日线2026-04-13至10-09；精确滞后一个股票交易日。个股行情核验截至10-08，故可检验118日。10-09日线与5分钟极值仍不一致，未并入账户回测。</li>
<li>10-09分时仅取得盘后回取的一天240点。09:36累计主力净流出11.68亿元、09:39为14.06亿元，说明该日早盘资金背景偏弱；但无原始实时版本证据，不能据此宣称当时已验证能提前卖出。不能以一天验证盘中流速策略。</li>
<li>日线120天不是已证实的数据源保留上限；扩展历史请求失败已登记。没有三年资金流、历史时点成分及冻结后新行情，无法完成固定三年度、更早历史与真正独立验证。</li>
<li>本轮为全部已见历史的固定规则探索；参数未拟合不等于新盲测。未宣称达到旧现金收益保留/回撤降低25%或财富1.20倍标准。</li></ul>
<h2>7. 下一步最有辨别力的检验</h2><p>先做同等仓位和融资使用量的对照，判断板块资金流是否优于简单少买；再积累连续、带实际采集时间的盘中板块流量，分开检验9:45/10:00净流出加速与价格承接。没有这两步，不把资金流改成默认买卖开关。</p>
<p>来源：<a href="https://data.eastmoney.com/bkzj/BK0877.html">东方财富PCB板块资金流</a>；<a href="pcb-flow.html">本任务原始采集与失败记录</a>。主力=大单+超大单，不能重复相加。提供方的订单金额分类不能证实真实“大资金”身份。</p>'''
body+=f'<p>核验：{audit["resetAccounts"]}个重置账户、{audit["carryAccounts"]}个承接账户，{audit["ledger"]}笔成交账本重算、{audit["loans"]}次买入额度检查、{audit["prefix"]}项前缀一致性、{audit["cycleReconciliations"]}项周期损益核对。输入SHA256未变化。</p><p><a href="pcb-flow-signal-evidence.zip">下载全部规则、结果、成交与复算材料 ZIP</a> · <a href="archive.html">研究归档</a> · <a href="../index.html">返回看板</a></p>'
html='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PCB资金流验证 · 沪电股份</title><style>body{margin:0;background:#f3f6fa;color:#1b304a;font:16px/1.8 system-ui,sans-serif}main{max-width:1180px;margin:32px auto;padding:30px;background:white;border-radius:16px}h1{font-size:30px}h2{font-size:22px;margin-top:38px}a{color:#117e83}.callout{padding:22px;background:#eef8f5;border-left:4px solid #117e83}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}td,th{text-align:left;border-bottom:1px solid #e0e7ef;padding:12px;min-width:90px}th{background:#f6f8fb}.eyebrow{color:#738598;font-size:13px}li{margin:12px 0}@media(max-width:600px){main{padding:16px;margin:0}h1{font-size:25px}}</style><main>'+body+'</main></html>'
(O/'report.html').write_text(html)
(O/'README.txt').write_text('PCB板块资金流固定规则探索。先读取 plan-before-results.json、report.html、audit.json。\n账户覆盖118日，非三年验证；不改变默认；不代表真实成交。\n复算：从压缩包根目录运行 node work/pcb_flow_signal/run.mjs，Python分析需pandas/scipy。prepare.py是登记脚本，已有登记不覆盖。\n')
with zipfile.ZipFile(O/'evidence.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in O.iterdir():
  if p.is_file()and p.suffix!='.zip':z.write(p,p.relative_to(R))
 inputs=list(load('manifest.json'))+['work/pcb_flow_signal/prepare.py','work/pcb_flow_signal/run.mjs','work/pcb_flow_signal/analyze.py','work/pcb_flow_signal/report.py','outputs/pcb_flow/request-receipts.json','outputs/pcb_flow/summary.json','outputs/sector_execution/freshness.json']
 for p in inputs:z.write(R/p,p)
(repo/'docs/research/pcb-flow-signal.html').write_text(html)
(repo/'docs/research/pcb-flow-signal-evidence.zip').write_bytes((O/'evidence.zip').read_bytes())
p=repo/'docs/research/archive.html';s=p.read_text();entry='<p><a href="pcb-flow-signal.html">整板块资金流检验：回撤改善，但沪电17/22胜率未提高 ↗</a></p>';assert 'pcb-flow-signal.html'not in s;p.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+entry))
p=R/'work/research-checkpoint.json';c=json.loads(p.read_text());c['updatedAt']=now;c['activeBatch']='东方财富整PCB板块昨日资金流固定规则118日探索完成：回撤改善、沪电周期胜率17/22未变。未证实独立择时能力，默认不改。';c['pcbFlowSignal']={'updatedAt':now,'status':'local verified, publication pending','outputs':'outputs/pcb_flow_signal','audit':audit,'period':['2026-04-14','2026-10-08'],'sameDayCorr':.7603408103243338,'lagDayCorr':-.14281383985077967,'findings':'Hudian L 147.37%return/22.93%DD; positiveflowfinance F120.00/15.24; both17wins22closed. Fexposure45.59vs59.24,borrow13vs57. Cashcap76.95/7.71; no Hwinincrease. 10bps andcarryDD directionretain; Shenghong L11/20,F13/20 butsameindustrynotindependent.','limitations':['118sessions only,22Hcycles','Dailyendflow lagged1day, notearlysessionflowtest','Noexposurematchedcontrol','No3annual/earlierflow/frozenunseenvalidation','Oct9excludedpriceextremadisagree','Allseenhistory,defaultunchanged'],'nextQuestion':'Preregister exposure-and-financing-matched controls before interpreting causal timing gain. PreservePITboardflow prospective; no posthoc reversingflowrule.','defaultChanged':False};p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print({'reportBytes':len(html.encode()),'zipBytes':(O/'evidence.zip').stat().st_size,'checkpointSaved':True})
