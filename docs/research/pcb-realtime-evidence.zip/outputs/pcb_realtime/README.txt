PCB实时数据来源核验；report.html为静态研究记录，不是实时页面。
复核字段及历史示例：work/pcb_realtime/normalize.py
只读实时快照采集：work/venv/bin/python work/pcb_realtime/collector.py --date 2026-10-12 --samples 120 --interval 30
必须在验证交易日/来源权限后启动；实际源日期、时间不匹配则不生成观察。每次最多120个采样，连续两次网络失败自动结束，不自动重试其他地址。
本批没有常驻进程或新自动化运行。历史分时接口失败，未向当前信号补填旧数据。
