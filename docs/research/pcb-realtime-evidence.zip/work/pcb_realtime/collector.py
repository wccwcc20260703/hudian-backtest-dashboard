# -*- coding: utf-8 -*-
"""Read-only BK0877 snapshot capture; bounded run, never orders or fabricated backfill."""
from pathlib import Path
from datetime import datetime,timedelta
from zoneinfo import ZoneInfo
import json,math,argparse,time,hashlib,requests
TZ=ZoneInfo('Asia/Shanghai');ROOT=Path(__file__).resolve().parents[2]
URL='https://push2.eastmoney.com/api/qt/stock/get'
PARAMS={'secid':'90.BK0877','ut':'fa5fd1943c7b386f172d6893dbfba10b','invt':'2','fltt':'2','fields':'f43,f44,f45,f46,f47,f48,f57,f58,f60,f86,f169,f170,f184,f137,f140,f143,f146,f149'}
FIELDS={'index':'f43','previousClose':'f60','changePct':'f170','turnoverYuan':'f48','mainNetYuan':'f137','superlargeNetYuan':'f140','largeNetYuan':'f143','mediumNetYuan':'f146','smallNetYuan':'f149'}
def session(t):
 s=t.strftime('%H:%M:%S')
 if '09:30:00'<=s<='11:30:00':return 'am'
 if '13:00:00'<=s<='15:00:00':return 'pm'
 return None
def normalize(j,received,expected_date):
 d=j.get('data');assert isinstance(d,dict)and d.get('f57')=='BK0877'and d.get('f58')=='PCB','Wrong/missing board'
 n={k:float(d[v])for k,v in FIELDS.items()};assert all(math.isfinite(x)for x in n.values()),'Nonfinite data'
 assert n['index']>0 and n['previousClose']>0 and n['turnoverYuan']>=0,'Invalid price/amount'
 assert abs(n['mainNetYuan']-n['largeNetYuan']-n['superlargeNetYuan'])<=max(2048,abs(n['mainNetYuan'])*1e-6),'Main-flow components inconsistent'
 source=datetime.fromtimestamp(float(d['f86']),TZ);age=(received-source).total_seconds();reasons=[]
 if source.date().isoformat()!=expected_date:reasons.append('source_date_mismatch')
 if received.date().isoformat()!=expected_date:reasons.append('not_expected_date')
 if received.weekday()>=5 or not session(received):reasons.append('outside_continuous_session')
 if age>90:reasons.append('snapshot_older_than_90s')
 if age< -5:reasons.append('source_clock_in_future')
 n.update(code='BK0877',name='PCB',sourceAt=source.isoformat(),receivedAt=received.isoformat(),ageSeconds=age,expectedDate=expected_date,mainNetPctDerived=n['mainNetYuan']/n['turnoverYuan']*100 if n['turnoverYuan']else None,flowFieldTimestampAvailable=False,usableForObservation=not reasons,healthReasons=reasons)
 return n

def window(current,history,minutes):
 if not current['usableForObservation']:return None
 t=datetime.fromisoformat(current['sourceAt']);target=t-timedelta(minutes=minutes)
 eligible=[]
 for r in history:
  if not r.get('usableForObservation'):continue
  s=datetime.fromisoformat(r['sourceAt'])
  if s.date()==t.date()and session(s)==session(t)and s<=target and (target-s).total_seconds()<=30:eligible.append(r)
 if not eligible:return None
 p=max(eligible,key=lambda r:r['sourceAt']);delta=current['turnoverYuan']-p['turnoverYuan']
 if delta<=0:return {'valid':False,'reason':'nonpositive_turnover_delta_or_revision'}
 flow=current['mainNetYuan']-p['mainNetYuan'];ret=current['index']/p['index']-1
 return {'valid':True,'fromSourceAt':p['sourceAt'],'toSourceAt':current['sourceAt'],'priceReturnPct':ret*100,'mainNetChangeYuan':flow,'turnoverChangeYuan':delta,'mainNetShareOfTurnoverPct':flow/delta*100,'priceUpFlowOutObservation':ret>0 and flow<0,'notTradeSignal':True}

def capture(out,expected,history):
 now=datetime.now(TZ);key=now.strftime('%Y%m%dT%H%M%S_%f%z');raw=out/'raw';raw.mkdir(parents=True,exist_ok=True)
 receipt={'requestedAt':now.isoformat(),'url':URL,'params':PARAMS};n=None
 try:
  r=requests.get(URL,params=PARAMS,headers={'Referer':'https://quote.eastmoney.com/bk/90.BK0877.html'},timeout=(8,12));received=datetime.now(TZ)
  p=raw/(key+'.json');p.write_bytes(r.content);receipt.update(status=r.status_code,receivedAt=received.isoformat(),rawPath=str(p),sha256=hashlib.sha256(r.content).hexdigest());r.raise_for_status();n=normalize(r.json(),received,expected)
  if history and n['sourceAt']<history[-1]['sourceAt']:n['usableForObservation']=False;n['healthReasons'].append('source_clock_regression')
  elif history and n['sourceAt']==history[-1]['sourceAt']:
   n['sameSourceTimestamp']=True
   if any(n[k]!=history[-1][k]for k in FIELDS):n['usableForObservation']=False;n['healthReasons'].append('revision_at_same_source_timestamp')
  n['windows']={str(i):window(n,history,i)for i in [1,5,10]};receipt['observation']=n
  with (out/'observations.ndjson').open('a')as f:f.write(json.dumps(n,ensure_ascii=False)+'\n')
  history.append(n)
 except Exception as e:receipt['error']=str(e)
 with(out/'receipts.ndjson').open('a')as f:f.write(json.dumps(receipt,ensure_ascii=False)+'\n')
 status={'lastAttempt':receipt,'lastRetainedSnapshot':history[-1]if history else None,'collectionMode':'read-only; no automatic trading; cashflow category is vendor estimate'}
 p=out/'status.tmp';p.write_text(json.dumps(status,ensure_ascii=False,indent=2));p.replace(out/'status.json')
 return receipt

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--date',required=True,help='Expected trading day; caller must verify exchange calendar');ap.add_argument('--samples',type=int,default=1);ap.add_argument('--interval',type=int,default=30);ap.add_argument('--output',default=str(ROOT/'work/pcb_realtime/captures'));a=ap.parse_args()
 datetime.strptime(a.date,'%Y-%m-%d');assert 1<=a.samples<=120 and a.interval>=15,'Bounded polling only, minimum15s'
 out=Path(a.output);out.mkdir(parents=True,exist_ok=True);history=[];p=out/'observations.ndjson'
 if p.exists():history=[json.loads(s)for s in p.read_text().splitlines()][-2000:]
 failures=0
 for i in range(a.samples):
  if i:time.sleep(a.interval)
  r=capture(out,a.date,history);failures=failures+1 if 'error'in r else 0
  print(json.dumps({'capture':i+1,'error':r.get('error'),'sourceAt':r.get('observation',{}).get('sourceAt'),'health':r.get('observation',{}).get('healthReasons')},ensure_ascii=False),flush=True)
  if failures>=2:print('Stopped after two consecutive failures; no rotating hosts or bypass.');break
if __name__=='__main__':main()
