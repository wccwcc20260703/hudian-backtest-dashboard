# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,csv,hashlib
R=Path.cwd();W=R/'work/pcb_realtime';O=R/'outputs/pcb_realtime';TZ=ZoneInfo('Asia/Shanghai')
pr=next((W/'raw').glob('*/price-minute.json'));qr=next((W/'raw').glob('*/official-quote.json'));p=json.loads(pr.read_text())['data'];q=json.loads(qr.read_text())['data']
flow={r['time']:r for r in csv.DictReader((R/'outputs/pcb_flow/pcb-minute-flow-2026-10-09.csv').open(encoding='utf-8-sig'))};rows=[]
for line in p['trends']:
 v=line.split(',');t=v[0];n={'time':t,'index':float(v[2]),'change_pct':(float(v[2])/p['preClose']-1)*100,'provider_average_index':float(v[7]),'minute_turnover_yuan':float(v[6]),'cumulative_turnover_yuan':sum(float(x.split(',')[6])for x in p['trends']if x.split(',')[0]<=t),'main_net_yuan':float(flow[t]['main_net_yuan'])if t in flow else None};rows.append(n)
lookup={r['time']:r for r in rows}
from datetime import timedelta
for r in rows:
 t=datetime.strptime(r['time'],'%Y-%m-%d %H:%M');prior=lookup.get((t-timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M'));valid=prior is not None and r['main_net_yuan']is not None and prior['main_net_yuan']is not None
 r['price_change_5min_pct']=(r['index']/prior['index']-1)*100 if valid else None;r['main_change_5min_yuan']=r['main_net_yuan']-prior['main_net_yuan']if valid else None;r['main_share_5min_pct']=r['main_change_5min_yuan']/(r['cumulative_turnover_yuan']-prior['cumulative_turnover_yuan'])*100 if valid and r['cumulative_turnover_yuan']>prior['cumulative_turnover_yuan']else None
with(O/'aligned-minute-example-2026-10-09.csv').open('w',encoding='utf-8-sig')as f:
 cw=csv.DictWriter(f,fieldnames=list(rows[0]));cw.writeheader();cw.writerows(rows)
checks={'codeMatch':q['f57']==p['code']=='BK0877','nameMatch':q['f58']==p['name']=='PCB','closeExact':q['f43']==rows[-1]['index'],'preCloseExact':q['f60']==p['preClose'],'mainFlowVsEarlierSnapshotExact':q['f137']==json.loads((R/'outputs/pcb_flow/summary.json').read_text())['snapshot']['mainNetYuan'],'amountSumGapYuan':rows[-1]['cumulative_turnover_yuan']-q['f48'],'volumeSumGap':sum(float(v.split(',')[5])for v in p['trends'])-q['f47'],'joinedMinutes':sum(r['main_net_yuan']is not None for r in rows)}
assert all(checks[x]for x in ['codeMatch','nameMatch','closeExact','preCloseExact','mainFlowVsEarlierSnapshotExact']);assert abs(checks['amountSumGapYuan'])<1000
summary={'verifiedAt':datetime.now(TZ).isoformat(),'purpose':'Intraday price/flow alignment and source availability; not prior-day predictor or trading strategy','code':'90.BK0877','snapshot':{'index':q['f43'],'changePct':q['f170'],'turnoverYuan':q['f48'],'mainNetYuan':q['f137'],'sourceAt':datetime.fromtimestamp(q['f86'],TZ).isoformat()},'checks':checks,'liveAcceptancePassed':False,'reason':'Saturday capture only; stock/get one successful response then two connection failures; minute-flow failed currenttwo probes although priorbatchsuccess. No continuousmarket timestamps observed.','minutePriceRows':len(rows),'keyTimes':[r for r in rows if r['time'][-5:]in ['09:36','09:39','09:45','10:00']],'processRunning':False,'defaultChanged':False,'collector':'work/pcb_realtime/collector.py','tradeDayCandidate':'2026-10-12; verify official calendar before live activation','fieldFreshness':'f86 is snapshot source timestamp; individual flow field freshness not separately exposed','failedBrowserInspection':'CUA timed out twice, no further attempts; officialHTML/JS/APIs inspected independently'}
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
