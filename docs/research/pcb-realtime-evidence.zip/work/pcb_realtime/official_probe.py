# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
import requests,json,hashlib,concurrent.futures
W=Path('work/pcb_realtime');O=W/'raw'/datetime.now().astimezone().strftime('%Y%m%dT%H%M%S%z');O.mkdir()
ut='fa5fd1943c7b386f172d6893dbfba10b'
items=[('official-flow','https://push2.eastmoney.com/api/qt/stock/fflow/kline/get',{'lmt':'0','klt':'1','secid':'90.BK0877','fields1':'f1,f2,f3,f7','fields2':'f51,f52,f53,f54,f55,f56','ut':ut}),('official-quote','https://push2.eastmoney.com/api/qt/stock/get',{'secid':'90.BK0877','ut':ut,'invt':'2','fltt':'2','fields':'f43,f44,f45,f46,f47,f48,f57,f58,f60,f86,f169,f170,f184,f137,f140,f143,f146,f149'}),('known-flow-snapshot','https://push2.eastmoney.com/api/qt/ulist.np/get',{'fltt':'2','secids':'90.BK0877','fields':'f12,f14,f62,f184,f66,f69,f72,f75,f78,f81,f84,f87,f64,f65,f70,f71,f76,f77,f82,f83,f124,f6','ut':'b2884a393a59ad64002292a3e90d46a5'})]
def get(x):
 n,u,p=x;r={'name':n,'requestedAt':datetime.now().astimezone().isoformat(),'url':u,'params':p}
 try:
  a=requests.get(u,params=p,headers={'Referer':'https://quote.eastmoney.com/bk/90.BK0877.html'},timeout=(8,18));r.update(status=a.status_code,receivedAt=datetime.now().astimezone().isoformat(),bytes=len(a.content),sha256=hashlib.sha256(a.content).hexdigest(),cors=a.headers.get('Access-Control-Allow-Origin'));fp=O/(n+'.json');fp.write_bytes(a.content);r['rawPath']=str(fp);a.raise_for_status();d=a.json().get('data');r['dataKeys']=list(d)if isinstance(d,dict)else str(type(d))
  if d:
   kl=d.get('klines',d.get('diff',[]));r.update(rows=len(kl),first=kl[0]if kl else None,last=kl[-1]if kl else None,meta={k:v for k,v in d.items()if k not in ['klines','diff']})
 except Exception as e:r['error']=str(e)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:r=list(ex.map(get,items))
(W/'official-probe-receipts.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False,indent=2))
