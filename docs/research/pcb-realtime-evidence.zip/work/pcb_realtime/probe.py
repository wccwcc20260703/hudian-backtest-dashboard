# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
import requests,json,hashlib,concurrent.futures
W=Path('work/pcb_realtime');stamp=datetime.now().astimezone().strftime('%Y%m%dT%H%M%S%z');O=W/'raw'/stamp;O.mkdir(parents=True)
ut='b2884a393a59ad64002292a3e90d46a5'
items=[('quote-page','https://quote.eastmoney.com/bk/90.BK0877.html',{}),('quote','https://push2.eastmoney.com/api/qt/ulist.np/get',{'fltt':'2','secids':'90.BK0877','fields':'f12,f14,f2,f3,f4,f5,f6,f8,f15,f16,f17,f18,f62,f184,f66,f69,f72,f75,f78,f81,f84,f87,f124','ut':ut}),('flow-minute','https://push2.eastmoney.com/api/qt/stock/fflow/kline/get',{'lmt':'0','klt':'1','fields1':'f1,f2,f3,f7','fields2':','.join('f'+str(i)for i in range(51,66)),'secid':'90.BK0877','ut':ut}),('price-minute','https://push2his.eastmoney.com/api/qt/stock/trends2/get',{'fields1':'f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13','fields2':'f51,f52,f53,f54,f55,f56,f57,f58','ndays':'1','iscr':'0','secid':'90.BK0877','ut':ut})]
def get(x):
 name,url,params=x;r={'name':name,'requestedAt':datetime.now().astimezone().isoformat(),'url':url,'params':params}
 try:
  a=requests.get(url,params=params,headers={'Referer':'https://quote.eastmoney.com/bk/90.BK0877.html'},timeout=(8,18));r.update(status=a.status_code,receivedAt=datetime.now().astimezone().isoformat(),bytes=len(a.content),sha256=hashlib.sha256(a.content).hexdigest(),serverDate=a.headers.get('Date'),cors=a.headers.get('Access-Control-Allow-Origin'))
  p=O/(name+('.html'if name.endswith('page')else'.json'));p.write_bytes(a.content);r['rawPath']=str(p);a.raise_for_status()
  if not name.endswith('page'):
   d=a.json().get('data');r['dataKeys']=list(d)if isinstance(d,dict)else type(d).__name__
   if d:
    rows=d.get('klines',d.get('trends',d.get('diff',[])));r.update(rows=len(rows),first=rows[0]if rows else None,last=rows[-1]if rows else None,meta={k:v for k,v in d.items()if k not in ['klines','trends','diff']})
 except Exception as e:r['error']=str(e)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as ex:rr=list(ex.map(get,items))
(W/'probe-receipts.json').write_text(json.dumps(rr,ensure_ascii=False,indent=2));print(json.dumps(rr,ensure_ascii=False,indent=2))
