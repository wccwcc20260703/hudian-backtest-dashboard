# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
from html import escape
import json,zipfile,hashlib
R=Path.cwd();W=R/'work/pcb_realtime';O=R/'outputs/pcb_realtime';repo=R/'work/hudian-backtest-dashboard';s=json.loads((O/'summary.json').read_text());now=datetime.now().astimezone().isoformat()
sources=[{'name':'东方财富PCB板块行情','url':'https://quote.eastmoney.com/bk/90.BK0877.html','code':'90.BK0877','verification':'官方页面及JS、指数241分钟、价格与资金同一快照取数成功；资金分时本轮失败，上一轮取得240点；短间隔快照再请求连续两次失败。盘中持续更新未验收。','access':'本次成功响应无需账号；公开网页内部接口无可验证SLA，不承诺15秒或1秒源刷新。'}, {'name':'东方财富板块资金流','url':'https://data.eastmoney.com/bkzj/BK0877.html','code':'BK0877','verification':'资金分时与股票大小单分类已核对；采用净流量，不解释为投资者身份。','access':'同一提供方，不是独立备用数据商。'}, {'name':'同花顺PCB概念','url':'https://basic.10jqka.com.cn/48/885959/','code':'885959','verification':'官方页面确有PCB概念，当前页面成分240家；东方财富此前返回205家，范围不可互换。未取得其板块分钟资金流接口。','access':'可作为另一个提供方的核对候选，不是已接通的自动备源。'}, {'name':'同花顺板块实时资金流功能','url':'https://www.10jqka.com.cn/l2_tyzxone/tyzx_ggbk.html','verification':'官方说明板块资金流向表/图；文档较旧，具体当前账户权限与PCB分钟数据需进一步实测。','access':'终端功能存在不等于API字段可取。'}, {'name':'Choice正式量化接口','url':'https://quantapi.eastmoney.com/AIGuide/PromotionPage?from=web','verification':'官方API与Python/Mac文档入口可读；官方GXSC.pdf说明实时行情及东财资金流插件自动刷新。未登录、未核验BK0877盘中资金字段权限/接口时效/服务承诺。','access':'专业渠道候选。未申请试用、未购买、未安装SDK。'}, {'name':'同花顺iFinD正式接口','url':'https://quantapi.10jqka.com.cn/gwstatic/static/ds_web/quantapi-web/example.html','verification':'官方实时行情与高频示例可读；整PCB分钟资金流字段仍未验证。','access':'需合法接口账户和相应权限；不能把普通App登录视为API授权。'}]
(O/'sources.json').write_text(json.dumps({'verifiedAt':now,'sources':sources},ensure_ascii=False,indent=2))
def table(head,rows):return '<div class="scroll"><table><tr>'+''.join('<th>'+escape(x)+'</th>'for x in head)+'</tr>'+''.join('<tr>'+''.join('<td>'+escape(str(x))+'</td>'for x in r)+'</tr>'for r in rows)+'</table></div>'
body=f'''<p class="meta">PCB / 实时数据来源核验 · {now}</p><h1>把板块指数与资金流放在同一时刻观察</h1><div class="note">这页是数据源核验记录和10月9日盘后回取示例，不是当前实时行情。已找到并实测成功的取数入口，但公开接口发生间歇连接失败，尚未通过交易时段连续采集验收。没有改变策略、发出订单或宣称后台已在持续盯盘。</div>
<h2>已取得哪些盘中字段</h2><p>东方财富 PCB 概念板块 90.BK0877：指数点位、相对昨收涨跌幅、累计成交额、主力/超大单/大单/中单/小单累计净流量与快照源时间，可以在同一个返回对象中取得。分时指数另外取得241点（含09:30），资金分时上一批取得240点（09:31起），共同分钟240个。</p><p>同一快照解决跨接口时间错位的一部分问题，但源时间并不是每一个资金字段的更新时间，仍需实盘观察其是否滞后。当前返回源时间为2026-10-09 15:39:30，今天是周六，不把旧数据称为实时。</p>
<h2>你提出的现象，在分钟数据上可以怎样看</h2><p>以下为2026-10-09盘后回取的同分钟对齐示例。尤其09:40→09:45：PCB指数反弹约0.36%，但这5分钟主力净流出约4.37亿元；截至09:45累计净流出19.74亿元。该时点板块相对昨收仍下跌2.47%，所以这是“短时反弹与资金流出并存”，不是全天涨幅为正。</p>'''
body+=table(['时点','PCB指数','较昨收','最近5分钟指数变化','累计主力净流量（亿元）','最近5分钟主力净流量（亿元）','5分钟主力净额/成交额'],[(r['time'][-5:],f"{r['index']:.2f}",f"{r['change_pct']:.2f}%",f"{r['price_change_5min_pct']:.2f}%",f"{r['main_net_yuan']/1e8:.2f}",f"{r['main_change_5min_yuan']/1e8:.2f}",f"{r['main_share_5min_pct']:.2f}%")for r in s['keyTimes']])
body+='''<p>这证明字段组合能描述你关心的情形，并不证明每次出现就应卖出。没有原始盘中到达时间的历史版本，不能声称当时9:45已成功实时识别。后续必须保存每次实际收到的数据。</p>
<h2>来源比较：存在、能取到、稳定更新是三件事</h2>'''
for x in sources:body+=f'<h3><a href="{escape(x["url"],quote=True)}">{escape(x["name"])}</a></h3><p>{escape(x["verification"])} {escape(x["access"])}</p>'
body+='''<p>Choice插件资料：<a href="https://choice.eastmoney.com/FileDownLoad/GXSC.pdf">官方使用资料</a>提到实时行情/资金流插件5—6秒刷新；这是该产品说明，不可套用为公开网页接口的更新承诺，也不能据此断言已拥有PCB板块API权限。</p>
<h2>公开数据入口的实际测试</h2>'''
body+=table(['入口','用途','本轮结果'],[('push2 /api/qt/stock/get','同一快照指数、涨跌、成交额、大小单净额、源时间','首次成功；后续两次连接失败，已停止重复请求'),('push2his /api/qt/stock/trends2/get','指数分时线、提供方均线、分钟成交额','成功：241点，最后价3854.76与快照完全一致'),('push2 /api/qt/stock/fflow/kline/get','当天累计资金分时曲线','本轮两种已知页面参数请求均连接失败；上一批取得240点'),('push2 /api/qt/ulist.np/get','资金快照另一入口','本轮两次请求失败；不是独立数据商'),('官方页面HTML/JS','字段口径与页面实际使用接口','成功读取；浏览器控制工具两次超时，未再尝试')])
body+='''<p>错误是当前请求链路报告 ProxyError / RemoteDisconnected，没有收到HTTP响应，原因尚未定位，不能断言一定是网站限流，也不能保证换浏览器必然恢复。未更换镜像、代理或绕过访问限制。</p><p>同源核对：指数收盘、昨收和主力净额一致；分钟成交额之和比快照高74元、成交量之和高3个提供方单位，保留差异。不是独立交易所数据审计。</p>
<h2>周一盘中的验收方案</h2><p>按<a href="https://investor.szse.cn/disclosure/notice/general/t20251222_618087.html">深交所2026休市安排</a>，10月10日周末休市；10月12日为下一周一，启动前仍核验临时休市信息。</p><ol>
<li>从开盘开始保存源时间与本机接收时间，指数、成交额和大小单净额一起保留。先按30秒采样；采样频率不等于数据源刷新频率，不承诺秒级精度。</li>
<li>09:45对照9:40及9:35的真实已收到快照，区分全天累计净流出和最近5/10分钟净流出。只用此前实际留存，不从未来收盘曲线补造当时信号。</li>
<li>观察指数相对昨收、近5/10分钟涨跌、净流出是否加速、净流量/同期成交额及大单/超大单是否同向。“流入不多”还需同一时段的历史分布才能给阈值；目前不随意划高低等级。</li>
<li>源日期不符、源时间滞后超过暂定90秒、时钟倒退、成交额反向修订、缺少窗口起点时暂停观察。90秒为工程暂停阈值，不是提供方保证；午休不拼接成连续5分钟。</li>
<li>同时核对官方终端/网页可见值，评估9:30—10:00期间缺失率、最大延迟、更新时间前进、资金字段是否更新及断线恢复。仅一两次成功不算可靠。</li>
<li>只有验收通过才接入看板实时观察；数据源不足时明确显示不可用。其他提供方口径不一致时独立展示，不静默拼成一条曲线。</li></ol>
<p>只读采集脚本已准备并通过旧日期/延迟、窗口差分、缺失起点、成交额修订和午休隔离检查。没有持续进程或新增定时任务在运行；本页不承诺无人值守实时监控已开通。因今天公开接口重复失败，周一盘中稳定性仍是未完成项。</p>
<h2>数据口径</h2><p>主力=大单+超大单。资金分时数值是开盘至该时刻的累计净额，不能把每一分钟累计额相加；最近5分钟净额应取两个端点相减。净流量是提供方按成交分类计算的指标，不等于外部新增现金，也不能鉴别真实机构身份。板块指数均线直接标记为“提供方分时均线”，不将指数点位与成分成交额错误组合成个股VWAP。</p>
<p><a href="pcb-realtime-evidence.zip">下载来源、请求回执、字段、对齐样例与只读采集脚本</a> · <a href="archive.html">研究归档</a> · <a href="../index.html">返回看板</a></p>'''
html='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PCB实时数据来源核验</title><style>body{background:#f3f6fa;color:#1b304a;font:16px/1.8 system-ui;margin:0}main{max-width:1100px;margin:32px auto;padding:28px;background:white;border-radius:16px}a{color:#117c84}h1{font-size:30px}h2{font-size:22px;margin-top:32px}h3{font-size:18px}.note{padding:20px;background:#fff7e8;border-left:4px solid #c9943e}.meta{color:#7a8da4;font-size:13px}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:14px}td,th{padding:12px;border-bottom:1px solid #dde6ef;text-align:left;min-width:90px}th{background:#f4f7fa}li{margin:10px 0}@media(max-width:600px){main{margin:0;padding:16px}}</style><main>'+body+'</main></html>'
(O/'report.html').write_text(html)
receipts=[]
for f in ['probe-receipts.json','official-probe-receipts.json']:
 receipts.extend(json.loads((W/f).read_text()))
receipts.extend(json.loads(x)for x in (W/'readiness/receipts.ndjson').read_text().splitlines())
(O/'request-receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2))
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in W.rglob('*')if p.is_file()and'__pycache__'not in str(p)}
(O/'manifest.json').write_text(json.dumps(manifest,indent=2))
(O/'README.txt').write_text('PCB实时数据来源核验；report.html为静态研究记录，不是实时页面。\n复核字段及历史示例：work/pcb_realtime/normalize.py\n只读实时快照采集：work/venv/bin/python work/pcb_realtime/collector.py --date 2026-10-12 --samples 120 --interval 30\n必须在验证交易日/来源权限后启动；实际源日期、时间不匹配则不生成观察。每次最多120个采样，连续两次网络失败自动结束，不自动重试其他地址。\n本批没有常驻进程或新自动化运行。历史分时接口失败，未向当前信号补填旧数据。\n')
with zipfile.ZipFile(O/'evidence.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in O.iterdir():
  if p.is_file()and p.suffix!='.zip':z.write(p,p.relative_to(R))
 for path in manifest:
  if Path(path).suffix in ['.js','.html'] or Path(path).name=='source-js-receipts.json':continue
  z.write(R/path,path)
 for path in ['outputs/pcb_flow/pcb-minute-flow-2026-10-09.csv','outputs/pcb_flow/summary.json']:z.write(R/path,path)
(repo/'docs/research/pcb-realtime.html').write_text(html);(repo/'docs/research/pcb-realtime-evidence.zip').write_bytes((O/'evidence.zip').read_bytes())
p=repo/'docs/research/archive.html';st=p.read_text();assert 'pcb-realtime.html'not in st;p.write_text(st.replace('<h1>研究归档</h1>','<h1>研究归档</h1><p><a href="pcb-realtime.html">PCB实时数据源：同刻指数与资金快照、09:45背离样例及盘中验收缺口 ↗</a></p>'))
p=R/'work/research-checkpoint.json';c=json.loads(p.read_text());c['updatedAt']=now;c['activeBatch']='用户明确优先盘中实时整PCB板块价格+资金流；已核验快照和指数分钟字段，公开接口间歇失败。暂停扩大昨日资金流研究，下一步先验证实时到达、连续性与同刻对齐。';c['pcbRealtime']={'updatedAt':now,'status':'source capability verified; live reliability not passed; publishing evidence','outputs':'outputs/pcb_realtime','summary':s,'userPriority':'Intraday same-time board price/volume and cumulative/recent5/10min flows; not dailyflow as mainfactor; no smallpeer proxy.','collector':'work/pcb_realtime/collector.py','processRunning':False,'defaultChanged':False,'nextQuestion':'Verify nextopen complete9:30-10:00 sourceadvancement, fieldlag andfailures. Do not claim livecoverage untilsampled. Need legal terminal/APIpermissions ifpublicsourceunreliable; no paidpurchase orinstall.','retryPolicy':'No repeat unchangedflow andulistprobes now; two collector stock/get failures stopped. Do not rotate hosts/proxies to bypass.','sourceOptions':sources};p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print({'reportBytes':len(html.encode()),'evidenceBytes':(O/'evidence.zip').stat().st_size,'receipts':len(receipts),'checkpointSaved':True})
