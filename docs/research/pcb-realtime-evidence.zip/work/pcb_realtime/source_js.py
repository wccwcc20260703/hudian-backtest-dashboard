# -*- coding: utf-8 -*-
from pathlib import Path
import requests,concurrent.futures,json,re
W=Path('work/pcb_realtime/raw');items=[('bk2.js','https://quote.eastmoney.com/newstatic/build/bk2.js'),('moneyflow.js','https://quote.eastmoney.com/newstatic/js/libs/quotemoneyflowchart0715.js'),('charts.js','https://quote.eastmoney.com/newstatic/libs/quotekchart/1.0.6.js')]
def get(x):
 name,url=x
 try:
  r=requests.get(url,timeout=(8,18));r.raise_for_status();(W/name).write_bytes(r.content);s=r.text
  out=[]
  for p in ['fflow','trends2','stock/get','setInterval','60000','fields2','f124']:
   for m in list(re.finditer(re.escape(p),s))[:6]:out.append(s[max(0,m.start()-120):m.start()+240])
  return {'name':name,'url':url,'bytes':len(r.content),'excerpts':out}
 except Exception as e:return {'name':name,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as ex:r=list(ex.map(get,items))
Path('work/pcb_realtime/source-js-receipts.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False))
