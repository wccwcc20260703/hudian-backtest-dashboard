# -*- coding: utf-8 -*-
from collector import normalize,window,TZ
from datetime import datetime,timedelta
from pathlib import Path
import json,copy
fixture=json.loads(next(Path('work/pcb_realtime/raw').glob('*/official-quote.json')).read_text())
# Weekend and wrong-day responses cannot enable observations.
s=normalize(fixture,datetime(2026,10,10,17,0,tzinfo=TZ),'2026-10-12');assert not s['usableForObservation']and'source_date_mismatch'in s['healthReasons']
def fake(t,index,flow,turnover):
 x=copy.deepcopy(fixture);x['data'].update(f86=t.timestamp(),f43=index,f137=flow,f140=flow*.5,f143=flow*.5,f48=turnover);return normalize(x,t+timedelta(seconds=2),t.date().isoformat())
t=datetime(2026,10,12,9,45,tzinfo=TZ);a=fake(t-timedelta(minutes=5),4000,-1e8,10e8);b=fake(t,4020,-2e8,15e8)
r=window(b,[a],5);assert r['valid']and r['priceUpFlowOutObservation']and r['mainNetChangeYuan']==-1e8
assert window(b,[],5)is None
c=fake(t+timedelta(minutes=1),4020,-2e8,9e8);assert not window(c,[a],6)['valid']
d=fake(datetime(2026,10,12,13,2,tzinfo=TZ),4010,-1e8,16e8);e=fake(datetime(2026,10,12,11,27,tzinfo=TZ),4000,-2e8,15e8);assert window(d,[e],95)is None
print('6 checks passed: stale/date/session gating, paired-window divergence, missing anchor, turnover correction, lunch separation. Synthetic fixtures only; not Monday market evidence.')
