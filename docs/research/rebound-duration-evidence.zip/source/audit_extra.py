# -*- coding: utf-8 -*-
from pathlib import Path
import ast,types,math,json
import numpy as np
R=Path.cwd();O=R/'outputs/rebound_duration';src=ast.parse((R/'work/stock_probability/study.py').read_text());ns={'np':np,'math':math};exec(compile(ast.Module(body=[n for n in src.body if isinstance(n,ast.FunctionDef) and n.name in ['px','fee']],type_ignores=[]),'helpers','exec'),ns);exec((R/'work/rebound_duration/generated_execution.py').read_text(),ns)
def setup():
 b=np.zeros((1,48,6));b[:,:,:4]=100;b[:,:,4]=1e6;b[:,:,5]=1e8;b[0,15:,0]=101;ns['e']=types.SimpleNamespace(B=b,REF=np.array([100.]),C=np.array([101.]),TRANSFER=np.array([.00001]),STAMP=np.array([.0005]),DATES=np.array(['2026-01-05']));return b
checks=[]
for h in [3,6,9]:
 b=setup();r,t=ns['episode_horizon'](0,{12:1},.0005,h);assert [x['bar'] for x in t]==[12,12+h] and t[-1]['shares']==5000 and t[-1]['available']==5000-t[0]['qty'];checks.append('Fixed horizon '+str(h*5)+'min sells old shares at corresponding next-open grid')
b=setup();b[0,20,4]=10000;r,t=ns['episode_horizon'](0,{12:1},.0005,9);assert t[1]['qty']==100 and t[-1]['bar']==22;checks.append('45min exit partialvolume extends execution rather than imaginary whole fill')
b=setup();b[0,21:,0]=90;ns['e'].C[0]=90;r,t=ns['episode_horizon'](0,{12:1},.0005,9);assert not r['complete'] and r['remaining']==t[0]['qty'] and r['net']<0;checks.append('45min limitdown retains marked loss')
b=setup();r,t=ns['episode_horizon'](0,{12:1},.0005,6);b[0,19:,:4]=50;rr,tt=ns['episode_horizon'](0,{12:1},.0005,6);assert t==tt;checks.append('Future after scheduled complete exit does not affect any fill')
(O/'additional_audit.json').write_text(json.dumps({'syntheticChecks':checks,'count':len(checks)},indent=2));print(json.dumps({'passed':len(checks)}))
