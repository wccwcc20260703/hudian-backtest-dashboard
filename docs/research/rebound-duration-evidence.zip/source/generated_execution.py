# -*- coding: utf-8 -*-
def episode_horizon(d,choices,slip,horizon):
 b=e.B[d];old=int(500000/e.REF[d]/100)*100;cash0=1e6-old*e.REF[d];cash=cash0;sh=old;avail=old;outstanding=0;first=-1;entryside=0;exitstart=-1;fills=[];q0=0;lo=round(e.REF[d]*.9+1e-8,2);hi=round(e.REF[d]*1.1+1e-8,2)
 for j in range(1,47):
  side=0;qty=0;cap=int(b[j-1,4]*.01/100)*100;op=b[j,0]
  if outstanding and j>=exitstart:side=-entryside;qty=min(outstanding,cap)
  elif first<0 and j in choices:
   side=choices[j];fill=px(op,side,slip);qty=min(int(100000/fill/100)*100,cap,avail)
  if not side or qty<=0:continue
  fill=px(op,side,slip)
  if (side>0 and (op>=hi-.005 or fill>hi)) or (side<0 and (op<=lo+.005 or fill<lo)):continue
  if side<0:qty=min(qty,avail)
  if side>0:
   while qty>0 and cash-qty*fill-fee(d,qty,fill,side)<200000-1e-8:qty-=100
  if qty<=0:continue
  costs=fee(d,qty,fill,side);cash-=side*qty*fill+costs;sh+=side*qty
  if side<0:avail-=qty
  if first<0:first=j;entryside=side;outstanding=qty;q0=qty;exitstart=j+horizon
  else:outstanding-=qty
  fills.append(dict(date=str(e.DATES[d]),bar=j,side=side,qty=qty,price=fill,fee=costs,cash=cash,shares=sh,available=avail));assert avail>=0 and cash>=200000-1e-6
  if first>=0 and outstanding==0:break
 net=cash+sh*e.C[d]-(cash0+old*e.C[d]);return dict(date=str(e.DATES[d]),traded=first>=0,side=entryside,entryBar=first,quantity=q0,complete=first>=0 and outstanding==0,remaining=outstanding,net=net),fills
