# -*- coding: utf-8 -*-
from pathlib import Path
import re,json,zipfile,shutil
import pandas as pd
R=Path.cwd();O=R/'outputs/rebound_duration';D=R/'work/hudian-backtest-dashboard/docs/research';m=pd.read_csv(O/'metrics.csv');paths=pd.read_csv(O/'path_summary.csv');profiles=pd.read_csv(O/'condition_profiles.csv');roll=pd.read_csv(O/'rolling_selection.csv')
labels={'all':'全部回落事件','volume_low':'缩量：量比<0.8','volume_normal':'量比0.8—1.5','volume_high':'放量：量比≥1.5','vwap_below':'明显低于VWAP','vwap_near':'VWAP附近','vwap_above':'明显高于VWAP','trend_down':'此前20日跌超5%','trend_flat':'此前20日在±5%内','trend_up':'此前20日涨≥5%'}
def table(df,cols):
 def cell(k,v):
  if pd.isna(v):return '—'
  if k=='condition':return labels[v]
  if k in ['quarter','trainThrough']:return str(v)
  if k=='chosen':return '不做T' if str(v)=='none' else str(v)+'分钟'
  if k in ['upRate','mean','median','p10','p90','meanFavorable','meanAdverse','winRate','netWinRate']:return f'{v*100:.2f}%'
  if k in ['averagePerOpportunity','averageWin','averageLoss','sumNet','worst','meanNet']:return f'{v:,.2f}'
  return str(int(v))
 return '<div class="scroll"><table><tr>'+''.join('<th>'+title+'</th>' for k,title in cols)+'</tr>'+''.join('<tr>'+''.join('<td>'+cell(k,r[k])+'</td>' for k,title in cols)+'</tr>' for _,r in df.iterrows())+'</table></div>'
cols=[('minutes','持有分钟'),('opportunities','原机会'),('completeDays','完整往返'),('winRate','扣费胜率'),('averagePerOpportunity','每机会增量/元'),('sumNet','独立日合计/元'),('worst','最差单日/元'),('unfinished','未完成')]
pc=[('condition','当时状态'),('n','样本'),('upRate','30分钟后上涨'),('netWinRate','扣费胜率'),('meanNet','每机会增量/元')]
css=re.search(r'<style>(.*?)</style>',(D/'xhs-positive.html').read_text(),re.S).group(1)
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>沪电股份 · 10:30反弹的持续性与成本</title><style>'+css+'</style></head><body><main><a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a> · <a href="stock-probability.html">股性概率地图</a><h1>10:30回落后会反弹，反弹够不够做T？</h1><p>第二十五批 · 2026-10-09 · 已核验历史至10月8日 · 固定15/30/45分钟，不继续调参</p><div class="callout"><b>本轮没有形成可直接交易的买点。</b>154个事件中，15/30/45分钟后的上涨比例约55.2%/53.2%/49.4%，但扣费后的三个持有方案都亏损。放量组在较近两段更好，可样本小且更早历史反转；明显低于均价线的回落更弱。保留这些股性线索，默认不变。</div>'
page+='''<section><h2>固定买点，只问反弹持续多久</h2><p>沿用上一批已经公开的条件：10:30时，最近完成的5分钟收盘价比15分钟前低超过昨日ATR的0.1倍。这里不是任何下跌都算，也没有追加新过滤条件。信号完成后在10:30开盘网格尝试买入，分别固定在10:45、11:00、11:15退出，即15、30、45分钟。</p><p>这是从上一批事后画像提出的候选。虽然本轮先登记持有期再计算，但所有历史此前已见，不能把结果称作新盲测。最多一轮；退出规则和时间不根据当天未来高低点改变。</p><p>每日独立100万元、约50%隔夜底仓，做T预算最多10万元，现金保留至少20万元；卖出使用隔夜老股。计入T+1、佣金最低5元、印花税、过户费、双边不利滑点、100股和前根量1%上限、涨跌停。到期卖不完则逐根尝试到14:50，剩余敞口按收盘估值，失败样本不删除。</p><p class="note">仍是独立当日场景，不是连续三年账户收益。现金/融资主策略未改；本批无融资、无长期累计领先或账户最大回撤达标宣称。</p></section>'''
page+='<section><h2>反弹有多长、多大？</h2>'+table(paths[paths.period=='full'],[('minutes','观察分钟'),('n','事件'),('upRate','到期上涨比例'),('mean','平均毛涨跌'),('median','毛涨跌中位数'),('p10','10%分位'),('p90','90%分位'),('meanFavorable','期间平均最大有利幅度'),('meanAdverse','期间平均最大不利幅度')])+'''<p>平均毛涨幅在30分钟时约0.15%，到45分钟回落至约0.11%；45分钟上涨比例已低于一半，持有更久没有自动改善。中位数比平均值低，说明少数较大的反弹抬高了均值，不能只看平均就认定大多数交易能赚钱。</p><p>期间最大有利幅度随持有时间上升，是因为观察窗口更长；它是事后最有利的5分钟开盘价格，不是当时可以提前知道的卖点，不可据此计算虚构收益。</p><p>在45分钟的开盘价格网格中，66天先到+0.5%，60天先到−0.5%，28天两边都未到。先到上涨目标只有42.9%；这还是毛价差描述，未把它当作实际止盈成交或胜率。5分钟内的触价可能漏掉，未冒充逐笔路径。</p></section>'''
page+='<section><h2>成本让“有反弹”与“能盈利”分开</h2>'+table(m[(m.period=='full')&(m.slip==.0005)],cols)+'''<p>按本模型费率，双边5基点滑点加佣金、印花税与过户费，基本往返成本约0.202%，还没算最小价位取整和最低佣金的额外影响；而30分钟平均毛涨幅只有约0.15%。反弹方向有一点优势，幅度仍可能不够。</p><p>30分钟完整往返62/154盈利，40.26%；每机会平均−71.77元。45分钟有1天未完成，保留估值损益，但完整往返胜率以153天为分母，没有隐藏这个缺口。</p><h3>10基点滑点压力</h3>'''+table(m[(m.period=='full')&(m.slip==.001)],cols)+'''<p>滑点加大后每机会平均亏损约171—238元，三个方案均未通过。不能为了让历史结果赚钱而降低费用或假定在最低价买、最高价卖。</p></section>'''
page+='<section><h2>哪种回落更容易失败？全部固定分组保留</h2><p>只描述三个当时可知因素，未把结果好的分组自动变成新策略：累计成交量相对此前20天同时段均量；当前价距VWAP是否超过±0.2倍昨日ATR；昨天已知的20日涨跌是否超过±5%。共9个分组，全部列出。本轮事先要求前后段各至少30个样本才讨论稳定分支，不作多重比较后的显著性结论。</p>'
for per,title in [('early','2023年10月至2024年底'),('validation','2025年至2026年6月底'),('recent','2026年7月以后'),('older','更早历史')]:page+='<h3>'+title+' · 30分钟</h3>'+table(profiles[(profiles.period==per)&(profiles.minutes==30)],pc)
page+='''<p><b>均价线附近与远低于均价线需要区分：</b>前后两段，明显低于VWAP组每机会约亏255元、211元；VWAP附近组约赚15元、5元，第三段也变成亏25元。附近反弹较容易出现，但利润太薄，还不足以升级。</p><p><b>放量也不能简单理解为一定危险或一定有承接：</b>放量组较近两段平均赚262元、274元，但仅10天、13天，未过样本门槛，7月后无样本。更早49天平均亏341元，毛上涨比例也只有38.8%，所以差异不只是费用变化造成。不能用23个较好案例宣布找到稳定股性。</p><p>历史量能基准不足的更早3个事件未分入量能组，仍保留在“全部回落事件”总计中。不同年份出现不同表现，提示还需解释行情阶段差异，不能只寻找一个永久固定阈值。</p></section>'''
page+='<section><h2>时间顺序检验与季度选择</h2>'
for per,title in [('early','较早段'),('validation','后续段'),('recent','7月以后'),('older','更早历史')]:page+='<h3>'+title+'</h3>'+table(m[(m.period==per)&(m.slip==.0005)],cols)
page+='''<p>按2024年底以前的结果，在15/30/45分钟和“不做T”之间选择，训练结果选不做T。每季度用此前252天重选也未挽救：短暂选择了45或30分钟，季度独立日增量合计约−7,394元。</p>'''+table(roll,[('quarter','季度'),('trainThrough','此前数据截至'),('chosen','选择'),('days','日期数'),('sumNet','独立日增量合计/元')])+'''<details><summary>固定年度明细</summary>'''
for y in [1,2,3]:page+='<h3>年度'+str(y)+'</h3>'+table(m[(m.period=='year'+str(y))&(m.slip==.0005)],cols)
page+='''</details><p class="note">季度选择是独立每日场景的历史顺序诊断，不是连续账户净值；2026年第四季只含1个已核验日期。全部历史已见，原现金达标标准及前瞻冻结不放宽。</p></section>'''
page+='''<section><h2>核验与下一步</h2><p>3,274个30分钟账户重放与上一引擎相同；上一批4个条件概率格子复现；1,637天入场特征按决策前价格与昨日ATR重建；5,636笔成交独立账本误差0；6项合成检查覆盖三个退出时点、部分成交延后、跌停未退出和修改未来数据不影响既有成交。</p><p>下一步先解释“均价附近的回落”和“远离均价的持续走弱”差别，以及何种当时可知的状态能区分短暂反弹与继续下跌。若研究反弹中途退出，必须事先固定能执行的触发条件，并保留触发后卖不出、触发后继续涨及未触发亏损，不能把本页的事后最大有利幅度当成收益。</p><p>本轮延续股性与条件概率主线，没有以提高显示胜率为目的删掉失败日期。默认策略、实际S/R观察层均不变。已核验历史仍到10月8日，10月9日分时极值差异未解决；本页不提供过期实时信号。</p><p><a href="rebound-duration-evidence.zip">下载预登记、所有154日路径、全部分组、执行与核验代码</a></p></section></main></body></html>'''
(O/'report.html').write_text(page);(D/'rebound-duration.html').write_text(page)
with zipfile.ZipFile(D/'rebound-duration-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(O.iterdir()):
  if p.suffix in ['.csv','.json'] and p.name!='publication.json':z.write(p,p.name)
 for p in sorted((R/'work/rebound_duration').glob('*.py')):z.write(p,'source/'+p.name)
 z.write(R/'work/stock_probability/study.py','source/previous_study.py')
a=D/'archive.html';s=a.read_text();item='<p><a href="rebound-duration.html">第二十五批：10:30反弹持续多久，均价位置、量能与成本分组 ↗</a></p>'
if 'rebound-duration.html' not in s:a.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+item,1))
print(json.dumps({'htmlBytes':len(page.encode()),'zipBytes':(D/'rebound-duration-evidence.zip').stat().st_size}))
