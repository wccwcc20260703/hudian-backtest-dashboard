# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,ast,math,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/rebound_duration';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
e=f.e;J=12;HORIZONS=[3,6,9]
plan={'createdAt':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'Does the previously described10:30falling15 rebound last15,30or45minutes, covercosts and remainstable?','setup':'At10:30, lastcompletedclose minusclose15minutes earlier < -0.1prior-dayATR. Exact batch24 definition, no new entryfilters. Prior descriptive selection is knownhistory, not independentdiscovery.','horizons':{'3':'10:45','6':'11:00','9':'11:15'},'controls':'Use source batch24 daily1m50%oldstock,100kworkingnotional,200kcashreserve;T+1,mincommissions,tickrounded5/10bps,1%priorvolume,limits. Enter10:30nextopen afterknownsignal;exitafterfixedhorizon,retrypartialexitto14:50,unfinishedclosemarked. Atmostonecycle/day. Cashonlyindependentdailyepisodes,notcontinuouswealth.','selection':'Choose15/30/45min ornoT solely with2023Oct..2024netpereligible opportunity, then latersegments;quarterrolling252daysincludesnoT. No extra optimization.','profiles':'Describe predefined9 bins at10:30: volume<.8/.8..1.5/>=1.5, VWAPdistance/priorATR<-0.2/near/>=0.2, prior20dayreturn<-5%/near/>=5%. Reportallcells, not translated into filters here. Need>=30cases in both early/later to discuss stablebranch. No multiple-testing significance claim.','paths':'Next5minuteopens only; grossmean/median,p10,p90 and maxfavorable/adverse. Within45min firsttouch +0.5%or-0.5% onopen grid; descriptive, NOT executable takeprofit winrate. No futureextrema used in entries.','freezeSHA':hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(O/'plan_before_results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2));p=R/'work/research-checkpoint.json';ck=json.loads(p.read_text());ck['activeBatch']='25_rebound_duration';ck['currentQuestion']=plan['question'];p.write_text(json.dumps(ck,ensure_ascii=False,indent=2))
z=np.load(R/'outputs/stock_probability/features_labels.npz');assert np.array_equal(z['dates'],e.DATES);X=z['features'][:,1,:];eligible=X[:,2]<-.1
src=(R/'work/stock_probability/study.py').read_text();tree=ast.parse(src);ns={'np':np,'math':math,'e':e};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['fee','px','episode']],type_ignores=[]),'previous_execution','exec'),ns)
fn=ast.get_source_segment(src,next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='episode')).replace('def episode(d,choices,slip):','def episode_horizon(d,choices,slip,horizon):').replace('exitstart=j+6','exitstart=j+horizon');exec(fn,ns);(R/'work/rebound_duration/generated_execution.py').write_text('# -*- coding: utf-8 -*-\n'+fn+'\n')
paths=[];rows=[];fills=[];parity=0
for d in range(e.N):
 gross=e.B[d,J+1:J+10,0]/e.B[d,J,0]-1;touch=0;touchbar=-1
 for k,r in enumerate(gross):
  if abs(r)>=.005:touch=1 if r>0 else -1;touchbar=k+1;break
 for h in HORIZONS:
  paths.append(dict(date=str(e.DATES[d]),eligible=bool(eligible[d]),minutes=h*5,grossReturn=gross[h-1],favorable=max(0,float(gross[:h].max())),adverse=min(0,float(gross[:h].min())),firstTouch45=touch,touchMinutes=touchbar*5 if touchbar>=0 else -1))
 for slip in [.0005,.001]:
  for h in HORIZONS:
   rr,ff=ns['episode_horizon'](d,{J:1} if eligible[d] else {},slip,h);rr.update(slip=slip,minutes=h*5,eligible=bool(eligible[d]));rows.append(rr)
   for t in ff:t.update(slip=slip,minutes=h*5);fills.append(t)
   if h==6:
    old,of=ns['episode'](d,{J:1} if eligible[d] else {},slip)
    assert old['net']==rr['net'] and of==[{k:v for k,v in t.items() if k not in ['slip','minutes']} for t in ff];parity+=1
path=pd.DataFrame(paths);acc=pd.DataFrame(rows);tr=pd.DataFrame(fills);path.to_csv(O/'path_outcomes.csv',index=False);acc.to_csv(O/'daily_execution.csv',index=False);tr.to_csv(O/'fills.csv',index=False)
periods={'full':('2023-10-09','2026-10-09'),'early':('2023-10-09','2025-01-01'),'validation':('2025-01-01','2026-07-01'),'recent':('2026-07-01','2026-10-09'),'older':(str(e.DATES[0]),'2023-10-09')}
for y in range(3):periods['year'+str(y+1)]=(f'{2023+y}-10-09',f'{2024+y}-10-09')
metrics=[];profiles=[];pathstats=[]
conditions={'all':np.ones(e.N,bool),'volume_low':X[:,3]<np.log(.8),'volume_normal':(X[:,3]>=np.log(.8))&(X[:,3]<np.log(1.5)),'volume_high':X[:,3]>=np.log(1.5),'vwap_below':X[:,1]<-.2,'vwap_near':(X[:,1]>=-.2)&(X[:,1]<.2),'vwap_above':X[:,1]>=.2,'trend_down':X[:,4]<-.05,'trend_flat':(X[:,4]>=-.05)&(X[:,4]<.05),'trend_up':X[:,4]>=.05}
for period,(a,b) in periods.items():
 ids=(e.DATES>=a)&(e.DATES<b);dates=e.DATES[ids]
 for h in HORIZONS:
  q=path[(path.date>=a)&(path.date<b)&path.eligible&(path.minutes==h*5)]
  pathstats.append(dict(period=period,minutes=h*5,n=len(q),upRate=(q.grossReturn>0).mean(),mean=q.grossReturn.mean(),median=q.grossReturn.median(),p10=q.grossReturn.quantile(.1),p90=q.grossReturn.quantile(.9),meanFavorable=q.favorable.mean(),meanAdverse=q.adverse.mean(),upFirst45=(q.firstTouch45==1).mean(),downFirst45=(q.firstTouch45==-1).mean(),neither45=(q.firstTouch45==0).mean()))
  for slip in [.0005,.001]:
   t=acc[(acc.date>=a)&(acc.date<b)&acc.eligible&(acc.minutes==h*5)&(acc.slip==slip)];done=t[t.complete];actual=t[t.traded]
   metrics.append(dict(period=period,slip=slip,minutes=h*5,opportunities=len(t),tradeDays=len(actual),completeDays=len(done),winRate=(done.net>0).mean(),averagePerOpportunity=t.net.mean(),averagePerTrade=actual.net.mean(),sumNet=t.net.sum(),worst=t.net.min(),averageWin=t.loc[t.net>0,'net'].mean(),averageLoss=t.loc[t.net<0,'net'].mean(),unfilled=int((~t.traded).sum()),unfinished=int((t.traded&(~t.complete)).sum())))
  for name,mask in conditions.items():
   dd=e.DATES[ids&eligible&mask];q=acc[(acc.date.isin(dd))&(acc.minutes==h*5)&(acc.slip==.0005)];p=path[(path.date.isin(dd))&(path.minutes==h*5)];profiles.append(dict(period=period,minutes=h*5,condition=name,n=len(q),upRate=(p.grossReturn>0).mean(),completeN=int(q.complete.sum()),netWinRate=(q.loc[q.complete,'net']>0).mean(),meanNet=q.net.mean(),sumNet=q.net.sum()))
mm=pd.DataFrame(metrics);mm.to_csv(O/'metrics.csv',index=False);ps=pd.DataFrame(pathstats);ps.to_csv(O/'path_summary.csv',index=False);pd.DataFrame(profiles).to_csv(O/'condition_profiles.csv',index=False)
# Baseline event reproduces previous table, bothwindows.
old=pd.read_csv(R/'outputs/stock_probability/conditional_profile.csv')
for per in ['early','validation','recent','full']:
 a=ps[(ps.period==per)&(ps.minutes==30)].iloc[0];b=old[(old.period==per)&(old.bar==12)&(old.condition=='falling15')].iloc[0];assert a['n']==b['n'] and abs(a.upRate-b.grossUp)<1e-12
wide=acc[acc.slip==.0005].pivot(index='date',columns='minutes',values='net');wide['none']=0;training=wide.loc['2023-10-09':'2024-12-31'].sum();chosen=training.idxmax();roll=[]
for q in pd.period_range('2025Q1','2026Q4',freq='Q'):
 start=str(q.start_time.date());end=str(q.end_time.date());k=int(np.searchsorted(e.DATES,start));hist=wide.iloc[max(0,k-252):k];pick=hist.sum().idxmax();out=wide.loc[start:end];roll.append(dict(quarter=str(q),trainThrough=hist.index[-1],chosen=str(pick),days=len(out),sumNet=out[pick].sum()))
pd.DataFrame(roll).to_csv(O/'rolling_selection.csv',index=False)
ledger=0
for (date,slip,mins),g in tr.groupby(['date','slip','minutes']):
 d=int(np.searchsorted(e.DATES,date));base=int(500000/e.REF[d]/100)*100;cash=1e6-base*e.REF[d];sh=base;av=base
 for t in g.itertuples():
  cost=ns['fee'](d,t.qty,t.price,t.side);cash-=t.side*t.qty*t.price+cost;sh+=t.side*t.qty
  if t.side<0:av-=t.qty
  assert abs(cash-t.cash)<1e-6 and sh==t.shares and av==t.available and av>=0 and t.qty<=int(e.B[d,int(t.bar)-1,4]*.01/100)*100;ledger+=1
# Independent featureprefix rebuild with priorATR only, and no laterbar dependency.
atr=(e.ATR/e.Q.close).shift().reindex(e.DATES).to_numpy()*e.REF;assert np.allclose(X[:,2],(e.B[:,11,3]-e.B[:,8,3])/atr,equal_nan=True)
audit={'oldHorizonAccountParity':parity,'priorEventCellsReproduced':4,'featurePrefixRows':e.N,'ledgerFills':ledger,'ledgerError':0,'trainChosen':str(chosen),'trainScores':{str(k):v for k,v in training.items()},'defaultChanged':False,'continuousPortfolio':False,'freezeSHA':plan['freezeSHA']};(O/'audit.json').write_text(json.dumps(audit,indent=2));print(mm[(mm.period.isin(['full','early','validation','recent','older']))&(mm.slip==.0005)].to_string(index=False));print(ps[ps.period=='full'].to_string(index=False));print(json.dumps(audit));print(pd.DataFrame(roll).to_string(index=False))
