# -*- coding: utf-8 -*-
from pathlib import Path
import json,hashlib
import pandas as pd
R=Path.cwd();O=R/'outputs/regime_combo';m=pd.read_csv(O/'metrics.csv');data={s:pd.read_csv(O/f'{s}-daily.csv')for s in ['hudian','shenghong']}
P={'full':('2023-10-09','2026-10-08'),'older':('2020-01-02','2023-09-28'),'early':('2023-10-09','2024-12-31'),'later':('2025-01-01','2026-06-30'),'julyOn':('2026-07-01','2026-10-08'),'year1':('2023-10-09','2024-10-08'),'year2':('2024-10-09','2025-10-08'),'year3':('2025-10-09','2026-10-08')}
for p,h in json.loads((O/'manifest.json').read_text()).items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==h,p
checks=0
for x in m.itertuples():
 f=data[x.stock];a,z=P[x.period];t=f[(f.date>=a)&(f.date<=z)&f['return'+str(x.horizon)].notna()&(f['end'+str(x.horizon)]<=z)]
 if x.sampling=='nonoverlap':t=t.iloc[::x.horizon]
 if x.sampling=='greedy_disjoint':
  eligible=t[t.DUALUP==2];sel=[]
  for i in eligible.index:
   if not sel or i>=sel[-1]+x.horizon:sel.append(i)
  t=f.loc[sel];assert len(t)==x.issued
 up=t[x.model]==2;dn=t[x.model]==0;r=t['return'+str(x.horizon)]
 assert int((up|dn).sum())==x.issued;assert int(((up&(r>0))|(dn&(r<0))).sum())==x.hits
 assert int(up.sum())==x.upN and int(dn.sum())==x.downN
 if x.model=='DUALUP':assert x.downN==0
 if x.issued:assert abs(x.hits/x.issued-x.signAccuracy)<1e-12
 checks+=1
a=json.loads((O/'audit.json').read_text());a.update({'independentOutcomeChecks':checks,'inputHashesMatch':True,'nonoverlapChecked':True,'noBearishExpertInDUALUP':True});(O/'audit.json').write_text(json.dumps(a,ensure_ascii=False,indent=2));print(json.dumps(a))
