# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
import json,html,zipfile,shutil
import pandas as pd
R=Path.cwd();O=R/'outputs/regime_combo';repo=R/'work/hudian-backtest-dashboard';m=pd.read_csv(O/'metrics.csv');b=pd.read_csv(O/'branches.csv');audit=json.loads((O/'audit.json').read_text());names={'MA3':'原MA3方向','VMA':'量均线确认方向','OBV':'OBV确认方向','ASYM':'A：上行量确认／下行原MA3','DUALUP':'B：趋势延续＋下行反弹','ALLUP':'全部日期看涨对照'};stocks={'hudian':'沪电','shenghong':'胜宏'};pct=lambda x:'—'if pd.isna(x)else f'{x*100:.2f}%'
def table(head,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>'for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>'for x in row)+'</tr>'for row in rows)+'</tbody></table></div>'
body='''<nav><a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a></nav><h1>能否把各自擅长的区间组合起来？</h1><p class="muted">两个组合假设 · 同规则迁移胜宏 · 5日／20日及不重叠观察 · 416组信号评估，未改默认</p>
<section><h2>先纠正前提：目前没有两位分别擅长上涨与下跌的“专家”</h2><p>上轮沪电后20日的上涨判断命中率：原均线65.89%、量均线确认72.79%、OBV确认64.09%；下跌判断分别只有36.25%、18.42%、22.22%。因此可以研究分工，但不能直接说已经找到高命中的下跌规则。下行＋放量之后常反弹，是“下跌状态中的看涨机会”，并非“下跌预测准确”。</p><p>这次把两种可能的组合明确分开：A尝试不同方向使用不同规则；B把趋势延续与下行反弹作为两类看涨观察。选择它们受之前已看过的结果启发，规则在本轮计算前固定，但不能冒称未见历史上的预注册成功。</p></section>
<section><h2>组合规则与冲突处理</h2>'''
body+=table(['组合','前一日已知条件','当天给出的判断'],[['A：方向分工','MA3上行，且5日均量≥20日均量','看涨'],['A：方向分工','MA3下行，不要求量能确认','看跌'],['B：两类看涨','MA3上行，且5日均量≥20日均量','趋势延续观察：看涨'],['B：两类看涨','MA3下行，且5日均量≥20日均量','反弹观察：看涨'],['A、B其余情况','条件不满足／过渡状态','未知；不是判断震荡，也不自动等于清仓']])
body+='''<p>用当天之前的MA3状态选分支，两分支互斥，没有根据未来实际上涨／下跌去挑规则。沿用既有MA20/60、斜率、3日确认及5/20日量均线，未新增阈值网格。OBV保留为原对照，没有在本轮继续拼参数。B只给出看涨机会，仍然缺少已验证的风险退出或看跌模块。</p></section>
<section><h2>近三年20日价格方向结果</h2>'''
v=m[(m.period=='full')&(m.horizon==20)&(m.sampling=='all')]
body+=table(['股票／规则','命中／判断日期','命中率','占全部可评分日期','明显反向比例'],[[stocks[x.stock]+'／'+names[x.model],f'{x.hits}/{x.issued}',pct(x.signAccuracy),f'{x.issued}/{x.n} · '+pct(x.coverage),pct(x.oppositeStrongRate)]for x in v.itertuples()])
body+='''<p>A在沪电59.91%，只比原MA3的59.63%高约0.28个百分点；胜宏44.53%，低于原MA3的50.71%。这次机械分工没有补上薄弱的下跌判断。</p><p>B为沪电138/185＝74.59%、胜宏125/202＝61.88%。同一三年范围、不挑日期而全部看涨的对照分别64.97%、59.46%。B在近期沪电的日期筛选表现值得保留，但在胜宏优势较小；给出判断仅占全部日期26.13%／28.53%，不应把无判断日期算作命中。</p><p>B与“在B选出的日期全部看涨”完全相同，这是规则本身的性质；它没有新增辨别下跌的能力。评价日期筛选是否有用，需要看更早阶段、迁移与失败风险，不能只用相同日期的看涨基线称其无效或有效。</p></section>
<section><h2>B的两个分支分别贡献什么？</h2>'''
v=b[(b.period=='full')&(b.horizon==20)]
body+=table(['股票／分支','后20日上涨／日期','上涨比例','后20日平均价格涨幅','最差5%窗口平均价格涨幅'],[[stocks[x.stock]+'／'+('趋势延续'if x.state==2 else '下行反弹'),f'{x.hits}/{x.issued}',pct(x.signAccuracy),pct(x.meanDirectionalReturn),pct(x.worst5pctDirectionalReturn)]for x in v.itertuples()])
body+='''<p>沪电趋势分支107/147上涨，反弹分支31/38上涨，合计138/185。这里的“81.58%反弹比例”不是38次独立做T的胜率：不少日期的20日观察窗口重叠，且没有模拟成交、成本或中途止损。不能据此满仓或融资。</p></section>
<section><h2>早期、三个年度与7月前后</h2>'''
rows=[]
for s in ['hudian','shenghong']:
 for period in ['older','year1','year2','year3','early','later','julyOn']:
  w=m[(m.stock==s)&(m.period==period)&(m.horizon==20)&(m.sampling=='all')].set_index('model');rows.append([stocks[s]+'／'+period,*[f'{w.loc[k,"hits"]}/{w.loc[k,"issued"]} · '+pct(w.loc[k,'signAccuracy'])for k in ['ASYM','DUALUP','ALLUP']]])
body+=table(['股票／时期','A方向分工','B两类看涨','全部日期看涨'],rows)
body+='''<p>B在更早行情中，沪电只有87/186＝46.77%，胜宏94/206＝45.63%；无法称为跨阶段稳定高命中。沪电2025年至2026年6月这一段达到85/105＝80.95%，但这是已知历史中的一段，不可挑出来当成稳定80%的依据。</p><p>沪电7月起没有满足B且能在该时段内完成20日评分的日期；这代表没有可评分判断，不代表成功预测该阶段的风险。所有时期末尾尚无完整后续结果的窗口不评分。older＝2020-01-02至2023-09-28；年度1／2／3各从2023／2024／2025年10月9日起一年；early＝2023-10-09至2024末；later＝2025年初至2026-06-30；julyOn＝2026-07-01至2026-10-08。</p></section>
<section><h2>去掉窗口重叠后，结果仍不稳定</h2><p>做两种事前可执行的观察抽样：一是从时段第一日每隔20日取一次，再检查信号；二是遇到第一个B信号就观察20日，期间不重复建立新观察窗口，再等待下一次B信号。两者都没有真实或模拟下单。</p>'''
v=m[(m.period=='full')&(m.horizon==20)&(m.model=='DUALUP')]
body+=table(['股票','窗口安排','上涨／观察窗口','上涨比例'],[[stocks[x.stock],{'all':'逐日、允许重叠','nonoverlap':'固定每20日取起点','greedy_disjoint':'首次信号后连续观察20日'}[x.sampling],f'{x.hits}/{x.issued}',pct(x.signAccuracy)]for x in v.itertuples()])
body+='''<p>沪电首次信号抽样16/21＝76.19%，胜宏却只有10/23＝43.48%；固定间隔法又是沪电6/8、胜宏7/10。样本少、进入时点敏感，说明“能否重复交易获利”远未由74.59%证明。两种预先约定方法的全部结果均已保留。</p></section>
<section><h2>5日与20日不能混成同一种买点</h2>'''
v=m[(m.period=='full')&(m.sampling=='all')&m.model.isin(['DUALUP','ALLUP'])]
body+=table(['股票／规则','观察期','方向命中／判断','命中率'],[[stocks[x.stock]+'／'+names[x.model],f'{x.horizon}个交易日',f'{x.hits}/{x.issued}',pct(x.signAccuracy)]for x in v.itertuples()])
body+='''<p>观察结果从决策日复权开盘到第5／20个交易日收盘；平盘不算命中。明显反向沿用“前20日日收益波动×√观察天数”的阈值。它们都是价格检验，不是完整账户胜率；未引入新的仓位、止损、卖出或融资组合，因而没有本轮新增的账户收益、回撤或滚动领先指标。</p></section>
<section><h2>本轮决策</h2><p>A方向分工未改善；B作为“趋势延续＋下行反弹”的两类看涨候选保留，但不接入默认。下一步若继续B，首先应按事前条件检验能否避开失败的市场阶段，并将现金与融资完整账户分开验证。需要先固定进入、退出与空仓处理，执行T+1、用户费率、滑点、成交量及涨跌停约束，不能把后20日收盘上涨直接当作能赚到钱。</p><p>全部历史已经见过，两个组合也是受这些历史启发，存在选择偏差。数据截止2026-10-08，两只PCB同业并非广泛市场代表。没有新盲测、没有默认调整、没有真实交易。相关指标原始定义见<a href="volume-regime.html">上轮量能检验与来源</a>。</p>'''
body+=f'<p>核验：{audit["ruleDateChecks"]}个股票日期逐条检查条件与信息时间；576个旧结果计数一致；{audit["independentOutcomeChecks"]}组新旧结果独立复核；不重叠窗口间距与B不含看跌分支均已校验。</p>'
body+='''<p><a href="regime-combo-evidence.zip">下载组合规则、全部结果、每日信号和复跑脚本</a> · <a href="volume-regime.html">上一轮量能检验</a></p></section>'''
style='body{font:16px/1.8 system-ui,sans-serif;color:#1b304a;background:#f3f6fa;margin:0}main{max-width:1220px;margin:30px auto;padding:20px}section{background:white;border:1px solid #dce5ee;border-radius:14px;padding:26px;margin:22px 0}h1{font-size:30px}h2{font-size:22px}a{color:#147f85}.muted{color:#697b8c;font-size:14px}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:11px;white-space:nowrap;text-align:left;border-bottom:1px solid #e2eaf1}th{background:#f4f7fa}'
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>区间信号组合检验｜沪电研究</title><style>'+style+'</style></head><body><main>'+body+'</main></body></html>'
(O/'report.html').write_text(page);(repo/'docs/research/regime-combo.html').write_text(page)
ar=repo/'docs/research/archive.html';s=ar.read_text();link='<p><a href="regime-combo.html">能否组合各自优势：方向分工与“趋势延续＋下行反弹”的检验 ↗</a></p>'
if 'href="regime-combo.html"'not in s:ar.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+link))
(O/'README.txt').write_text('From workspace root run python work/regime_combo/research.py then check.py and report.py. pandas/numpy required. Futurelabels evaluationonly. ASYM routes on knownMA3, DUALUP is two bullish branches, notbearish forecasting. Rules motivated by alreadyseen history. Noaccountbacktest/defaultchange.\n')
inputs=list(json.loads((O/'manifest.json').read_text()))
with zipfile.ZipFile(O/'regime-combo-evidence.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in list(O.glob('*'))+list((R/'work/regime_combo').glob('*.py'))+[R/f for f in inputs]:
  if f.is_file()and f.suffix!='.zip'and f.name not in ['publication.json','deployment.log']:z.write(f,str(f.relative_to(R)))
shutil.copyfile(O/'regime-combo-evidence.zip',repo/'docs/research/regime-combo-evidence.zip')
cp=R/'work/research-checkpoint.json';q=json.loads(cp.read_text());now=datetime.now().astimezone().isoformat();q['regimeCombo']={'updatedAt':now,'outputs':'outputs/regime_combo','status':'locally verified; publication pending','audit':audit,'finding':'ASYM upVMA/downMA3 H59.91 Sh44.53 weak. DUALUP upVMAtrend+downVMArebound H138/18574.59 Sh125/20261.88 versus all-dateup64.97/59.46. Earlier46.77/45.63; greedy20nonoverlapH16/21Sh10/23. No goodbearish expert, DUALUP bullishonly, notTsuccess.','defaultChanged':False,'newBlindTest':False,'nextQuestion':'B remains seen-history bullish candidate. Test causal market/risk context for failures, then fixedentry/exit/position full cash vs margin separately; do not declare missing bearish module solved or tune ranges after seeing winners.'};q['updatedAt']=now;cp.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n');print('Combination report and checkpoint saved.')
