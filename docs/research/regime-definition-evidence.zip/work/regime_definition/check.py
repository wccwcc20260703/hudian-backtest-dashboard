from pathlib import Path
import pandas as pd,numpy as np,json
O=Path('outputs/regime_definition');m=pd.read_csv(O/'metrics.csv');conf=pd.read_csv(O/'confusion.csv');cnt=0
for r in m.itertuples():
 t=conf[(conf.stock==r.stock)&(conf.model==r.model)&(conf.period==r.period)&(conf.horizon==r.horizon)&(conf.sampling==r.sampling)];a=t.pivot(index='actual',columns='predicted',values='count').to_numpy();assert a.sum()==r.n
 if r.n:
  assert abs(np.trace(a)/r.n-r.accuracy)<1e-10
  totals=a.sum(1);assert abs(np.mean(np.diag(a)[totals>0]/totals[totals>0])-r.balancedAccuracy)<1e-10
 cnt+=1
for stock in ['hudian','shenghong']:
 f=pd.read_csv(O/(stock+'-daily.csv'))
 for h in [5,20]:
  t=f[f['return'+str(h)].notna()];assert (t['end'+str(h)]>=t.date).all();a=np.where(t['return'+str(h)]>t['threshold'+str(h)],2,np.where(t['return'+str(h)]<-t['threshold'+str(h)],0,1));assert np.array_equal(a,t['label'+str(h)])
a=json.loads((O/'audit.json').read_text());a['confusionReconciliations']=cnt;a['uiVerification']='Local browser: defaultunchecked, onshowsHcolors/explanation, offremovescolors whilepreservingcandlesandfills; presentationtestpassed.';(O/'audit.json').write_text(json.dumps(a,ensure_ascii=False,indent=2));print('224 confusion rows and future label boundaries reconciled')
