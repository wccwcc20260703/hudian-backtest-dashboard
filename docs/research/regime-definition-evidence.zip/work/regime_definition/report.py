# -*- coding: utf-8 -*-
from pathlib import Path
import json,html,datetime,hashlib,zipfile
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
R=Path.cwd();O=R/'outputs/regime_definition';repo=R/'work/hudian-backtest-dashboard';m=pd.read_csv(O/'metrics.csv');c=pd.read_csv(O/'conditional.csv');s=pd.read_csv(O/'stability.csv');h=pd.read_csv(O/'hudian-daily.csv');audit=json.loads((O/'audit.json').read_text());pct=lambda x:'—' if pd.isna(x) else f'{x*100:.2f}%';stocks={'hudian':'沪电','shenghong':'胜宏'};names={'H':'H交易模式（非方向模型）','MA':'均线结构','ER':'20日方向效率','MA3':'均线结构＋3日确认'};states={0:'下行状态',1:'过渡／未确认',2:'上行状态'}
def table(head,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
v=h[h.date>='2023-10-09'].reset_index(drop=True);fig,axs=plt.subplots(3,1,figsize=(13,9),sharex=True,sharey=True);colors=['#d98979','#c7cfd9','#6db29b'];dates=pd.to_datetime(v.date)
for ax,k in zip(axs,['H','MA','MA3']):
 a=0
 for i in range(1,len(v)+1):
  if i==len(v) or v[k].iloc[i]!=v[k].iloc[a]:ax.axvspan(dates.iloc[a],dates.iloc[min(i,len(v)-1)],color=colors[int(v[k].iloc[a])],alpha=.24);a=i
 ax.plot(dates,v.close,color='#263a50',lw=1.15);ax.set_ylabel('Adjusted price');ax.set_title({'H':'Existing H policy: defense / reversal / trend (not directional labels)','MA':'Prior-day MA20 / MA60 structure','MA3':'Same structure, 3 completed-day confirmation'}[k],loc='left',fontsize=11);ax.grid(alpha=.12)
axs[0].legend(handles=[Patch(color=colors[0],alpha=.4,label='H defense / candidate down'),Patch(color=colors[1],alpha=.4,label='H reversal / candidate transition'),Patch(color=colors[2],alpha=.4,label='H trend / candidate up')],loc='upper left',fontsize=8);fig.tight_layout();fig.savefig(O/'comparison.svg');fig.savefig(O/'comparison.png',dpi=130);plt.close(fig)
body='''<a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a><h1>先定义行情区间，再验证不同策略</h1><p class="muted">H模式审计 · 三种固定、事前可知的方向规则 · 5日与20日分开评估 · 不改交易默认</p>
<section><h2>截图中的差异：展示的是交易模式，不是涨跌区间</h2><p>原图读取H模型的mode数组，与当前选中的D或融资L策略独立。H先判断过去反转交易是否有优势：此前约126日、RSI低组和高组各至少20个已结束次日收益样本，低组平均毛收益超过0.2%，且高于高组0.2%，就优先标为“反转交易”；不满足才考虑趋势参与。已披露利润增长不为正则防御。收益样本只到当日之前已能知道的结果，优先级本身并非前视错误。</p><p><strong>因此，上涨期间长期紫色是定义目标不同，并非紫色表示股票横盘。</strong>近三年727日中H反转模式458日；其中183日同时满足本轮简单均线上行结构，51日满足下行结构，其余224日未确认。当前默认D＋所有满仓融资，也不是由H背景决定买卖。把这层背景当作默认策略的行情分区，容易产生误解。</p><p>已将首页H背景改为可选的“叠加H交易模式对照”，默认不叠加，并注明与D/L独立。没有把未经验证的新分区直接替换成默认交易规则。以下图示仅作研究对照，三种方法全部使用当时之前的数据；H第一行的颜色含义与下面候选不同。</p><img src="regime-definition-chart.svg" alt="H交易模式、均线结构和三日确认区间的历史对照"></section>
<section><h2>区间定义要回答两个不同问题</h2><p><strong>当前是什么状态：</strong>根据已完成行情描述上涨结构、下跌结构或过渡期。<strong>接下来适合哪种交易：</strong>需要另测该状态下的未来收益、下行风险、反弹与策略损益。下行状态之后可能反弹，上行状态也可能发生拐点；不能要求当时识别器提前知道每一个顶底，再把事后分段当实时能力。</p><p>本轮不把所有非趋势状态称为“震荡区”。它可能是窄幅整理，也可能是剧烈反复或转折，尚未证明适合做T。更合理的研究结构是方向状态＋波动／风险状态＋入场信号，分别验证后再组合。一个适合20日持有的状态划分，未必适合5日或分钟交易。</p></section>
<section><h2>三个预先固定的定义，不搜索最佳阈值</h2>'''
body+=table(['候选','上行','下行','其余'],[['MA均线结构','前收盘＞MA20＞MA60，MA20高于5日前','前收盘＜MA20＜MA60，MA20低于5日前','过渡／未确认'],['ER方向效率','过去20日净涨幅／逐日绝对变动总和≥0.35','同一比率≤−0.35','过渡／未确认'],['MA3连续确认','MA的新状态连续出现3个已完成日才切换','同左；不倒填到第一天','尚未确认时保留前状态']])
body+='''<p>均用截至前一收盘的前复权行情。ER阈值0.35沿用早期研究既有设置，不按本轮结果搜索。MA3在初始无有效历史时用未确认状态；连续确认增加至少两个观测日的响应时间。均线斜率相等时按未确认，使用1e−10数值容差处理浮点相等，不是新择时参数。</p></section>
<section><h2>如何客观检验“准确”，避免只看图形顺眼</h2><p>对每个决策日，另算从当日复权开盘到第5／20个交易日复权收盘的涨幅；超过“前20日对数收益标准差×√持有天数”算明显上涨，低于负阈值算明显下跌，中间算未越阈值。阈值在当天之前可知，后续价格仅用于评分，绝不进入状态计算。</p><p>“未越阈值”只描述终点涨跌，不能证明过程平静、可低买高卖。标签不是唯一真理，本轮只是固定检验口径。普通准确率是三类判断命中比例；平衡准确率是每个实际类别召回率的平均，避免一直猜样本最多的中间类就拿高分。缺少某一实际类别的分段只对出现的类别求均值，不能与完整三类结果直接等同。</p><p>近期20日标签中，约69.49%属于中间类；全部猜中间就能得到69.49%普通准确率，但三类平衡准确率仅33.33%。不能只用一个漂亮的“命中率”宣称识别成功。H不是方向分类器，不参与候选优劣排名；证据包将其机械映射后的分数只保留作错误混用的诊断。</p></section>
<section><h2>近三年预测区分能力</h2>'''
body+=table(['股票／规则','未来天数','样本','普通准确率','平衡准确率','全部猜最大类准确率'],[[stocks[x.stock]+'／'+names[x.model],x.horizon,x.n,pct(x.accuracy),pct(x.balancedAccuracy),pct(x.majorityAccuracy)] for x in m[(m.period=='full')&(m.sampling=='all')&(m.model!='H')].itertuples()])
body+='''<p>沪电MA3的20日平衡准确率48.50%，高于简单MA的47.30%；但5日只有33.23%，接近三类中性基准。ER普通准确率较高，主要因更常输出未确认状态，不能直接叫它“最准确”。这轮尚未找到同时跨周期、跨阶段稳定的最优定义。</p></section>
<section><h2>稳定性与滞后：少变色不等于预测更好</h2>'''
body+=table(['股票／规则','上行／下行／过渡日数','状态切换','每段持续天数中位数','切换后5日内回到前状态／可观察切换'],[[stocks[x.stock]+'／'+names[x.model],f'{x.up}/{x.down}/{x.transition}',x.switches,x.medianDuration,f'{x.whipsaws5}/{x.eligibleSwitches}'] for x in s[(s.period=='full')&(s.model!='H')].itertuples()])
body+='''<p>沪电MA→MA3的切换83→46次，短期返回前状态37/82→8/44；胜宏也减少切换。这是状态稳定性改善，不是成交胜率改善。原H只有26次切换，却不适合用来描述涨跌区间；同样，过度延长确认期也可能延迟逃离下跌。</p></section>
<section><h2>同一区间的未来表现会跨阶段翻转</h2>'''
body+=table(['沪电MA3区间','时段','样本','后20日明显上涨','后20日明显下跌','平均20日涨幅','最差5%样本均值'],[[states[x.state],x.period,x.n,f'{x.up}/{x.n}',f'{x.down}/{x.n}',pct(x.meanReturn),pct(x.tail5)] for x in c[(c.stock=='hudian')&(c.model=='MA3')&(c.horizon==20)&c.period.isin(['full','early','later','julyOn','older'])].itertuples()])
body+='''<p>MA3下行状态在2023年10月至2024年末的28个可评分日期，后20日平均反弹20.90%；2025年至2026年6月的41个日期却平均−2.35%。同样的下行结构可能对应筑底反转，也可能对应风险延续，仅用均线把它们合并后统一买或卖都不充分。</p><p>7月后MA3仍判上行、且后20日可完整评分的只有4个日期，平均后续−25.96%，其中3个越过下跌阈值；这些高度重叠，不能说是4次独立失败，但确实展示了趋势末端的滞后风险。下行分类之后也可能是强反弹，不能把名称当作买卖结论。</p></section>
<section><h2>年度、早期与不重叠样本</h2>'''
body+=table(['股票／规则','时段','20日样本','20日平衡准确率'],[[stocks[x.stock]+'／'+names[x.model],x.period,x.n,pct(x.balancedAccuracy)] for x in m[(m.horizon==20)&(m.sampling=='all')&(m.model!='H')&m.period.isin(['older','year1','year2','year3'])].itertuples()])
body+='<p>再从每段第一日开始每隔持有天数抽一个起点，避免持有窗口重叠；这是一个固定相位检查，样本显著减少，不当成独立新数据：</p>'
body+=table(['股票／规则','未来天数','不重叠样本','平衡准确率'],[[stocks[x.stock]+'／'+names[x.model],x.horizon,x.n,pct(x.balancedAccuracy)] for x in m[(m.period=='full')&(m.sampling=='nonoverlap')&(m.model!='H')].itertuples()])
body+='''<p>20日不重叠样本仅36个。沪电MA3约57.76%、胜宏约39.81%，仍不足以宣布通用胜率提升。更早沪电MA3仅34.71%，说明近期48.50%不可直接外推。所有历史都已被研究过；本批没有重新训练或按分段选赢家，按时间列出的early/later与年度仍不冒称新盲测。</p></section>
<section><h2>下一步怎样衔接不同策略</h2><p>先冻结候选状态，再增加一个有独立经济含义的风险条件，检验能否区分“下跌延续”与“承接反转”、以及“趋势延续”与“趋势末端”。优先复用已测试的量价和市场相对强弱资料，避免不断扩大因子组合搜索。方向不明时应允许不新增交易，而不是硬贴震荡标签。</p><p>之后用相同状态划分分别跑趋势持有、反转买回、风险减仓的完整现金和融资账户，保留交易成本、未成交、T+1、融资额度和未平仓亏损。只有在原方案对照、年度、更早历史、滑点和冻结后独立证据中改善胜率／回撤，才提出接入默认。本轮只检验定义，没有新策略收益，也不拿价格分类准确率冒充做T胜率。</p>'''
body+=f"<p>核验：{audit['dailyPrefixChecks']}个股票日期的均线与效率指标由严格历史前缀独立复算；727行H状态与线上数据一致；224组按股票、规则、时段、期限、重叠方式的指标已保存。所有标签终点均限制在相应时段内，最后尚未完成的窗口不评分。</p>"
body+='''<p>数据截止2026-10-08；本轮使用日线而非有极值差异的5分钟数据，复权数据仍是当前版本。历史已见、重叠标签与有限样本都限制未来推断。多次尝试造成历史过拟合的风险参考原作者<a href="https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf">The Probability of Backtest Overfitting</a>；没有计算本策略PBO。<a href="regime-definition-evidence.zip">下载规则、每日状态、混淆矩阵、指标与脚本</a> · <a href="trade-frequency.html">上轮：频次与快速买回</a></p></section>'''
style='body{font:16px/1.75 system-ui,sans-serif;background:#f3f6fa;color:#1b304a;margin:0}main{max-width:1260px;margin:32px auto;padding:20px}section{background:white;border:1px solid #dce5ee;border-radius:14px;padding:24px;margin:22px 0}h1{font-size:30px}h2{font-size:22px}a{color:#147f85}.muted{font-size:14px;color:#6b7889}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:14px}th,td{white-space:nowrap;text-align:left;padding:11px;border-bottom:1px solid #e2e9ef}th{background:#f4f7fa}img{width:100%;height:auto}'
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>区间定义核验｜沪电研究</title><style>'+style+'</style></head><body><main>'+body+'</main></body></html>'
(O/'report.html').write_text(page.replace('src="regime-definition-chart.svg"','src="comparison.svg"'));(repo/'docs/research/regime-definition.html').write_text(page);(repo/'docs/research/regime-definition-chart.svg').write_bytes((O/'comparison.svg').read_bytes())
f=repo/'docs/research/archive.html';t=f.read_text();entry='<p><a href="regime-definition.html">区间定义核验：H背景为何与走势不同，均线、效率与连续确认的跨期检验 ↗</a></p>'
if 'href="regime-definition.html"' not in t:f.write_text(t.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+entry))
inputs=['work/round2/data/daily_qfq_early.csv','work/data/daily_qfq.csv','work/shenghong/data/daily_qfq.csv','work/risk_priority/data.json','work/shenghong/data.json','work/round2/adaptive_edge.py','work/hudian-backtest-dashboard/docs/data.json','work/hudian-backtest-dashboard/docs/default-selection.json']
(O/'manifest.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in inputs},indent=2));(O/'README.txt').write_text('Python pandas/numpy/matplotlib. Run work/regime_definition/research.py, then report.py inoriginalworkspace layout. research.py preserves initial registration if present. H direct source mode inspected; its rule not a directional predictor. Futurelabel evaluationonly, never features. UI optionalHcomparison defaultoff, no defaultstrategychange.\n')
with zipfile.ZipFile(repo/'docs/research/regime-definition-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in list(O.glob('*'))+list((R/'work/regime_definition').glob('*'))+[R/p for p in inputs]:
  if p.is_file() and p.name not in ['publication.json','deployment.log']:z.write(p,str(p.relative_to(R)))
f=R/'work/research-checkpoint.json';cp=json.loads(f.read_text());cp['regimeDefinition']={'updatedAt':datetime.datetime.now().astimezone().isoformat(),'outputs':'outputs/regime_definition','status':'locally verified, publication pending','finding':'H isreversal-edge-firstpolicy notprice-regime; alwaysshowedH withD/L, nowoptionaldefaultoff. Hreversal458days includes183MAup51MAdown. FixedMA/ER.35/MA3 testedfuture5/20volbandlabels. HMA3switch83->46,20balanced48.50vsMA47.30,5balanced33.23;older34.71. July4overlappingupstate20returnsmean-25.96;no stable optimalclassification.','audit':audit,'defaultStrategyChanged':False,'newBlindTest':False,'nextQuestion':'Validate an additional independent risk/acceptance condition separating downcontinuation vsrebound andupcontinuation vsdistribution, thenfixedpolicyaccounttest; transitionalnotrange,labelsnotTwin.'};cp['updatedAt']=cp['regimeDefinition']['updatedAt'];f.write_text(json.dumps(cp,ensure_ascii=False,indent=2)+'\n');print('report saved')
