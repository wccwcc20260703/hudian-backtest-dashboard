# -*- coding: utf-8 -*-
from pathlib import Path
import pandas as pd,numpy as np,json,datetime,math
R=Path.cwd();O=R/'outputs/regime_definition'
plan={'registeredAt':datetime.datetime.now().astimezone().isoformat(),'question':'SeparateHtradingpolicyfromobservedmarketregime; test whether causal states discriminate future5/20sessionreturns, without tailoring to hindsightregions.','rules':{'MA':'Prioradjustedclose>MA20>MA60 andMA20>MA20lag5 ->up; reverseall ->down;else transition.','ER':'Signed20session netchange /sum absoluteclosechanges >=.35 ->up,<=-.35 ->down,else transition. ExistingERthreshold reused, no search.','MA3':'MAraw mustholdsame newstate3consecutive knownsessions before switch; initialstate=transition, no futurebackdating.','H':'Existing displayedH modes onlyforHudian; audit notcallpricetruth. Defensive=0 mapsdown solely for illustrativeclassification,reverse=1 mapsneutral,trend=2 mapsup. Thismappingisnotvalidsemanticidentity.'},'horizons':[5,20],'evaluationLabel':'Fromdecisiondayadjustedopen to hthsessionadjustedclose; up ifreturn>prior20dailylogreturnstd*sqrt(h),down if<-threshold,else within-band. Thisfuturelabelonlyscores,neverusedfeatures. Within-banddoesnotproveintradayrange orsafeT. Fixedonevolthresholdno tuning.','chronology':'5periods full,older,early,later,July;3annual. Keepoutcomeendwithinperiod. Frozenrules,nofitting;separatechronologicalresultsandShenghongtransfer;pastseennotblind. Reportoverlappingandnonoverlappinghorizonssensitivities.','metrics':'Balancedaccuracy/macrorecall,confusion,conditionalfuturepriceprobabilities,mean/tailreturns,days/states,switchesanddwell,reversionwithin5sessions. Noprofit/Twin claims,nobacktestportfolioreturn thisbatch.','priority':'Validate definition before policy; no optimalguarantee,transitionnotrange; no newdefaultstrategy. Hpolicy hasedgepriority overtrend; displayedregime independentofselectedD/L.','data':'Dailyqfqcurrentvintage,onlyhistorythroughOct8;oldminutequalitylimitsnotusedtopredictlabels;future-returnlabelsadjustednotactualfill.','execution':'No orders/noportfoliochanges/no unvalidatedregime-router deployment.'}

if not (O/'plan-before-results.json').exists():(O/'plan-before-results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
q=pd.concat([pd.read_csv('work/round2/data/daily_qfq_early.csv',index_col='date'),pd.read_csv('work/data/daily_qfq.csv',index_col='date')]).sort_index();q=q[~q.index.duplicated(keep='last')]
sq=pd.read_csv('work/shenghong/data/daily_qfq.csv',index_col='date').sort_index();hd=json.load(open('work/hudian-backtest-dashboard/docs/data.json'));hs=dict(zip(hd['dates'],hd['state']));rows=[];summ=[];cond=[];conf=[];stability=[];checks=0
periods={'full':('2023-10-09','2026-10-08'),'older':('2020-01-02','2023-09-28'),'early':('2023-10-09','2024-12-31'),'later':('2025-01-01','2026-06-30'),'julyOn':('2026-07-01','2026-10-08'),'year1':('2023-10-09','2024-10-08'),'year2':('2024-10-09','2025-10-08'),'year3':('2025-10-09','2026-10-08')}
for stock,Q in [('hudian',q),('shenghong',sq)]:
 data=json.load(open('work/'+('risk_priority' if stock=='hudian' else 'shenghong')+'/data.json'));dates=data['dates'];Q=Q.loc[:dates[-1]];p=Q.close;ma20=p.rolling(20).mean();ma60=p.rolling(60).mean();raw=pd.Series(np.where((p>ma20)&(ma20>ma60)&(ma20-ma20.shift(5)>1e-10),2,np.where((p<ma20)&(ma20<ma60)&(ma20-ma20.shift(5)<-1e-10),0,1)),index=Q.index);raw[ma60.isna()]=np.nan
 er=(p-p.shift(20))/p.diff().abs().rolling(20).sum();ers=pd.Series(np.where(er>=.35,2,np.where(er<=-.35,0,1)),index=Q.index);ers[er.isna()]=np.nan
 stable=[];last=1;pending=None;count=0
 for v in raw:
  if pd.isna(v):stable.append(np.nan);continue
  if v==pending:count+=1
  else:pending=v;count=1
  if count>=3:last=int(v)
  stable.append(last)
 states={'MA':raw.shift().reindex(dates),'ER':ers.shift().reindex(dates),'MA3':pd.Series(stable,index=Q.index).shift().reindex(dates)}
 if stock=='hudian':states['H']=pd.Series([hs.get(d,np.nan) for d in dates],index=dates)
 vol=np.log(p/p.shift()).rolling(20).std(ddof=1).shift();f=pd.DataFrame({'date':dates,'stock':stock,'open':Q.open.reindex(dates),'close':p.reindex(dates),'vol':vol.reindex(dates),'priorMA20':ma20.shift().reindex(dates),'priorMA60':ma60.shift().reindex(dates),'priorER20':er.shift().reindex(dates)}).reset_index(drop=True)
 for k,v in states.items():f[k]=v.to_numpy()
 # Rebuild each daily feature from the strict prefix independently; also verify MA3 finite-state transition.
 previous=1;pending=None;count=0
 for i,date in enumerate(dates):
  j=Q.index.get_loc(date);known=Q.iloc[:j].close
  if len(known)>=65:
   a=known.iloc[-20:].mean();b=known.iloc[-60:].mean();old=known.iloc[-25:-5].mean();m=2 if known.iloc[-1]>a>b and a-old>1e-10 else 0 if known.iloc[-1]<a<b and a-old< -1e-10 else 1
   assert int(f.loc[i,'MA'])==m,(stock,date,f.loc[i,'MA'],m,known.iloc[-1],a,b,old)
   ev=(known.iloc[-1]-known.iloc[-21])/known.diff().iloc[-20:].abs().sum();assert abs(ev-f.loc[i,'priorER20'])<1e-9;checks+=1
 for h in [5,20]:
  future=p.shift(-(h-1));f['return'+str(h)]=(future/Q.open-1).reindex(dates).to_numpy();f['threshold'+str(h)]=(vol*np.sqrt(h)).reindex(dates).to_numpy();f['end'+str(h)]=pd.Series(Q.index,index=Q.index).shift(-(h-1)).reindex(dates).to_numpy();f['label'+str(h)]=np.where(f['return'+str(h)]>f['threshold'+str(h)],2,np.where(f['return'+str(h)]<-f['threshold'+str(h)],0,1));f.loc[f['return'+str(h)].isna(),'label'+str(h)]=np.nan
 f.to_csv(O/(stock+'-daily.csv'),index=False)
 for model in states:
  for period,(a,z) in periods.items():
   v=f[(f.date>=a)&(f.date<=z)&f[model].notna()].copy();seq=v[model].astype(int).tolist();switch=[i for i in range(1,len(seq)) if seq[i]!=seq[i-1]];runs=np.diff([0]+switch+[len(seq)]) if len(seq) else []
   whips=sum(seq[i-1] in seq[i+1:min(i+6,len(seq))] for i in switch if i+5<len(seq));eligible=sum(i+5<len(seq) for i in switch)
   stability.append(dict(stock=stock,model=model,period=period,days=len(seq),up=seq.count(2),down=seq.count(0),transition=seq.count(1),switches=len(switch),medianDuration=float(np.median(runs)) if len(runs) else None,whipsaws5=int(whips),eligibleSwitches=eligible))
   for h in [5,20]:
    vv=v[v['label'+str(h)].notna()&(v['end'+str(h)]<=z)].copy()
    for sampling in ['all','nonoverlap']:
     t=vv if sampling=='all' else vv.iloc[::h];mat=np.zeros((3,3),dtype=int)
     for pred,label in zip(t[model],t['label'+str(h)]):mat[int(label),int(pred)]+=1
     recall=np.divide(np.diag(mat),mat.sum(1),out=np.full(3,np.nan),where=mat.sum(1)>0);n=len(t);majority=int(mat.sum(1).max())/n if n else None
     summ.append(dict(stock=stock,model=model,period=period,horizon=h,sampling=sampling,n=n,accuracy=float(np.trace(mat)/n) if n else None,balancedAccuracy=float(np.nanmean(recall)) if n else None,majorityAccuracy=majority))
     for actual in range(3):
      for pred in range(3):conf.append(dict(stock=stock,model=model,period=period,horizon=h,sampling=sampling,actual=actual,predicted=pred,count=int(mat[actual,pred])))
     if sampling=='all':
      for state in range(3):
       w=t[t[model]==state];n1=len(w);ret=w['return'+str(h)]
       cond.append(dict(stock=stock,model=model,period=period,horizon=h,state=state,n=n1,up=int((w['label'+str(h)]==2).sum()),down=int((w['label'+str(h)]==0).sum()),within=int((w['label'+str(h)]==1).sum()),meanReturn=float(ret.mean()) if n1 else None,tail5=float(ret.nsmallest(max(1,math.ceil(n1*.05))).mean()) if n1 else None))
for name,rr in [('metrics',summ),('conditional',cond),('confusion',conf),('stability',stability)]:pd.DataFrame(rr).to_csv(O/(name+'.csv'),index=False)
# Exact UI source identity and its relation to observed trend, not future labeling.
h=pd.read_csv(O/'hudian-daily.csv');v=h[(h.date>='2023-10-09')&(h.date<='2026-10-08')];overlap=pd.crosstab(v.H,v.MA);overlap.to_csv(O/'H-vs-MA.csv');au={'dailyPrefixChecks':checks,'HUiRows':len(hd['dates']),'HUiMatches':all(int(h.loc[h.date==d,'H'].iloc[0])==s for d,s in hs.items()),'evaluations':len(summ),'defaultUnchanged':True,'HSource':'work/round2/adaptive_edge.py: Gpositive +reversaledge first, trendsecond; renderPrice always data.state regardlessactiveD/L','notNewBlindTest':True};(O/'audit.json').write_text(json.dumps(au,ensure_ascii=False,indent=2));print(json.dumps(au));print(pd.DataFrame(summ).query("period=='full' and sampling=='all'").to_string(index=False));print(overlap)
