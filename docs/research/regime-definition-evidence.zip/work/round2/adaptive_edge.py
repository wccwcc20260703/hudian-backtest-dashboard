from engine import *
from hybrid import EXTRA
# Causal regime selector: use only earlier realized outcomes to decide whether reversal has an edge.
# At session d, outcome from t->t+1 is included only for t <= d-2.
G=pd.read_csv(OUT/'fundamental_point_in_time_map.csv',index_col='date').reindex(DATES).yoy_netprofit.to_numpy();r=LAG.rsi2.to_numpy();factor=(Q.close/D.close).loc[DATES].to_numpy()
y=np.r_[B[1:,3,0]*factor[1:]/(B[:-1,6,0]*factor[:-1])-1,np.nan]
trend=(LAG.z60>0).to_numpy() & EXTRA['slope120']
params={'lookback':126,'minimum_group_observations':20,'gross_return_hurdle':.002,'low_minus_high_hurdle':.002,'rsi_low':35,'rsi_high':60,'earnings_gate':0.,'mean_reversion_weights':[1.,.5,0.],'trend_weight':1.,'defensive_weight':0.,'buy_bar':6,'sell_bar':3}
(ROOT/'adaptive_edge_parameters_before_test.json').write_text(json.dumps(params,indent=2))
def make(window=126,hurdle=.002):
 s=np.full((N,48),-1.);w=np.zeros(N);mode=np.zeros(N,dtype=int);stats=[]
 for d in range(N):
  a=max(0,d-window-1);z=max(0,d-1);v=y[a:z];rr=r[a:z];eligible=G[a:z]>0
  low=v[(rr<35)&eligible];high=v[(rr>60)&eligible];lo=np.mean(low) if len(low) else np.nan;hi=np.mean(high) if len(high) else np.nan
  edge=len(low)>=20 and len(high)>=20 and lo>hurdle and lo-hi>hurdle
  if G[d]<=0 or not np.isfinite(G[d]):mode[d]=0;w[d]=0.
  elif edge:mode[d]=1;w[d]=1. if r[d]<35 else (0. if r[d]>60 else .5)
  elif trend[d]:mode[d]=2;w[d]=1.
  else:mode[d]=0;w[d]=0.
  s[d,3 if d>0 and w[d]<w[d-1] else 6]=w[d]
  stats.append({'date':DATES[d],'mode':mode[d],'target':w[d],'historical_low_mean':lo,'historical_high_mean':hi,'low_count':len(low),'high_count':len(high),'latest_outcome_start_day':str(DATES[d-2]) if d>=2 else ''})
 return s,pd.DataFrame(stats)
if __name__=='__main__':
 s,stats=make();result={'full':export('H_adaptive_edge',s),'preperiod':export('H_adaptive_edge_preperiod',s,0,START),'stress':{},'years':{},'sensitivity':[]}
 stats.to_csv(OUT/'H_adaptive_edge_states.csv',index=False);np.save(ROOT/'H_adaptive_edge_signals.npy',s)
 for slip in [.001,.002]:result['stress'][str(slip)]=export('H_adaptive_edge_slip'+str(slip),s,slip=slip)
 for start,end,label in [('2023-10-09','2024-10-09','year1'),('2024-10-09','2025-10-09','year2'),('2025-10-09','2026-10-09','year3')]:
  a=int(np.searchsorted(DATES,start));z=int(np.searchsorted(DATES,end));result['years'][label]=export('H_adaptive_edge_'+label,s,a,z)
 for window,hurdle in [(84,.002),(168,.002),(252,.002),(126,.001),(126,.003)]:
  ss,_=make(window,hurdle);result['sensitivity'].append({'window':window,'hurdle':hurdle,**metrics(run(ss))})
 (OUT/'H_results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));print('modes',stats.iloc[START:].mode.value_counts().to_dict() if False else stats.iloc[START:]['mode'].value_counts().to_dict())
