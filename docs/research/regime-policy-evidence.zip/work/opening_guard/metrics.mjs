import assert from 'node:assert/strict';
export function stats(r){let previous=r.capital,peak=r.capital,run=0,longest=0,wins=0,losses=0,flat=0;const returns=[];
 // Whole holding episodes run from a flat account to a flat account, measured at day close including interest.
 let epStart=null,priorShares=0,episodeProfit=0;const episodes=[];
 for(let i=0;i<r.nav.length;i++){const eq=r.nav[i],delta=eq-previous,ret=eq/previous-1;returns.push(ret);if(delta>1e-7)wins++;else if(delta < -1e-7)losses++;else flat++;
 if(epStart===null&&(priorShares>0||r.daily[i].shares>0||Math.abs(delta)>1e-7))epStart=previous;
 if(epStart!==null&&r.daily[i].shares===0){episodes.push(eq-epStart);episodeProfit+=eq-epStart;epStart=null;}
 priorShares=r.daily[i].shares;peak=Math.max(peak,eq);run=eq<peak-1e-7?run+1:0;longest=Math.max(longest,run);previous=eq;
 }
 const openProfit=epStart===null?0:r.nav.at(-1)-epStart;assert.ok(Math.abs(episodeProfit+openProfit-(r.nav.at(-1)-r.capital))<1e-5);
 const pos=episodes.filter(x=>x>0),neg=episodes.filter(x=>x<0),sorted=returns.slice().sort((a,b)=>a-b),tail=sorted.slice(0,Math.ceil(sorted.length*.05));
 const done=(r.trips||[]).filter(t=>t.complete),tw=done.filter(t=>t.netCash>0);const tprofit=done.reduce((s,t)=>s+Math.max(t.netCash,0),0),tloss=-done.reduce((s,t)=>s+Math.min(t.netCash,0),0);
 return {days:returns.length,winningDays:wins,losingDays:losses,flatDays:flat,winningDayFraction:wins/returns.length,nonflatDayWinRate:wins/(wins+losses),worstDay:sorted[0],worst5pctDayMean:tail.reduce((s,v)=>s+v,0)/tail.length,longestDailyUnderwater:longest,closedEpisodes:episodes.length,episodeWins:pos.length,episodeWinRate:pos.length/episodes.length,episodeProfitFactor:neg.length?pos.reduce((s,x)=>s+x,0)/-neg.reduce((s,x)=>s+x,0):null,openEpisode:epStart!==null,openEpisodeMarked:openProfit,tEntered:(r.trips||[]).length,tCompleted:done.length,tWinRate:done.length?tw.length/done.length:null,tProfitFactor:tloss?tprofit/tloss:null,tUnfinished:(r.trips||[]).length-done.length};
}
