from pathlib import Path
import json, hashlib, math
import pandas as pd
R=Path.cwd();O=R/'outputs/regime_policy';m=pd.read_json(O/'metrics.json');daily=pd.read_json(O/'daily.json');ep=pd.read_json(O/'episodes.json');audit=json.loads((O/'audit.json').read_text())
for p,sha in json.loads((O/'manifest.json').read_text()).items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==sha,p
state_checks=0
for stock in ['hudian','shenghong']:
 if stock=='hudian':
  q=pd.concat([pd.read_csv(R/'work/round2/data/daily_qfq_early.csv'),pd.read_csv(R/'work/data/daily_qfq.csv')]).sort_values('date').drop_duplicates('date',keep='last')
 else:q=pd.read_csv(R/'work/shenghong/data/daily_qfq.csv').sort_values('date')
 q=q.reset_index(drop=True);p=q.close; ma20=p.rolling(20).mean();ma60=p.rolling(60).mean();slope=ma20-ma20.shift(5)
 known={};current=1;pending=None;count=0
 for i in range(len(q)):
  if i>=60:known[q.date.iloc[i]]=current
  if pd.isna(ma60.iloc[i]):continue
  raw=2 if p.iloc[i]>ma20.iloc[i]>ma60.iloc[i] and slope.iloc[i]>1e-10 else 0 if p.iloc[i]<ma20.iloc[i]<ma60.iloc[i] and slope.iloc[i]<-1e-10 else 1
  count=count+1 if pending==raw else 1;pending=raw
  if count>=3:current=raw
 ss=json.loads((O/f'{stock}-states.json').read_text())
 for date,value in zip(ss['dates'],ss['MA3']):assert known[date]==value,(stock,date);state_checks+=1
episode_checks=0; summaries=[];boundary=[]
for row in m[(m.period=='full')&(m.slip==.0005)].itertuples():
 e=ep[(ep.stock==row.stock)&(ep.name==row.name)];closed=e[e.complete];v=daily[(daily.stock==row.stock)&(daily.name==row.name)]
 assert len(closed)==row.closedEpisodes
 assert (closed.pnl>0).sum()==row.episodeWins
 assert abs(e.pnl.sum()-row.return_*1e6)<.01
 assert abs(v['return_'].add(1).prod()-1-row.return_)<1e-9
 assert abs(v.exposure.mean()-row.exposure)<1e-9
 n=len(closed);w=(closed.pnl>0).sum();z=1.96
 if n:
  p=w/n;ctr=(p+z*z/(2*n))/(1+z*z/n);half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n);ci=[ctr-half,ctr+half]
 else:ci=[None,None]
 summaries.append({'stock':row.stock,'name':row.name,'complete':n,'wins':int(w),'medianDays':float(closed.days.median()) if n else None,'meanEpisodeReturn':float(closed.return_.mean()) if n else None,'wilsonLow':ci[0],'wilsonHigh':ci[1],'openCount':len(e)-n,'openPnl':float(e[~e.complete].pnl.sum())})
 episode_checks+=1
for stock in ['hudian','shenghong']:
 f=pd.read_csv(R/f'outputs/regime_definition/{stock}-daily.csv');f=f[f.date>='2023-10-09'].set_index('date')
 for name in ['RC','RL','D10','L10']:
  v=daily[(daily.stock==stock)&(daily.name==name)].copy();v['date']=v.date.dt.strftime('%Y-%m-%d') if pd.api.types.is_datetime64_any_dtype(v.date) else v.date
  v=v.set_index('date').join(f[['MA','MA3']]);v['pnl']=v.nav.diff();v.iloc[0,v.columns.get_loc('pnl')]=v.nav.iloc[0]-1e6
  for flag,mask in [('up_raw_agrees',(v.MA3==2)&(v.MA==2)),('up_raw_disagrees',(v.MA3==2)&(v.MA!=2)),('down',(v.MA3==0)),('transition',(v.MA3==1))]:
   t=v[mask];boundary.append({'stock':stock,'name':name,'condition':flag,'days':len(t),'pnl':t.pnl.sum(),'positiveDays':int((t.return_>1e-12).sum()),'meanDailyReturn':t.return_.mean(),'worstDay':t.return_.min()})
pd.DataFrame(summaries).to_csv(O/'episode-summary.csv',index=False);pd.DataFrame(boundary).to_csv(O/'boundary-diagnostic.csv',index=False)
for name,x in [('metrics',m),('episodes',ep),('quarters',pd.read_json(O/'quarters.json'))]:x.to_csv(O/(name+'.csv'),index=False)
audit['independentEpisodeReconciliations']=episode_checks;audit['causalStateRebuilds']=state_checks;audit['manifestMatches']=True;audit['diagnosticNote']='RawMA/MA3 disagreement attribution only; not traded or used to pick a new gate. MonetaryPnl additive within account, not causal counterfactual.'
(O/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2));print(json.dumps(audit));print(pd.DataFrame(boundary).query("stock=='hudian'").round(4).to_string(index=False));print(ep[(ep.stock=='hudian')&(ep.name=='S2_F100')].sort_values('pnl').head(5).to_string(index=False))
