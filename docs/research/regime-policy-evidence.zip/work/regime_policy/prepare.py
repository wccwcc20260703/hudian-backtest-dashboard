from pathlib import Path
from datetime import datetime
import json, hashlib
import pandas as pd

R=Path.cwd(); O=R/'outputs/regime_policy'; O.mkdir(exist_ok=True)
plan={
 'registeredAt':datetime.now().astimezone().isoformat(),
 'question':'With one frozen causal MA3 partition, do fixed exposure and reversal policies differ across states, and does a preregistered continuous router improve risk and genuine closed-episode success?',
 'definition':'Reuse previous MA3 without changes: prior completed close>MA20>MA60 and MA20>its value5sessions before=rawup; all reversed=rawdown;else unconfirmed. New rawstate must persist3completed observations before change. Priorstate held while pending. No hindsight recoloring; middle is NOT established sideways.',
 'factors':'Price position, MA20/MA60 order,5session MA20 slope,3observation persistence. ER20, prior volatility, gap, VWAP and volume are diagnostic/next-study candidates, not new gates in this batch.',
 'comparisons':{'global':['CASH','B buyhold','F50','F100','D original','L original','D10 original targets at10:00','L10 original targets at10:00'], 'stateOnly':'For each MA3 state0,1,2: F50,F100,D10,L10; outside selected state target0. Actual liquidation costs and overnight carry after state change remain in the account. No reset between visits. Same10:00 decision time for all masked policies, 5bar max fill window.', 'routers':{'RC':'Up100%,middleDtarget,down0%;all10:00','RL':'Up150%,middleDtarget withfull amplified150%,down0%;all10:00. Borrowcap and marginmaintenance retained.'}},
 'execution':'Reuse audited shenghong/finance.mjs unchanged. Commission.0001 min5; historical stamp/transfer; slip5and10bps eachside; T+1,100shares,previousbar1%volume,300kfillcap,limitprices; finance6%annual,loan<=50%netonbuys,passiveovershootallowed. Forcedmaintenance can override state. F100constanttarget differs from buyhold. 10:00 time is fixed for isolation, not optimized.',
 'chronology':'No training or selection: rules fixed before this run; main2023-10-09..2026-10-08,earlier2020..2023,early/later/July,3fixedyearsegments; Shenghong exacttransfer;63day rolling relative returns and quarters. All past seen, not new blind validation. Never choose winner per state ex post for router.',
 'metrics':'Return;5minutecloseDD;worst5%dailyreturns;wholeflat-to-flatclosedepisodes wins/count; openepisode marked separately;positiveaccountdays/allandnonflat;exposure,fees,interest,trade days,lead/longestbehind,rolling63. No explicit same-dayroundtrips,no T success claim.',
 'guardrails':'No default change, no new accounts/paiddata/orders. CASH no profitabletrades not100%success. Stateonly returns not priceconditionalreturns nor additive contributions; allcalendar days in denominator. Mainhistory throughOct8, Oct9notcertified. MA3 correctness is deterministic rule reproducibility, not guaranteed foresight.',
 'totalScenarios':704
}
p=O/'plan-before-results.json'
if not p.exists():p.write_text(json.dumps(plan,ensure_ascii=False,indent=2))
manifest={}
for stock,path in [('hudian','work/risk_priority/data.json'),('shenghong','work/shenghong/data.json')]:
 d=json.loads((R/path).read_text()); src=R/f'outputs/regime_definition/{stock}-daily.csv'; f=pd.read_csv(src).set_index('date').loc[d['dates']]
 assert f.MA3.notna().all(); states=f.MA3.astype(int).tolist()
 # Export only causal state. Future diagnostic columns NEVER go into account input.
 (O/f'{stock}-states.json').write_text(json.dumps({'dates':d['dates'],'MA3':states}))
 manifest[path]=hashlib.sha256((R/path).read_bytes()).hexdigest();manifest[str(src.relative_to(R))]=hashlib.sha256(src.read_bytes()).hexdigest()
for path in ['work/shenghong/finance.mjs','work/shenghong/benchmark.mjs','work/hudian-backtest-dashboard/docs/fees.js','work/hudian-backtest-dashboard/docs/default-selection.json']:
 manifest[path]=hashlib.sha256((R/path).read_bytes()).hexdigest()
(O/'manifest.json').write_text(json.dumps(manifest,indent=2));print('Frozen plan and 3274 causal states saved; no result evaluated.')
