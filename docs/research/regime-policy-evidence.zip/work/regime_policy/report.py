# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
import json, html, zipfile, shutil
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R=Path.cwd();O=R/'outputs/regime_policy';repo=R/'work/hudian-backtest-dashboard';M=pd.read_json(O/'metrics.json');E=pd.read_json(O/'episodes.json');D=pd.read_json(O/'daily.json');A=json.loads((O/'audit.json').read_text())
N={'CASH':'空仓','B':'全仓买入持有基准','F50':'全程目标50%','F100':'全程目标100%','D':'原D现金／原时点','L':'默认L融资／原时点','D10':'D现金／统一10:00','L10':'L融资／统一10:00','RC':'分区组合／现金','RL':'分区组合／融资'}
S={0:'下行结构',1:'过渡／未确认',2:'上行结构'}
for s in range(3):
 for p in ['F50','F100','D10','L10']:N[f'S{s}_{p}']=S[s]+' · '+{'F50':'目标50%','F100':'目标100%','D10':'D现金','L10':'L融资'}[p]
periods={'full':'近三年 2023-10-09—2026-10-08','older':'更早 2020-01-02—2023-09-28','early':'2023-10-09—2024-12-31','later':'2025-01-01—2026-06-30','julyOn':'2026-07-01—2026-10-08（重新建仓）','year1':'固定年度1：2023-10-09—2024-10-08','year2':'固定年度2：2024-10-09—2025-10-08','year3':'固定年度3：2025-10-09—2026-10-08'}
pct=lambda x:'—' if pd.isna(x) else f'{x*100:+.2f}%'
dd=lambda x:f'{abs(x)*100:.2f}%'
def table(head,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def get(name,period='full',stock='hudian',slip=.0005):return M[(M.stock==stock)&(M.name==name)&(M.period==period)&(M.slip==slip)].iloc[0]
def ratio(x):return f'{x.episodeWins}/{x.closedEpisodes}（{x.episodeWinRate*100:.2f}%）' if x.closedEpisodes else '无完整平仓周期'

fig,axs=plt.subplots(2,1,figsize=(12,7),sharex=True)
for ax,keys,title in [(axs[0],['B','D10','RC'],'Cash: frozen regime router versus reversal control'),(axs[1],['B','L10','RL'],'Margin: frozen regime router versus reversal control')]:
 for name,color in zip(keys,['#8793a6','#147f85','#d78f31']):
  v=D[(D.stock=='hudian')&(D.name==name)];ax.plot(pd.to_datetime(v.date),v.nav/1e6,label={'B':'Buy and hold','D10':'D at 10:00','RC':'Up100 / transition D / down0','L10':'L at 10:00','RL':'Up150 / transition L / down0'}[name],color=color,lw=1.5)
 ax.set_title(title,loc='left',fontsize=11);ax.set_ylabel('Account / initial capital');ax.legend(fontsize=9);ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(O/'comparison.svg');plt.close(fig)
body='''<nav><a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a></nav>
<h1>同一区间，用什么策略？先固定定义，再比较账户</h1>
<p class="muted">MA3固定定义 · 22种账户 × 2只股票 × 8个时段 × 2档滑点＝704次回测 · 截至2026-10-08</p>
<section class="notice"><h2>结论：这一版区间还不足以决定“上行满仓、下行空仓”</h2><p>固定均线分区后，这种直觉式组合在沪电三年现金账户的回撤32.51%、完整持仓周期胜率64.15%，均劣于同为10:00执行的D对照（19.46%、67.62%）。融资版回撤43.65%，也劣于同时间L对照的26.16%。因此保留现有默认，不把这次分区直接接入交易。</p><p>这里的准确分两层：<strong>状态定义能否按当时已知数据复算一致；这种状态是否能稳定区分未来风险和适用策略。</strong>第一层已核验，第二层尚未通过。不能靠事后把下跌改叫“下行”来证明实时识别准确。</p></section>
<section><h2>1．区间定义与真正使用的关键因子</h2>'''
body+=table(['原始状态','截至前一收盘的必要条件','其含义'],[['上行结构','前收盘 > MA20 > MA60，且MA20 > 5个交易日前的MA20','中短期价格与均线方向一致'],['下行结构','前收盘 < MA20 < MA60，且MA20 < 5个交易日前的MA20','中短期价格与均线方向一致向下'],['过渡／未确认','以上两组均不满足','可能整理、转折或剧烈反复；不能直接叫可做T的震荡']])
body+='''<p><strong>稳定状态MA3：</strong>原始状态连续出现3个已完成交易日，次日才切换；等待确认期间保留旧状态，不把新状态倒填至第一天。均使用当时之前的日线复权价格；均线斜率相等按过渡处理。3日确认减少反复，也会使拐点识别更迟。</p>'''
body+=table(['因子','明确计算／用途','本轮状态是否使用'],[['价格相对均线','前收盘与MA20位置','是'],['均线排列','MA20与MA60的位置','是'],['均线方向','MA20减去5个交易日前的MA20','是'],['连续性','同一原始状态持续3日，切换不回填','是'],['方向效率ER20','20日净价格变化 ÷ 20日逐日绝对变化之和，既有±0.35候选','否；上轮对照因子，未叠加搜索'],['已知波动','前20日日对数收益标准差；用于判断风险尺度','否；不能把高波动当必跌'],['成交量、VWAP、高低开','早盘完成后才可确认；量价与承接候选','否；本轮先隔离方向分区的作用'],['市场相对强弱／海外背景','交易时点已完成的大盘与海外数据','否；尚未证明提高该分区的稳定性']])
body+='''<p>“震荡”仍缺少独立检验：至少需要同时判断方向弱、区间边界可重复、波动可承受以及扣费后往返收益。仅因不满足上行／下行就命名震荡，会把趋势转折混进去。<a href="regime-definition.html">上轮定义检验</a>中MA3的20日三类平衡准确率为48.50%，更早行情34.71%；该分数既不是做T胜率，也不能保证后续涨跌。</p></section>
<section><h2>2．如何公平比较不同区间的策略</h2><p>对每个状态分别设立同起点100万元的独立模拟账户：只在指定状态使用50%仓位、100%仓位、D现金或L融资；离开该状态，10:00开始按真实成交约束清仓。多次进入同一状态时延续同一账户，不重置本金，不删除隔夜跳空和退出费用。空仓也作为零收益、零交易的对照，其胜率未定义。</p><p>D目标由前日RSI2及当时已披露业绩决定：RSI2&lt;35目标100%，&gt;60目标0%，其余50%；业绩门槛不满足则0%。L将D的100%目标放大至150%，50%目标不放大。为隔离策略而不是时点，本轮区间账户与分区组合的普通订单统一10:00，最多5根5分钟K线完成；原D/L时点另列对照，没有偷偷将10:00版当原默认。</p><p>另预先固定两个连续分区组合：<strong>现金＝上行100%／过渡D／下行0%；融资＝上行150%／过渡L／下行0%。</strong>这是出结果前写下的规则，没有在看到各区间赢家后拼接“最优组合”。所有历史已经研究过，年度和胜宏迁移不冒称新盲测。</p><p>100%目标按每日再平衡执行；全仓买入持有基准只在初始买入并保留分红现金，两者分开。买入扣费后融资欠款不超过当前净资产50%，允许被动超仓，担保约束仍在。费用按用户股票佣金万1、最低5元及历史税费，融资年息6%，单边滑点5/10基点；保留T+1、手数、涨跌停、成交量容量限制。</p></section>
<section><h2>3．每种区间的实际账户结果</h2><p>下表为沪电三年、单边5基点。状态日数：上行303、过渡344、下行80。<strong>收益为只在相应状态运作的整个账户收益，含退出到下一状态时的价格变动与费用；不是行情区间自身涨幅，也不能将各行相加。</strong>所有未完成周期均按市值计入收益、回撤，单列期末未平仓损益。</p>'''
body+=table(['区间／策略','账户收益','最大回撤','盈利完整周期／全部完整周期','平均实际仓位','期末未平仓损益（元）'],[[N[x.name],pct(x.return_),dd(x.mdd5),ratio(x),f'{x.exposure*100:.2f}%',f'{x.openEpisodeMarked:,.0f}'] for x in M[(M.stock=='hudian')&(M.period=='full')&(M.slip==.0005)&M.name.str.startswith('S')].itertuples()])
body+='''<p>上行状态内，100%仓位并未天然提高胜率：完整周期仅6/15盈利，最大回撤31.22%；D现金为34/55、回撤17.21%。二者周期长度不同（中位数21日与4日），不能将差异当作每个买点准确率的提升。下行状态中D仍有反弹收益，说明“下行＝必须放弃全部买点”也不成立。</p><p>下行区融资出现12/15＝80%的完整周期盈利，但中位持有3个交易日，并非日内做T。简单Wilson区间约54.8%—93.0%，且同一股票各周期并不必然独立，该区间只是样本不确定性的提示；不能宣称未来80%。胜宏下行50%账户甚至7/7已平仓盈利，但期末仍有约3.46万元未平仓亏损，回撤22.12%——高已实现胜率不等于低风险。</p></section>
<section><h2>4．连续切换区间，组合是否更好？</h2>'''
body+=table(['方案','三年收益','最大回撤','完整周期胜率','盈利日／所有727日','最差5%交易日平均收益'],[[N[k],pct((x:=get(k)).return_),dd(x.mdd5),ratio(x),f'{x.winningDays}/727',pct(x.worst5pctDayMean)] for k in ['B','D','D10','RC','L','L10','RL']])
body+='''<img src="regime-policy-chart.svg" alt="固定分区现金与融资组合对照净资产曲线"><p>现金分区组合相对D10：完整周期胜率67.62%→64.15%，回撤19.46%→32.51%。融资组合相对L10：73.20%→68.00%，26.16%→43.65%。两者同时恶化，因此失败不是仅仅“收益少一点”的取舍，而是不符合当前优先胜率和回撤的目标。</p></section>
<section><h2>5．失败在哪些具体日期？</h2><p>以下是整段账户运行中，当天收盘净资产相对前收盘的收益，用来定位差异；不是可重复获得的单笔收益，也不是证明某一因素造成全部损益。</p>'''
pv=D[(D.stock=='hudian')&D.name.isin(['RC','D10'])].pivot(index='date',columns='name',values='return_');f=pd.read_csv(R/'outputs/regime_definition/hudian-daily.csv');f.date=pd.to_datetime(f.date);pv=pv.join(f.set_index('date')[['MA','MA3']]);pv['gap']=pv.RC-pv.D10
v=pv.nsmallest(6,'gap');body+=table(['日期','MA3／未确认前的原始MA','分区现金当天','D10当天','差异'],[[str(i.date()),S[int(x.MA3)]+'／'+S[int(x.MA)],pct(x.RC),pct(x.D10),pct(x.gap)] for i,x in v.iterrows()])
body+='''<p>例如2026-07-02，前一日信息下MA和MA3都仍是上行；分区现金当天约−9.99%，D10约−1.65%。2024-09-24仍在下行结构，分区现金空仓，而D10当天约+8.79%。均线结构对趋势有描述作用，却不会提前知道急跌或反弹。</p><p>也不能把亏损简单归咎于3日确认：MA3仍上行、原始MA已不一致的41日，分区现金合计账面损益仍为正约21.25万元。这里包含不同本金与隔夜持仓，不能作为提前卖出的反事实收益；至少表明“遇到不一致立刻卖”尚未被证实，需要单独对照，不能从几个亏损案例直接推出新规则。</p></section>
<section><h2>6．跨时段、滑点与迁移</h2>'''
body+=table(['时段／股票','D10回撤／胜率','分区现金回撤／胜率','L10回撤／胜率','分区融资回撤／胜率'],[[lab,*[f'{dd((x:=get(k,p,s)).mdd5)} / {ratio(x)}' for k in ['D10','RC','L10','RL']]] for lab,p,s in [('沪电年度1','year1','hudian'),('沪电年度2','year2','hudian'),('沪电年度3','year3','hudian'),('沪电更早历史','older','hudian'),('胜宏近三年','full','shenghong')]])
body+='''<p>沪电三个固定年度，现金与融资分区组合的回撤全部比相同时间对照更大；更早历史的现金／融资组合回撤61.17%／78.35%。单边滑点增加至10基点后，三年现金组合回撤33.82%、融资45.48%，结论不变。胜宏迁移也没有同时提高胜率并降低回撤。</p><p>下表承接三年账户持仓，在7月1日不重置；与下方交互表的“7月起重新建仓”是两个不同问题。滚动63日窗口互相重叠，不能当独立交易胜率；累计领先比例是净资产超过全仓基准的日期比例。</p>'''
body+=table(['方案','截至6月30日段内收益','7月起段内收益','累计领先全仓日期比例','最长连续落后','滚动63日领先比例'],[[N[k],pct((x:=get(k)).preJuly),pct(x.postJuly),f'{x.leadFraction*100:.2f}%',f'{x.longestBehind}日',f'{x.rolling63Lead*100:.2f}%'] for k in ['D10','RC','L10','RL','B']])
body+='''<p>基准自身领先指标不适用；原始输出中记0作占位，不能解读为基准表现差。财富1.20倍或“保留持有收益且回撤降低25%”仍仅是旧对照目标；本轮因胜率和回撤恶化而否决组合，不是因为重新引入收益硬门槛。</p></section>
<section><h2>7．查看全部账户与时段</h2><div class="controls"><label>股票 <select id="stock"><option value="hudian">沪电股份</option><option value="shenghong">胜宏科技</option></select></label><label>时段 <select id="period">'''
body+=''.join(f'<option value="{k}">{v}</option>' for k,v in periods.items())
body+='''</select></label><label>单边滑点 <select id="slip"><option value="0.0005">5基点</option><option value="0.001">10基点</option></select></label></div><p id="selection" class="muted"></p><div class="scroll"><table><thead><tr><th>账户／策略</th><th>收益</th><th>最大回撤</th><th>完整周期胜率</th><th>盈利日／全部日</th><th>平均仓位</th><th>完整周期盈亏比*</th><th>费用／利息（元）</th><th>未平仓损益（元）</th><th>交易日数</th></tr></thead><tbody id="results"></tbody></table></div><p class="muted">*盈利完整周期的利润总和 ÷ 亏损完整周期的亏损绝对值总和；没有亏损时显示—，不显示无穷大。不是平均每笔盈亏比。胜率分母为完整的空仓→持仓→再空仓周期，未平仓单列；没有定义日内配对往返，做T胜率未估计。空仓和平盘日不算盈利日。</p></section>
<section><h2>8．可以改善的方向与本轮边界</h2><p>本轮已否决“用这套均线区间直接绑定满仓／空仓”的简单版本。下一步的可检验问题是：<strong>方向相同的情况下，哪种风险或承接因子能分开趋势延续与突然转折？</strong>优先单独检验前日波动扩大／回撤状态，再与前15分钟量价承接分开对照；先测一个因素，再谈组合，不按每段历史赢家重新配方。真正的震荡需单独验证，不能将未确认区默认为可高频做T。</p><p>证据强度目前只支持历史模拟比较。704次账户并非704组独立数据，没有冻结后的独立新交易日；所有已见历史不能再次命名样本外。反复寻找参数的选择偏差参考原作者<a href="https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf">The Probability of Backtest Overfitting</a>（2026-10-10访问），本文没有估计本策略PBO。</p><p>数据截止2026-10-08；10月9日的日线与分钟极值差异未完全核验，未补造交易。历史5分钟与日线存在极值／量口径差异，回撤按5分钟收盘及日线收盘，不代表真实盘中最坏成交。前复权为当前数据版本，历史财报版本与逐日融资资格未完整验证；现金分红税模型简化，策略和长期持有基准的假定不同。结果均为模拟，不能声称可实现收益或已找到“长期准确制胜”的方法。</p>'''
body+=f'<p>核验：{A["causalStateRebuilds"]}个股票日期的状态独立按前缀重建；{A["originalMetricParity"]}个原账户指标逐一一致；{A["ledger"]:,}笔模拟成交与{A["accountDays"]:,}个账户日期核对现金、仓位、费用及利息；{A["loanChecks"]:,}次买入核对融资上限；44组完整周期收益与期末净资产对账。</p>'
body+='''<p><a href="regime-policy-evidence.zip">下载完整方案、704组结果、每日净资产、成交、周期与可复跑脚本</a> · <a href="regime-definition.html">上轮：区间定义检验</a> · <a href="trade-frequency.html">买卖频次研究</a></p></section>'''
cols=['stock','name','period','slip','return_','mdd5','episodeWins','closedEpisodes','episodeWinRate','winningDays','days','exposure','episodeProfitFactor','fees','interest','openEpisodeMarked','tradeDays']
payload=json.dumps(json.loads(M[cols].to_json(orient='records')),ensure_ascii=False)
script='const DATA='+payload+';const NAMES='+json.dumps(N,ensure_ascii=False)+''';
const pc=x=>x==null?'—':(x*100).toFixed(2)+'%',money=x=>(x??0).toLocaleString('zh-CN',{maximumFractionDigits:0});
function render(){const stock=document.getElementById('stock').value,period=document.getElementById('period').value,slip=Number(document.getElementById('slip').value);const rows=DATA.filter(x=>x.stock===stock&&x.period===period&&x.slip===slip);document.getElementById('selection').textContent=`共 ${rows.length} 个账户；每个账户起始100万元，各时段独立建仓，不将区间账户收益相加。`;
document.getElementById('results').innerHTML=rows.map(x=>`<tr><td>${NAMES[x.name]}</td><td>${pc(x.return_)}</td><td>${pc(Math.abs(x.mdd5))}</td><td>${x.closedEpisodes?`${x.episodeWins}/${x.closedEpisodes} · ${pc(x.episodeWinRate)}`:'—（无完整周期）'}</td><td>${x.winningDays}/${x.days}</td><td>${pc(x.exposure)}</td><td>${x.episodeProfitFactor==null?'—':x.episodeProfitFactor.toFixed(2)}</td><td>${money(x.fees)} / ${money(x.interest)}</td><td>${money(x.openEpisodeMarked)}</td><td>${x.tradeDays}</td></tr>`).join('');}
for(const id of ['stock','period','slip'])document.getElementById(id).addEventListener('change',render);render();'''
style='body{font:16px/1.8 system-ui,sans-serif;background:#f3f6fa;color:#1b304a;margin:0}main{max-width:1280px;margin:30px auto;padding:20px}section{background:#fff;border:1px solid #dce5ee;border-radius:14px;padding:26px;margin:22px 0}.notice{border-top:4px solid #c88c39}h1{font-size:30px}h2{font-size:22px}a{color:#147f85}.muted{font-size:14px;color:#66798b}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:11px;white-space:nowrap;text-align:left;border-bottom:1px solid #e3eaf1}th{background:#f4f7fa}img{max-width:100%;height:auto}.controls{display:flex;gap:16px;flex-wrap:wrap}select{padding:8px;font:inherit;border:1px solid #bccbda;border-radius:6px;max-width:100%}nav{font-size:14px}'
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>区间与仓位策略对照｜沪电研究</title><style>'+style+'</style></head><body><main>'+body+'</main><script>'+script+'</script></body></html>'
(O/'report.html').write_text(page.replace('regime-policy-chart.svg','comparison.svg'))
(repo/'docs/research/regime-policy.html').write_text(page);shutil.copyfile(O/'comparison.svg',repo/'docs/research/regime-policy-chart.svg')
archive=repo/'docs/research/archive.html';s=archive.read_text();link='<p><a href="regime-policy.html">固定区间后比较空仓、半仓、满仓与反转：704组账户结果及分区组合失败原因 ↗</a></p>'
if 'href="regime-policy.html"' not in s:archive.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+link))
(O/'README.txt').write_text('Run from workspace root: python work/regime_policy/prepare.py ; node work/regime_policy/run.mjs ; python work/regime_policy/check.py ; python work/regime_policy/report.py. Python uses pandas/numpy/matplotlib. Stateinputs exclusively causal MA3; prior regime research CSV has evaluation-only future labels, never exported into accountinput. Fixed10:00 for statepolicies vs originaltimecontrol. All pastseen. Default unchanged.\n')
inputs=list(json.loads((O/'manifest.json').read_text()))+['outputs/trade_frequency/metrics.json','work/opening_guard/metrics.mjs','work/hudian-backtest-dashboard/docs/attribution.js','work/round2/data/daily_qfq_early.csv','work/data/daily_qfq.csv','work/shenghong/data/daily_qfq.csv']
with zipfile.ZipFile(O/'regime-policy-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in list(O.glob('*'))+list((R/'work/regime_policy').glob('*.py'))+list((R/'work/regime_policy').glob('*.mjs'))+[R/p for p in inputs]:
  if p.is_file() and p.suffix!='.zip' and p.name not in ['publication.json','deployment.log']:z.write(p,str(p.relative_to(R)))
shutil.copyfile(O/'regime-policy-evidence.zip',repo/'docs/research/regime-policy-evidence.zip')
cp=R/'work/research-checkpoint.json';c=json.loads(cp.read_text());now=datetime.now().astimezone().isoformat();c['regimePolicy']={'updatedAt':now,'outputs':'outputs/regime_policy','status':'verified locally; pending publication','question':'Can frozenMA3 states safely route fullholding/reversal/flat?','finding':'No. H cashrouter DD32.51vsD10 19.46,episodes34/53vs71/105; margin43.65vs26.16 and34/50vs71/97. All3fixedyearsrouterDDworse;olderDD61.17/78.35. Upstate F1006/15wins DD31.22 vsD34/55 DD17.21;downL12/15 notT80%. Confirmationdisagreement41days netpositive, cannotblamealllosseson3daydelay.','audit':A,'defaultChanged':False,'newBlindTest':False,'nextQuestion':'Single independent riskcondition within direction, distinguish abruptdownside vs rebound; test previousdayvolatility/drawdown separately from09:45volumeacceptance. Do not select historical winner perstate; true sideways not established.'};c['updatedAt']=now;cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print('Report, chart, evidence and checkpoint saved.')
