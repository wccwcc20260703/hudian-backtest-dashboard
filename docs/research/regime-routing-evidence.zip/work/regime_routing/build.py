# -*- coding: utf-8 -*-
from pathlib import Path
import json,datetime,math
import pandas as pd,numpy as np
R=Path.cwd();O=R/'outputs/regime_routing';W=R/'work/regime_routing'
plan={'registeredAt':datetime.datetime.now().astimezone().isoformat(),'question':'Can prior-known regimes distinguish high and low forward price hit rates and support different portfolio policies?','state':'6cells: priorclose>MA60 and MA120rising20 (existingtrend true/false) x09:45 first3completedbars close above bothopen/cumulativeVWAP,belowboth,otherwise mixed. Equality mixed. No future intradayhighlow. Gap -1%/+1% and volume1.2prior20 sameperiod are diagnosis only, not router inputs.','trainingLabel':'09:45 nextbar open to officialclose return, minus hypothetical roundtrip commission2bp +2transfer+sellstamp +2*5bps slippage hurdle. Positive fraction is cost-hurdle price-hit, NOT executable T1roundtripwin. No minfee since hurdle specifies100knotional. Not simulatedtrade.','mapping':'Per cell n>=30; price-hit>=60% andmean netproxy>0 =>participation P (max(originalD,.5),onlypositiveknown growth); price-hit<=40% andmean netproxy<0 =>defensive C (min(originalD,.5));else R originalD. Fixed thresholds, no search. P never newlyleveragesadded.5. Originalfull can stillmargin150; C caps50cash. No guaranteed success probability; Wilson95intervals separately.','freeze':'F: trainHudian2023-10-09..2024-12-31, frozen2025on, earlier dates baseline. SameHudianmapping transferShenghong withoutrefit. W: everycalendarquarter trainpreceding252completedHudian days,freezequarter,require252; beforeavailabilitybaseline. SameHudianmap transferredShenghong. Allhistorypreviouslyseen, not newblindtest.','evaluate':'2stocks B,D,L,F50,FD,FL,WD,WL; 8period*2slips. Full,older,early,later,Julyon,3annual,continuous quarters & rolling63. Fdisabledolder/early is not validation. W warmup disclosed. Cash andmargin separated, no defaultchange. Newrule onlytargetchanges at originalscheduling>=09:45.','priority':'DD/tails/wholecycleanddaywin; participationandreturn retained, no returnhardfloor. Costhurdlehit nottrade win. No intradayT80%claim. No postresultfilteraddition.','execution':'Unchanged auditedengine,commission1bpmin5,5/10bps,T1,lots,priorbarvolume1%,limits,loan<=.5currentnetonbuy,6%interest,passivedriftallowed. Historicaldata throughOct8,minutequality/financialvintage/eligibility limitations persist.'}
(O/'plan-before-results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
floor=pd.read_csv(R/'outputs/trend_floor/signal-ledger.csv');frames={};datas={};checks=0
for stock,path in [('hudian','work/risk_priority/data.json'),('shenghong','work/shenghong/data.json')]:
 d=json.loads((R/path).read_text());datas[stock]=d;a=np.array(d['bars']);old=floor[floor.stock==stock].set_index('date').reindex(d['dates']);v=a[:,:3,4].sum(1);amount=a[:,:3,5].sum(1);vwap=amount/v;c=a[:,2,3];op=a[:,0,0];pathstate=np.where((c>op)&(c>vwap),'strong',np.where((c<op)&(c<vwap),'weak','mixed'));pastvol=pd.Series(v).rolling(20).mean().shift();volratio=v/pastvol;gap=op/np.array(d['reference'])-1
 f=pd.DataFrame({'date':d['dates'],'stock':stock,'trend':old.trend.to_numpy(),'path':pathstate,'open':op,'known0945':c,'vwap0945':vwap,'volumeRatio':volratio,'gap':gap,'growth':old.growth.to_numpy(),'originalTarget':[x[1] for x in d['signals']['D']],'bar':[x[0] for x in d['signals']['D']],'reference0945':a[:,3,0],'close':d['close']})
 f['state']=np.where(f.trend,'up/','other/')+f.path;f['hurdle']=.0002+2*np.array(d['transfer'])+np.array(d['stamp'])+.001;f['priceReturn']=f.close/f.reference0945-1;f['netProxy']=f.priceReturn-f.hurdle;f['hit']=f.netProxy>0;f['volumeGroup']=np.where(f.volumeRatio.isna(),'unknown',np.where(f.volumeRatio>=1.2,'high','normal'));f['gapGroup']=np.where(f.gap<=-.01,'low',np.where(f.gap>=.01,'high','flat'));frames[stock]=f
 for i in range(len(f)):
  prefix=d['bars'][i][:3];vw=sum(b[5] for b in prefix)/sum(b[4] for b in prefix);cl=prefix[-1][3];o=prefix[0][0];ps='strong' if cl>o and cl>vw else 'weak' if cl<o and cl<vw else 'mixed';assert ps==f.iloc[i].path;assert f.iloc[i].bar>=3;checks+=1
 f.to_csv(O/(stock+'-features.csv'),index=False)
states=[x+'/'+y for x in ['up','other'] for y in ['strong','weak','mixed']]
def wilson(k,n):
 if not n:return (None,None)
 p=k/n;z=1.96;center=(p+z*z/(2*n))/(1+z*z/n);rad=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n);return center-rad,center+rad
maps=[]
def fit(f,kind,validFrom,validThrough):
 out={}
 for state in states:
  v=f[f.state==state];n=len(v);rate=float(v.hit.mean()) if n else None;mean=float(v.netProxy.mean()) if n else None;mode='P' if n>=30 and rate>=.6 and mean>0 else 'C' if n>=30 and rate<=.4 and mean<0 else 'R';lo,hi=wilson(int(v.hit.sum()),n);out[state]=mode;maps.append({'kind':kind,'state':state,'trainingStart':f.date.iloc[0],'trainingEnd':f.date.iloc[-1],'validFrom':validFrom,'validThrough':validThrough,'days':n,'hits':int(v.hit.sum()),'hitRate':rate,'meanNetProxy':mean,'wilsonLow':lo,'wilsonHigh':hi,'mode':mode});assert f.date.iloc[-1]<validFrom
 return out
h=frames['hudian'];frozen=fit(h[(h.date>='2023-10-09')&(h.date<'2025-01-01')],'F','2025-01-01','2026-10-08');quarter=h.date.map(lambda x:x[:4]+'Q'+str((int(x[5:7])-1)//3+1));rolling={}
for q in quarter.unique():
 indices=h.index[quarter==q];first=int(indices[0]);last=int(indices[-1]);rolling[q]=fit(h.iloc[first-252:first],'W',h.iloc[first].date,h.iloc[last].date) if first>=252 else {s:'R' for s in states}
plans={};assignment=[]
for stock,f in frames.items():
 plans[stock]={}
 for kind in ['F','W']:
  arr=[]
  for i,row in f.iterrows():
   q=row.date[:4]+'Q'+str((int(row.date[5:7])-1)//3+1);mode=frozen[row.state] if kind=='F' and row.date>='2025-01-01' else rolling[q][row.state] if kind=='W' else 'R';target=row.originalTarget
   if mode=='P' and row.growth>0:target=max(target,.5)
   if mode=='C':target=min(target,.5)
   arr.append([int(row.bar),float(target)]);assignment.append({'stock':stock,'kind':kind,'date':row.date,'state':row.state,'mode':mode,'originalTarget':row.originalTarget,'target':target,'changed':target!=row.originalTarget})
  plans[stock][kind]=arr
(W/'plans.json').write_text(json.dumps(plans,separators=(',',':')));pd.DataFrame(maps).to_csv(O/'training-maps.csv',index=False);pd.DataFrame(assignment).to_csv(O/'assignments.csv',index=False)
# All cells/factors, time partitions reported without choosing a winner.
summary=[]
for stock,f in frames.items():
 for period,a,z in [('train','2023-10-09','2024-12-31'),('validation','2025-01-01','2026-06-30'),('julyOn','2026-07-01','2026-10-08'),('older','2020-01-02','2023-09-28')]:
  sel=f[(f.date>=a)&(f.date<=z)]
  for factor in ['state','gapGroup','volumeGroup']:
   for key,v in sel.groupby(factor):
    lo,hi=wilson(int(v.hit.sum()),len(v));summary.append({'stock':stock,'period':period,'factor':factor,'group':key,'days':len(v),'hits':int(v.hit.sum()),'hitRate':float(v.hit.mean()),'meanNetProxy':float(v.netProxy.mean()),'worst5pctMean':float(v.netProxy.nsmallest(max(1,math.ceil(len(v)*.05))).mean()),'wilsonLow':lo,'wilsonHigh':hi})
pd.DataFrame(summary).to_csv(O/'conditional-rates.csv',index=False)
a={'priorOnlyPricePrefixChecks':checks,'trainingMaps':len(maps),'strictTrainEndBeforeUse':True,'frozenHudianMap':frozen,'walkModeCounts':pd.Series([x['mode'] for x in maps if x['kind']=='W']).value_counts().to_dict(),'changedDates':pd.DataFrame(assignment).groupby(['stock','kind']).changed.sum().to_dict()};a['changedDates']={str(k):int(v) for k,v in a['changedDates'].items()};(O/'signal-audit.json').write_text(json.dumps(a,indent=2));print(json.dumps(a))
