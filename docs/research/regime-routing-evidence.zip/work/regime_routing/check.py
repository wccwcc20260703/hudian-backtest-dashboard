# -*- coding: utf-8 -*-
from pathlib import Path
import pandas as pd,json,numpy as np
O=Path('outputs/regime_routing');maps=pd.read_csv(O/'training-maps.csv');assign=pd.read_csv(O/'assignments.csv');plans=json.load(open('work/regime_routing/plans.json'));h=pd.read_csv(O/'hudian-features.csv');checks=0
for x in maps.itertuples():
 train=h[(h.date>=x.trainingStart)&(h.date<=x.trainingEnd)];assert train.date.max()<x.validFrom
 if x.kind=='W':assert len(train)==252
 else:assert train.date.min()=='2023-10-09' and train.date.max()=='2024-12-31'
 v=train[train.state==x.state];assert len(v)==x.days and int(v.hit.sum())==x.hits
 mode='P' if len(v)>=30 and v.hit.mean()>=.6 and v.netProxy.mean()>0 else 'C' if len(v)>=30 and v.hit.mean()<=.4 and v.netProxy.mean()<0 else 'R';assert mode==x.mode;checks+=1
for stock,path in [('hudian','work/risk_priority/data.json'),('shenghong','work/shenghong/data.json')]:
 d=json.load(open(path));f=pd.read_csv(O/(stock+'-features.csv'));assert list(f.date)==d['dates']
 for kind in ['F','W']:
  for i,row in f.iterrows():
   m=maps[(maps.kind==kind)&(maps.validFrom<=row.date)&(maps.validThrough>=row.date)&(maps.state==row.state)]
   assert len(m)<=1;mode=m.iloc[0]['mode'] if len(m) else 'R';target=row.originalTarget
   if mode=='P' and row.growth>0:target=max(target,.5)
   if mode=='C':target=min(target,.5)
   assert plans[stock][kind][i]==[row.bar,target];checks+=1
r=pd.read_json(O/'metrics.json');e=pd.read_json(O/'episodes.json');cycles=pd.read_csv(O/'actual-cycle-by-entry-state.csv')
for stock in ['hudian','shenghong']:
 for name in ['B','D','L','F50','FD','FL','WD','WL']:
  v=e[(e.stock==stock)&(e.name==name)];m=r[(r.stock==stock)&(r.name==name)&(r.period=='full')&(r.slip==.0005)].iloc[0];assert len(v[v.complete])==m.closedEpisodes;assert abs(v.pnl.sum()-m.return_*1e6)<1e-5
 for name in ['D','L']:
  v=cycles[(cycles.stock==stock)&(cycles.name==name)];m=r[(r.stock==stock)&(r.name==name)&(r.period=='full')&(r.slip==.0005)].iloc[0];assert v.closed.sum()==m.closedEpisodes and v.wins.sum()==m.episodeWins
# Separate all-quarter no-map warmup and F pre-freeze inactivity.
assert not assign[(assign.kind=='F')&(assign.date<'2025-01-01')].changed.any()
a=json.load(open(O/'audit.json'));a.update({'independentTrainingAndAssignments':checks,'holdingEpisodeReconciliation':16,'actualCycleGroupsReconciled':4});json.dump(a,open(O/'audit.json','w'),indent=2);print(a)
