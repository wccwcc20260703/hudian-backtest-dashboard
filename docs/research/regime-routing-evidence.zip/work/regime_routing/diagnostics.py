# -*- coding: utf-8 -*-
from pathlib import Path
import pandas as pd,numpy as np,json
O=Path('outputs/regime_routing');episodes=pd.read_json(O/'episodes.json');daily=pd.read_json(O/'daily.json');daily.date=daily.date.dt.strftime('%Y-%m-%d');daily['dayReturn']=daily.groupby(['stock','name']).nav.transform(lambda x:x/x.shift().fillna(1e6)-1);summary=[];tagged=[];follow=[]
maps=pd.read_csv(O/'training-maps.csv');assign=pd.read_csv(O/'assignments.csv')
for stock in ['hudian','shenghong']:
 f=pd.read_csv(O/(stock+'-features.csv'));e=episodes[(episodes.stock==stock)&episodes.name.isin(['D','L'])].merge(f[['date','state']],left_on='start',right_on='date',validate='many_to_one');e=e.merge(daily[daily.stock==stock][['name','date','dayReturn']],on=['name','date'],validate='many_to_one');tagged.append(e)
 for (name,state),v in e.groupby(['name','state']):
  c=v[v.complete];o=v[~v.complete];summary.append({'stock':stock,'name':name,'entryState':state,'closed':len(c),'wins':int((c.return_>0).sum()),'entryDayWins':int((c.dayReturn>0).sum()),'entryDayWinRate':(c.dayReturn>0).mean(),'winRate':(c.return_>0).mean(),'closedMeanReturn':c.return_.mean(),'openCount':len(o),'openMarkedPnl':o.pnl.sum(),'medianHoldingDays':c.days.median()})
 a=assign[(assign.stock==stock)&(assign.kind=='W')];a=a.merge(f[['date','hit','netProxy']],on='date')
 for x in maps[(maps.kind=='W')&(maps['mode']=='P')].itertuples():
  v=a[(a.date>=x.validFrom)&(a.date<=x.validThrough)&(a.state==x.state)];follow.append({'stock':stock,'state':x.state,'from':x.validFrom,'trainN':x.days,'trainHit':x.hitRate,'testN':len(v),'testHits':int(v.hit.sum()),'testHit':v.hit.mean(),'testMean':v.netProxy.mean()})
pd.DataFrame(summary).to_csv(O/'actual-cycle-by-entry-state.csv',index=False);pd.concat(tagged).to_csv(O/'tagged-episodes.csv',index=False);pd.DataFrame(follow).to_csv(O/'high-hit-followup.csv',index=False)
print(pd.DataFrame(summary).query('stock=="hudian"').to_string(index=False))
