# -*- coding: utf-8 -*-
from pathlib import Path
import json,datetime,hashlib,zipfile,html
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path.cwd();O=R/'outputs/regime_routing';repo=R/'work/hudian-backtest-dashboard';rows=json.loads((O/'metrics.json').read_text());audit=json.loads((O/'audit.json').read_text());signal=json.loads((O/'signal-audit.json').read_text());rates=pd.read_csv(O/'conditional-rates.csv');cycles=pd.read_csv(O/'actual-cycle-by-entry-state.csv');maps=pd.read_csv(O/'training-maps.csv');follow=pd.read_csv(O/'high-hit-followup.csv');assign=pd.read_csv(O/'assignments.csv');quarters=pd.read_json(O/'quarters.json')
names={'B':'全仓持有','D':'原现金','L':'原融资默认','F50':'固定50%','FD':'冻结分环境·现金','FL':'冻结分环境·融资','WD':'季度更新分环境·现金','WL':'季度更新分环境·融资'};stocks={'hudian':'沪电','shenghong':'胜宏'};states={a+'/'+b:c+'／'+e for a,c in [('up','满足上行趋势'),('other','未满足上行趋势')] for b,e in [('strong','早盘双上方'),('weak','早盘双下方'),('mixed','早盘混合')]};pct=lambda x:'—' if x is None or pd.isna(x) else f'{x*100:.2f}%';get=lambda stock,name,period='full',slip=.0005:next(x for x in rows if (x['stock'],x['name'],x['period'],x['slip'])==(stock,name,period,slip))
for name in ['metrics','daily','episodes','quarters']:pd.read_json(O/(name+'.json')).to_csv(O/(name+'.csv'),index=False)
fig,axs=plt.subplots(1,2,figsize=(12,5.8),sharey=True);keys=list(states)
for ax,stock in zip(axs,stocks):
 x=cycles[(cycles.stock==stock)&(cycles.name=='L')].set_index('entryState').reindex(keys);y=np.arange(6);ax.barh(y-.17,x.entryDayWinRate*100,.32,label='Entry day profit',color='#168a92');ax.barh(y+.17,x.winRate*100,.32,label='Completed cycle profit',color='#bd7e36')
 for j,row in enumerate(x.itertuples()):
  ax.text(row.entryDayWinRate*100+.8,j-.17,f'{row.entryDayWins}/{row.closed}',va='center',fontsize=8);ax.text(row.winRate*100+.8,j+.17,f'{row.wins}/{row.closed}',va='center',fontsize=8)
 ax.set_yticks(y);ax.set_yticklabels(keys);ax.invert_yaxis();ax.set_xlim(0,115);ax.set_title(stock.title()+' original margin');ax.set_xlabel('Profit frequency %');ax.grid(axis='x',alpha=.15);ax.legend(loc='upper center',bbox_to_anchor=(.5,-.13),ncol=2,fontsize=8)
fig.suptitle('Same completed episodes: entry-day result vs final multi-day result');fig.tight_layout(rect=[0,.06,1,.95]);fig.savefig(O/'comparison.svg');fig.savefig(O/'comparison.png',dpi=140);plt.close(fig)
def table(h,rs):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(v))+'</th>' for v in h)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in rs)+'</tbody></table></div>'
def metrics(rs):return table(['股票／方案','净收益','最大回撤¹','平均仓位','完整周期胜率','盈利日／全部日','最差5%日均收益'],[[stocks[x['stock']]+'／'+names[x['name']],pct(x['return_']),pct(-x['mdd5']),pct(x['exposure']),f"{x['episodeWins']}/{x['closedEpisodes']}={pct(x['episodeWinRate'])}" if x['closedEpisodes'] else '无已结束周期',f"{x['winningDays']}/{x['days']}={pct(x['winningDayFraction'])}",pct(x['worst5pctDayMean'])] for x in rs])
body='''<a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a><h1>按环境切换策略：先区分日内胜率与跨日胜率</h1><p class="muted">6类事前环境 · 冻结与季度更新两种检验 · 256组完整账户 · 不改默认</p>
<section><h2>本轮结论：分环境减险有价值，持仓期限不能混用</h2><p>按用户提出的方向，本轮先定义可当时识别的环境，再从此前数据决定保留基础仓位、沿用原反转策略或限制仓位。季度更新方案在沪电和胜宏三年中都降低了回撤；但完整持仓周期胜率没有同步提高，更早沪电融资回撤仍接近70%，尚不具备稳定高胜率的证据。</p><p><strong>最重要的新发现：</strong>沪电“未满足上行趋势、09:45低于开盘价和分时均价”环境下，原融资策略的14个已完成持仓周期，建仓当日仅4次盈利，最终却有13次盈利，持仓中位数5天。不能因为日内表现弱，就直接否定跨日反转；也不能把13/14称作日内做T成功率。样本小、历史已见，92.86%不是未来概率。</p></section>
<section><h2>环境定义：全部在09:45前可知</h2><p>趋势轴：前日收盘高于60日均线，且前日120日均线高于20个交易日前，标记“满足上行趋势”；其余为“未满足”，后者包括震荡，不能直接等同于下行趋势。该条件复用已有研究。</p><p>早盘轴：只使用09:30至09:45三根已完成5分钟K线。09:45价格同时高于开盘价和累计成交均价为“双上方”；同时低于两者为“双下方”；其余为“混合”。成交均价＝前三根成交金额之和÷成交量之和。两轴组成6类，不使用当日未来最高、最低或收盘。</p><p>另把跳空分为低开至少1%、中间、高开至少1%；早15分钟量除以前20交易日同期平均量，1.2倍分为放量／普通。这两项只做并列诊断，没有在结果出来后追加到切换条件中。</p></section>
<section><h2>实际持仓周期：同一环境，期限不同，结论可能相反</h2><p>以下直接统计原账户的已完成持仓周期，按建仓当天09:45环境分组。建仓当日盈利与最终盈利使用完全相同的一组周期，账户收益已计费用及融资利息；期中可能经历其他环境，不能把最终结果全归因于入场状态。</p>'''
body+=table(['股票／账户','入场环境','同组建仓日盈利','完整周期盈利','持仓中位天数','未结束周期／市值损益'],[[stocks[x.stock]+'／'+names[x.name],states[x.entryState],f'{x.entryDayWins}/{x.closed}={pct(x.entryDayWinRate)}',f'{x.wins}/{x.closed}={pct(x.winRate)}',f'{x.medianHoldingDays:g}',f'{x.openCount} / {x.openMarkedPnl:,.0f}元'] for x in cycles.itertuples()])
body+='''<img src="regime-routing-chart.svg" alt="同组持仓周期的建仓日盈利比例与最终盈利比例对照"><p>只统计已结束周期不能忽略未结束亏损：上表单列，全部按市值纳入账户净值和回撤。其他环境的低比例也要保留，例如沪电原融资“满足上行趋势／早盘双下方”完整周期仅16/27盈利，另有一个未结束周期；没有只展示13/14的高胜率小组。</p></section>
<section><h2>用于初筛的价格命中率：与实际交易分开</h2><p>训练指标是09:45之后首根K线开盘至日收盘涨幅，扣除示意往返成本门槛后是否为正。门槛为双边佣金、双边过户费、卖出印花税及单边5基点滑点，按10万元订单估算，佣金高于最低5元。它没有模拟T+1库存、可成交量或实际成交价，<strong>只是价格代理指标，不是完整做T胜率</strong>。10基点账户压力测试仍使用原5基点训练映射，不重选规则。</p><p>真实T+1及成交限制在后面的完整账户回测执行。价格代理与实际跨日周期的期限、参与日期不同，本轮也正是在核验二者能否衔接。</p>'''
body+=table(['沪电环境','2023-10至2024年训练命中','2025至2026年6月命中','2026年7月后命中'],[[states[key]]+[f"{int(v.iloc[0].hits)}/{int(v.iloc[0].days)}={pct(v.iloc[0].hitRate)}" for v in [rates[(rates.stock=='hudian')&(rates.factor=='state')&(rates.group==key)&(rates.period==p)] for p in ['train','validation','julyOn']]] for key in keys])
low=rates[(rates.factor=='state')&(rates.group=='other/weak')]
body+=table(['股票／时间段','命中数／样本','命中率','Wilson95%区间¹','平均示意扣费后涨幅'],[[stocks[x.stock]+'／'+x.period,f'{x.hits}/{x.days}',pct(x.hitRate),pct(x.wilsonLow)+'～'+pct(x.wilsonHigh),pct(x.meanNetProxy)] for x in low.itertuples()])
body+='''<p>沪电该低命中环境在训练、后续段及更早历史均约36%～37%；但胜宏2025年至2026年6月达到14/24＝58.33%，说明同业也可能有不同反应。¹ Wilson区间仅展示有限样本的不确定性，未校正时间相关性和多重比较，不能视作严格未来概率保证。训练43天的区间仍覆盖50%。</p></section>
<section><h2>高命中小组有没有延续？</h2>'''
body+=table(['股票','环境','下一季度开始','此前样本／命中率','下一季度命中／样本','下一季度平均示意扣费涨幅'],[[stocks[x['stock']],states[x['state']],x['from'],f"{x['trainN']} / {pct(x['trainHit'])}",f"{x['testHits']}/{x['testN']} / {pct(x['testHit'])}",pct(x['testMean'])] for x in follow.to_dict('records')])
body+='''<p>训练期达到约61%的小组，在下一季度可能没有出现，或沪电只有3/8命中；胜宏3/5的样本同样太少。没有找到足以称为稳定80%日内胜率的环境，不能将全历史最高比例直接移作未来策略。</p></section>
<section><h2>怎样把区分因子变成可检验的策略切换</h2><p>每个环境至少30天样本；价格命中率≥60%且平均示意扣费涨幅为正，使用“参与模式”：在已披露利润增长为正时，目标至少50%，新增部分不融资。命中率≤40%且均值为负，使用“防守模式”：原目标上限压至50%，不新增融资。其余或样本不足，沿用原反转目标。原目标0%在防守模式仍为0%，不会凭空建仓。</p><p>F冻结方案：仅用沪电2023-10-09至2024-12-31训练，2025年起固定不变，之前沿用原方案；同一映射直接用于胜宏，不按胜宏结果重新拟合。实际仅“未满足上行趋势／早盘双下方”被分到防守，其他五组沿用原方案。</p><p>W季度更新方案：每季度仅用沪电此前252个完整交易日重新统计，映射冻结一个季度，同样转用于胜宏。2021年4月前不足252天，沿用原方案。23个季度×6组中，105组沿用原策略、31组防守、2组参与。所有参数先登记，没有挑选历史最优季度。</p><p>策略仍在原09:45／10:00执行；09:45条件允许该时点减少目标，但没有自动提前原本10:00的调仓。假设分钟收盘数据可及时获得，真实延迟仍是未验证项。</p></section>
<section><h2>三年完整账户：2023-10-09至2026-10-08</h2>'''
body+=metrics([x for x in rows if x['period']=='full' and x['slip']==.0005])
body+='''<p>¹ 最大回撤按5分钟采样及官方日收盘。各账户100万元独立起步。季度更新融资：沪电回撤25.20%→21.60%，收益1226.51%→946.20%；胜宏回撤48.39%→39.47%，收益300.94%→183.37%。平均仓位也下降，因此目前只能称分环境减险候选，不能全部归因为更精准的择时。</p><p>按当前偏好，收益下降不是自动淘汰理由；但沪电融资完整周期胜率72.55%→71.30%，胜宏60.42%→59.38%，不能声称同时提升了胜率。简单固定50%仍一并列出，保留仓位降低本身的风险对照。</p></section>
<section><h2>冻结后的时间段与7月后表现</h2><p>以下区间独立起步：later为2025-01-01至2026-06-30，julyOn为2026-07-01至数据末日。虽然严格按时间顺序训练，但这些行情此前已被研究过，不是新的盲测。</p>'''
body+=table(['股票','区间','方案','净收益','最大回撤','完整周期胜率'],[[stocks[x['stock']],x['period'],names[x['name']],pct(x['return_']),pct(-x['mdd5']),pct(x['episodeWinRate'])] for x in rows if x['period'] in ['later','julyOn'] and x['slip']==.0005 and x['name'] in ['D','L','FD','FL','WD','WL']])
body+='''<p>冻结规则在沪电7月后反而放大回撤；季度更新映射在2026年7月、10月回到原方案，因此重新起步的julyOn结果与原策略一致，不能宣称当时通过新因子提前躲过大跌。</p></section>
<section><h2>固定年度、更早历史与滑点</h2>'''
annual=[]
for stock in stocks:
 for name in ['FD','FL','WD','WL']:
  for slip in [.0005,.001]:
   n=sum(get(stock,name,'year'+str(i),slip)['mdd5']>get(stock,name[-1],'year'+str(i),slip)['mdd5']+1e-10 for i in [1,2,3]);annual.append([stocks[stock]+'／'+names[name],f'{slip*10000:g}基点',f'{n}/3'])
body+=table(['方案','单边滑点','年度回撤小于原方案'],annual)
body+='''<p>沪电季度更新融资5基点下3/3年度回撤较小，但其中两个年度差异不足0.05个百分点；这是数值改善，不能等同于每年都明显减险。年度起点为每年10月9日，每段独立100万元。</p>'''
body+=metrics([x for x in rows if x['period']=='older' and x['slip']==.0005 and x['name'] in ['D','L','WD','WL']])
body+='''<p>更早沪电融资回撤仍为69.89%、收益−19.16%，是明显未解决的风险。冻结方案在更早区间没有启用，故不拿其与原方案相同的结果冒充通过检验。</p>'''
body+=metrics([x for x in rows if x['period']=='full' and x['slip']==.001 and x['name'] in ['D','L','FD','FL','WD','WL']])
body+='''<p>10基点时，季度更新融资的沪电回撤22.34%、胜宏39.56%，仍低于原方案；胜率变化不统一。原现金保留全仓收益并降回撤25%、财富1.20倍仍作历史对照，本批不宣称达标。</p></section>
<section><h2>连续账户领先、未平仓与尾部</h2>'''
body+=table(['方案','截至6月30日连续收益','7月起连续收益','累计领先全仓','最长落后','63日滚动领先','未结束周期市值损益'],[[stocks[x['stock']]+'／'+names[x['name']],pct(x['preJuly']),pct(x['postJuly']),pct(x['leadFraction']),str(x['longestBehind'])+'日',pct(x['rolling63Lead']),f"{x['openEpisodeMarked']:,.0f}元"] for x in rows if x['period']=='full' and x['slip']==.0005 and x['name'] in ['D','L','FD','FL','WD','WL']])
body+='''<p>上表7月前后承接持仓，复利相乘；与上一表分段独立起步口径不同。所有未平仓已按市值计入账户，不靠延后止损制造完整周期高胜率。完整256组明细另列非平盘日盈利比例、费用利息、周期盈亏比、季度连续结果及63日重叠窗口表现。</p></section>
<section><h2>核验与后续研究重点</h2>'''
body+=f"<p>完成{audit['scenarios']}组完整账户回测；{audit['originalMetricParity']}项基准指标复现；{audit['ledger']}笔账本、{audit['loanChecks']}笔买入额度核验；独立复算{audit['independentTrainingAndAssignments']}项训练与日期分配，16组持仓周期损益和4组实际周期分层汇总与原账户一致。</p>"
body+='''<p>佣金万1、最低5元、日期对应印花税与过户费、T+1、整手、前根5分钟量1%及单笔30万股上限、涨跌停、融资年息6%保持原模型。借款买入后不超过净资产50%，持有期间被动超仓沿用用户规则。策略分红税20%、长期全仓0%的简化假设保留。</p><p>数据截至2026-10-08；10月9日分钟极值与日线差异未解决，未纳入已核验回测。今日休市，没有新增冻结后行情。历史分钟质量、财报修订版本与融资资格限制未解决。反复使用同一历史研究有选择偏差；相关方法风险可参考原作者论文<a href="https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf">The Probability of Backtest Overfitting</a>。本批没有计算PBO，也不能给出策略“不是运气”的概率。</p><p>下一步应把目标拆成日内机会与跨日反转两套结果标签，并仅用训练截止日前已完成的持仓周期估计条件表现；跨越训练截止日的周期不能提前使用最终盈亏。高胜率小组还要检验最大中途亏损、退出时间和盈亏比，再决定仓位。此次实际周期分层是诊断，未据此反向改选本轮映射。</p><p>默认保持不变。<a href="regime-routing-evidence.zip">下载全部分组、训练映射、信号、逐笔账本和复现脚本</a> · <a href="trend-exit.html">上轮：MA20退出条件</a></p></section>'''
style='body{font:16px/1.75 system-ui,sans-serif;background:#f3f6fa;color:#1b304a;margin:0}main{max-width:1260px;margin:32px auto;padding:20px}section{background:white;border:1px solid #dce5ee;border-radius:14px;padding:24px;margin:22px 0}h1{font-size:30px}h2{font-size:22px}a{color:#147f85}.muted{font-size:14px;color:#6b7889}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:14px}th,td{white-space:nowrap;text-align:left;padding:11px;border-bottom:1px solid #e2e9ef}th{background:#f4f7fa}img{width:100%;height:auto}'
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>分环境与持仓期限｜沪电研究</title><style>'+style+'</style></head><body><main>'+body+'</main></body></html>'
(O/'report.html').write_text(page.replace('src="regime-routing-chart.svg"','src="comparison.svg"'));(repo/'docs/research/regime-routing.html').write_text(page);(repo/'docs/research/regime-routing-chart.svg').write_bytes((O/'comparison.svg').read_bytes())
f=repo/'docs/research/archive.html';s=f.read_text();entry='<p><a href="regime-routing.html">分环境切换策略：高低命中因子、季度减险，以及日内与跨日胜率的差异 ↗</a></p>'
if 'href="regime-routing.html"' not in s:f.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+entry))
inputs=['outputs/trend_floor/signal-ledger.csv','outputs/trend_exit/metrics.json','work/risk_priority/data.json','work/shenghong/data.json','work/shenghong/finance.mjs','work/shenghong/benchmark.mjs','work/opening_guard/metrics.mjs','work/hudian-backtest-dashboard/docs/fees.js','work/hudian-backtest-dashboard/docs/attribution.js']
(O/'manifest.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in inputs},indent=2));(O/'README.txt').write_text('Python build.py (pandas/numpy) builds fixed6state features and training-onlyquarterly maps; node work/regime_routing/run.mjs (Node22) replays256accounts; diagnostics.py and check.py reconcile actualcycle grouping. report.py expectspublicationworkspace. SameHudiantrainedmap transfersShenghong, notretuned. Allhistoryseen, no independentforwardclaim.\n')
with zipfile.ZipFile(repo/'docs/research/regime-routing-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in list(O.glob('*'))+list((R/'work/regime_routing').glob('*'))+[R/p for p in inputs]:
  if p.is_file() and p.name not in ['publication.json','deployment.log']:z.write(p,str(p.relative_to(R)))
f=R/'work/research-checkpoint.json';c=json.loads(f.read_text());c['regimeRouting']={'updatedAt':datetime.datetime.now().astimezone().isoformat(),'outputs':'outputs/regime_routing','status':'locally verified, publication pending','rule':'6priortrend x0945price/open/VWAPstates; n30,60%positive-meanfloor50,40%negative-meancap50,elseoriginal. FrozenHudianearlymap2025on andquarter252pastmap, same mapping transfersShenghong. Priceproxylabels notTwin.','finding':'Wmargin Hudianreturn1226.51->946.20/DD25.20->21.60,win74/102->77/108;Shenghong300.94->183.37/DD48.39->39.47,win58/96->57/96. EarlierHmarginDD69.89 stillfails. other/weak Hprices37.21%train35.90%later30.77%July;Svalidation58.33% reversal. Actualsame14Hmarginotherweakcycles entryday4/14,completed13/14median5days: horizonmismatch. High61%traininggroupnextHquarter3/8 only.','audit':audit,'signalAudit':signal,'defaultChanged':False,'newBlindTest':False,'nextQuestion':'Separate intradayprice label versus completedmulti-daytrade label; trainonlyfullyfinishedcycles, pendingunmarked outcomesexcludedfromtrainingbutmarkedaccount. Test preknownstate withcycle MAE/exit horizon, preserve entryday4/14 versus final13/14 finding withoutturningposthoc92.86intoexpectedprobability.'};c['updatedAt']=c['regimeRouting']['updatedAt'];f.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print('report saved')
