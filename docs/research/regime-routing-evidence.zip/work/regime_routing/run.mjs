import fs from 'node:fs';import assert from 'node:assert/strict';import {financeBacktest} from '../shenghong/finance.mjs';import {holdBenchmark} from '../shenghong/benchmark.mjs';import {stats} from '../opening_guard/metrics.mjs';import {attribution} from '../hudian-backtest-dashboard/docs/attribution.js';
const read=p=>JSON.parse(fs.readFileSync(p)),O='outputs/regime_routing/',rows=[],match=[],daily=[],quarters=[],episodes=[],plans=read('work/regime_routing/plans.json');let parity=0,ledger=0,loan=0;
for(const [stock,path] of [['hudian','work/risk_priority/data.json'],['shenghong','work/shenghong/data.json']]){
 const d=read(path),n=d.dates.length,start=d.dates.indexOf('2023-10-09'),idx=s=>{let i=d.dates.findIndex(x=>x>=s);return i<0?n:i},g={D:{all_full:Array(n).fill(1)}},periods={full:[start,n],older:[0,start],early:[start,idx('2025-01-01')],later:[idx('2025-01-01'),idx('2026-07-01')],julyOn:[idx('2026-07-01'),n]};for(let y=0;y<3;y++)periods['year'+(y+1)]=[idx(`${2023+y}-10-09`),idx(`${2024+y}-10-09`)];
 const run=(name,a,z,slip)=>name==='B'?holdBenchmark(d,a,z,{slip}):financeBacktest(name==='F50'?{...d,signals:{D:d.dates.map(()=>[6,.5])}}:['FD','FL','WD','WL'].includes(name)?{...d,signals:{D:plans[stock][name[0]]}}:d,g,a,z,{slip,level:name.endsWith('L')?1.5:1,rate:name.endsWith('L')?.06:0});
 const old=read('outputs/trend_exit/metrics.json');
 function audit(r){let cash=r.capital,shares=0;const rate=r.config?.rate??0;for(let day=r.start;day<r.end;day++){const days=day>r.start?Math.max(0,(Date.parse(d.dates[day])-Date.parse(d.dates[day-1]))/86400000-1):0;cash-=Math.max(0,-cash)*rate/365*days;cash+=shares*d.dividend[day]*(r.model==='B'?1:.8);if(d.bonus[day])shares=Math.round(shares*(1+d.bonus[day]));let av=shares,maxDebt=Math.max(-cash,0);for(const t of r.trades.filter(t=>t[0]===day)){assert.equal(shares,t[12]);assert.equal(av,t[9]);assert(t[3]<=t[11]&&t[3]<=300000);const gross=t[3]*t[4],fee=Math.max(5,gross*.0001)+gross*(d.transfer[day]+(t[2]<0?d.stamp[day]:0));assert(Math.abs(fee-t[5])<1e-6);cash-=t[2]*gross+fee;shares+=t[2]*t[3];if(t[2]<0)av-=t[3];assert(av>=0);assert(Math.abs(cash-t[6])<1e-5);if(t[2]>0){const eq=cash+shares*d.bars[day][t[1]][0];assert(-cash<=(r.config?.level===1.5?.5*eq:0)+1e-6);loan++;}maxDebt=Math.max(maxDebt,-cash);ledger++;}cash-=maxDebt*rate/365;assert(Math.abs(cash+shares*d.close[day]-r.nav[day-r.start])<1e-4);}}
 for(const [period,[a,z]]of Object.entries(periods)){
  for(const slip of [.0005,.001]){
   const results=Object.fromEntries(['B','D','L','F50','FD','FL','WD','WL'].map(name=>[name,run(name,a,z,slip)]));
   for(const [name,r]of Object.entries(results)){const attr=attribution(r,results.B,d.dates.slice(a,z));delete attr.relative;const fattr=attribution(r,results.F50,d.dates.slice(a,z));delete fattr.relative;const s=stats(r);let rolling=0,ct=0;const rv=[r.capital,...r.nav],bv=[results.B.capital,...results.B.nav];for(let i=63;i<rv.length;i++){ct++;rolling+=rv[i]/rv[i-63]>bv[i]/bv[i-63]?1:0}
    rows.push({stock,name,period,slip,...r.metrics,...s,...attr,relativeWealth:r.nav.at(-1)/results.B.nav.at(-1),leadVsF50:fattr.leadFraction,longestBehindF50:fattr.longestBehind,relativeWealthF50:r.nav.at(-1)/results.F50.nav.at(-1),rolling63Lead:ct?rolling/ct:null});
    if(['B','D','L','F50'].includes(name)){const saved=old.find(x=>x.stock===stock&&x.name===name&&x.period===period&&x.slip===slip);for(const k of ['return_','mdd5','exposure']){assert(Math.abs(r.metrics[k]-saved[k])<1e-10);parity++;}}
    if(period==='full'&&['FD','FL','WD','WL'].includes(name)){
     const base=results[name.at(-1)],baseattr=attribution(r,base,d.dates.slice(a,z));let wins=0,ct=0;const cn=[r.capital,...r.nav],bn=[base.capital,...base.nav];for(let i=63;i<cn.length;i++){ct++;wins+=cn[i]/cn[i-63]>bn[i]/bn[i-63]?1:0;}
     Object.assign(rows.at(-1),{comparisonBase:name.at(-1),leadVsComparison:baseattr.leadFraction,longestBehindComparison:baseattr.longestBehind,rolling63VsComparison:wins/ct});
     const buckets={};d.dates.slice(a,z).forEach((date,i)=>{const key=date.slice(0,4)+'Q'+Math.ceil(Number(date.slice(5,7))/3);(buckets[key]??=[]).push(i)});
     for(const [quarter,ix] of Object.entries(buckets)){const first=ix[0],last=ix.at(-1);const calc=rr=>{let peak=first?rr.nav[first-1]:rr.capital,dd=0;for(const i of ix){peak=Math.max(peak,rr.nav[i]);dd=Math.max(dd,1-rr.nav[i]/peak)}return {ret:rr.nav[last]/(first?rr.nav[first-1]:rr.capital)-1,dd}};const v=calc(r),b=calc(base);quarters.push({stock,name,slip,quarter,days:ix.length,start:d.dates[a+first],end:d.dates[a+last],return_:v.ret,comparisonBase:name.at(-1),comparisonReturn:b.ret,dd:v.dd,comparisonDD:b.dd});}
    }
    if(period==='full'&&slip===.0005){
     let initial=null,first=null,prev=r.capital;for(let i=0;i<r.nav.length;i++){
      if(initial===null&&(r.daily[i].shares>0||Math.abs(r.nav[i]-prev)>1e-7)){initial=prev;first=i}
      if(initial!==null&&r.daily[i].shares===0){episodes.push({stock,name,start:d.dates[a+first],end:d.dates[a+i],days:i-first+1,return_:r.nav[i]/initial-1,pnl:r.nav[i]-initial,complete:true});initial=null}
      prev=r.nav[i];
     }if(initial!==null)episodes.push({stock,name,start:d.dates[a+first],end:d.dates[z-1],days:r.nav.length-first,return_:r.nav.at(-1)/initial-1,pnl:r.nav.at(-1)-initial,complete:false});
     audit(r);for(let i=0;i<r.nav.length;i++)daily.push({stock,name,date:d.dates[a+i],nav:r.nav[i],exposure:r.exposure[i]});fs.writeFileSync(O+stock+'-'+name+'-trades.json',JSON.stringify(r.trades));}
   }
  }
 }
}
fs.writeFileSync(O+'metrics.json',JSON.stringify(rows));fs.writeFileSync(O+'episodes.json',JSON.stringify(episodes));fs.writeFileSync(O+'quarters.json',JSON.stringify(quarters));fs.writeFileSync(O+'daily.json',JSON.stringify(daily));fs.writeFileSync(O+'audit.json',JSON.stringify({scenarios:rows.length,originalMetricParity:parity,ledger,loanChecks:loan,defaultChanged:false,forwardEvidence:false},null,2));console.log(JSON.stringify(rows.filter(x=>['full','older'].includes(x.period)&&x.slip===.0005).map(x=>({stock:x.stock,name:x.name,period:x.period,ret:x.return_,dd:x.mdd5,exposure:x.exposure,win:x.episodeWinRate,cycles:x.closedEpisodes,tail:x.worst5pctDayMean})),null,2));
