# -*- coding: utf-8 -*-
import json,numpy as np
from pathlib import Path
r=Path.cwd();d=json.loads((r/'work/band_overlay/data.json').read_text());p=np.load(r/'work/leverage/plans.npz');g={}
for base in ['D','H']:
 s=p[base];d['signals'][base]=[]
 for row in s:
  js=np.flatnonzero(row>=0);assert len(js)==1
  d['signals'][base].append([int(js[0]),float(row[js[0]])])
 g[base]={gate:(p[f'{base}_{gate}_1.5'].max(axis=1)>1).astype(int).tolist() for gate in ['all_full','trend','edge','strong_edge','edge_morning','deep_rsi20']}
web=json.loads((r/'work/hudian-backtest-dashboard/docs/data.json').read_text());wg=json.loads((r/'work/hudian-backtest-dashboard/docs/finance-gates.json').read_text());a=d['dates'].index(web['dates'][0]);n=0
for base in g:
 assert d['signals'][base][a:]==web['signals'][base]
 for gate in g[base]:
  for i in range(a,len(d['dates'])):
   if d['signals'][base][i][1]==1:
    assert bool(g[base][gate][i])==bool(wg[base][gate][i-a]);n+=1
(r/'work/risk_priority/data.json').write_text(json.dumps(d,separators=(',',':')))
(r/'work/risk_priority/gates.json').write_text(json.dumps(g,separators=(',',':')))
(r/'outputs/risk_priority/data-audit.json').write_text(json.dumps({'eligibleGateParity':n,'signalsMatch':True,'through':d['dates'][-1]}))
print(n)
