# -*- coding: utf-8 -*-
import json,html,zipfile,hashlib
from pathlib import Path
from datetime import datetime
r=Path.cwd();out=r/'outputs/risk_priority';repo=r/'work/hudian-backtest-dashboard';rows=json.loads((out/'metrics.json').read_text());p=lambda v:'—' if v is None else f'{v*100:.2f}%'
labels={'D':'D·现金','H':'H·现金','B':'全仓持有','D_all_full_1.5':'当前默认：D 全满仓信号融资150%','D_trend_1.5':'D 趋势条件融资150%','D_trend_1.25':'D 趋势条件融资125%','D_all_full_1.25':'D 全满仓信号融资125%','D_T_gated':'D现金＋强势背景布林T','L_T_gated':'当前融资＋强势背景布林T'}
name=lambda x:labels.get(x,x)
get=lambda n,per='full',s=.0005:next(x for x in rows if x['name']==n and x['period']==per and x['slip']==s)
focus=['D_all_full_1.5','D_trend_1.5','D_trend_1.25','D','D_T_gated','L_T_gated']
def table(rs):
 heads=['方案','收益','最大回撤¹','持仓周期胜率²','周期盈利/总数','盈利日/非平盘日³','最差单日','期末资产/当前默认']
 body=''
 for x in rs:
  vals=[name(x['name']),p(x['return_']),p(-x['mdd5']),p(x['episodeWinRate']),f"{x['episodeWins']}/{x['closedEpisodes']}",p(x['nonflatDayWinRate']),p(x['worstDay']),p(x['terminalWealthVsCurrent'])]
  body+='<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in vals)+'</tr>'
 return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+v+'</th>' for v in heads)+'</tr></thead><tbody>'+body+'</tbody></table></div>'
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>胜率与回撤优先 · 沪电股份研究</title><style>body{margin:0;background:#f4f7fb;color:#18304c;font:16px/1.75 system-ui,sans-serif}main{max-width:1250px;margin:40px auto;padding:0 24px}section{background:white;padding:26px;margin:22px 0;border:1px solid #dde6ef;border-radius:14px}h1{font-size:32px}h2{font-size:22px}a{color:#117f8a}table{border-collapse:collapse;width:100%;white-space:nowrap;font-size:14px}td,th{padding:11px;text-align:right;border-bottom:1px solid #e2e9f0}td:first-child,th:first-child{text-align:left}.scroll{overflow:auto}.note{color:#60738b}.accent{border-top:4px solid #188b90}summary{cursor:pointer;font-weight:600}</style><main><a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a><h1>先看胜率和回撤，再看收益取舍</h1><p>用户新偏好：暂不设收益下降的硬上限，优先胜率与控制回撤。此次按实际佣金复核31个既有方案，合计496组期间/滑点比较；没有新增参数寻优，也没有变更主看板默认。</p>'''
page+='''<section class="accent"><h2>已有值得继续检验的方向</h2><p>趋势条件融资150%：三年五分钟最大回撤25.20% → 19.84%，相对下降21.27%；完整持仓周期胜率72.55% → 75.00%。代价是累计收益1226.51% → 760.94%，期末账户资产较当前默认少35.10%。这是明显取舍，不能称为收益只下降一点。</p><p>这一条件是：上一个已完成交易日的复权收盘价高于60日均线，且120日均线高于20个交易日前；只有D原策略本来要求100%时才提高到150%。不是看到当日上涨就追买，也没有增加新的做T点。</p><p><strong>75%是跨日持仓周期胜率，不是日内做T胜率。</strong>盈利日占非平盘日52.72% → 52.65%，并未同步提升；三个独立年度中周期胜率仅一个年度严格提高，另两个持平。更早历史中该方案仍亏损10.89%、最大回撤63.89%，尚不具备跨环境稳定性的证据。</p>'''+table([get(x) for x in focus])+'''<p class="note">范围2023-10-09至2026-10-08。本金100万元，股票/信用佣金万1，每笔最低5元，单边滑点5基点，印花税及过户费按既有历史数据，融资年息6%为研究假设。T+1、100股买入、前一根5分钟量1%成交上限、涨跌停约束沿用已核验引擎。新增融资买入后欠款不超过当前净资产50%，被动漂移不触发减仓。</p></section>'''
page+='''<section><h2>胜率口径与风险优先标准</h2><p>① 最大回撤使用五分钟收盘市值曲线；不能覆盖每根K线内的全部极值。② 完整持仓周期从空仓开始，到日末再次空仓结束，纳入该周期手续费、融资利息、分红税。部分减仓合并在同一周期，未平仓周期单列，其浮盈亏计入账户净值和回撤，不混入已完成胜率。③ 盈利日率这里剔除平盘日；完整导出同时保留盈利日/全部交易日、亏损和平盘日数量，空仓日不冒充盈利日。</p><p>研究采用风险与胜率多指标比较，暂不设收益硬下限；仍保留净收益、盈亏比、样本数、未平仓风险与参与度，避免通过长期空仓或拖延止损抬高指标。旧“收益不低于持有、回撤降低25%”及财富1.20倍目标保留为历史对照，本次不声称原标准达标。</p><p>指标定义参考 <a href="https://www.fidelity.com/research/backtesting/glossary.html">Fidelity回测指标说明</a>；本页持仓周期分组和五分钟回撤为本模型明确规定的统计口径。已见历史重评不是新盲测，组合筛选及多次检验存在偏差，后续仍需冻结规则后的独立证据。</p></section>'''
for slip in [.0005,.001]:
 page+=f'<section><h2>全期对照 · 单边滑点{slip*10000:g}基点</h2><details><summary>展开全部31个方案（按回撤排序）</summary>'+table(sorted([x for x in rows if x['period']=='full' and x['slip']==slip],key=lambda x:-x['mdd5']))+'</details></section>'
page+='<section><h2>时序、年度和更早历史复核</h2><p>下列各段独立从100万元空仓启动，因此不能直接与全期账户承接持仓的分段收益拼接。导出另含全期承接持仓的7月前后表现、累计与63日滚动领先比例。</p>'
for per,label in [('early','早段：2023-10-09至2024年底'),('later','后段：2025年起至2026年6月底'),('julyOn','2026年7月起'),('year1','固定年度1'),('year2','固定年度2'),('year3','固定年度3'),('older','更早已见历史')]:
 page+='<details><summary>'+label+'</summary>'+table([get(x,per) for x in focus[:4]])+'</details>'
page+='</section><section><h2>本批结论</h2><p>收益下降本身不再是淘汰理由。但强势背景布林T接入融资账户后，回撤25.20% → 25.31%，周期胜率72.55% → 71.57%，因此按新目标仍未改善。现金版回撤仅降低约0.018个百分点，周期胜率也下降，暂不能据此替换默认。</p><p>接下来优先研究亏损周期共同条件、尾部风险及亏损后的退出/恢复条件，在冻结规则后比较胜率、平均盈亏与回撤。用户最新偏好已写入续研检查点与原自动化；尚未选择新的默认执行方案。</p><p>历史验证截止2026-10-08；10月9日分时与日内极值差异尚未核验，不计入本批，也不产生新的实时交易信号。</p><a href="risk-priority-evidence.zip">下载全部结果、固定比较清单与核验记录</a></section></main></html>'
(out/'report.html').write_text(page);(repo/'docs/research/risk-priority.html').write_text(page)
with zipfile.ZipFile(repo/'docs/research/risk-priority-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in out.iterdir():
  if f.suffix in ['.csv','.json']:z.write(f,f.name)
 for f in (r/'work/risk_priority').iterdir():
  if f.suffix in ['.mjs','.py']:z.write(f,'scripts/'+f.name)
archive=repo/'docs/research/archive.html';s=archive.read_text();needle='<h1>研究归档</h1>';assert needle in s;s=s.replace(needle,needle+'<p><a href="risk-priority.html">第二十八批：胜率与回撤优先，31个既有方案按实际费率重评 ↗</a></p>',1);archive.write_text(s)
p=r/'work/research-checkpoint.json';c=json.loads(p.read_text());c['updatedAt']=datetime.now().astimezone().isoformat();c['userRiskPreference']={'priority':['win_rate','drawdown'],'returnSacrificeHardLimit':None,'confirmedByUser':True,'instruction':'暂不设收益下降硬上限，优先看回撤与胜率；不再仅因收益低于原方案或持有而否决。原收益/回撤25%及财富1.20目标只作历史对照，不冒称原标准达标。未完成交易/大亏/空仓必须诚实统计。','defaultChanged':False};c['riskPriority']={'outputs':'outputs/risk_priority','comparisons':496,'configurations':31,'mainCandidate':'D_trend_1.5','fullEpisodeWinRate':.75,'fullMDD':.19844296363518432,'notIntradayWinRate':True,'olderFailsStability':True,'automationUpdated':True,'defaultChanged':False};c['currentQuestion']='按用户胜率与回撤优先偏好，研究亏损周期及尾部风险，收益暂无硬下限';c['next']=['优先解释亏损周期共同条件与尾部亏损，冻结一个退出或过滤改动，再在完整账户中检验；不要继续用最大收益硬门槛否决风险改善。','复用outputs/risk_priority：D趋势150%全期周期胜率75%和回撤19.84%，但更早回撤63.89%、亏损10.89%，并非日内75%或稳定新赢家。布林T融资版仍未改善风险与胜率，不重复筛选已知高胜率窗口。','现金/融资分别，万1最低5元、5/10bp、T+1、成交量与融资买入50%净资产限制。记录完整T往返、持仓周期、盈利日三种胜率及分母，含未完成市值风险。旧达标标准保留历史对照；默认未经用户指定或充分新证据不自动更换。'];p.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
print('Saved risk preference, full evidence and research page')
