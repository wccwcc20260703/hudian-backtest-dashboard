import fs from 'node:fs';import assert from 'node:assert/strict';
import {attribution} from '../hudian-backtest-dashboard/docs/attribution.js';
import {backtest} from '../hudian-backtest-dashboard/docs/engine.js';
import {financeBacktest} from '../hudian-backtest-dashboard/docs/finance-engine.js';
import {experimentalBacktest} from '../hudian-backtest-dashboard/docs/experimental-engine.js';
const read=p=>JSON.parse(fs.readFileSync(p)),d=read('work/risk_priority/data.json'),g=read('work/risk_priority/gates.json'),ctx=read('work/band_overlay/context.json'),out='outputs/risk_priority/';
const idx=x=>{let i=d.dates.findIndex(t=>t>=x);return i<0?d.dates.length:i},a=idx('2023-10-09'),n=d.dates.length;
const periods={full:[a,n],early:[a,idx('2025-01-01')],later:[idx('2025-01-01'),idx('2026-07-01')],julyOn:[idx('2026-07-01'),n],older:[0,a]};for(let y=0;y<3;y++)periods['year'+(y+1)]=[idx(`${2023+y}-10-09`),idx(`${2024+y}-10-09`)];
const configs=[{name:'B',cash:'B'},...['D','H'].map(b=>({name:b,cash:b}))];for(const base of ['D','H'])for(const gate of Object.keys(g[base]))for(const level of [1.25,1.5])configs.push({name:`${base}_${gate}_${level}`,base,gate,level});for(const account of ['D','L'])for(const overlay of ['all','gated'])configs.push({name:`${account}_T_${overlay}`,account,overlay});
fs.writeFileSync(out+'comparison-plan.json',JSON.stringify({purpose:'Re-evaluate existing rules under user win-rate/drawdown priority; no hard terminal wealth floor. No new parameter search or blind-test claim.',configs,periods,fee:.0001,minimum:5,slippage:[.0005,.001],defaultChange:false},null,2));
function stats(r){let previous=r.capital,peak=r.capital,run=0,longest=0,wins=0,losses=0,flat=0;const returns=[];
 // Whole holding episodes run from a flat account to a flat account, measured at day close including interest.
 let epStart=null,priorShares=0,episodeProfit=0;const episodes=[];
 for(let i=0;i<r.nav.length;i++){const eq=r.nav[i],delta=eq-previous,ret=eq/previous-1;returns.push(ret);if(delta>1e-7)wins++;else if(delta < -1e-7)losses++;else flat++;
 if(epStart===null&&(priorShares>0||r.daily[i].shares>0||Math.abs(delta)>1e-7))epStart=previous;
 if(epStart!==null&&r.daily[i].shares===0){episodes.push(eq-epStart);episodeProfit+=eq-epStart;epStart=null;}
 priorShares=r.daily[i].shares;peak=Math.max(peak,eq);run=eq<peak-1e-7?run+1:0;longest=Math.max(longest,run);previous=eq;
 }
 const openProfit=epStart===null?0:r.nav.at(-1)-epStart;assert.ok(Math.abs(episodeProfit+openProfit-(r.nav.at(-1)-r.capital))<1e-5);
 const pos=episodes.filter(x=>x>0),neg=episodes.filter(x=>x<0),sorted=returns.slice().sort((a,b)=>a-b),tail=sorted.slice(0,Math.ceil(sorted.length*.05));
 const done=(r.trips||[]).filter(t=>t.complete),tw=done.filter(t=>t.netCash>0);const tprofit=done.reduce((s,t)=>s+Math.max(t.netCash,0),0),tloss=-done.reduce((s,t)=>s+Math.min(t.netCash,0),0);
 return {days:returns.length,winningDays:wins,losingDays:losses,flatDays:flat,winningDayFraction:wins/returns.length,nonflatDayWinRate:wins/(wins+losses),worstDay:sorted[0],worst5pctDayMean:tail.reduce((s,v)=>s+v,0)/tail.length,longestDailyUnderwater:longest,closedEpisodes:episodes.length,episodeWins:pos.length,episodeWinRate:pos.length/episodes.length,episodeProfitFactor:neg.length?pos.reduce((s,x)=>s+x,0)/-neg.reduce((s,x)=>s+x,0):null,openEpisode:epStart!==null,openEpisodeMarked:openProfit,tEntered:(r.trips||[]).length,tCompleted:done.length,tWinRate:done.length?tw.length/done.length:null,tProfitFactor:tloss?tprofit/tloss:null,tUnfinished:(r.trips||[]).length-done.length};
}
const rows=[];let count=0;
for(const c of configs)for(const [period,[start,end]]of Object.entries(periods))for(const slip of [.0005,.001]){
 const opt={...c,slip,commission:.0001,minCommission:5,driftPolicy:'buy_cap_only'};
 const r=c.cash?backtest(d,c.cash,start,end,opt):c.overlay?experimentalBacktest(d,g,start,end,{...opt,overlayContext:ctx}):financeBacktest(d,g,start,end,opt);
 const benchmark=backtest(d,'B',start,end,{slip});const attr=attribution(r,benchmark,d.dates.slice(start,end));delete attr.relative;let lead=0,total=0;const rv=[r.capital,...r.nav],bv=[benchmark.capital,...benchmark.nav];for(let i=63;i<rv.length;i++){total++;if(rv[i]/rv[i-63]>bv[i]/bv[i-63])lead++;}
 rows.push({name:c.name,period,slip,start:d.dates[start],end:d.dates[end-1],...r.metrics,...stats(r),...attr,rolling63Lead:total?lead/total:null});count++;
}
const full=rows.filter(x=>x.period==='full'&&x.slip===.0005),base=full.find(x=>x.name==='D_all_full_1.5');assert.ok(Math.abs(base.return_-12.265060918741748)<1e-12);assert.ok(Math.abs(base.mdd5+.2520418016155769)<1e-12);
for(const r of rows){const b=rows.find(x=>x.period===r.period&&x.slip===r.slip&&x.name==='D_all_full_1.5');r.terminalWealthVsCurrent=(1+r.return_)/(1+b.return_);r.drawdownReductionVsCurrent=1-Math.abs(r.mdd5/b.mdd5);}
fs.writeFileSync(out+'metrics.json',JSON.stringify(rows));const keys=Object.keys(rows[0]);fs.writeFileSync(out+'metrics.csv',[keys.join(','),...rows.map(r=>keys.map(k=>JSON.stringify(r[k]??'')).join(','))].join('\n'));
fs.writeFileSync(out+'audit.json',JSON.stringify({configurations:configs.length,periods:Object.keys(periods).length,comparisons:count,episodeReconciliations:count,currentDefaultReproduced:true,newBlindTest:false,defaultChanged:false},null,2));
console.log(JSON.stringify(full.sort((a,b)=>b.mdd5-a.mdd5).map(x=>({name:x.name,ret:x.return_,dd:x.mdd5,daywin:x.nonflatDayWinRate,epwin:x.episodeWinRate,episodes:x.closedEpisodes,pf:x.episodeProfitFactor,wealth:x.terminalWealthVsCurrent})),null,2));
