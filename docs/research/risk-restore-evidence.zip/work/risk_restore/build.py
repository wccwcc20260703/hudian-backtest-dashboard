import json,hashlib,datetime
from pathlib import Path
r=Path.cwd();root=r/'work/risk_restore';out=r/'outputs/risk_restore';src=(r/'work/opening_guard/engine.mjs').read_text()
p={'createdAt':datetime.datetime.now().astimezone().isoformat(),'question':'Following actual prior-session risk sales, can earlier next-session09:45 re-entry improve risk and participation over waiting for original10:00 plan?','fixedRule':'Prior session had actual nonforced risk-related selling; today original D target100% scheduled10:00; at09:45 both last two completed5m closes >=today open AND latestclose>previousclose; no current09:45 risk trigger. Try BUY ONLY at09:45 up to original target; keep original10:00 instruction. No high/low inputs, no new volume filter, no parameter grid.','antecedent':'Batch31 price-only risk mask unchanged, including VWAP and20session warmup; still unverified source volume/extrema caveats. Cashriskcap50%, financingriskcap100%.','accounts':['D cash','L all_full150','T trend150'],'costs':'Actualcommission1bp min5;5/10bp adverse slip,100lot,1%previousbarvolume,price limits,T+1,6%margininterest,buydebt<=50%netequity; passiveleveragedriftunchanged.','comparison':['original off','price-risk only','price-risk + restore','quarterrolling prior252sessions choose risk vs risk+restore by DD then cyclewin withpositive return and>=5actualrestoreddays, otherwise risk only'], 'periods':['full2023-10-09..2026-10-08','earlythrough2024','later2025..2026Jun','Julyon','3fixedannual','older2020..2023Oct'],'selection':'Risk-first nohardreturnfloor. Alreadyseenhistory, notnewblindtest. Frozenfutureevidence absent. Do notmodifydefault onresults.','previousFailures':['outputs/reentry/plan_before_results.json','outputs/tdx_rebuy/plan_before_results.json','outputs/volume_ablation/carry-summary.json'],'benchmark':'continuous-v2','engineBeforeSHA':hashlib.sha256(src.encode()).hexdigest()}
(out/'plan-before-results.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
src=src.replace('riskMask=[],riskCap=1','riskMask=[],riskCap=1,restoreMask=[],restore=false')
src=src.replace('let mdd5=0,mdd=0,dailyPeak=capital;', 'let mdd5=0,mdd=0,dailyPeak=capital,previousRiskSale=false;const restoreDecisions=[];')
src=src.replace('dayCap=Infinity,reduceOnly=false;', 'dayCap=Infinity,reduceOnly=false,recoveryPending=false,dayRiskSale=false;')
src=src.replace('forced=false;reduceOnly=false;}', 'forced=false;reduceOnly=false;recoveryPending=false;}')
needle='    if(loan>0&&(ratio<maintenance'
i=src.index(needle)
src=src[:i]+"    if(j===3&&restore&&previousRiskSale&&restoreMask[d]&&!riskMask[d]&&plan[0]===6&&orig[1]===1){target=plan[1];pending=true;deadline=Math.min(j+4,46);reduceOnly=false;forced=false;recoveryPending=true;restoreDecisions.push(d);}\n"+src[i:]
src=src.replace('forced=true;reduceOnly=true;}', 'forced=true;reduceOnly=true;recoveryPending=false;}')
src=src.replace('if(side<0){if(qty>available)', 'if(side<0&&recoveryPending)qty=0;\n      if(side<0){if(qty>available)')
src=src.replace('if(qty>0){\n       const gross=', 'if(qty>0){\n       if(side<0&&!forced&&Number.isFinite(dayCap)&&(reduceOnly||plan[1]>dayCap))dayRiskSale=true;\n       const gross=')
src=src.replace('sig>dayCap?2:0)]);', 'sig>dayCap?2:0),recoveryPending?1:0]);')
src=src.replace('if(dayBorrow>0)borrowDays++;', 'if(dayBorrow>0)borrowDays++;previousRiskSale=dayRiskSale;')
src=src.replace('return {commission,minCommission,', 'return {restoreDecisions,commission,minCommission,')
assert 'recoveryPending?1:0' in src and 'previousRiskSale=dayRiskSale' in src
(root/'engine.mjs').write_text(src)
print('Fixed rule registered; isolated engine written')
