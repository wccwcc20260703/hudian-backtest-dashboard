# -*- coding: utf-8 -*-
import json,html,hashlib,zipfile,datetime,math
from pathlib import Path
r=Path.cwd();out=r/'outputs/risk_restore';repo=r/'work/hudian-backtest-dashboard';read=lambda n:json.loads((out/n).read_text());rows=read('metrics.json');pairs=read('paired.json');rolling=read('rolling.json');audit=read('audit.json')
get=lambda name,mode,p='full',s=.0005:next(x for x in rows if (x['name'],x['mode'],x['period'],x['slip'])==(name,mode,p,s))
# Independent prefix-rule reproduction and exact parity against the previous batch.
data=json.loads((r/'work/risk_priority/data.json').read_text());events=read('events.json')
for i,b in enumerate(data['bars']):
 vol=0;amt=0;vwap=[]
 for bar in b[:3]:vol+=bar[4];amt+=bar[5];vwap.append(amt/vol)
 risk=i>=20 and sum(x[4] for z in data['bars'][i-20:i] for x in z[:3])>0 and b[2][3]<=b[0][0]*.99 and b[1][3]<vwap[1]*.999 and b[2][3]<vwap[2]*.999
 restore=b[1][3]>=b[0][0] and b[2][3]>=b[0][0] and b[2][3]>b[1][3]
 assert events[i]['risk']==risk and events[i]['restoreConfirmation']==restore
old=json.loads((r/'outputs/volume_ablation/metrics.json').read_text());parity=0
for row in rows:
 if row['mode'] not in ['off','risk']:continue
 prev=next(x for x in old if (x['name'],x['mode'],x['period'],x['slip'])==(row['name'],'guard' if row['mode']=='risk' else 'off',row['period'],row['slip']))
 for key in ['return_','mdd5','episodeWins','closedEpisodes']:assert abs(row[key]-prev[key])<1e-12;parity+=1
summary={}
for name in ['D','L','T']:
 p=[x for x in pairs if x['name']==name and x['fills']];wins=sum(x['effectClose']>1e-9 for x in p);n=len(p);ph=wins/n;z=1.96;den=1+z*z/n;mid=(ph+z*z/(2*n))/den;half=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
 summary[name]={'pairedDays':n,'betterSameDay':wins,'worseSameDay':sum(x['effectClose']< -1e-9 for x in p),'wilson95':[mid-half,mid+half],'note':'Descriptive same-start counterfactual outcomes, not T win rate; independence not established; tiny sample','annualDDImprovesVsRisk':sum(abs(get(name,'restore','year'+str(y))['mdd5'])<abs(get(name,'risk','year'+str(y))['mdd5']) for y in [1,2,3]),'annualWinImprovesVsRisk':sum(get(name,'restore','year'+str(y))['episodeWinRate']>get(name,'risk','year'+str(y))['episodeWinRate'] for y in [1,2,3])}
audit.update(independentPythonPrefixChecks=len(events),previousBatchMetricParity=parity,summary=summary,rollingEnabled=sum(x['enable'] for x in rolling));(out/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
files=['work/risk_priority/data.json','work/risk_priority/gates.json','work/opening_guard/engine.mjs','work/opening_guard/metrics.mjs','work/hudian-backtest-dashboard/docs/engine.js','work/hudian-backtest-dashboard/docs/benchmark.js','work/hudian-backtest-dashboard/docs/fees.js','work/hudian-backtest-dashboard/docs/attribution.js']
manifest={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files};(out/'input-manifest.json').write_text(json.dumps(manifest,indent=2))
(out/'source-status.json').write_text(json.dumps({'checkedAt':datetime.datetime.now().astimezone().isoformat(),'historicalThrough':'2026-10-08','newDataIngested':False,'priorVerifiedSources':'outputs/benchmark_repair/cross-source.json and daily-crosscheck.json','minuteIssue':'5m high/low mismatch unresolved; similar results from two interfaces do not prove independent sources. Risk antecedent VWAP and volume-based capacity remain provisional. No exact tick or latency validation.','adjacentBars':{'identicalOpenToPreviousClose':21717,'total':34169,'conclusion':'Not all bars copy prior close; cannot label as blanket forward-fill bug.'},'marketCalendar':'2026-10-10 closed; prior official verification reused','financialStatus':'Previously verified2026H1; no new financial information inserted; source vintage incomplete'},ensure_ascii=False,indent=2))
pct=lambda x:'—' if x is None else f'{x*100:.2f}%'
def table(head,body):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>' for row in body)+'</tbody></table></div>'
names={'D':'D 现金','L':'L 全满仓融资','T':'趋势融资对照'};modes={'off':'原方案','risk':'仅提前减仓','restore':'减仓＋次日恢复','rolling':'滚动择用恢复'}
def mainTable(rs):return table(['账户／方案','收益','最大回撤¹','持仓周期盈利²','盈利日³','最差5%日均跌幅','提前买回天数'],[[names[x['name']]+' / '+modes[x['mode']],pct(x['return_']),pct(-x['mdd5']),f"{x['episodeWins']}/{x['closedEpisodes']} = {pct(x['episodeWinRate'])}",f"{x['winningDays']}/{x['days']} = {pct(x['winningDayFraction'])}",pct(-x['worst5pctDayMean']),x['restoreFillDays']] for x in rs])
body='''<a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a><h1>减仓后，次日提前15分钟买回能改善吗？</h1><p class="sub">固定规则检验 · 数据截至2026-10-08 · 本批未更换默认策略</p><section><h2>结论：小幅改善，证据不足以接入</h2><p>现金方案在三年整段里回撤略降、持仓周期胜率略升，但实际提前买回仅7天；融资方案只有6天。更高滑点下现金胜率改善消失，更早历史也没有改善回撤。24次账户／季度训练中，没有一次满足预设的启用条件。</p>
<p><strong>没有得到80%日内做T胜率。</strong>本实验是跨日恢复仓位；原持仓周期统计、账户盈利日和单日配对改善率分别列示，不能混称为做T成功率。</p></section>
<section><h2>为什么检验这个条件</h2><p>上一批发现：提前减仓可能躲开当天部分跌幅，却错过次日反弹。本次只改变买回时点，不重新筛选历史赢家：前一天必须有因风险规则而实际成交的减仓；今天原D方案仍安排10:00满仓；到09:45，前两个已完成5分钟收盘都不低于今日开盘、最新收盘高于前一个，且今天没有再次触发风险规则，才提前尝试买回。</p>
<p>现金恢复到原100%目标；融资是否到150%仍按原门槛。只买不卖，原10:00指令保留。若只发出风险提示而没有实际卖出，不触发恢复；原策略退出、新风险或维持担保风险不会被恢复指令覆盖。融资每笔买入后的欠款不超过净资产50%，被动超仓规则不变。</p>
<p>风险前提沿用上一批：09:45跌离开盘至少1%，最近两根完成收盘低于各自累计成交均价0.1%，无需额外放量；现金当日上限50%、融资100%。保留20日数据准备期。恢复规则本身不依赖最高最低价、不加量能门槛。没有参数网格。</p></section>
<section><h2>三年完整账户：2023-10-09至2026-10-08</h2><p>本金100万元；股票佣金万1、每笔最低5元，另计当日适用印花税及过户费；单边5基点滑点、100股整数手、前一根5分钟量的1%容量、涨跌停和T+1；融资年息6%。</p>'''
body+=mainTable([x for x in rows if x['period']=='full' and x['slip']==.0005 and x['mode']!='rolling'])
body+='''<p class="sub">¹ 五分钟收盘采样的净值回撤，并非逐笔可见的真正盘中最大回撤。² 从空仓到再次空仓的完整持仓周期，计费用、利息；并非每个买点胜率。³ 盈利日÷全部交易日，空仓和平盘不算盈利。未平仓计入账户净值和回撤，不计入已结束周期分母；完整T往返本实验未定义，因此没有T胜率。</p></section>
<section><h2>滑点加倍到单边10基点</h2>'''
body+=mainTable([x for x in rows if x['period']=='full' and x['slip']==.001 and x['mode'] in ['risk','restore']])
body+='<p>现金持仓周期胜率从65.77%降至64.86%。这说明5基点时看到的胜率提升不稳健；不能用三年整段的单一数字决定接入。</p></section><section><h2>按年度重新起算，以及更早历史</h2><p>以下每个区间独立以100万元开始；这些收益不能拼接为连续账户。三段固定年度分别从2023、2024、2025年10月9日开始，到下一年度10月9日前的最后可用交易日。</p>'
body+=table(['区间','账户','减仓回撤→恢复回撤','减仓周期胜率→恢复','恢复收益','恢复天数'],[[p,names[name],pct(-get(name,'risk',p)['mdd5'])+' → '+pct(-get(name,'restore',p)['mdd5']),pct(get(name,'risk',p)['episodeWinRate'])+' → '+pct(get(name,'restore',p)['episodeWinRate']),pct(get(name,'restore',p)['return_']),get(name,'restore',p)['restoreFillDays']] for p in ['year1','year2','year3','older'] for name in names])
body+='<p>更早历史为2020年至2023-10-08可用数据。现金恢复后最大回撤57.47%，融资71.62%，都略差于只减仓。现金仅1/3年度回撤改善，融资2/3，但融资年度持仓周期胜率没有一段严格提高。历史收益保留及财富1.20倍仍仅作旧目标对照，本轮没有以它们淘汰风险改善候选，也没有宣称旧目标达标。</p></section><section><h2>7月前后与持续领先</h2><p>下面从三年同一起点连续承接持仓，7月1日不清空账户。全仓对照采用修复后的持续建仓基准；基准现金分红、税务与容量假设仍有局限。</p>'
body+=table(['账户／方案','截至2026-06-30','7月起段内收益','累计领先交易日','最长连续落后','63日滚动领先'],[[names[x['name']]+' / '+modes[x['mode']],pct(x['preJuly']),pct(x['postJuly']),pct(x['leadFraction']),str(x['longestBehind'])+'天',pct(x['rolling63Lead'])] for x in rows if x['period']=='full' and x['slip']==.0005 and x['mode'] in ['off','risk','restore']])
body+='</section><section><h2>每个提前恢复日：有赚到时点，也有追高</h2><p>每行从“仅减仓”账户的相同此前状态出发，只启用这一天的提前买回；差额以当天开始前净值为分母。不能相加当作组合收益，也不是当日买卖往返胜率。</p>'
body+=table(['账户','日期','模拟买入股数','首笔价','当日账户改善','次日收盘改善','首笔后最差采样收盘相对首笔'],[[names[x['name']],x['date'],x['quantity'],f"{x['firstFill']:.2f}",pct(x['effectClose']),pct(x['nextCloseEffect']),pct(x['sampledWorstCloseAfterFill'])] for x in pairs])
body+='<p>现金4/7天优于等待10:00（57.14%），融资3/6天（50%），趋势融资仅1天，均不足以估计稳定成功率。独立二项假设下前两项Wilson 95%区间约25%–84%、19%–81%；这些日期来自同一股票，独立性也未经证明，区间仅提示小样本不确定性。</p><p><strong>2024-07-31：</strong>融资提前买回首笔33.31元，后续33.03、32.90元；等待方案10:00起为32.77、32.38元。当日收盘虽上涨至33.48元，提前操作仍令账户少1.76个百分点。“买完收盘上涨”不等于优于原计划。</p><p><strong>2025-06-27：</strong>提前首笔42.14元确实低于原计划首笔42.32元，但第二笔30,800股成交在42.67元，最终整体账户少0.13个百分点。必须核算全部分笔、数量、费用和融资，不能只挑第一笔证明时点好。</p></section><section><h2>时序检验和冻结证据</h2><p>2025年起每季度，仅用此前252个交易日比较“仅减仓”和“提前恢复”。预设启用条件：至少5个实际恢复日、回撤下降、持仓周期胜率不降且净收益为正。24个账户／季度全部未通过，训练样本最多4天，因此滚动账户完全等同“仅减仓”，没有实际启用恢复规则。不能事后降低门槛制造通过。</p><p>2024年底前、2025年至2026年6月、7月后的固定阶段以及5/10基点全部150组结果已保存。所有这些行情都已见过，只是时间顺序复核，不是新盲测。冻结后独立交易日证据仍为零。</p></section><section><h2>核验与限制</h2>'
body+=f"<p>完成{audit['scenarios']}组计算；{audit['parity']:,}个序列值与原引擎一致，{parity}个上一批指标复现；{audit['ledger']:,}笔逐笔账本核对、{audit['loanChecks']:,}次买入额度检查；{len(events)}天由Python独立复核信号，另有{len(audit['synthetic'])}个执行边界测试。</p>"
body+='''<p>分钟最高最低价与日线不一致尚未解决；本次新条件虽不直接用极值，但前提风险规则仍用分时均价，成交容量也依赖分钟量。两接口一致不证明独立来源正确；09:45收盘确认后按下一根开盘加滑点成交仍是模拟假设，未经真实延迟检验。融资券商资格、历史额度、财报版本与分红税务仍有未决事项。</p>
<p>10月10日休市，无新交易报告；历史仍截至10月8日。没有补造10月9日成交，没有新增可执行信号。本页不修改默认方案。</p>
<p><strong>下一步方向：</strong>先解决数据质量和执行可复核性；若继续研究恢复仓位，应考察早盘反弹后的持续性和分批成交成本，不把“站回开盘价”直接等同于风险解除。本批固定规则列入证据不足记录，避免重复筛选。</p>
<p><a href="risk-restore-evidence.zip">下载全部结果、逐日账本及研究脚本</a> · <a href="volume-ablation.html">上一批减仓代价</a> · <a href="benchmark-repair.html">数据与基准整改</a></p></section>'''
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>次日恢复仓位｜沪电股份研究</title><style>body{font:16px/1.75 system-ui,sans-serif;color:#1b304a;background:#f3f6fa;margin:0}main{max-width:1220px;margin:32px auto;padding:20px}section{background:white;border:1px solid #dce5ec;border-radius:14px;padding:24px;margin:22px 0}h1{font-size:30px}h2{font-size:22px}a{color:#147d83}.sub{color:#64748b;font-size:14px}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:12px;text-align:left;border-bottom:1px solid #e2e8f0;white-space:nowrap}th{background:#f3f7fa}p{margin:16px 0}</style></head><body><main>'+body+'</main></body></html>'
(out/'report.html').write_text(page);(repo/'docs/research/risk-restore.html').write_text(page)
a=repo/'docs/research/archive.html';s=a.read_text();entry='<p><a href="risk-restore.html">减仓后次日提前恢复：7个现金样本、滑点压力与追高失败 ↗</a></p>'
if 'href="risk-restore.html"' not in s:a.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+entry))
with zipfile.ZipFile(repo/'docs/research/risk-restore-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.glob('*')):
  if p.name!='publication.json':z.write(p,'outputs/risk_restore/'+p.name)
 for p in sorted((r/'work/risk_restore').glob('*')):z.write(p,'work/risk_restore/'+p.name)
 for p in files:z.write(r/p,p)
cp=r/'work/research-checkpoint.json';c=json.loads(cp.read_text());c['riskRestore']={'updatedAt':datetime.datetime.now().astimezone().isoformat(),'status':'verified locally, publication pending','outputs':'outputs/risk_restore','rule':'Actual prior-day risk sale; original full target10:00;2completedcloses>=open and latest rising at09:45; buy-only restore; keep original10:00.','finding':'D5bpDD18.72->18.16 win68.81->70.37 on7days;10bpwin65.77->64.86. L6daysDD25.25->24.76 return1025.52->1017.64. OlderDDworse,rolling24/24notenabled; insufficient evidence.','audit':audit,'defaultChanged':False,'newBlindTest':False};c['updatedAt']=c['riskRestore']['updatedAt'];cp.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print(json.dumps(audit,ensure_ascii=False,indent=2))
