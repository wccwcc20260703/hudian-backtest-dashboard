# -*- coding: utf-8 -*-
from pathlib import Path
import json,datetime
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/robustness';P=R/'work/robustness'
plan={'registeredAt':datetime.datetime.now().astimezone().isoformat(),'question':'Is current default a narrow RSI threshold peak or broadly regime dependent? How concentrated is relative log wealth?','grid':{'rsiPeriod':2,'low':[30,35,40],'high':[55,60,65],'fixedCenter':[35,60]},'scope':'All9 neighbors reported, no winner selection or default update. Cash andallfull150margin separate. HuiDian and Shenghong,full/3annual/older/early/later/Julyon,5/10bps actualcommission. Previous reentry concentration studies concern different overlays/olderfees; thisbatch audits currentdefault vsfairB.','concentration':'For center only,compute dailylog(strategyreturnfactor/benchmarkfactor). Top5/10/20 positive logrelative days set tozero as mathematical stress; NOT executable counterfactual, no account reset,retraining or causalprofitclaim. Also bottom5 symmetric stress. Retain all days in actualbacktest.','inference':'Neighborhood stability does not remove priorsearch bias; allhistory seen. No forward evidence, no probability ofluck estimated. No newfactor optimization. Dataquality/financialvintage/eligibility limitations persist.','execution':'Existing exchange-adapted engine,defaultmin5commission1bp,T1,1%prior5mvolume,lots,price limits,6%interest,loan<=50%netonbuy,passive drift unchanged.'}
(O/'plan-before-results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
h=pd.read_csv(R/'outputs/round2/fundamental_point_in_time_map.csv',index_col='date');Q=pd.concat([pd.read_csv(R/'work/round2/data/daily_qfq_early.csv',index_col='date'),pd.read_csv(R/'work/data/daily_qfq.csv',index_col='date')]).sort_index();Q=Q.loc[~Q.index.duplicated(keep='last')];change=Q.close.diff();gain=change.clip(lower=0).ewm(alpha=.5,adjust=False).mean();loss=(-change.clip(upper=0)).ewm(alpha=.5,adjust=False).mean();h['rsi2lag']=(100-100/(1+gain/loss.replace(0,np.nan))).fillna(50).shift(1).reindex(h.index);h=h.rename(columns={'yoy_netprofit':'YOYNI'})
s=pd.read_csv(R/'outputs/shenghong/signal-ledger.csv',index_col='date');plans={}
for stock,df,path in [('hudian',h,'work/risk_priority/data.json'),('shenghong',s,'work/shenghong/data.json')]:
 d=json.loads((R/path).read_text());df=df.reindex(d['dates']);assert df[['rsi2lag','YOYNI']].notna().all().all();plans[stock]={}
 for lo in [30,35,40]:
  for hi in [55,60,65]:
   w=np.where(df.YOYNI<=0,0,np.where(df.rsi2lag<lo,1,np.where(df.rsi2lag>hi,0,.5)));sig=[[3 if i>0 and v<w[i-1] else 6,float(v)] for i,v in enumerate(w)];plans[stock][f'{lo}_{hi}']=sig
 assert plans[stock]['35_60']==d['signals']['D']
(P/'plans.json').write_text(json.dumps(plans,separators=(',',':')));print('18 schedules frozen; both centers reproduce production signals')
