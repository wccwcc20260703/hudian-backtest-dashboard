# -*- coding: utf-8 -*-
from pathlib import Path
import json,datetime,zipfile,hashlib,html,math
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path.cwd();O=R/'outputs/robustness';repo=R/'work/hudian-backtest-dashboard';rows=json.loads((O/'metrics.json').read_text());conc=json.loads((O/'concentration.json').read_text());daily=json.loads((O/'daily-relative.json').read_text());audit=json.loads((O/'audit.json').read_text());groups=[]
for stock in ['hudian','shenghong']:
 for account in ['D','L']:
  for period in ['full','older','year1','year2','year3','early','later','julyOn']:
   for slip in [.0005,.001]:
    a=[x for x in rows if (x['stock'],x['account'],x['period'],x['slip'])==(stock,account,period,slip)];assert len(a)==9
    groups.append(dict(stock=stock,account=account,period=period,slip=slip,beatingHold=sum(x['relativeWealth']>1 for x in a),positive=sum(x['return_']>0 for x in a),returnMin=min(x['return_'] for x in a),returnMax=max(x['return_'] for x in a),drawdownMin=min(-x['mdd5'] for x in a),drawdownMax=max(-x['mdd5'] for x in a),winMin=min(x['episodeWinRate'] for x in a),winMax=max(x['episodeWinRate'] for x in a),oldCashGoal=sum(x['oldCashGoal'] for x in a),wealth120=sum(x['wealth120'] for x in a)))
checks=0
for x in conc:
 a=[r for r in daily if (r['stock'],r['account'])==(x['stock'],x['account'])];total=sum(math.log(r['strategyFactor']/r['benchmarkFactor']) for r in a);assert abs(math.exp(total)-x['originalRelativeWealth'])<1e-10;sel=[r for r in a if r['date'] in x['dates']];assert len(sel)==x['count'];assert abs(math.exp(total-sum(math.log(r['strategyFactor']/r['benchmarkFactor']) for r in sel))-x['remainingRelativeWealth'])<1e-10;checks+=1
pd.DataFrame(rows).to_csv(O/'all-results.csv',index=False);pd.DataFrame(groups).to_csv(O/'group-summary.csv',index=False);pd.DataFrame(conc).to_csv(O/'concentration.csv',index=False);pd.DataFrame(daily).to_csv(O/'daily-relative.csv',index=False);audit['independentConcentrationChecks']=checks;(O/'audit.json').write_text(json.dumps(audit,indent=2))
fig,axs=plt.subplots(1,3,figsize=(13,4));stocks=['hudian','hudian','shenghong'];periods=['full','older','full'];titles=['Hudian 2023-2026','Hudian 2020-2023','Shenghong 2023-2026']
for ax,stock,period,title in zip(axs,stocks,periods,titles):
 a=[x for x in rows if x['stock']==stock and x['period']==period and x['account']=='L' and x['slip']==.0005];mat=np.array([[next(x['relativeWealth'] for x in a if x['param']==f'{lo}_{hi}') for hi in [55,60,65]] for lo in [30,35,40]]);ax.imshow(mat,cmap='RdYlGn',vmin=0,vmax=3);ax.set_xticks([0,1,2],[55,60,65]);ax.set_yticks([0,1,2],[30,35,40]);ax.set_xlabel('RSI upper exit threshold');ax.set_ylabel('RSI lower buy threshold');ax.set_title(title)
 for i in range(3):
  for j in range(3):ax.text(j,i,f'{mat[i,j]:.2f}x',ha='center',va='center',color='#172536',fontweight='bold')
fig.suptitle('Margin strategy final equity / buy-and-hold equity (1.00x = tie)');fig.tight_layout();fig.savefig(O/'neighborhood.svg');fig.savefig(O/'neighborhood.png',dpi=140);plt.close(fig);(repo/'docs/research/robustness-neighborhood.svg').write_bytes((O/'neighborhood.svg').read_bytes())
pct=lambda x:f'{x*100:.2f}%';names={'hudian':'沪电','shenghong':'胜宏','D':'现金','L':'融资'}
def table(headers,rs):return '<div class="scroll"><table><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in headers)+'</tr>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>' for row in rs)+'</table></div>'
def groupTable(rs):return table(['股票／账户','区间','滑点','跑赢持有','收益范围','回撤范围','周期胜率范围'],[[names[x['stock']]+'／'+names[x['account']],x['period'],str(round(x['slip']*1e4))+'基点',str(x['beatingHold'])+'/9',pct(x['returnMin'])+'～'+pct(x['returnMax']),pct(x['drawdownMin'])+'～'+pct(x['drawdownMax']),pct(x['winMin'])+'～'+pct(x['winMax'])] for x in rs])
body='''<a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a><h1>参数碰巧选中，还是行情阶段合适？</h1><p class="muted">固定九组邻近参数 · 沪电与胜宏 · 576组复算 · 没有另选赢家</p>
<section><h2>结论：不是孤立阈值奏效，跨阶段失效更明显</h2><p>沪电近三年，九组邻近参数的融资版本全部跑赢全仓，收益范围729.43%至1297.36%，说明35/60不是唯一表现好的组合。可是同样九组参数在沪电更早历史全部亏损，回撤70.39%至72.86%；在胜宏近三年则全部跑输持有。</p><p><strong>这削弱了“恰好选中两个神奇数字”的解释，却没有证明稳定股性。</strong>证据更符合“这一类反转规则适应了某段行情”的解释。整个策略家族及研究区间本身仍是在看过历史后确定的，邻近参数稳定不能消除这种筛选偏差。</p></section>
<section><h2>预先固定的检验</h2><p>RSI仍为2日，买入阈值固定30、35、40，卖出阈值固定55、60、65，构成9组；保留当前35/60中心。业绩门槛、50%中间仓位、09:45减仓、10:00买入、佣金、股息税假设、成交容量和融资规则全部不变，不调整止盈或止损。每组都报告，不按结果挑新默认。</p><p>两只股票、现金与150%融资分别比较；本金100万元、万1佣金最低5元、单边5及10基点滑点。沿用已核验的制度适配：沪电10%涨跌幅，胜宏2020-08-24起20%；T+1、100股及成交量约束，融资年息6%、买入后欠款不超过净资产50%，允许被动超仓。</p><p>完整区间2023-10-09至2026-10-08；更早段2020-01-02至2023-09-28。固定年度每年10月9日起至下一年10月9日前；年度和更早段各自以100万元重新开始，不能拼接为一条连续曲线。</p></section>
<section><h2>九组参数在不同股票与阶段</h2><img src="robustness-neighborhood.svg" alt="三幅九参数矩阵：沪电近三年均超过持有、更早历史及胜宏均低于持有"><p class="muted">格子是期末资产÷全仓期末资产；1.00倍为持平，不是收益率，也不是胜率。统一色标；中间格为现行35/60。</p>'''
body+=groupTable([x for x in groups if x['period'] in ['full','older'] and x['slip']==.0005])
body+='</section><section><h2>拆成年度，不能只看总收益</h2>'
body+=groupTable([x for x in groups if x['period'] in ['year1','year2','year3'] and x['slip']==.0005])
body+='<p>沪电融资第一年九组全部跑输持有，第二、三年九组全部跑赢。现金第一年0/9、第二年1/9、第三年9/9跑赢。胜宏现金和融资的前两年全部落后，第三年全部领先。这种阶段差异比邻近阈值的差异更值得关注；不能把第三年的避跌效果推断为此前持续领先。</p></section><section><h2>单边10基点压力测试</h2>'
body+=groupTable([x for x in groups if x['period'] in ['full','older'] and x['slip']==.001])
body+='<p>胜率均指完整“空仓到空仓”的持仓周期，未结束持仓按市值计入账户损益和回撤，不放入已结束周期胜率分母；本实验没有定义独立做T往返，不提供日内做T胜率。完整CSV还保留盈利日、空仓/平盘、尾部日亏损、参与度、费用利息和未平仓损益。</p></section><section><h2>少数日期对超额收益有多重要？</h2><p>只检验当前35/60。先把每天“策略净值涨幅÷全仓净值涨幅”取对数，累加得到最终相对财富；再把贡献最大的5、10、20天的相对贡献人为置零，相当于那些天改为与持有表现相同。这只是算术集中度压力测试：没有重演持仓和后续成交，不能称作可执行策略收益、剔除交易后的真实回测，或未来发生概率。</p>'
body+=table(['股票／账户','处理的相对贡献日','原相对财富','置零后相对财富'],[[names[x['stock']]+'／'+names[x['account']],('最佳' if x['side']=='best' else '最差')+str(x['count'])+'天',f"{x['originalRelativeWealth']:.3f}倍",f"{x['remainingRelativeWealth']:.3f}倍"] for x in conc])
body+='<p>沪电现金原相对财富1.217倍，最佳5天贡献置零后变为0.770倍；融资由2.533倍，置零最佳10天后剩1.097倍，最佳20天后0.596倍。这说明超额收益对少数日子的相对表现敏感，但“去掉最佳日后变差”本身必然偏向负面，不能据此证明运气或过拟合。最差5天也做了对称处理，避免只呈现一边。</p><p>沪电融资最大的5个相对贡献日依次为2025-04-07、2025-02-05、2026-07-10、2026-07-02、2025-04-08。下表列出真实账户当日涨跌；赚取超额可能是少跌或空仓避跌，并不等于准确买到上涨。</p>'
sel=next(x['dates'] for x in conc if x['stock']=='hudian' and x['account']=='L' and x['side']=='best' and x['count']==5)
body+=table(['日期','策略当日涨跌','持有当日涨跌','当日相对财富变化'],[[d,pct(next(x for x in daily if x['stock']=='hudian' and x['account']=='L' and x['date']==d)['strategyFactor']-1),pct(next(x for x in daily if x['stock']=='hudian' and x['account']=='L' and x['date']==d)['benchmarkFactor']-1),pct(math.exp(next(x for x in daily if x['stock']=='hudian' and x['account']=='L' and x['date']==d)['logRelative'])-1)] for d in sel])
body+='<p>上述日期按事后结果选出用于解释，并不能提前识别。相对贡献日期也不一定有当日成交，不能叫“最佳交易日”。</p></section><section><h2>旧目标与当前风险偏好分开记录</h2><p>当前目标仍优先控制回撤与胜率，没有收益硬下限。以下只留存旧标准的对照数量，不用来淘汰所有风险改善；也不把单段通过当作整体达标。</p>'
body+=table(['股票／账户／5基点全段','保留持有收益且回撤降低至少25%','期末财富达到持有1.20倍'],[[names[x['stock']]+'／'+names[x['account']],str(x['oldCashGoal'])+'/9',str(x['wealth120'])+'/9'] for x in groups if x['period']=='full' and x['slip']==.0005])
body+='<p>原“现金”标准仅针对现金方案；融资列同样公式是数值对照，不冒称现金达标。至少2/3固定年度、更早行情和冻结后独立证据要求仍未同时满足。</p></section><section><h2>核验与下一步</h2>'
body+=f"<p>576组复算；中心参数的{audit['centerMetricParity']}个原结果完全复现，{checks}组相对贡献由Python独立重算并核对。没有修改执行引擎、默认方案或实时信号；所有历史行情均已见过，不是新盲测。</p>"
body+='''<p>数据继续截至2026-10-08。分钟与日线极值/成交量不一致、历史财报修订版本、历史融资资格和成交延迟仍未彻底核验；这些局限也适用于本页。10月10日休市，没有新增冻结后的交易日证据。本次没有再次请求相同历史数据。</p><p>下一步应研究“何时反转有效、何时应保留趋势仓位”的可提前识别边界，并与简单固定仓位对照，防止把降低仓位本身的减险误认为择时能力。先冻结候选及风险评价方式，再接受后续行情的检验；本批没有给出新最佳参数。</p><p><a href="robustness-evidence.zip">下载全部结果、每日相对贡献、源数据与复现脚本</a> · <a href="shenghong-transfer.html">胜宏原样迁移测试</a> · <a href="strict-audit.html">策略严格审查</a></p></section>'''
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>参数稳健性与超额集中度｜沪电研究</title><style>body{font:16px/1.75 system-ui,sans-serif;background:#f3f6fa;color:#1b304a;margin:0}main{max-width:1240px;margin:32px auto;padding:20px}section{background:white;border:1px solid #dce5ee;border-radius:14px;padding:24px;margin:22px 0}h1{font-size:30px}h2{font-size:22px}.scroll{overflow:auto}table{border-collapse:collapse;font-size:14px;width:100%}th,td{padding:11px;white-space:nowrap;text-align:left;border-bottom:1px solid #e1e8ef}th{background:#f5f8fa}.muted{color:#69798c;font-size:14px}a{color:#137f88}img{width:100%;height:auto}</style></head><body><main>'+body+'</main></body></html>'
(O/'report.html').write_text(page.replace('src="robustness-neighborhood.svg"','src="neighborhood.svg"'));(repo/'docs/research/robustness.html').write_text(page)
f=repo/'docs/research/archive.html';s=f.read_text();entry='<p><a href="robustness.html">参数稳健性：9组邻近参数与超额收益集中度，阶段依赖更明显 ↗</a></p>'
if 'href="robustness.html"' not in s:f.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+entry))
inputs=['work/robustness/plans.json','work/risk_priority/data.json','work/shenghong/data.json','work/shenghong/finance.mjs','work/shenghong/benchmark.mjs','work/opening_guard/metrics.mjs','work/hudian-backtest-dashboard/docs/fees.js','work/hudian-backtest-dashboard/docs/attribution.js','outputs/risk_restore/metrics.json','outputs/shenghong/metrics.json'];(O/'manifest.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in inputs},indent=2))
(O/'README.txt').write_text('Extract ZIP into an empty directory and run node work/robustness/run.mjs. Prepared schedules/data and dependencies included. build.py/report.py require broader workspace; not needed for numerical reproduction. Do not overwrite saved preregistration. No winner selected; no future evidence.\n')
with zipfile.ZipFile(repo/'docs/research/robustness-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 seen=set()
 for p in list(O.glob('*'))+list((R/'work/robustness').glob('*'))+[R/p for p in inputs]:
  if p.is_file() and p not in seen and p.name!='publication.json':z.write(p,str(p.relative_to(R)));seen.add(p)
f=R/'work/research-checkpoint.json';c=json.loads(f.read_text());c['robustness']={'updatedAt':datetime.datetime.now().astimezone().isoformat(),'outputs':'outputs/robustness','status':'locally verified, publication pending','finding':'9/9marginneighbors beatHold recentHudian;0/9older andalllose,0/9recentShenghong. Not isolated35/60peak, strongerregimedependency evidence. Hudian cashrelative1.217->.770 afterbest5relative-daycontributionneutralized;L2.533->1.097best10. Arithmeticstress only,notexecutable/pvalue.','audit':audit,'defaultChanged':False};c['updatedAt']=c['robustness']['updatedAt'];f.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print('report and checkpoint saved')
