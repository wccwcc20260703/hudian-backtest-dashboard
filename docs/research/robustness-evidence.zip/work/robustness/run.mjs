import fs from 'node:fs';import assert from 'node:assert/strict';import {financeBacktest} from '../shenghong/finance.mjs';import {holdBenchmark} from '../shenghong/benchmark.mjs';import {stats} from '../opening_guard/metrics.mjs';import {attribution} from '../hudian-backtest-dashboard/docs/attribution.js';
const read=p=>JSON.parse(fs.readFileSync(p)),plans=read('work/robustness/plans.json'),out='outputs/robustness/',rows=[],conc=[],daily=[];let parity=0;
for(const [stock,path]of [['hudian','work/risk_priority/data.json'],['shenghong','work/shenghong/data.json']]){
 const original=read(path),n=original.dates.length,idx=s=>{let i=original.dates.findIndex(x=>x>=s);return i<0?n:i},start=idx('2023-10-09'),g={D:{all_full:Array(n).fill(1)}},periods={full:[start,n],older:[0,start],early:[start,idx('2025-01-01')],later:[idx('2025-01-01'),idx('2026-07-01')],julyOn:[idx('2026-07-01'),n]};for(let y=0;y<3;y++)periods['year'+(y+1)]=[idx(`${2023+y}-10-09`),idx(`${2024+y}-10-09`)];
 const old=read(stock==='hudian'?'outputs/risk_restore/metrics.json':'outputs/shenghong/metrics.json');
 for(const [period,[a,z]]of Object.entries(periods))for(const slip of [.0005,.001]){
  const b=holdBenchmark(original,a,z,{slip});for(const [param,signals] of Object.entries(plans[stock]))for(const account of ['D','L']){
   const d={...original,signals:{D:signals}},r=financeBacktest(d,g,a,z,{slip,level:account==='D'?1:1.5,rate:account==='D'?0:.06}),s=stats(r),attr=attribution(r,b,d.dates.slice(a,z));delete attr.relative;
   const rv=[r.capital,...r.nav],bv=[b.capital,...b.nav];let lead=0,ct=0;for(let i=63;i<rv.length;i++){ct++;lead+=rv[i]/rv[i-63]>bv[i]/bv[i-63]?1:0}
   rows.push({stock,param,account,period,slip,...r.metrics,...s,...attr,rolling63Lead:ct?lead/ct:null,benchmarkReturn:b.metrics.return_,benchmarkDD:b.metrics.mdd5,relativeWealth:r.nav.at(-1)/b.nav.at(-1),oldCashGoal:r.metrics.return_>=b.metrics.return_&&Math.abs(r.metrics.mdd5)<=.75*Math.abs(b.metrics.mdd5),wealth120:r.nav.at(-1)/b.nav.at(-1)>=1.2});
   if(param==='35_60'){
    const saved=old.find(x=>x.name===account&&x.period===period&&x.slip===slip&&(stock==='shenghong'||x.mode==='off'));
    for(const key of ['return_','mdd5','episodeWinRate']){assert(Math.abs((r.metrics[key]??s[key])-saved[key])<1e-10);parity++;}
    if(period==='full'&&slip===.0005){
     const logs=r.nav.map((v,i)=>({date:d.dates[a+i],strategyFactor:v/rv[i],benchmarkFactor:b.nav[i]/bv[i],logRelative:Math.log(v/rv[i])-Math.log(b.nav[i]/bv[i])}));const total=logs.reduce((s,x)=>s+x.logRelative,0);assert(Math.abs(Math.exp(total)-r.nav.at(-1)/b.nav.at(-1))<1e-10);
     const pos=logs.filter(x=>x.logRelative>0).sort((x,y)=>y.logRelative-x.logRelative),neg=logs.filter(x=>x.logRelative<0).sort((x,y)=>x.logRelative-y.logRelative);for(const [side,ordered,counts]of [['best',pos,[5,10,20]],['worst',neg,[5]]])for(const count of counts){const selected=ordered.slice(0,count),sum=selected.reduce((s,x)=>s+x.logRelative,0);conc.push({stock,account,side,count,totalLogRelative:total,originalRelativeWealth:Math.exp(total),selectedLogRelative:sum,remainingRelativeWealth:Math.exp(total-sum),dates:selected.map(x=>x.date),note:'Mathematical deletion of relative contribution; not executable NAV or predicted probability'});}
     daily.push(...logs.map(x=>({stock,account,...x})));
    }
   }
  }
 }
}
fs.writeFileSync(out+'metrics.json',JSON.stringify(rows));fs.writeFileSync(out+'concentration.json',JSON.stringify(conc));fs.writeFileSync(out+'daily-relative.json',JSON.stringify(daily));fs.writeFileSync(out+'audit.json',JSON.stringify({scenarios:rows.length,centerMetricParity:parity,parametersRechosen:false,defaultChanged:false,frozenForwardEvidence:false},null,2));console.log(JSON.stringify({scenarios:rows.length,centerMetricParity:parity}));
