import fs from 'node:fs';import assert from 'node:assert/strict';import {financeBacktest}from '../shenghong/finance.mjs';import {guardBacktest}from '../opening_guard/engine.mjs';import {splitBacktest}from './split.mjs';
const read=p=>JSON.parse(fs.readFileSync(p)),m=read('outputs/sector_execution/masks.json'),dm=read('work/late_entry/masks.json');let prefix=0,known=0;
for(const [s,p]of [['hudian','work/risk_priority/data.json'],['shenghong','work/shenghong/data.json']]){
 const d=read(p),a=d.dates.indexOf('2023-10-09'),n=d.dates.length,g={D:{all_full:Array(n).fill(true)}},f=m[s];
 for(let day=0;day<n;day++){if(d.signals.D[day][1]===1){assert(d.signals.D[day][0]>=6);known++;}}
 for(const type of ['TM','TP','GP','split','size'])for(const level of [1,1.5]){
  const o={level,rate:level===1.5?.06:0},fn=(end)=>type==='TM'||type==='TP'?financeBacktest(d,{D:{all_full:f.trend.map((v,i)=>v&&f[type==='TM'?'morning':'peerUp'][i])}},a,end,o):type==='GP'?guardBacktest(d,g,a,end,{...o,riskMask:f.peerGuard,riskCap:level===1?.5:1}):splitBacktest(d,g,a,end,{...o,delayMask:dm[s],topup:type==='split'});
  const full=fn(n);for(const end of [a+50,a+310]){const short=fn(end);assert.deepEqual(short.nav,full.nav.slice(0,end-a));assert.deepEqual(short.trades,full.trades.filter(t=>t[0]<end));prefix++;}
 }
}
const e=read('outputs/sector_execution/episodes.json'),metrics=read('outputs/sector_execution/metrics.json');let cycles=0;for(const r of metrics.filter(x=>x.period==='full'&&x.slip===.0005)){const ee=e.filter(x=>x.stock===r.stock&&x.name===r.name);assert(Math.abs(ee.reduce((s,x)=>s+x.pnl,0)-r.return_*1e6)<1e-4);assert.equal(ee.filter(x=>x.complete).length,r.closedEpisodes);assert.equal(ee.filter(x=>x.complete&&x.pnl>0).length,r.episodeWins);cycles++;}
const a=read('outputs/sector_execution/audit.json');Object.assign(a,{tenAMSignalTimeChecks:known,accountPrefixChecks:prefix,episodeReconciliations:cycles,synthetic:read('outputs/sector_execution/engine-audit.json'),features:read('outputs/sector_execution/data-audit.json')});fs.writeFileSync('outputs/sector_execution/audit.json',JSON.stringify(a,null,2));console.log({known,prefix,cycles});
