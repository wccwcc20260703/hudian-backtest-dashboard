import baostock as bs,socket,json,signal,datetime,pathlib
p=pathlib.Path('work/sector_execution');socket.setdefaulttimeout(10)
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('overall 40-second source timeout')));signal.alarm(40)
result={'checkedAt':datetime.datetime.now().astimezone().isoformat(),'requestedSession':'2026-10-09','status':'not_checked'}
try:
 lg=bs.login();assert lg.error_code=='0',lg.error_msg
 for frequency,fields,name in [('d','date,open,high,low,close,volume,amount','daily'),('5','date,time,open,high,low,close,volume,amount','minute5')]:
  rs=bs.query_history_k_data_plus('sz.002463',fields,start_date='2026-10-09',end_date='2026-10-09',frequency=frequency,adjustflag='3');rows=[]
  while rs.error_code=='0' and rs.next():rows.append(rs.get_row_data())
  result[name]={'error':rs.error_code,'message':rs.error_msg,'rows':len(rows)}
  (p/(name+'_oct9.json')).write_text(json.dumps({'fields':rs.fields,'rows':rows},ensure_ascii=False))
 rs=bs.query_growth_data(code='sz.002463',year=2026,quarter=3);rows=[]
 while rs.error_code=='0' and rs.next():rows.append(rs.get_row_data())
 result['quarter3Growth']={'error':rs.error_code,'rows':len(rows)}
 (p/'quarter3_growth.json').write_text(json.dumps({'fields':rs.fields,'rows':rows},ensure_ascii=False))
 result['status']='source_returned';bs.logout()
except Exception as ex:result['status']='unavailable';result['error']=str(ex)
finally:
 signal.alarm(0);pathlib.Path('outputs/sector_execution/freshness.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
