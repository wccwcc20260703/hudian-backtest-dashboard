from pathlib import Path
import json,pandas as pd,numpy as np
R=Path.cwd();O=R/'outputs/sector_execution';m=pd.read_json(O/'metrics.json');m.to_csv(O/'metrics.csv',index=False)
comparisons={}
for stock in ['hudian','shenghong']:
 for name,base in [('TM','T'),('TP','T'),('DGP','D'),('LGP','L'),('Dsplit','D'),('Lsplit','L'),('Dsize','D'),('Lsize','L')]:
  find=lambda n,p,s:m[(m.stock==stock)&(m.name==n)&(m.period==p)&(m.slip==s)].iloc[0]
  comparisons[stock+'_'+name]={'base':base,'annualLowerDD':sum(float(find(name,'year'+str(y),.0005).mdd5)>float(find(base,'year'+str(y),.0005).mdd5) for y in [1,2,3]),'annualHigherWin':sum(float(find(name,'year'+str(y),.0005).episodeWinRate)>float(find(base,'year'+str(y),.0005).episodeWinRate) for y in [1,2,3])}
qty=[]
for stock in ['hudian','shenghong']:
 for mode in ['D','L']:
  for name in [mode,mode+'30',mode+'split',mode+'size']:
   t=json.loads((O/(stock+'-'+name+'-trades.json')).read_text());de=json.loads((O/(stock+'-'+name+'-delays.json')).read_text());days={x['day']for x in de};buys=[x for x in t if x[0]in days and x[2]>0]
   qty.append({'stock':stock,'name':name,'eligibleIntentDays':len(days),'daysWithAnyBuy':len({x[0]for x in buys}),'earlyQuantity':sum(x[3]for x in buys if x[1]<42),'lateQuantity':sum(x[3]for x in buys if x[1]>=42),'note':'Continuous accounts differ; total shares are not matched-state causal quantity comparison'})
# Same prior account state, alter one qualified buy day only, and measure both same-day and next-day net account effect.
(O/'comparisons.json').write_text(json.dumps(comparisons,indent=2));(O/'quantities.json').write_text(json.dumps(qty,indent=2))
f=json.loads((O/'freshness.json').read_text())
if f.get('status')=='source_returned':
 d=json.loads((R/'work/sector_execution/daily_oct9.json').read_text());b=json.loads((R/'work/sector_execution/minute5_oct9.json').read_text());dd=pd.DataFrame(d['rows'],columns=d['fields']);bb=pd.DataFrame(b['rows'],columns=b['fields']);
 if len(dd)==1 and len(bb)==48:
  f['extremaCheck']={'dailyHigh':float(dd.high.iloc[0]),'minuteHigh':bb.high.astype(float).max(),'dailyLow':float(dd.low.iloc[0]),'minuteLow':bb.low.astype(float).min(),'dailyClose':float(dd.close.iloc[0]),'minuteClose':float(bb.close.iloc[-1])};v=f['extremaCheck'];f['extremaMatch']=abs(v['dailyHigh']-v['minuteHigh'])<.011 and abs(v['dailyLow']-v['minuteLow'])<.011 and abs(v['dailyClose']-v['minuteClose'])<.011
f['backtestThrough']='2026-10-08';f['quarter3Note']='Missing source rows are not zero growth or proof of no publication';(O/'freshness.json').write_text(json.dumps(f,indent=2,default=lambda x:x.item()))
print(m[(m.stock=='hudian')&(m.period=='full')&(m.slip==.0005)][['name','return_','mdd5','episodeWins','closedEpisodes','episodeWinRate','exposure','worst5pctDayMean']].to_string(index=False))
print('Earlier H');print(m[(m.stock=='hudian')&(m.period=='older')&(m.slip==.0005)&m.name.isin(['L','T','TM','TP','LGP','Lsplit','Lsize'])][['name','return_','mdd5','episodeWinRate']].to_string(index=False))
