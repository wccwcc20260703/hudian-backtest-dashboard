from pathlib import Path
import json,numpy as np,pandas as pd,hashlib
R=Path.cwd();O=R/'outputs/sector_execution';P=R/'work/sector_execution/data'
data={s:json.loads((R/p).read_text()) for s,p in [('hudian','work/risk_priority/data.json'),('shenghong','work/shenghong/data.json')]}
dates=data['hudian']['dates'];assert dates==data['shenghong']['dates'];N=len(dates)
raw={s:np.array(d['bars'],float) for s,d in data.items()};quality={};manifest={}
expected=[f'{h:02d}{m:02d}' for h in range(9,16) for m in range(0,60,5) if '0935'<=f'{h:02d}{m:02d}'<='1130' or '1305'<=f'{h:02d}{m:02d}'<='1500']
assert len(expected)==48
for code in ['sz.002916','sh.603228']:
 files=sorted(P.glob(code+'-*.csv'));assert len(files)==7
 q=pd.concat([pd.read_csv(p,dtype={'time':str}) for p in files]);groups={date:g for date,g in q.groupby('date')};arr=np.full((N,48,6),np.nan);invalid=[]
 for i,date in enumerate(dates):
  g=groups.get(date)
  if g is None:invalid.append(date);continue
  times=list(g.time.str[8:12]);assert len(times)==len(set(times)),(code,date,'duplicate minute')
  g=g.assign(slot=g.time.str[8:12]).set_index('slot').reindex(expected)
  b=g[['open','high','low','close','volume','amount']].to_numpy(float)
  valid=np.isfinite(b).all(axis=1)&(b[:,:4]>0).all(axis=1)&(b[:,4:]>=0).all(axis=1)&(b[:,1]+.011>=np.max(b[:,[0,2,3]],axis=1))&(b[:,2]-.011<=np.min(b[:,[0,1,3]],axis=1))
  if not valid.all():invalid.append(date)
  b[~valid]=np.nan;arr[i]=b
 raw[code]=arr;quality[code]={'validDays':N-len(invalid),'invalidDays':invalid,'timeGridChecked':expected}
 for p in files:manifest[str(p.relative_to(R))]=hashlib.sha256(p.read_bytes()).hexdigest()

def calc(b,k):
 v=b[:,:k,4].sum(axis=1);amt=b[:,:k,5].sum(axis=1);vw=np.divide(amt,v,out=np.full(N,np.nan),where=v>0)
 prior=pd.Series(amt).rolling(20,min_periods=20).mean().shift().to_numpy()
 ratio=amt/prior;ready=np.isfinite(ratio)&np.isfinite(vw)&(prior>0)
 return {'up':(b[:,k-1,3]>b[:,0,0])&(b[:,k-1,3]>vw)&ready,'down':(b[:,k-1,3]<b[:,0,0])&(b[:,k-1,3]<vw)&ready,'relativeAmount':ratio,'ready':ready}
feat={s:{k:calc(b,k) for k in [3,6]} for s,b in raw.items()};masks={};checks=0;mutation=0
for s,b in raw.items():
 for k in [3,6]:
  changed=b.copy();changed[:,k:,:]=np.nan;c=calc(changed,k)
  for key in c:assert np.array_equal(c[key],feat[s][k][key],equal_nan=True)
  mutation+=1
for stock,d in data.items():
 peers=[s for s in raw if s!=stock];rows=[];b=raw[stock];m={key:[] for key in ['trend','morning','peerUp','ownGuard','peerGuard']}
 paths=['work/round2/data/daily_qfq_early.csv','work/data/daily_qfq.csv']if stock=='hudian'else['work/shenghong/data/daily_qfq.csv']
 q=pd.concat([pd.read_csv(R/p) for p in paths]).sort_values('date').drop_duplicates('date',keep='last').set_index('date');c=q.close;ma120=c.rolling(120).mean();trend=((c>c.rolling(60).mean())&(ma120>ma120.shift(20))).shift(fill_value=False).reindex(dates).fillna(False).to_numpy(bool)
 for i,date in enumerate(dates):
  ready={k:all(feat[p][k]['ready'][i] for p in peers) for k in [3,6]}
  ups=sum(feat[p][6]['up'][i] for p in peers);downs=sum(feat[p][3]['down'][i] for p in peers)
  ratios={k:float(np.median([feat[p][k]['relativeAmount'][i] for p in peers])) if ready[k] else None for k in [3,6]}
  cv=b[i,:3,4].cumsum();vw=b[i,:3,5].cumsum()/cv
  ownRaw=bool(b[i,2,3]<=b[i,0,0]*.99 and b[i,1,3]<vw[1]*.999 and b[i,2,3]<vw[2]*.999)
  ownVol=float(b[i-20:i,:3,4].sum(axis=1).mean()) if i>=20 else None
  ownGuard=bool(ownRaw and ownVol is not None and cv[2]>=ownVol*1.2)
  pg=bool(ownRaw and ready[3] and downs>=2 and ratios[3]>=1.2);pu=bool(ready[6] and ups>=2 and ratios[6]>=1)
  vals={'trend':bool(trend[i]),'morning':bool(b[i,5,3]>b[i,0,0] and b[i,5,3]>b[i,:6,5].sum()/b[i,:6,4].sum()),'peerUp':pu,'ownGuard':ownGuard,'peerGuard':pg}
  for key,val in vals.items():m[key].append(val)
  rows.append({'date':date,**vals,'peerNames':'|'.join(peers),'peerUpCount':int(ups),'peerDownCount':int(downs),'peerRelativeAmount15':ratios[3],'peerRelativeAmount30':ratios[6],'peerReady15':ready[3],'peerReady30':ready[6]})
  # Independent per-peer sequential prefix calculation, no later-day prices in indicator.
  for k in [3,6]:
   for p in peers:
    bb=raw[p];past=bb[max(0,i-20):i,:k,5].sum(axis=1);today=bb[i,:k];den=past.mean() if i>=20 else np.nan
    rr=today[:,5].sum()/den;actual=feat[p][k]['relativeAmount'][i]
    assert (np.isnan(rr) and np.isnan(actual)) or abs(rr-actual)<1e-10
    checks+=1
 pd.DataFrame(rows).to_csv(O/(stock+'-features.csv'),index=False);masks[stock]=m
 # Independent same-existing-trigger parity for Hudian.
 if stock=='hudian':
  prior=json.loads((R/'outputs/opening_guard/events.json').read_text());assert m['ownGuard']==[v['trigger'] for v in prior]
  gate=json.loads((R/'work/risk_priority/gates.json').read_text())['D']['trend']
  for i in range(N):
   if d['signals']['D'][i][1]==1:assert bool(gate[i])==m['trend'][i]
(O/'masks.json').write_text(json.dumps(masks));(O/'data-audit.json').write_text(json.dumps({'peerData':quality,'futureIntradayMutationChecks':mutation,'sequentialPrefixChecks':checks,'through':dates[-1],'fundFlowAvailable':False,'historicalSectorMembershipAvailable':False},indent=2));(O/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'checks':checks,'quality':{k:v['validDays'] for k,v in quality.items()},'counts':{s:{k:sum(v[910:])for k,v in m.items()}for s,m in masks.items()}}))
