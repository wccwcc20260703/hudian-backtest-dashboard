from pathlib import Path
from datetime import datetime
import baostock as bs,pandas as pd,json,socket,hashlib
socket.setdefaulttimeout(25)
P=Path('work/sector_execution/data');meta={'accessedAt':datetime.now().astimezone().isoformat(),'source':'BaoStock raw 5-minute public history'}
lg=bs.login();assert lg.error_code=='0'
try:
 for code in ['sz.002916','sh.603228']:
  for year in range(2020,2027):
   p=P/(code+'-'+str(year)+'.csv')
   if p.exists():continue
   rs=bs.query_history_k_data_plus(code,'date,time,open,high,low,close,volume,amount',start_date=str(year)+'-01-01',end_date=min(str(year)+'-12-31','2026-10-08'),frequency='5',adjustflag='3')
   rows=[]
   while rs.error_code=='0' and rs.next():rows.append(rs.get_row_data())
   assert rs.error_code=='0',(code,year,rs.error_msg)
   pd.DataFrame(rows,columns=rs.fields).to_csv(p,index=False)
   print(code,year,len(rows),flush=True)
 for p in P.glob('*.csv'):meta[p.name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':sum(1 for _ in p.open())-1}
finally:
 bs.logout();(P/'manifest.json').write_text(json.dumps(meta,indent=2))
