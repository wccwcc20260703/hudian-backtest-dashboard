from pathlib import Path
s=Path('work/late_entry/run.mjs').read_text()
s=s.replace("import {lateBacktest} from './engine.mjs';", "import {lateBacktest} from '../late_entry/engine.mjs';import {splitBacktest} from './split.mjs';import {guardBacktest} from '../opening_guard/engine.mjs';")
s=s.replace("O='outputs/late_entry/'","O='outputs/sector_execution/'").replace("masks=read('work/late_entry/masks.json');", "masks=read('work/late_entry/masks.json'),features=read('outputs/sector_execution/masks.json');")
a=s.index(' const run=');z=s.index('\n const old=',a)
s=s[:a]+''' const f=features[stock];
 const run=(name,a,z,slip)=>{
  if(name==='B')return holdBenchmark(d,a,z,{slip});
  const margin=['L','T','TM','TP','LG','LGP','L30','Lsplit','Lsize'].includes(name),opts={slip,level:margin?1.5:1,rate:margin?.06:0};
  if(['T','TM','TP'].includes(name))return financeBacktest(d,{D:{all_full:f.trend.map((v,i)=>v&&(name==='T'||f[name==='TM'?'morning':'peerUp'][i]))}},a,z,opts);
  if(name.endsWith('G')||name.endsWith('GP'))return guardBacktest(d,g,a,z,{...opts,riskMask:f[name.endsWith('GP')?'peerGuard':'ownGuard'],riskCap:margin?1:.5});
  if(name.endsWith('split')||name.endsWith('size'))return splitBacktest(d,g,a,z,{...opts,delayMask:masks[stock],earlyFraction:.5,topup:name.endsWith('split')});
  return lateBacktest(d,g,a,z,{...opts,delayMask:name.endsWith('30')?masks[stock]:[],delayBar:42});
 };''' + s[z:]
s=s.replace("['B','D','L','F50','D30','L30','D45','L45']","['B','D','L','T','TM','TP','DG','LG','DGP','LGP','D30','L30','Dsplit','Lsplit','Dsize','Lsize']")
s=s.replace("const fattr=attribution(r,results.F50,d.dates.slice(a,z));delete fattr.relative;",'')
s=s.replace(',leadVsF50:fattr.leadFraction,longestBehindF50:fattr.longestBehind,relativeWealthF50:r.nav.at(-1)/results.F50.nav.at(-1)','')
s=s.replace("['B','D','L','F50'].includes(name)","['B','D','L'].includes(name)")
s=s.replace("['D30','L30','D45','L45'].includes(name)","!['B','D','L'].includes(name)")
s=s.replace("const base=results[name[0]]", "const base=results[name.startsWith('D')?'D':'L']")
s=s.replace("comparisonBase:name[0]", "comparisonBase:name.startsWith('D')?'D':'L'")
Path('work/sector_execution/run.mjs').write_text(s)
