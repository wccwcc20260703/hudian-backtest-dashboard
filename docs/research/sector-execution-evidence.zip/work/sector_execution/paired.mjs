import fs from 'node:fs';import assert from 'node:assert/strict';import {financeBacktest} from '../shenghong/finance.mjs';import {splitBacktest} from './split.mjs';
const read=p=>JSON.parse(fs.readFileSync(p)),masks=read('work/late_entry/masks.json'),out=[],episodes=read('outputs/regime_routing/episodes.json');let prefixChecks=0;
for(const [stock,path] of [['hudian','work/risk_priority/data.json'],['shenghong','work/shenghong/data.json']]){
 const d=read(path),n=d.dates.length,a=d.dates.indexOf('2023-10-09'),g={D:{all_full:Array(n).fill(1)}};
 for(const name of ['D','L']){
  const opt={slip:.0005,level:name==='L'?1.5:1,rate:name==='L'?.06:0},base=financeBacktest(d,g,a,n,opt),days=[...new Set(base.trades.filter(t=>masks[stock][t[0]]&&t[2]>0&&!t[15]&&t[1]<42).map(t=>t[0]))];
  for(const day of days)for(const variant of ['split','size']){
   const mask=Array(n).fill(false);mask[day]=true;const z=Math.min(n,day+2),late=splitBacktest(d,g,a,z,{...opt,delayMask:mask,topup:variant==='split'});
   assert.deepEqual(late.nav.slice(0,day-a),base.nav.slice(0,day-a));assert.deepEqual(late.trades.filter(t=>t[0]<day),base.trades.filter(t=>t[0]<day));prefixChecks++;
   const calc=r=>{const t=r.trades.filter(t=>t[0]===day&&t[2]>0&&!t[15]),qty=t.reduce((s,t)=>s+t[3],0),gross=t.reduce((s,t)=>s+t[3]*t[4],0);return {qty,vwap:qty?gross/qty:null,fees:t.reduce((s,t)=>s+t[5],0),bars:t.map(t=>t[1]).join(','),position:r.exposure[day-a],nav:r.nav[day-a],nextNav:r.nav[Math.min(day-a+1,r.nav.length-1)]}};
   const b=calc(base),l=calc(late),prior=day===a?base.capital:base.nav[day-a-1],flat=base.trades.find(t=>t[0]===day)[12]===0,episode=episodes.find(e=>e.stock===stock&&e.name===name&&e.start===d.dates[day]);
   out.push({stock,name,date:d.dates[day],variant,flatEntry:flat,baselineEpisodeComplete:episode?.complete??null,baselineEpisodeWin:episode?.complete?episode.pnl>0:null,baselineEpisodeDays:episode?.days??null,priorNav:prior,baseQty:b.qty,lateQty:l.qty,baseVWAP:b.vwap,lateVWAP:l.vwap,priceImprovement:l.qty?1-l.vwap/b.vwap:null,quantityRatio:l.qty/b.qty,noFill:l.qty===0,lateTargetShortfall:Math.max(0,late.targets[day-a][1]-l.position),basePosition:b.position,latePosition:l.position,baseBars:b.bars,lateBars:l.bars,baseEntryDayReturn:b.nav/prior-1,lateEntryDayReturn:l.nav/prior-1,dayNavDifference:(l.nav-b.nav)/prior,nextNavDifference:(l.nextNav-b.nextNav)/prior,hasNextDay:day+1<n});
  }
 }
}
fs.writeFileSync('outputs/sector_execution/paired.json',JSON.stringify(out));fs.writeFileSync('outputs/sector_execution/paired-audit.json',JSON.stringify({rows:out.length,identicalPrefixChecks:prefixChecks,description:'Each rerun changes only one prospective eligible buy date, same prior holdings/cash/fees; day/next-day NAV marked, not continuous new strategy or T wins.'},null,2));console.log({rows:out.length,prefixChecks});
