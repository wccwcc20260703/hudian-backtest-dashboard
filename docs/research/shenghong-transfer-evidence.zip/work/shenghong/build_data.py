# -*- coding: utf-8 -*-
from pathlib import Path
import pandas as pd,numpy as np,json
P=Path('work/shenghong/data');out=Path('outputs/shenghong')
D=pd.read_csv(P/'daily_raw.csv',index_col='date');Q=pd.read_csv(P/'daily_qfq.csv',index_col='date')
M=pd.concat([pd.read_csv(p,dtype={'time':str}) for p in sorted(P.glob('minute_*.csv'))]).sort_values(['date','time']);assert not M.duplicated(['date','time']).any()
dates=sorted(M.date.unique());counts=M.groupby('date').size();assert (counts==48).all(),counts[counts!=48]
expected=[f'{h:02}{m:02}00' for h,m in [(9,35),(9,40),(9,45),(9,50),(9,55)]+[(h,m) for h in [10] for m in range(0,60,5)]+[(11,m) for m in range(0,35,5)]+[(13,m) for m in range(5,60,5)]+[(14,m) for m in range(0,60,5)]+[(15,0)]]
for date,g in M.groupby('date'):assert [t[8:14] for t in g.time]==expected,date
assert len(dates)==len(D.loc[(D.index>=dates[0])&(D.index<=dates[-1])&(D.tradestatus==1)])
B=M[['open','high','low','close','volume','amount']].to_numpy(float).reshape(len(dates),48,6);assert np.isfinite(B).all() and (B[:,:,:4]>0).all() and (B[:,:,4:]>=0).all()
ch=Q.close.diff();gain=ch.clip(lower=0).ewm(alpha=.5,adjust=False).mean();loss=(-ch.clip(upper=0)).ewm(alpha=.5,adjust=False).mean();rsi=(100-100/(1+gain/loss.replace(0,np.nan))).fillna(50).shift(1).loc[dates]
G=pd.concat([pd.read_csv(p) for p in sorted(P.glob('growth_*.csv'))]).sort_values(['statDate','pubDate']);signal=[];fund=[];previous=None
for d in dates:
 g=G[G.pubDate<d].sort_values(['statDate','pubDate']);assert len(g)>0,d;x=g.iloc[-1];assert np.isfinite(float(x.YOYNI));w=1. if rsi[d]<35 else (0. if rsi[d]>60 else .5)
 if x.YOYNI<=0:w=0.
 signal.append([3 if previous is not None and w<previous else 6,w]);previous=w;fund.append({'date':d,'rsi2lag':rsi[d],'pubDate':x.pubDate,'statDate':x.statDate,'YOYNI':x.YOYNI,'target':w,'bar':signal[-1][0]})
div=np.zeros(len(dates));bonus=np.zeros(len(dates));dv=pd.concat([pd.read_csv(p) for p in sorted(P.glob('dividend_*.csv'))]).dropna(subset=['dividCashPsBeforeTax']).drop_duplicates('dividOperateDate',keep='last')
for _,x in dv.iterrows():
 if x.dividOperateDate in dates:
  i=dates.index(x.dividOperateDate);div[i]=x.dividCashPsBeforeTax;bonus[i]=x[['dividStocksPs','dividReserveToStockPs']].fillna(0).sum()
ref=(D.close.shift().loc[dates].to_numpy()-div)/(1+bonus)
limit=[.2 if d>='2020-08-24' else .1 for d in dates]
obj=dict(dates=dates,bars=B.tolist(),close=D.close.loc[dates].tolist(),dividend=div.tolist(),bonus=bonus.tolist(),reference=ref.tolist(),stamp=[.001 if d<'2023-08-28' else .0005 for d in dates],transfer=[.00002 if d<'2022-04-29' else .00001 for d in dates],limitPct=limit,signals={'D':signal})
Path('work/shenghong/data.json').write_text(json.dumps(obj,separators=(',',':'),allow_nan=False));pd.DataFrame(fund).to_csv(out/'signal-ledger.csv',index=False)
quality=[]
for i,d in enumerate(dates):
 raw=D.loc[d];b=B[i];quality.append({'date':d,'highGap':float(raw.high-b[:,1].max()),'lowGap':float(raw.low-b[:,2].min()),'closeGap':float(raw.close-b[-1,3]),'volumePctGap':float(b[:,4].sum()/raw.volume-1),'rawHigh':raw.high,'rawLow':raw.low,'minuteHigh':b[:,1].max(),'minuteLow':b[:,2].min()})
pd.DataFrame(quality).to_csv(out/'data-quality.csv',index=False)
a={'sessions':len(dates),'mainSessions':sum(d>='2023-10-09' for d in dates),'start':dates[0],'end':dates[-1],'rawDailyThrough':D.index[-1],'missingFinancialDays':0,'highLowGap2cMain':sum((abs(x['highGap'])>=.019999 or abs(x['lowGap'])>=.019999) and x['date']>='2023-10-09' for x in quality),'closeGap2cMain':sum(abs(x['closeGap'])>=.019999 and x['date']>='2023-10-09' for x in quality),'volGap1pctMain':sum(abs(x['volumePctGap'])>.01 and x['date']>='2023-10-09' for x in quality),'latestFinancial':fund[-1],'dividendRows':dv.fillna('').to_dict('records')}
(out/'data-audit.json').write_text(json.dumps(a,ensure_ascii=False,indent=2));print(json.dumps(a,ensure_ascii=False,indent=2))
