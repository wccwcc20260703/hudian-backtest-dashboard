# -*- coding: utf-8 -*-
from pathlib import Path
import pandas as pd,numpy as np,json
R=Path.cwd();Q=pd.concat([pd.read_csv(R/'work/round2/data/daily_qfq_early.csv',index_col='date'),pd.read_csv(R/'work/data/daily_qfq.csv',index_col='date')]).sort_index();Q=Q.loc[~Q.index.duplicated(keep='last')]
hd=json.loads((R/'work/risk_priority/data.json').read_text());dates=hd['dates'];change=Q.close.diff();gain=change.clip(lower=0).ewm(alpha=.5,adjust=False).mean();loss=(-change.clip(upper=0)).ewm(alpha=.5,adjust=False).mean();rsi=(100-100/(1+gain/loss.replace(0,np.nan))).fillna(50).shift(1).loc[dates];G=pd.read_csv(R/'outputs/round2/fundamental_point_in_time_map.csv',index_col='date').reindex(dates).yoy_netprofit;target=np.where(G<=0,0,np.where(rsi<35,1,np.where(rsi>60,0,.5)));signals=[[3 if i>0 and w<target[i-1] else 6,float(w)] for i,w in enumerate(target)];assert signals==hd['signals']['D']
s=pd.read_csv(R/'outputs/shenghong/signal-ledger.csv');assert (s.pubDate<s.date).all();assert s.YOYNI.iloc[-1]==.333
D=pd.read_csv(R/'work/shenghong/data/daily_raw.csv');assert (D.isST==0).all()
a=json.loads((R/'outputs/shenghong/audit.json').read_text());a['hudianSignalReproduction']=len(signals);a['financialDatesStrictlyEarlier']=len(s);a['latestH1GrowthSignPrimaryChecked']=True;a['dividendCleanup']='2021 provider has two duplicate-date records, one missing cash value; use complete0.19 record, matching textual10派1.9; strict JSON prohibits NaN.';(R/'outputs/shenghong/audit.json').write_text(json.dumps(a,ensure_ascii=False,indent=2));print(a)
