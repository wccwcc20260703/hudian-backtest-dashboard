# -*- coding: utf-8 -*-
import json,pandas as pd
from pathlib import Path
p=Path('work/shenghong');a=json.loads((p/'tencent_daily.json').read_text());daily=a['data']['sz300476']['day'];d=pd.read_csv(p/'data/daily_raw.csv',index_col='date');rows=[]
for x in daily:
 if x[0] in d.index:
  y=d.loc[x[0]];gap=max(abs(float(x[i])-float(y[k])) for i,k in [(1,'open'),(2,'close'),(3,'high'),(4,'low')]);rows.append({'date':x[0],'ohlcMaxGap':gap,'volumeGap':float(x[5])*100-y.volume})
m=json.loads((p/'tencent_m5.json').read_text())['data']['sz300476']['m5'];minrows=[]
for x in m:minrows.append({'date':x[0][:4]+'-'+x[0][4:6]+'-'+x[0][6:8],'high':float(x[3]),'low':float(x[4]),'close':float(x[2]),'vol':float(x[5])*100})
mt=pd.DataFrame(minrows);cross=[]
for date,g in mt.groupby('date'):
 if len(g)==48 and date in d.index:cross.append({'date':date,'dailyHigh':d.loc[date,'high'],'minuteHigh':g.high.max(),'dailyLow':d.loc[date,'low'],'minuteLow':g.low.min(),'volGap':g.vol.sum()-d.loc[date,'volume']})
out={'dailyCompared':len(rows),'dailyOHLCDifferences':sum(x['ohlcMaxGap']>.009 for x in rows),'maxVolumeRoundingGap':max(abs(x['volumeGap']) for x in rows),'dailyDifferences':[x for x in rows if x['ohlcMaxGap']>.009],'minuteRecent':cross,'limitsSource':'https://www.szse.cn/aboutus/trends/news/t20200821_580924.html','financialPrimary':'https://static.cninfo.com.cn/finalpage/2026-08-28/1225522514.PDF','financialPrimaryH1YOY':.333,'financialCheckNote':'H1 positive sign verified; exact report provider value/rounding checked separately; all historical financial vintages not certified'}
Path('outputs/shenghong/source-check.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(out)
