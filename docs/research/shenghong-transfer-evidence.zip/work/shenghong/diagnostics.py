# -*- coding: utf-8 -*-
import json,pandas as pd,numpy as np
from pathlib import Path
p=Path('outputs/shenghong');r=json.loads((p/'metrics.json').read_text());s=pd.read_csv(p/'signal-ledger.csv',index_col='date');Q=pd.read_csv('work/shenghong/data/daily_qfq.csv',index_col='date');s['stockReturn']=Q.close.pct_change().reindex(s.index);s=s.loc['2023-10-09':]
summary=[]
for label,mask in [('all',pd.Series(True,index=s.index)),('earningsOff',s.YOYNI<=0),('rsiHotPositiveEarnings',(s.YOYNI>0)&(s.rsi2lag>60)),('rsiLowPositiveEarnings',(s.YOYNI>0)&(s.rsi2lag<35)),('middlePositiveEarnings',(s.YOYNI>0)&s.rsi2lag.between(35,60))]:
 z=s[mask];summary.append(dict(group=label,days=len(z),positiveDays=int((z.stockReturn>0).sum()),up3pct=int((z.stockReturn>=.03).sum()),down3pct=int((z.stockReturn<=-.03).sum()),meanStockReturn=z.stockReturn.mean(),medianStockReturn=z.stockReturn.median(),targetMean=z.target.mean()))
nav=pd.read_json(p/'daily-nav.json',convert_dates=False);nav.index=nav.date;months=[]
for month,g in nav.groupby(nav.index.str[:7]):
 i=nav.index.get_loc(g.index[0]);prior=nav.iloc[i-1] if i else {k:1e6 for k in ['B','D','L','RD','RL']};x={'month':month,'days':len(g)}
 for k in ['B','D','L','RD','RL']:x[k+'Return']=g.iloc[-1][k]/prior[k]-1;x[k+'MeanExposure']=g[k+'Exposure'].mean()
 x['zeroTargetDays']=int((s.loc[g.index].target==0).sum());months.append(x)
(p/'regime-diagnosis.json').write_text(json.dumps(summary,indent=2));pd.DataFrame(months).to_csv(p/'monthly.csv',index=False)
print('REGIMES',summary)
print('MOST MISSED MONTHS',sorted(months,key=lambda x:x['LReturn']-x['BReturn'])[:5])
for period in ['year1','year2','year3','older']:
 print(period,[(x['name'],round(x['return_']*100,2),round(-x['mdd5']*100,2),round(x['episodeWinRate']*100,2) if x['episodeWinRate'] is not None else None) for x in r if x['period']==period and x['slip']==.0005])
print('DEFAULT FULL', next(x for x in r if (x['period'],x['slip'],x['name'])==('full',.0005,'L')))
