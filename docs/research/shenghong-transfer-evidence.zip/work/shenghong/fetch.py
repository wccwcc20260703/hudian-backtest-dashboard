# -*- coding: utf-8 -*-
import baostock as bs,pandas as pd,socket,json,hashlib,datetime
from pathlib import Path
socket.setdefaulttimeout(30);P=Path('work/shenghong/data');meta={};lg=bs.login();assert lg.error_code=='0'
def save(rs,n):
 rows=[]
 while rs.error_code=='0' and rs.next():rows.append(rs.get_row_data())
 assert rs.error_code=='0',(n,rs.error_msg)
 pd.DataFrame(rows,columns=rs.fields).to_csv(P/(n+'.csv'),index=False);meta[n]=dict(rows=len(rows),fields=rs.fields,sha256=hashlib.sha256((P/(n+'.csv')).read_bytes()).hexdigest());print(n,len(rows),flush=True)
f='date,code,open,high,low,close,preclose,volume,amount,adjustflag,turn,tradestatus,pctChg,isST'
for adj,n in [('3','daily_raw'),('2','daily_qfq')]:save(bs.query_history_k_data_plus('sz.300476',f,start_date='2019-01-01',end_date='2026-10-09',frequency='d',adjustflag=adj),n)
for y in range(2020,2027):
 save(bs.query_history_k_data_plus('sz.300476','date,time,open,high,low,close,volume,amount',start_date=f'{y}-01-01',end_date=min('2026-10-08',f'{y}-12-31'),frequency='5',adjustflag='3'),'minute_'+str(y))
 save(bs.query_dividend_data('sz.300476',str(y),'operate'),'dividend_'+str(y))
for y in range(2019,2027):
 for q in range(1,5):
  if y==2026 and q>2:continue
  save(bs.query_growth_data('sz.300476',year=y,quarter=q),f'growth_{y}_{q}')
bs.logout();meta['fetchedAt']=datetime.datetime.now().astimezone().isoformat();(P/'manifest.json').write_text(json.dumps(meta,indent=2))
