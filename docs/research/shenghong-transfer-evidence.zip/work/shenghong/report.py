# -*- coding: utf-8 -*-
from pathlib import Path
import json,datetime,hashlib,zipfile,html
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path.cwd();out=R/'outputs/shenghong';repo=R/'work/hudian-backtest-dashboard';rows=json.loads((out/'metrics.json').read_text());data=json.loads((out/'data-audit.json').read_text());audit=json.loads((out/'audit.json').read_text());nav=pd.read_json(out/'daily-nav.json');names={'B':'全仓持有','D':'原策略·现金','L':'当前默认·融资','RD':'减仓＋恢复·现金候选','RL':'减仓＋恢复·融资候选'};p=lambda x:'—' if x is None else f'{x*100:.2f}%';get=lambda n,period='full',slip=.0005:next(x for x in rows if (x['name'],x['period'],x['slip'])==(n,period,slip))
# Export clear user-facing ledger tables.
pd.DataFrame(rows).to_csv(out/'all-results.csv',index=False)
for name in names:pd.DataFrame(json.loads((out/(name+'-trades.json')).read_text())).to_csv(out/(name+'-trades.csv'),index=False)
fig,ax=plt.subplots(2,1,figsize=(11,7),sharex=True,gridspec_kw={'height_ratios':[2,1]});colors={'B':'#8191a5','D':'#148497','L':'#bb7827','RD':'#594eaa'}
for name,c in colors.items():
 y=nav[name].to_numpy();ax[0].plot(nav.date,y/1e6,label={'B':'Buy & hold','D':'Cash D','L':'Default margin L','RD':'Cash risk + restore'}[name],color=c,linewidth=1.5);ax[1].plot(nav.date,(y/np.maximum.accumulate(np.r_[1e6,y])[1:]-1)*100,color=c,linewidth=1.2)
ax[0].set_ylabel('Equity / initial capital');ax[0].legend(ncol=2,frameon=False);ax[0].set_title('Shenghong 300476 | frozen strategy transfer | 2023-10-09 to 2026-10-08');ax[1].set_ylabel('Daily-close drawdown %');ax[1].set_xlabel('Date (not minute-level drawdown)')
for a in ax:a.grid(alpha=.2);a.spines[['top','right']].set_visible(False)
fig.tight_layout();fig.savefig(out/'comparison.svg');fig.savefig(out/'comparison.png',dpi=150);plt.close(fig);(repo/'docs/research/shenghong-comparison.svg').write_bytes((out/'comparison.svg').read_bytes())
def table(headers,rows):return '<div class="scroll"><table><tr>'+''.join('<th>'+html.escape(str(v))+'</th>' for v in headers)+'</tr>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in rows)+'</table></div>'
def summary(rs):return table(['方案','净收益','期末资产（万元）','最大回撤¹','完整周期胜率²','盈利日³','平均仓位'],[[names[x['name']],p(x['return_']),f"{x['finalEquity']/10000:.2f}",p(-x['mdd5']),f"{x['episodeWins']}/{x['closedEpisodes']}={p(x['episodeWinRate'])}" if x['closedEpisodes'] else '未结束持有，不计算',f"{x['winningDays']}/{x['days']}={p(x['winningDayFraction'])}",p(x['exposure'])] for x in rs])
body='''<a href="../index.html">← 沪电看板</a> · <a href="archive.html">研究归档</a><h1>原策略迁移到胜宏科技，结果如何？</h1><p class="muted">300476 · 固定参数迁移测试 · 2026-10-10计算 · 不是新推荐策略</p>
<section><h2>结论：不能原样视为成熟可用方案</h2><p>2023-10-09至2026-10-08，同样100万元本金，当前默认融资方案净收益<strong>300.94%</strong>，全仓持有<strong>818.57%</strong>；最大回撤分别为<strong>48.39%</strong>与<strong>55.12%</strong>。收益明显落后，回撤改善也不足以支持“高胜率、低回撤”的判断。</p><p>现金版本最大回撤34.50%，完整持仓周期胜率62.24%；融资后回撤升至48.39%，周期胜率降至60.42%。对你更重视回撤和胜率的偏好而言，融资并没有带来更好的组合。</p><p>这次冻结沪电参数后计算，没有根据胜宏的结果调参。胜宏是用户选定的同行，不是随机股票样本；这是一项跨股票迁移检验，不代表全市场有效，也不是冻结后的未来实盘验证。</p></section>
<section><h2>测试的具体规则</h2><p>当前默认D策略：使用前一交易日两日RSI，低于35目标100%，高于60目标0%，中间50%；最近已披露归母净利润同比不大于0时空仓。目标比前一天降低时09:45执行，否则10:00。融资版把所有100%目标放大到150%；买入后欠款不超过净资产50%，持有期间允许被动超仓，真正的减仓信号及担保风控保留。</p><p>100万元本金，股票佣金万1、最低5元，另计印花税和过户费；单边5基点滑点，融资年息6%。T+1、100股整数手、前一根5分钟量的1%成交上限；每笔最多30万股，假定限价委托。创业板2020-08-24起按20%涨跌幅，此前10%。这些是交易制度适配，不是策略调参。</p><p>全仓基准使用已修复的持续建仓版本；初始资金受相同成本及容量限制，未买完继续尝试，分红保留现金。恢复候选则把上一轮“早盘风险减仓＋次日09:45确认后恢复”整套规则迁移，仅作附加对照，不能把它的差异全部归因于提前买回。</p></section>
<section><h2>三年完整账户</h2>'''
body+=summary([get(n) for n in names])
body+='''<p class="muted">¹ 5分钟收盘采样回撤，不是逐笔盘中最大回撤。² 从空仓到再次空仓的完整持仓周期，计费用与利息；不是每个买点、不是做T往返胜率。³ 盈利日÷727个交易日，空仓和平盘不计盈利。各方案完整T往返胜率未定义，不能宣称60%或80%的日内做T准确率。</p><img src="shenghong-comparison.svg" alt="胜宏科技策略净值与日终回撤对照"><p>图中回撤按日终计算，表中采用更细的5分钟采样，两个数字不应混淆。曲线均从相同本金开始。</p></section>
<section><h2>为什么跑输：过早离场，也可能在下跌中加杠杆</h2><p><strong>2025年3月：</strong>全仓持有+58.41%，融资策略−3.03%；21个交易日中13天目标空仓，平均实际仓位38.21%。<strong>2025年6月：</strong>全仓+55.04%，融资+7.49%；20天中16天目标空仓，平均仓位14.81%。短期RSI偏高后继续上涨，使反转策略失去参与机会。</p><p><strong>2024年2月：</strong>全仓持有+46.27%，策略整月空仓，原因包含负增长财报门槛。<strong>2024年8月：</strong>全仓−12.19%，融资策略−31.33%；抄跌反转与杠杆共同放大亏损。上述月份按结果挑选用于解释失败，不能反过来当作预先可知的交易条件。</p><p>在727天中，业绩门槛关闭131天；另有251天业绩为正但昨日RSI大于60而目标空仓，其中65天股票当日涨幅至少3%。这是事后条件分组，不等于65次可以完整抓住的涨幅；策略在开盘仍可能持有前日仓位，实际损益以账本为准。</p></section>
<section><h2>固定年度与更早历史</h2><p>每段独立以100万元开始。第一年2023-10-09至2024-10-08，第二年2024-10-09至2025-10-08，第三年2025-10-09至2026-10-08；更早段2020-01-02至2023-09-28。</p>'''
body+=table(['区间','方案','净收益','最大回撤','完整周期胜率'],[[period,names[n],p(get(n,period)['return_']),p(-get(n,period)['mdd5']),p(get(n,period)['episodeWinRate'])] for period in ['year1','year2','year3','older'] for n in ['B','D','L','RD','RL']])
body+='''<p>默认融资第一年亏6.41%，全仓却涨110.67%；第二年201.59%仍显著低于全仓534.92%；第三年在全仓下跌28.41%时盈利38.50%。收益改善主要体现在后段避跌，无法弥补前两段的机会损失。更早历史融资收益−6.67%、回撤60.81%，没有稳定性证据。</p></section>
<section><h2>滑点加倍与尾部风险</h2>'''
body+=summary([get(n,slip=.001) for n in ['B','D','L','RD','RL']])
body+=table(['5基点方案','最差单日','最差5%日均','已结束周期盈亏金额比','未结束周期浮动损益（元）'],[[names[n],p(get(n)['worstDay']),p(get(n)['worst5pctDayMean']),f"{get(n)['episodeProfitFactor']:.2f}" if get(n)['episodeProfitFactor'] is not None else '—',f"{get(n)['openEpisodeMarked']:,.2f}"] for n in names])
body+='<p>默认融资最差单日−18.27%，持仓比例峰值178.62%是价格下跌后的被动漂移；并不代表新买入突破50%净资产欠款限制。期末未结束持仓周期亏损已按市值计入净值及回撤，没有靠不平仓隐藏亏损。股息税仍沿用原模型简化（策略20%、长期持有基准0%），未精确重建每批股份的税龄。</p></section><section><h2>7月前后与领先比例</h2><p>下面是三年账户连续承接的分段收益，不在7月1日重置持仓。累计领先比例按每个交易日的期末资产与全仓比较；63日滚动领先按各自滚动区间的净值涨幅比较。</p>'
body+=table(['方案','截至2026-06-30收益','7月起收益','累计领先比例','最长连续落后','63日滚动领先'],[[names[n],p(get(n)['preJuly']),p(get(n)['postJuly']),p(get(n)['leadFraction']) if n!='B' else '基准',get(n)['longestBehind'] if n!='B' else '—',p(get(n)['rolling63Lead']) if n!='B' else '—'] for n in names])
body+='<p>默认融资只有13.48%的交易日累计领先全仓，最长连续落后569个交易日。现金与融资都不能依靠期末盈利就证明迁移成功。</p></section><section><h2>附加候选是否值得继续</h2><p>早盘风险减仓＋次日恢复的现金候选收益172.45%、回撤26.47%、周期胜率62/99=62.63%；相较原现金版本回撤改善，但胜率仅小幅变化。该候选只在第一年度降低回撤，第二、三年度回撤反而略增；它不是已验证的新默认。融资候选回撤仍有41.44%。没有在胜宏数据上重新选择参数。</p><p>若继续优化，优先研究强趋势期间保留基础仓位、RSI高位钝化时是否需要清仓，以及负增长财报门槛是否过于滞后。必须预先固定规则再检验，不能单凭这几个已知大涨月倒推完美买点。本次到此完成迁移测试，沪电默认保持不变。</p></section><section><h2>数据核验、未决事项与下载</h2>'
body+=f"<p>下载2020年以来{data['sessions']}个完整48根5分钟交易日，三年段727天；腾讯800日日线与BaoStock的OHLC全部相同，成交量差最多50股为手数取整。但三年有{data['highLowGap2cMain']}天分钟最高最低价与日线至少差2分，{data['closeGap2cMain']}天收盘差至少2分，{data['volGap1pctMain']}天成交量差超过1%。近期另一分钟接口同样存在极值缺失，不能视为独立逐笔核验。因此这里是可复算的同口径研究模拟，不能声称精确成交或预测胜率。</p>"
body+=f"<p>完成80组固定对照、{audit['ledger']}笔账本及{audit['loanChecks']}次融资买入额度核对；沪电原{audit['hudianSignalReproduction']}天信号完全复现，交换规则适配后原沪电回测序列一致。胜宏每个财务数据使用日严格晚于pubDate；最新H1同比33.30%与官方摘要一致，但所有历史财报修订版本、历史融资标的资格、券源额度及实际成交延迟没有逐日核实。2021年分红源有同日一条缺值、一条0.19元，采用完整记录，不把缺值当零。</p>"
body+='''<p>回测截至2026-10-08以与沪电保持相同区间；2026-10-09日线可取得，但未纳入分钟回测。现金方案可以直接比较，融资结果以券商允许该股及额度为前提。没有真实交易，也未更换任何默认方案。</p>
<p>来源：<a href="https://www.szse.cn/aboutus/trends/news/t20200821_580924.html">深交所创业板交易规则</a> · <a href="https://static.cninfo.com.cn/finalpage/2026-08-28/1225522514.PDF">胜宏2026半年报摘要</a> · <a href="https://www.baostock.com/">BaoStock</a>；原始响应、日期、公式与逐笔结果见证据包。</p>
<p><a href="shenghong-transfer-evidence.zip">下载全部80组结果、逐笔记录、原始数据及脚本</a></p></section>'''
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>胜宏科技｜沪电策略迁移检验</title><style>body{background:#f3f6fa;color:#1b304a;font:16px/1.75 system-ui,sans-serif;margin:0}main{max-width:1200px;margin:30px auto;padding:20px}section{background:white;border:1px solid #dde5eb;border-radius:14px;padding:24px;margin:20px 0}h1{font-size:30px}h2{font-size:22px}a{color:#147e85}.muted{color:#6b7a8c;font-size:14px}.scroll{overflow:auto}table{border-collapse:collapse;font-size:14px;width:100%}td,th{padding:11px;border-bottom:1px solid #e6ecf1;text-align:left;white-space:nowrap}th{background:#f6f8fa}img{max-width:100%;height:auto}</style></head><body><main>'+body+'</main></body></html>'
(repo/'docs/research/shenghong-transfer.html').write_text(page);(out/'report.html').write_text(page.replace('src="shenghong-comparison.svg"','src="comparison.svg"'))
a=repo/'docs/research/archive.html';s=a.read_text();entry='<p><a href="shenghong-transfer.html">胜宏科技迁移检验：默认融资+301%，为何落后全仓+819%？ ↗</a></p>'
if 'shenghong-transfer.html' not in s:a.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+entry))
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in list((R/'work/shenghong/data').glob('*.csv'))+[R/'work/shenghong/data.json']};(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
(out/'README.txt').write_text('Extract into empty directory. Run node work/shenghong/study.mjs, node work/shenghong/verify.mjs to reproduce results from included prepared data. Optional rebuild raw data uses pandas/numpy and build_data.py. Report/checkpoint generation expects original workspace and is not required for numeric reproduction. Do not rerun setup.py over frozen registration. Research simulation only; no real orders.\n')
with zipfile.ZipFile(repo/'docs/research/shenghong-transfer-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in [out,R/'work/shenghong']:
  for f in folder.rglob('*'):
   if f.is_file() and f.suffix not in ['.log','.pyc'] and f.name!='publication.json':z.write(f,str(f.relative_to(R)))
 for name in ['work/opening_guard/metrics.mjs','work/hudian-backtest-dashboard/docs/attribution.js','work/hudian-backtest-dashboard/docs/finance-engine.js','work/hudian-backtest-dashboard/docs/benchmark.js','work/hudian-backtest-dashboard/docs/fees.js','work/risk_priority/data.json','work/risk_priority/gates.json']:
  z.write(R/name,name)
cpath=R/'work/research-checkpoint.json';c=json.loads(cpath.read_text());c['shenghongTransfer']={'updatedAt':datetime.datetime.now().astimezone().isoformat(),'status':'verified locally, publication pending','outputs':'outputs/shenghong','parameterTuning':False,'defaultChanged':False,'finding':'FrozenDefaultLreturn300.94 vsB818.57;DD48.39vs55.12;episode58/96=60.42%;longestbehind569. Cash191.85/DD34.50. Mainmissed2025March/June;131financialoffdays. EarlierL-6.67/DD60.81. RDcash172.45/DD26.47 butonly1/3annualDDimprovement.','audit':audit};c['updatedAt']=c['shenghongTransfer']['updatedAt'];cpath.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print('report,chart,evidence,checkpoint saved')
