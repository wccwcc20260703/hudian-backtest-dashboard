# -*- coding: utf-8 -*-
import json,datetime,hashlib
from pathlib import Path
r=Path.cwd();p=r/'work/shenghong';out=r/'outputs/shenghong';repo=r/'work/hudian-backtest-dashboard/docs'
plan={'registeredAt':datetime.datetime.now().astimezone().isoformat(),'stock':'300476 胜宏科技','mainQuestion':'Transfer current user-selected D_all_full150_buycaponly with frozen parameters, no stock-specific tuning','period':'2023-10-09..2026-10-08 matched to Hudian; earlier2020..2023 supplemental if available','parameters':{'rsi':2,'low':35,'high':60,'targets':[1,.5,0],'growthGate':'Latest statDate among pubDate strictly earlier than trade date; YOYNI<=0 =>flat','buyTime':'10:00','reduceTime':'09:45 when target below preceding session target','capital':1000000,'commission':.0001,'minimum':5,'slip':[.0005,.001],'loanRate':.06,'buyLoanCap':'.5*netequity','passiveDrift':'hold','capacity':'.01*previous5mvolume','T1':True},'variants':['cashD','defaultL','fullhold','previousrisk+restore as secondary transfer, not retuned'],'exchangeAdaptation':'20% from2020-08-24,10%before;100sharelots;300000 share per fill upper bound (limit order assumption), no fictional limit fills','evaluation':['full','3fixedannual','older','pre/postJuly continuous','cumulative/63drolling leading','winning accountdays','closedholdingepisodes','openepisode mark','5/10bps'],'data':'Raw5m for fills,adjusted dailyRSI;rawdaily marks;dividend/bonus adjustments. Minute/daily discrepancies retained as limitations, no exact-tick claim. Financial vintages not fully certifiable. No optimization; selected peer is not random-universe validation.'}
(out/'plan-before-results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
for src,dst in [(repo/'finance-engine.js','finance.mjs'),(repo/'benchmark.js','benchmark.mjs'),(r/'work/risk_restore/engine.mjs','restore.mjs')]:
 s=src.read_text();s=s.replace("'./fees.js?v=74745f12a7da'","'../hudian-backtest-dashboard/docs/fees.js'")
 # Original restore import already correct from work sibling.
 s=s.replace('data.reference[d]*1.1','data.reference[d]*(1+(data.limitPct?.[d]??.1))').replace('data.reference[d]*.9','data.reference[d]*(1-(data.limitPct?.[d]??.1))')
 s=s.replace('Math.trunc(data.bars[d][j-1][4]*.01/100)*100','Math.min(300000,Math.trunc(data.bars[d][j-1][4]*.01/100)*100)')
 (p/dst).write_text(s)
print('Frozen transfer specification and isolated exchange-adapted engines saved')
