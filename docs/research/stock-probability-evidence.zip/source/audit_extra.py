# -*- coding: utf-8 -*-
import ast,sys,json,math,types
from pathlib import Path
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/stock_probability';z=np.load(O/'features_labels.npz');X=z['features'];dates=z['dates'];pred=pd.read_csv(O/'predictions.csv');checked=0
# Reconstruct selected live-like forecasts from truncated histories, then overwrite current/future labels/features.
def forecast(x,y,d,t):
 ids=np.arange(d-504,d);hist=x[ids,t];ok=np.isfinite(hist).all(axis=1);ids=ids[ok];hist=hist[ok];med=np.median(hist,axis=0);iq=np.maximum(np.quantile(hist,.75,axis=0)-np.quantile(hist,.25,axis=0),1e-6);delta=np.clip((hist-med)/iq,-3,3)-np.clip((x[d,t]-med)/iq,-3,3);near=ids[np.argsort((delta**2).sum(axis=1),kind='stable')[:80]]
 return ((y[near,t]>0).sum()+20*(y[ids,t]>0).mean())/100
for d in [504,700,910,1200,len(dates)-1]:
 for t,j in enumerate(z['anchors']):
  for side,key in [(1,'buy5'),(-1,'sell5')]:
   y=z[key];a=forecast(X,y,d,t);short=forecast(X[:d+1],y[:d+1],d,t);xx=X.copy();yy=y.copy();xx[d+1:]=999;yy[d:]=-999;b=forecast(xx,yy,d,t)
   row=pred[(pred.day==d)&(pred.bar==j)&(pred.side==side)&(pred.slip==.0005)].iloc[0];assert abs(a-row.prob)<1e-12 and a==short==b;checked+=1
src=ast.parse((R/'work/stock_probability/study.py').read_text());ns={'np':np,'math':math};exec(compile(ast.Module(body=[n for n in src.body if isinstance(n,ast.FunctionDef) and n.name in ['px','fee','episode']],type_ignores=[]),'execution_functions','exec'),ns)
def setup():
 b=np.zeros((1,48,6));b[:,:,:4]=100;b[:,:,4]=1e6;b[:,:,5]=1e8;b[0,12:,0]=101
 ns['e']=types.SimpleNamespace(B=b,REF=np.array([100.]),C=np.array([101.]),STAMP=np.array([.0005]),TRANSFER=np.array([.00001]),DATES=np.array(['2026-01-05']))
 return b
checks=[]
b=setup();r,t=ns['episode'](0,{6:1,12:-1},.0005);assert len(t)==2 and [x['bar'] for x in t]==[6,12] and t[-1]['shares']==5000 and t[-1]['available']==5000-t[0]['qty'];checks.append('Buyfirst sells oldstock at30min, ignoreslateropportunity, does not sell same-day purchasedshares')
b=setup();r,t=ns['episode'](0,{6:-1},.0005);assert len(t)==2 and t[-1]['shares']==5000 and t[-1]['available']==5000-t[0]['qty'];checks.append('Sellfirst buyback replenishes holdings but not availableoldstock')
b=setup();b[0,11,4]=10000;r,t=ns['episode'](0,{6:1},.0005);assert t[1]['qty']==100 and t[-1]['bar']==13 and r['complete'];checks.append('Volume-limited exit continues afterhorizon, executiondiffersfrom ideal30minlabel')
b=setup();b[0,12:,0]=90;ns['e'].C[0]=90;r,t=ns['episode'](0,{6:1},.0005);assert len(t)==1 and not r['complete'] and r['remaining']>0 and r['net']<0;checks.append('Limitdown blocks sell, retainedinventory close-marked notdeleted')
b=setup();b[0,6,0]=110;r,t=ns['episode'](0,{6:1},.0005);assert not r['traded'];checks.append('Limitup entry cannot be assumedfilled')
(O/'additional_audit.json').write_text(json.dumps({'forecastPrefixAndFuturePoisonChecks':checked,'executionSyntheticChecks':checks,'count':len(checks)},indent=2));print(json.dumps({'forecastChecks':checked,'syntheticChecks':len(checks)}))
