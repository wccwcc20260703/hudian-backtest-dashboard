# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/stock_probability';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
e=f.e;z=np.load(O/'features_labels.npz');X=z['features'];POINTS=z['anchors'];labels=z['buy5'];sell=z['sell5'];periods={'early':('2023-10-09','2025-01-01'),'validation':('2025-01-01','2026-07-01'),'recent':('2026-07-01','2026-10-09'),'full':('2023-10-09','2026-10-09')}
# Declared diagnostic after model result; NOT new trading rules or independent hypotheses.
conditions={'all':(None,None),'gap_down':(0,(-np.inf,-.25)),'gap_flat':(0,(-.25,.25)),'gap_up':(0,(.25,np.inf)),'below_vwap':(1,(-np.inf,-.2)),'near_vwap':(1,(-.2,.2)),'above_vwap':(1,(.2,np.inf)),'falling15':(2,(-np.inf,-.1)),'flat15':(2,(-.1,.1)),'rising15':(2,(.1,np.inf)),'low_volume':(3,(-np.inf,np.log(.8))),'normal_volume':(3,(np.log(.8),np.log(1.5))),'high_volume':(3,(np.log(1.5),np.inf)),'trend_down':(4,(-np.inf,-.05)),'trend_flat':(4,(-.05,.05)),'trend_up':(4,(.05,np.inf)),'range_low':(5,(-np.inf,.2)),'range_middle':(5,(.2,.8)),'range_high':(5,(.8,np.inf))}
rows=[]
for t,j in enumerate(POINTS):
 gross=e.B[:,j+6,0]/e.B[:,j,0]-1
 for period,(start,end) in periods.items():
  universe=(e.DATES>=start)&(e.DATES<end)
  for cond,(k,bounds) in conditions.items():
   mask=universe if k is None else universe&(X[:,t,k]>=bounds[0])&(X[:,t,k]<bounds[1]);vals=gross[mask];n=len(vals)
   if n==0:continue
   p=(vals>0).mean();den=1+1.96**2/n;mid=(p+1.96**2/(2*n))/den;half=1.96*np.sqrt(p*(1-p)/n+1.96**2/(4*n*n))/den
   rows.append(dict(period=period,bar=int(j),condition=cond,n=n,grossUp=p,upLow=mid-half,upHigh=mid+half,grossMean=vals.mean(),median=np.median(vals),q10=np.quantile(vals,.1),q90=np.quantile(vals,.9),buyNetHit=(labels[mask,t]>0).mean(),sellNetHit=(sell[mask,t]>0).mean(),baselineUp=(gross[universe]>0).mean(),excessUp=p-(gross[universe]>0).mean()))
df=pd.DataFrame(rows);df.to_csv(O/'conditional_profile.csv',index=False)
# All comparisons retained, descriptive consistency not statistical discovery significance.
a=df[df.period=='early'];b=df[df.period=='validation'];paired=a.merge(b,on=['bar','condition'],suffixes=('_early','_later'));paired['sameDirection']=(paired.excessUp_early*paired.excessUp_later>0);paired['enoughBoth']=(paired.n_early>=40)&(paired.n_later>=40);paired.to_csv(O/'profile_consistency.csv',index=False)
(O/'profile_note.json').write_text(json.dumps({'status':'Diagnostic added after primary model results; all18factorbins retained,not traded','thresholds':{k:[v[0],str(v[1])] for k,v in conditions.items()},'confidence':'Wilson intervals for descriptive single cells; no multiplecomparison significance or guarantee; withincondition one observation/day/time','selection':'No profile cell replaces probability model ordefault'}))
print(df[(df.period=='full')&(df.condition=='all')].to_string(index=False));print(paired[(paired.enoughBoth)&(paired.sameDirection)&(paired.excessUp_early.abs()>=.05)&(paired.excessUp_later.abs()>=.05)][['bar','condition','n_early','n_later','grossUp_early','grossUp_later','excessUp_early','excessUp_later','buyNetHit_later','sellNetHit_later']].to_string(index=False))
