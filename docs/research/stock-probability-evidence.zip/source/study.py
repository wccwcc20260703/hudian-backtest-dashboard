# -*- coding: utf-8 -*-
from pathlib import Path
import json,sys,math,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/stock_probability';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
e=f.e;POINTS=[6,12,18,30,36];WINDOW=504;K=80;PRIOR=20;THRESH=.60
plan={'createdAt':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'Learn Hudians conditional intraday probabilities from prior similar days, then test calibration and probability-guided T rather than fit isolated indicator thresholds.','features':['openinggap/priorATR','completedclose minus cumulativeVWAP / priorATR','completed15minmomentum/priorATR','log cumulativevolume / previous20days same-time cumulativevolume','prior20dayreturn','position within range known sofar'], 'anchors':['10:00','10:30','11:00','13:30','14:00'],'labels':'Net buy-first and sell-first roundtrip return to30tradingminutes later on5minuteopen grid, fixed100knotionalrounded100shares,adverseslip,tickrounding,mincommission,stamp/transfer. Labels assume executable idealquote; separate constrained execution below. Worst/best gross intermediate open movement reported, NOT intrabar extrema.', 'estimator':'For each day andanchor use only preceding504completedtradingdays; require full504 window; scale6features by priorwindow median/IQR,clip[-3,3]; equalweight80nearestsquaredEuclideandays, smooth with20pseudoobservations at samewindowunconditional probability/mean. No hyperparameter search. Distinct timeanchor; one sample per historicalday in each lookup.','decision':'At eachanchor choose buy orsell if estimated netpositiveprob>=0.60 AND estimatedmean netreturn>0; at most first executable signal/day. Ignorelater signals once entered. Nozero-cost assumptions. Fixed0.6 not optimized.','execution':'Independentdaily1m account with50%referencevalueovernightoldshares andcash;workingnotional100krounded100;entry/exit1%priorbarvolume cap andlimits;T+1selloldshares;cashreserve>=200k;no borrowing. Exit attempts atscheduled30minhorizon theneach5minthrough14:50;unfinishedbuy/exposure orsell/sharedeficit close-marked,not discarded. No further intra-daycycle. Baselines: noT, unconditional10:00buy-first, unconditional10:00sell-first.5/10bps.','evaluation':'All dated predictions preserved, reliabilityandBrier versus same-windowunconditional probabilities; sameanchor calibration separately toavoid overlapping sample inference; chronologicalsegments, fixedannual,oldereligiblehistory. Show dailyblock-bootstrap95% interval for Brier advantage (fixedseed,500draws). Wholehistory previouslyseen,notnewblindtest. No continuouswealth/financing ororiginalgoalclaim.','freezeSHA':hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(O/'plan_before_results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2));p=R/'work/research-checkpoint.json';c=json.loads(p.read_text());c['activeBatch']='24_stock_probability';c['currentQuestion']=plan['question'];c['userSteering']='先学习沪电股份股性与条件概率，再用当时可知的概率指导买卖点；不只套用网络指标。';p.write_text(json.dumps(c,ensure_ascii=False,indent=2))
atr=(e.ATR/e.Q.close).shift().reindex(e.DATES).to_numpy()*e.REF
cv=np.cumsum(e.B[:,:,4],axis=1);vw=np.cumsum(e.B[:,:,5],axis=1)/np.maximum(cv,1);expected=pd.DataFrame(cv).rolling(20,min_periods=20).mean().shift().to_numpy();rel=cv/expected
ret20=e.Q.close.pct_change(20).shift().reindex(e.DATES).to_numpy()
def fee(d,q,p,side):return max(5,q*p*.00025)+q*p*(e.TRANSFER[d]+(e.STAMP[d] if side<0 else 0))
def px(raw,side,slip):return math.ceil(raw*(1+slip)*100-1e-8)/100 if side>0 else math.floor(raw*(1-slip)*100+1e-8)/100
def target(d,j,side,slip):
 a=px(e.B[d,j,0],side,slip);b=px(e.B[d,j+6,0],-side,slip);q=int(100000/a/100)*100
 return (side*q*(b-a)-fee(d,q,a,side)-fee(d,q,b,-side))/(q*a)
X=np.empty((e.N,5,6));Y={};paths=np.empty((e.N,5,2))
for t,j in enumerate(POINTS):
 lo=np.min(e.B[:,:j,2],axis=1);hi=np.max(e.B[:,:j,1],axis=1);cl=e.B[:,j-1,3]
 X[:,t,:]=np.stack([(e.B[:,0,0]-e.REF)/atr,(cl-vw[:,j-1])/atr,(cl-e.B[:,j-4,3])/atr,np.log(rel[:,j-1]),ret20,(cl-lo)/np.maximum(hi-lo,.01)],axis=1)
 path=e.B[:,j+1:j+7,0]/e.B[:,j,0,None]-1;paths[:,t,0]=path.min(axis=1);paths[:,t,1]=path.max(axis=1)
for slip in [.0005,.001]:
 for side in [1,-1]:Y[slip,side]=np.array([[target(d,j,side,slip) for j in POINTS] for d in range(e.N)])
rows=[];matches=[]
for d in range(WINDOW,e.N):
 for t,j in enumerate(POINTS):
  ids=np.arange(d-WINDOW,d);h=X[ids,t];valid=np.isfinite(h).all(axis=1);ids=ids[valid];h=h[valid]
  if len(h)<K or not np.isfinite(X[d,t]).all():continue
  med=np.median(h,axis=0);scale=np.percentile(h,75,axis=0)-np.percentile(h,25,axis=0);scale=np.maximum(scale,1e-6)
  z=np.clip((h-med)/scale,-3,3);now=np.clip((X[d,t]-med)/scale,-3,3);dist=((z-now)**2).sum(axis=1);order=np.argsort(dist,kind='stable')[:K];near=ids[order];assert near.max()<d
  # Confirm removing all future rows leaves scale, neighbor ordering, and labels unchanged by construction.
  matches.append(dict(date=str(e.DATES[d]),bar=j,trainThrough=str(e.DATES[d-1]),neighborFirst=str(e.DATES[near.min()]),neighborLast=str(e.DATES[near.max()]),neighbors='|'.join(map(str,e.DATES[near])),meanDistance=float(dist[order].mean())))
  for slip in [.0005,.001]:
   for side in [1,-1]:
    hist=Y[slip,side][ids,t];yy=Y[slip,side][near,t];p0=(hist>0).mean();p=((yy>0).sum()+PRIOR*p0)/(K+PRIOR);mean=(yy.sum()+PRIOR*hist.mean())/(K+PRIOR)
    rows.append(dict(date=str(e.DATES[d]),day=d,bar=j,slip=slip,side=side,prob=p,baseProb=p0,expected=mean,realized=Y[slip,side][d,t],won=bool(Y[slip,side][d,t]>0),qualified=bool(p>=THRESH and mean>0),neighborCount=K,rawNeighborProb=(yy>0).mean(),neighborMean=yy.mean(),predAdverse=float(paths[near,t,0 if side==1 else 1].mean()),actualAdverse=paths[d,t,0 if side==1 else 1]))
pred=pd.DataFrame(rows);pred.to_csv(O/'predictions.csv',index=False);pd.DataFrame(matches).to_csv(O/'neighbor_audit.csv',index=False);np.savez_compressed(O/'features_labels.npz',dates=e.DATES,features=X,anchors=POINTS,buy5=Y[.0005,1],sell5=Y[.0005,-1])
periods={'full':('2023-10-09','2026-10-09'),'early':('2023-10-09','2025-01-01'),'validation':('2025-01-01','2026-07-01'),'recent':('2026-07-01','2026-10-09'),'older':(str(e.DATES[WINDOW]),'2023-10-09')}
for y in range(3):periods['year'+str(y+1)]=(f'{2023+y}-10-09',f'{2024+y}-10-09')
cal=[];reliability=[]
for period,(start,end) in periods.items():
 for slip in [.0005,.001]:
  for side in [1,-1]:
   for j in [0]+POINTS:
    q=pred[(pred.date>=start)&(pred.date<end)&(pred.slip==slip)&(pred.side==side)]
    if j:q=q[q.bar==j]
    brier=((q.prob-q.won.astype(int))**2).mean();baseline=((q.baseProb-q.won.astype(int))**2).mean();chosen=q[q.qualified]
    cal.append(dict(period=period,slip=slip,side=side,bar=j,n=len(q),qualified=len(chosen),predicted=chosen.prob.mean(),observed=chosen.won.mean(),meanLabel=chosen.realized.mean(),brier=brier,baseBrier=baseline,brierAdvantage=baseline-brier))
    if j==0:
     for low,high in [(0,.4),(.4,.5),(.5,.6),(.6,.7),(.7,1.00001)]:
      v=q[(q.prob>=low)&(q.prob<high)];reliability.append(dict(period=period,slip=slip,side=side,lower=low,upper=high,n=len(v),meanPrediction=v.prob.mean(),observed=v.won.mean(),meanLabel=v.realized.mean()))
pd.DataFrame(cal).to_csv(O/'calibration.csv',index=False);pd.DataFrame(reliability).to_csv(O/'reliability.csv',index=False)
# Day-block bootstrap for calibration differences; five overlapping intraday windows never independent replicates.
rng=np.random.default_rng(2463);boot=[]
for period,(start,end) in periods.items():
 for side in [1,-1]:
  q=pred[(pred.date>=start)&(pred.date<end)&(pred.slip==.0005)&(pred.side==side)].copy();q['adv']=(q.baseProb-q.won.astype(int))**2-(q.prob-q.won.astype(int))**2;v=q.groupby('date').adv.mean().to_numpy();samples=np.array([rng.choice(v,len(v),replace=True).mean() for _ in range(500)])
  boot.append(dict(period=period,side=side,days=len(v),advantage=v.mean(),lo=np.quantile(samples,.025),hi=np.quantile(samples,.975)))
pd.DataFrame(boot).to_csv(O/'calibration_day_bootstrap.csv',index=False)
# Separate execution layer, no new model fitting. At most first executable decision per day.
def episode(d,choices,slip):
 b=e.B[d];old=int(500000/e.REF[d]/100)*100;cash0=1e6-old*e.REF[d];cash=cash0;sh=old;avail=old;outstanding=0;first=-1;entryside=0;exitstart=-1;fills=[];q0=0;lo=round(e.REF[d]*.9+1e-8,2);hi=round(e.REF[d]*1.1+1e-8,2)
 for j in range(1,47):
  side=0;qty=0;cap=int(b[j-1,4]*.01/100)*100;op=b[j,0]
  if outstanding and j>=exitstart:side=-entryside;qty=min(outstanding,cap)
  elif first<0 and j in choices:
   side=choices[j];fill=px(op,side,slip);qty=min(int(100000/fill/100)*100,cap,avail)
  if not side or qty<=0:continue
  fill=px(op,side,slip)
  if (side>0 and (op>=hi-.005 or fill>hi)) or (side<0 and (op<=lo+.005 or fill<lo)):continue
  if side<0:qty=min(qty,avail)
  if side>0:
   while qty>0 and cash-qty*fill-fee(d,qty,fill,side)<200000-1e-8:qty-=100
  if qty<=0:continue
  costs=fee(d,qty,fill,side);cash-=side*qty*fill+costs;sh+=side*qty
  if side<0:avail-=qty
  if first<0:first=j;entryside=side;outstanding=qty;q0=qty;exitstart=j+6
  else:outstanding-=qty
  fills.append(dict(date=str(e.DATES[d]),bar=j,side=side,qty=qty,price=fill,fee=costs,cash=cash,shares=sh,available=avail));assert avail>=0 and cash>=200000-1e-6
  if first>=0 and outstanding==0:break
 net=cash+sh*e.C[d]-(cash0+old*e.C[d]);return dict(date=str(e.DATES[d]),traded=first>=0,side=entryside,entryBar=first,quantity=q0,complete=first>=0 and outstanding==0,remaining=outstanding,net=net),fills
accounts=[];trades=[]
for slip in [.0005,.001]:
 sp=pred[pred.slip==slip]
 for d in range(WINDOW,e.N):
  q=sp[(sp.day==d)&sp.qualified];choices={int(r.bar):int(r.side) for r in q.itertuples()};assert len(choices)==len(q)
  for variant,cc in [('probability',choices),('buy10',{6:1}),('sell10',{6:-1}),('none',{})]:
   rr,tt=episode(d,cc,slip);rr.update(variant=variant,slip=slip);accounts.append(rr)
   for z in tt:z.update(variant=variant,slip=slip);trades.append(z)
acc=pd.DataFrame(accounts);acc.to_csv(O/'daily_execution.csv',index=False);pd.DataFrame(trades).to_csv(O/'fills.csv',index=False)
metrics=[]
for period,(start,end) in periods.items():
 for slip in [.0005,.001]:
  for variant in ['probability','buy10','sell10','none']:
   q=acc[(acc.date>=start)&(acc.date<end)&(acc.slip==slip)&(acc.variant==variant)];b=q[q.traded];done=b[b.complete]
   metrics.append(dict(period=period,slip=slip,variant=variant,days=len(q),tradeDays=len(b),completeDays=len(done),completeHit=(done.net>0).mean(),averagePerDay=q.net.mean(),averagePerTrade=b.net.mean(),sumNet=q.net.sum(),worst=q.net.min(),buyDays=int((b.side==1).sum()),sellDays=int((b.side==-1).sum())))
mm=pd.DataFrame(metrics);mm.to_csv(O/'execution_metrics.csv',index=False)
# Ledger independently reconstructs all cash and inventory from output.
ledger=0
for (date,slip,variant),g in pd.DataFrame(trades).groupby(['date','slip','variant']):
 d=int(np.searchsorted(e.DATES,date));old=int(500000/e.REF[d]/100)*100;cash=1e6-old*e.REF[d];sh=old;av=old
 for t in g.itertuples():
  q=int(t.qty);cost=fee(d,q,t.price,t.side);cash-=t.side*q*t.price+cost;sh+=t.side*q
  if t.side<0:av-=q
  assert abs(cash-t.cash)<1e-6 and sh==t.shares and av==t.available and q<=int(e.B[d,int(t.bar)-1,4]*.01/100)*100;ledger+=1
(O/'audit.json').write_text(json.dumps({'neighborLookups':len(matches),'predictions':len(pred),'ledgerFills':ledger,'ledgerError':0,'trainingBeforeEveryPrediction':True,'notContinuousPortfolio':True,'defaultChanged':False,'freezeSHA':plan['freezeSHA']},indent=2))
print(pd.DataFrame(cal).query("period in ['full','validation','recent','older'] and slip==0.0005 and bar==0").to_string(index=False));print(mm.query("period in ['full','early','validation','recent','older'] and slip==0.0005").to_string(index=False));print(pd.DataFrame(boot).to_string(index=False))
