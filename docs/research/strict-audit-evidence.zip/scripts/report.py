import json,math,hashlib,html,zipfile
from pathlib import Path
from datetime import datetime
r=Path.cwd(); out=r/'outputs/strict_audit'; repo=r/'work/hudian-backtest-dashboard'; rows=json.loads((out/'stress.json').read_text()); d=json.loads((repo/'docs/data.json').read_text()); old=json.loads((r/'outputs/risk_priority/metrics.json').read_text())
now=datetime.now().astimezone().isoformat(); pct=lambda x:f'{x*100:.2f}%'
labels={'D':'D 现金','L':'默认：D 全满仓信号融资150%','T':'候选：D 趋势融资150%','B':'持有基准'}
checks=[]
for x in rows:
 if x['variant']=='current 5bp':
  prior=next(v for v in old if v['period']=='full' and v['slip']==.0005 and v['name']=={'D':'D','L':'D_all_full_1.5','T':'D_trend_1.5'}[x['account']])
  for k in ['return_','mdd5','episodeWins','closedEpisodes']:assert abs(x[k]-prior[k])<1e-10;checks.append([x['account'],k])
assert len(d['dates'])==727
counts={}; outside=0
for date,b,day in zip(d['dates'],d['bars'],d['daily']):
 y=date[:4];c=counts.setdefault(y,dict(days=0,highLowMismatch=0,volumeAbove1pct=0));c['days']+=1
 c['highLowMismatch']+=int(abs(max(x[1] for x in b)-day[1])>.011 or abs(min(x[2] for x in b)-day[2])>.011)
 c['volumeAbove1pct']+=int(abs(sum(x[4] for x in b)/day[4]-1)>.01)
 outside+=sum(x[0]>day[1]+.011 or x[0]<day[2]-.011 or x[3]>day[1]+.011 or x[3]<day[2]-.011 for x in b)
files=['work/hudian-backtest-dashboard/docs/engine.js','work/hudian-backtest-dashboard/docs/finance-engine.js','work/hudian-backtest-dashboard/docs/data.json','work/risk_priority/data.json','work/risk_priority/gates.json','work/strict_audit/run.mjs','work/round2/finalize_tests.py','work/round2/frozen_candidates.json','work/hudian-backtest-dashboard/docs/signal-strength.js']
manifest={'generatedAt':now,'scope':'code/data/statistical/execution review, not third-party assurance or clean-data recertification','baselineChecks':len(checks),'checks':checks,'dataByYear':counts,'barOpenOrCloseOutsideDailyRange':outside,'knownHistory':True,'defaultChanged':False,'hashes':{f:hashlib.sha256((r/f).read_bytes()).hexdigest() for f in files}}
(out/'verification.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
source=[('回测过拟合原始研究','https://escholarship.org/uc/item/4w1110bb'),('证监会：融资融券维持担保比例由券商与客户约定','https://www.csrc.gov.cn/csrc/c100028/c1000931/content.shtml'),('税务总局：财税〔2015〕101号','https://fgk.chinatax.gov.cn/zcfgk/c102416/c5203902/content.html')]
body=f'''<h1>严格审查：先证明数据和执行可信，再讨论高胜率</h1><p>审查时间 {now}。主回测 2023-10-09—2026-10-08，727 个交易日；更早对照复用既有已见历史。当前默认没有修改。本报告是对现有研究的内部复核，并非第三方审计认证。</p>
<div class="warning"><b>审查结论：不通过“已经找到稳定高胜率、可直接照搬实盘”的验收。</b><p>保留研究价值，但必须先解决数据口径、基准实现和胜率解释。历史盈利不是虚构的结论，但它是给定数据与成交假设下的模拟结果，精确收益率及日内择时能力尚不能直接外推。</p></div>
<h2>1．最关键的逻辑疑问：默认策略究竟在交易什么？</h2><p>源码显示，D 的基础是前一日 RSI(2)：低于35目标100%，高于60目标0%，中间50%；最近可用净利润同比不为正时目标0%。目标比前日下降安排09:45，否则10:00。默认融资把其中100%目标升至150%，只限制买入后的贷款≤净资产50%，允许持有期间被动超仓。</p><p><b>这主要是日线反转仓位策略，不是已经验证的全天日内做T系统。</b>周月支撑、VWAP、S/R 观察点属于另一层；S1/S2 只是规则满足程度，代码明确 validated:false，10%/20%也只是未验证预算示例。R2没有自动减仓不能用默认收益解释。下一步须把“观察触发→可执行条件→成交→退出→归因”连成完整流程，一次只接入一条已冻结规则；买入后可否卖出仍以老仓T+1可用量为准。</p>
<h2>2．高优先级：历史数据也未通过与10月9日一致的质量门槛</h2><p>按价格差大于0.011元（即通常至少2分钱）比较：727天中，356天高价不一致、337天低价不一致，合并525天；4天收盘相差至少2分钱。543天分钟成交量合计与日线相差超过1股，其中89天差异超过1%，最大约2.04%。全部分钟开/收仍在对应日线高低区间内，不能因此直接判定全部成交失真。</p><table><tr><th>年份</th><th>天数</th><th>高/低不一致天数</th><th>量差超过1%天数</th></tr>'''+''.join(f'<tr><td>{y}</td><td>{c["days"]}</td><td>{c["highLowMismatch"]}</td><td>{c["volumeAbove1pct"]}</td></tr>' for y,c in counts.items())+'''</table>
<p>例：2023-10-09日线最高22.80，分钟聚合22.74；分钟量34,534,300股，日线33,995,698股。差异可能涉及采样、集合竞价或供应商统计口径，目前没有充分来源证据能确定原因。不能把“日线和分钟线都来自同一供应商”当作独立交叉验证。此前只阻止10月9日进入回测，旧数据仍保留，是质量门槛不一致。</p><p><b>改善：</b>建立全历史逐日对账和质量等级，复核另一可靠来源及交易时段定义；保留原始响应。修订影响到哪些信号、成交和风险指标必须重算。禁止直接把极值或成交量按比例补平；也不能简单删掉不一致日来让绩效变好。未解决前，暂停对“精准低点”“极值触发胜率”作肯定结论。</p>
<h2>3．已确认的实现问题：大本金下的“全仓基准”并未全仓</h2><p>基准只在首日09:35发起买入，最多持续至09:55，未买足之后也不再补。100万元本金首日仓位99.92%，这一问题影响较小；1000万元首日仅20.58%，策略却仍可之后多次交易。后者不能冠以全仓持有，更不能据此宣称大资金同样跑赢全仓。</p><p><b>改善：</b>分列“理想全仓总回报参考”和“同等容量约束下逐步建仓的可执行持有”；后者持续补仓至规则完成，展示闲置现金、完成时间和股息再投资政策。所有本金设置统一比较，再补测不同起点。此次审查识别并留证，尚未修改基准代码或重写历史成绩。</p>
<h2>4．胜率可以升到95%，同时策略变差</h2><p>在完全不优化信号的容量压力测试中，本金由100万提高至1000万，默认融资方案完整持仓周期从74/102盈利（72.55%）变成22/23（95.65%），但三年收益由1226.51%降至529.08%，最大回撤由25.20%增至27.86%。周期数量大幅改变与受限成交、难以清仓导致的周期合并有关；这不是95%的日内买卖准确率。</p><p>默认方案期末仍有一个未结束周期，按市值亏损约41.20万元（100万元初始资金、复利运行后的账户），已经进入净值/回撤，却不进入已闭合周期胜率。必须同屏列出，避免只看已结束的成功案例。账户非平盘盈利日比例为52.72%，也不等同于做T胜率。</p><p><b>改善：</b>分别报告信号固定期限收益、完整T往返扣费胜率、持仓周期胜率及盈利日比例；逐项显示分母、未成交、单腿、未平仓和盈亏比。强弱等级需以前瞻校准证明，例如S2是否稳定好于S1；在此之前等级不可解释为盈利概率或满仓权限。</p>
<h2>5．历史稳定性和统计证据不足</h2><p>默认融资在三年区间最大回撤25.20%，更早2020年以来的对照期回撤72.81%、收益-23.97%；趋势融资候选三年周期胜率75%、回撤19.84%，更早回撤63.89%、收益-10.89%。这与“稳定控制回撤”不符，不能只因旧行情不符合新股性而直接排除。</p><p>三年默认74/102、候选78/104的描述性Wilson 95%区间分别约63.2%—80.3%、65.9%—82.3%，大量重叠。这些区间还未校正周期依赖、模型筛选和重复研究，不能用来证明二者显著差异或未来胜率达标。</p><p>已做多轮因子、阈值、时段和持仓筛选；过去称为训练、验证、滚动、更早的历史均已被反复查看。时间顺序验证有价值，但不能把看过结果后的再优化称为新盲测。既有冻结记录始于2026-10-09，本次审查没有新增完整独立交易日。代码账本一致性不等于市场数据正确，更不等于预测优势成立。</p><p><b>改善：</b>登记每次试验与失败，冻结少量具有经济理由的候选；以完整未来交易日和足够事件数积累证据，采用按日期分块的配对检验并计入多重筛选。不得边看未来结果边改参数，再把合并曲线当独立样本。60个未来交易日只作为首次复核点，不是自动通过标准。</p>
<h2>6．成交、滑点与风险度量仍是简化模型</h2><p>模型按下一根5分钟开盘价加减滑点，数量上限取上一根成交量的1%。默认三年1262笔中，563笔数量超过成交所在那根K线成交量的1%；159笔滑点后价格超出该根记录的高低范围。后者常由逆向滑点构造产生，不能全部视为虚增收益，但说明这不是逐笔历史成交重放。上一根有量也不能保证下一根开盘有对应盘口。</p><p>风险统计为5分钟收盘采样，并非逐笔最大回撤；开盘跳空、队列、停牌、极端流动性、券商额度和担保物折算都未完整建模。融资年息6%是假设，不是从佣金截图确认的实际利率。净资产50%的自设借款上限不等于券商当天一定可借到；维持担保约定也需核实。</p><p><b>本次不挑赢家的单项压力测试：</b>每次仅改变一个成交假设，已使用佣金万1、最低5元及现有税费。T列代表趋势融资候选，不是做T次数。延迟5分钟只延迟原定调仓，不改维护担保逻辑。容量降至0.1%是敏感性检验，不是对实际可成交容量的认定。</p>'''
body+='<div class="scroll"><table><tr><th>账户</th><th>条件</th><th>三年收益</th><th>最大回撤</th><th>已闭合周期盈利/总数</th></tr>'
for x in rows:
 body+=f'<tr><td>{labels[x["account"]]}</td><td>{html.escape(x["variant"])}</td><td>{pct(x["return_"])}</td><td>{pct(-x["mdd5"])}</td><td>{x["episodeWins"]}/{x["closedEpisodes"]}</td></tr>'
body+='''</table></div><p>默认融资单边滑点从5bp升至10bp，周期胜率72.55%降至68.00%，回撤25.20%升至25.95%；20bp时收益仍为正，但回撤27.21%。不能据此说策略一加成本就失效，也不能忽视其对执行假设的依赖。未来应进行合法免费行情下的影子委托日志核对，并把未成交与错失涨幅一起计入。</p>
<h2>7．费用与因果数据还需收尾审查</h2><p>已纳入T+1、实际佣金、最低佣金、历史印花税/过户费、利息和买入融资额度，这是必要基础，不能据此豁免其他问题。分红当前对策略统一扣20%、持有基准扣0%，没有按每批持股期限和卖出时点结算差别税；应补持仓批次账本。三年默认恰未持有除息日，分红税为0，不是此次主要夸大利润来源，但更早和其他候选受影响。</p><p>业绩字段做了公告日期滞后，但尚未逐份核验原始历史披露版本、修订值；最近一次下载的前复权序列也需要确认所用指标是否受后续复权影响。不是所有复权处理都造成未来泄漏，不能未检查就定罪，也不能仅看到shift(1)就认为全链路无未来数据。</p>
<h2>修复与研究顺序</h2><ol><li><b>先统一全历史数据门槛并修正基准。</b>修复前不再扩增因子或宣传精确日内胜率；保存原版本与修正对照，不能悄悄更换收益数字。</li><li><b>再统一信号、成交和胜率分母。</b>独立观察点与默认模型绩效分开归因；未平仓、未成交和连续亏损必须可见。</li><li><b>建立风险优先的候选比较。</b>现金与融资分别报告回撤、尾部亏损、恢复时间、亏损周期、参与度和净收益；可降收益但不以空仓或拖延止损制造高胜率。默认融资方案不应被描述为已证明适合稳健偏好。</li><li><b>最后研究风险退出后的重新参与。</b>已有新增86个风险日中，融资14个当天改善案例有10个到次日收盘转差，支持研究仓位恢复，但不能据此直接断言提前买回有效。固定一条恢复规则，同时检验再次下跌的代价。</li><li><b>冻结版本进行未来影子验证。</b>先建立可重复、无未来信息、含真实执行约束的证据链，再决定是否调整默认，不按历史最高收益自动升级。</li></ol><p>本次没有下单，没有替换默认，没有声称研究达标。以上未完成整改已进入检查点，后续小批研究优先解决基础审查问题。</p>
<h2>资料与可复核文件</h2><p>外部资料访问日期：2026-10-10。回测过拟合研究解释重复挑选的风险；融资/红利资料用于核对模型应实现的规则，不是本策略有效性证明。</p><ul>'''
body+=''.join(f'<li><a href="{u}">{t}</a></li>' for t,u in source)+'</ul><p><a href="strict-audit-evidence.zip">下载计算结果、检查明细与复现脚本</a> · <a href="archive.html">研究归档</a></p>'
page='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>沪电股份策略严格审查</title><style>body{margin:0;background:#f3f6fa;color:#21344a;font:16px/1.85 system-ui,sans-serif}main{max-width:1060px;margin:30px auto;background:white;padding:32px;border-radius:16px}h1{font-size:30px}h2{font-size:22px;margin-top:36px}a{color:#137d85}.warning{background:#fff4e0;padding:20px;border-left:5px solid #b87b17}table{border-collapse:collapse;width:100%;font-size:14px}td,th{text-align:left;padding:10px;border-bottom:1px solid #dae2ea}th{background:#eef4f6}.scroll{overflow:auto}li{margin:12px 0}@media(max-width:700px){main{padding:18px;margin:0}h1{font-size:25px}}</style><main>'+body+'</main></html>'
(out/'report.html').write_text(page);(repo/'docs/research/strict-audit.html').write_text(page)
with zipfile.ZipFile(out/'strict-audit-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in out.glob('*.json'):z.write(p,p.name)
 for f in ['run.mjs','cap-engine.mjs','cap-cash.mjs','report.py']:z.write(r/'work/strict_audit'/f,'scripts/'+f)
(repo/'docs/research/strict-audit-evidence.zip').write_bytes((out/'strict-audit-evidence.zip').read_bytes())
p=repo/'docs/research/archive.html';s=p.read_text();assert 'strict-audit.html' not in s;s=s.replace('<h1>研究归档</h1>','<h1>研究归档</h1><p><a href="strict-audit.html">严格审查：数据、胜率分母、基准与执行假设的缺陷 ↗</a></p>');p.write_text(s)
print(json.dumps({'baselineChecks':len(checks),'dataByYear':counts,'reportBytes':len(page.encode())},ensure_ascii=False))
