import fs from 'node:fs';import assert from 'node:assert/strict';
import {backtest} from '../hudian-backtest-dashboard/docs/engine.js';
import {financeBacktest} from '../hudian-backtest-dashboard/docs/finance-engine.js';
import {stats} from '../opening_guard/metrics.mjs';
const read=p=>JSON.parse(fs.readFileSync(p));const d=read('work/risk_priority/data.json'),g=read('work/risk_priority/gates.json'),a=d.dates.indexOf('2023-10-09'),z=d.dates.length;
const plan={createdAt:new Date().toISOString(),purpose:'Strict audit, no optimization or default change',variants:['current 5bp','10bp','20bp','scheduled target delayed one 5-minute bar, no other change','capital 10m capacity sensitivity','execution cap0.1% prior bar vs1%'],accounts:['D cash','L all-full150','T trend150'],knownHistory:true};fs.writeFileSync('outputs/strict_audit/plan.json',JSON.stringify(plan,null,2));
// Isolated execution-cap sensitivity. No source engine mutation.
let src=fs.readFileSync('work/hudian-backtest-dashboard/docs/finance-engine.js','utf8');assert.ok(src.includes('[4]*.01/100'));src=src.replace("'./fees.js?v=74745f12a7da'","'../hudian-backtest-dashboard/docs/fees.js'").replace('[4]*.01/100','[4]*.001/100');fs.writeFileSync('work/strict_audit/cap-engine.mjs',src);const {financeBacktest:capBT}=await import('./cap-engine.mjs');
let cs=fs.readFileSync('work/hudian-backtest-dashboard/docs/engine.js','utf8').replace("'./fees.js?v=74745f12a7da'","'../hudian-backtest-dashboard/docs/fees.js'").replace('[4]*.01/100','[4]*.001/100');fs.writeFileSync('work/strict_audit/cap-cash.mjs',cs);const {backtest:capCash}=await import('./cap-cash.mjs');
const rows=[],baselines={};
for(const account of ['D','L','T'])for(const variant of plan.variants){let x=d,opt={base:'D',gate:account==='T'?'trend':'all_full',level:account==='D'?1:1.5,rate:account==='D'?0:.06,slip:.0005,capital:1e6};
if(variant==='10bp')opt.slip=.001;if(variant==='20bp')opt.slip=.002;if(variant.startsWith('capital'))opt.capital=1e7;
if(variant.startsWith('scheduled'))x={...d,signals:{...d.signals,D:d.signals.D.map(([j,t])=>[j+1,t])}};
let r=variant.startsWith('execution')?(account==='D'?capCash(x,'D',a,z,opt):capBT(x,g,a,z,opt)):account==='D'?backtest(x,'D',a,z,opt):financeBacktest(x,g,a,z,opt);
if(variant==='current 5bp')baselines[account]=r;
rows.push({account,variant,...r.metrics,...stats(r),initialExposure:r.exposure[0]});}
for(const capital of [1e6,1e7]){const r=backtest(d,'B',a,z,{capital});rows.push({account:'B',variant:'capital '+capital,...r.metrics,...stats(r),initialExposure:r.exposure[0],initialCash:r.daily[0].cash});}
const checks={};for(const [k,r]of Object.entries(baselines)){let out=0,participationOver1=0,partial=0;for(const t of r.trades){let b=d.bars[t[0]][t[1]];if(t[4]>b[1]+.011||t[4]<b[2]-.011)out++;if(t[3]>.01*b[4])participationOver1++;if(t[3]===t[11])partial++;}checks[k]={trades:r.trades.length,adverseFillOutsideSameBarRange:out,qtyExceeds1pctExecutionBarVolume:participationOver1,qtyAtPriorBarCap:partial};}
fs.writeFileSync('outputs/strict_audit/stress.json',JSON.stringify(rows,null,2));fs.writeFileSync('outputs/strict_audit/execution-checks.json',JSON.stringify(checks,null,2));
for(const r of rows)console.log(JSON.stringify({account:r.account,variant:r.variant,ret:r.return_,dd:r.mdd5,win:r.episodeWinRate,initial:r.initialExposure,orders:r.orders}));console.log(checks);
