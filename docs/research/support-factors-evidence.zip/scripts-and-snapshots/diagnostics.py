from pathlib import Path
import sys,json
import pandas as pd,numpy as np
R=Path.cwd();O=R/'outputs/support_factors';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
e=f.e;ff=pd.read_csv(O/'features.csv');lookup={str(d):i for i,d in enumerate(e.DATES)}
rows=[]
for rule in ['touch','reclaim','volume','market','combined']:
 mask=ff.touch if rule=='touch' else ff.reclaim
 if rule in ['volume','combined']:mask=mask&ff.volume
 if rule in ['market','combined']:mask=mask&ff.market
 for _,r in ff[mask].groupby('date',sort=True).first().reset_index().iterrows():
  d=lookup[r.date];j=int(r.bar);px=e.B[d,j,0]
  rows.append(dict(rule=rule,date=r.date,time='10:00' if j==6 else '13:30',price=px,baseEligible=bool(r.baseEligible),volumeRatio=r.volumeRatio,market=bool(r.market),weekly=bool(r.weekly),monthly=bool(r.monthly),next0935Return=(e.B[d+1,1,0]*(1+e.BONUS[d+1])+e.DIV[d+1])/px-1 if d+1<e.N else np.nan))
all_events=pd.DataFrame(rows);all_events.to_csv(O/'independent_events.csv',index=False)
periods={'older':('2020-01-01','2023-10-08'),'train':('2023-10-09','2024-12-31'),'validation':('2025-01-01','2026-06-30'),'recent':('2026-07-01','2026-10-08'),'full':('2023-10-09','2026-10-08')}
out=[]
for period,(a,z) in periods.items():
 for rule in all_events.rule.unique():
  for account in [False,True]:
   q=all_events[(all_events.date>=a)&(all_events.date<=z)&(all_events.rule==rule)]
   if account:q=q[q.baseEligible]
   v=q.next0935Return.dropna();out.append(dict(period=period,rule=rule,accountEligibleOnly=account,n=len(q),outcomeN=len(v),mean=v.mean(),median=v.median(),win=(v>0).mean() if len(v) else np.nan))
pd.DataFrame(out).to_csv(O/'event_summary.csv',index=False)
# Reconstruct index support from only the input available before the stock decision day.
market_states=[]
for name,file in [('SZ','index_sz.csv'),('HS300','index_hs300.csv')]:
 df=pd.read_csv(R/'work/round2/data'/file,index_col='date');state=[]
 for d,date in enumerate(e.DATES):
  if d<5:state.append((False,False));continue
  prev=str(e.DATES[d-1]);past=df.loc[:prev];lv=[]
  for freq,n in [('W-FRI',19),('M',9)]:
   ps=pd.to_datetime(past.index).to_period(freq);closed=past.loc[ps<pd.Timestamp(prev).to_period(freq)];v=closed.close.groupby(pd.to_datetime(closed.index).to_period(freq)).last().tail(n);lv.append(v.mean() if len(v)==n else np.nan)
  last=df.loc[e.DATES[d-5:d]];c=last.close.iloc[-1];ok=np.isfinite(lv).all() and c>=min(lv)*.99;held=any(np.isfinite(l) and c>=l and ((last.low<=l*1.01)&(last.high>=l*.99)).any() for l in lv);state.append((ok,held))
 market_states.append(np.array(state,dtype=bool))
expected=market_states[0][:,0]&market_states[1][:,0]&(market_states[0][:,1]|market_states[1][:,1]);assert np.array_equal(expected,ff.groupby('date').first().market.to_numpy())
# Newly available daily and five-minute snapshot, excluded from the efficacy study.
def frame(file):
 obj=json.loads((R/'work/support_factors'/file).read_text());df=pd.DataFrame(obj['rows'],columns=obj['fields']);return df
b=frame('minute5_oct9.json');d=frame('daily_oct9.json');cols=['open','high','low','close','volume','amount'];b[cols]=b[cols].astype(float);d[cols]=d[cols].astype(float)
times=list(pd.date_range('2026-10-09 09:35','2026-10-09 11:30',freq='5min'))+list(pd.date_range('2026-10-09 13:05','2026-10-09 15:00',freq='5min'))
assert list(b.time)==[t.strftime('%Y%m%d%H%M')+'00000' for t in times];assert (b.date=='2026-10-09').all();assert np.isfinite(b[cols]).all().all();assert (b[cols]>0).all().all();assert (b.high>=b[['open','close','low']].max(axis=1)).all();assert (b.low<=b[['open','close','high']].min(axis=1)).all()
agg=dict(open=b.open.iloc[0],high=b.high.max(),low=b.low.min(),close=b.close.iloc[-1],volume=b.volume.sum(),amount=b.amount.sum());diff={k:agg[k]-d.iloc[0][k] for k in cols}
vol_bonus_dates=[str(e.DATES[x]) for x in np.flatnonzero(e.BONUS>0)]
checks=dict(indexPrefixDays=e.N,allMarketFlagsMatch=True,bonusDates=vol_bonus_dates,volumeNote='Raw share volume compared at equal checkpoints; any bonus within20sessions must be separately assessed.',today=dict(date='2026-10-09',bars=len(b),timestampsComplete=True,ohlcValid=True,daily=d[cols].iloc[0].to_dict(),barAggregate=agg,aggregateMinusDaily=diff,lowestBarEnd=str(b.loc[b.low.idxmin(),'time']),includedInBacktest=False))
(O/'additional_audit.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print(pd.DataFrame(out).query("period=='full'").to_string(index=False));print(json.dumps(checks,ensure_ascii=False))
bonusWindows=set()
for x in np.flatnonzero(e.BONUS>0):bonusWindows.update(str(d) for d in e.DATES[x:min(x+20,e.N)])
checks['bonusWindowSignalDates']=sorted(set(all_events[all_events.date.isin(bonusWindows)].date))
checks['bonusWindowVolumeSignals']=all_events[all_events.date.isin(bonusWindows)&all_events.rule.isin(['volume','combined'])][['date','rule']].to_dict('records')
raw=e.D.reindex(e.DATES);hd=e.B[:,:,1].max(axis=1)-raw.high.to_numpy();ld=e.B[:,:,2].min(axis=1)-raw.low.to_numpy()
checks['historicalBarRangeAudit']={'days':e.N,'highMismatchDaysOverCent':int((abs(hd)>.011).sum()),'lowMismatchDaysOverCent':int((abs(ld)>.011).sum()),'maxHighDifference':float(abs(hd).max()),'maxLowDifference':float(abs(ld).max()),'note':'Stored5min high/low may omit daily extrema; support touches dependent on provider bar representation. No fabricated corrections.'}
(O/'additional_audit.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));print(json.dumps(checks['historicalBarRangeAudit']));print(checks['bonusWindowSignalDates']);print(checks['bonusWindowVolumeSignals'])
