# -*- coding: utf-8 -*-
import ast,math,json,types
from pathlib import Path
import numpy as np
R=Path.cwd();O=R/'outputs/t_stop_review';ns={'np':np,'math':math};exec((R/'work/t_stop_review/generated_simulator.py').read_text(),ns)
def setup():
 b=np.zeros((1,48,6));b[:,:,:4]=100;b[:,:,4]=1e6;b[:,:,5]=1e8
 e=types.SimpleNamespace(B=b,REF=np.array([100.]),TRANSFER=np.array([.00001]),STAMP=np.array([.0005]),C=np.array([100.]),DATES=np.array(['2026-01-05']))
 sig=np.zeros((1,48,3),bool);sig[0,5,1]=True
 ns.update(e=e,sig=sig,rv=np.full((1,48),1.5),trend=np.array([True]),a5=np.ones((1,48)))
 return e
checks=[]
e=setup();e.B[0,6,3]=99.98;e.B[0,7,0]=99.90;r,t=ns['simulate_stop'](0,'volume',.0005,'swing');assert r['stopBar']==6 and t[-1]['bar']==7 and t[-1]['price']==99.85;checks.append('Frozen prior3barlow minus tick; completedclose triggers nextopen with adverse slippage')
e=setup();e.B[0,6,3]=98.54;e.B[0,7,0]=97;r,t=ns['simulate_stop'](0,'volume',.0005,'atr15');assert r['stopHit'] and t[-1]['price']==96.95;checks.append('ATR threshold98.55 is not guaranteed fill: gap sells96.95')
e=setup();e.B[0,6,3]=104;e.B[0,7,3]=103;e.B[0,8,3]=102.4;r,t=ns['simulate_stop'](0,'volume',.0005,'trail15');assert r['stopBar']==8 and t[-1]['bar']==9;checks.append('Trailing level rises to102.5 then does not loosen when price falls')
e=setup();e.B[0,6,3]=98;e.B[0,7:,0]=90;r,t=ns['simulate_stop'](0,'volume',.0005,'atr15');assert r['stopHit'] and not r['complete'] and len(t)==1 and r['remaining']==t[0]['qty'];checks.append('Limitdown blocks triggered stop; retain and mark inventory')
e=setup();e.B[0,6,3]=98;e.B[0,6,4]=10000;r,t=ns['simulate_stop'](0,'volume',.0005,'atr15');assert t[1]['qty']==100 and t[2]['bar']==8 and r['complete'] and t[-1]['available']>=0;checks.append('Stop is latched through volume-limited partial sales using old stock')
(O/'additional_audit.json').write_text(json.dumps({'syntheticChecks':checks,'count':len(checks)},indent=2));print(json.dumps({'passed':len(checks)}))
