# -*- coding: utf-8 -*-
from pathlib import Path
import json,re,zipfile
import pandas as pd
R=Path.cwd();O=R/'outputs/t_stop_review';D=R/'work/hudian-backtest-dashboard/docs/research';m=pd.read_csv(O/'metrics.csv');audit=json.loads((O/'audit.json').read_text())
labels={'base':'原缩量正T','swing':'跌破近期低点退出','atr15':'固定1.5倍ATR退出','trail15':'1.5倍ATR跟踪退出'}
registry={'updatedAt':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'policy':'Mature documentation does not mean verified highwinrate. Separate education, reproducible tested systems, unverifiable socialmedia anecdotes. Do not select by advertised hitrate.','methods':[{'id':'vwap_reclaim','source':'https://www.schwab.com/learn/story/how-to-use-volume-weighted-indicators-trading','evidence':'Broker educational example; no demonstrated Hudian winrate','ruleIdea':'Price belowVWAP then closesbackabove; priorlowrisklevel','status':'Entry condition queued for fixed comparative study; not implemented live'},{'id':'atr_exit','source':'https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr','evidence':'Indicator explanation; volatility notdirection; no highwinrate proof','adaptation':'Simplemean14five-minuteTR,1.5multiple frozenatentry, priorbar nextopen; differs from Wilder method','status':'Batch22 fixed andtrailing tested; averageexpectancynegative,olderworse; rejected default promotion'},{'id':'stop_execution','source':'https://workplace.schwab.com/story/help-protect-your-position-using-stop-orders','evidence':'Execution mechanics andgaps, not an alpha claim','adaptation':'Trigger is not guaranteedfill; nextopen volume/limits/T+1','status':'Already reflected in simulator and five synthetic tests'},{'id':'social_positiveT','source':'https://xhslink.cn/o/1Z5ip97mLgj','evidence':'Login gated; user abstract only; asserted92-100%notverified','status':'Batch21 variantsfailed; no author exact replication'},{'id':'social_preorders','source':'https://xhslink.cn/o/8E7JyXIPjx8','evidence':'Login gated; user abstract only;80%notverified','status':'Percenttargetanchor andauctionqueue unresolved; not simulatedexactly'},{'id':'tdx_dynamic_support','source':'user supplied formula, prior research tdx-t.html','evidence':'Finalextrema canrepaint historicalcrossings','status':'Causal variants failed batches18-20; no repeatwinnersearch'}]}
(O/'method_registry.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2))
def table(df):
 cols=[('mode','规则'),('buyDays','买入日'),('completeHit','完整往返胜率'),('averageNet','平均增量/元'),('worst','最差单日/元'),('improved','改善日'),('worse','恶化日')]
 def cell(k,v):
  if k=='mode':return labels[v]
  if pd.isna(v):return '—'
  if k=='completeHit':return f'{100*v:.2f}%'
  if k in ['averageNet','worst']:return f'{v:,.2f}'
  return str(int(v))
 return '<div class="scroll"><table><tr>'+''.join('<th>'+t+'</th>' for k,t in cols)+'</tr>'+''.join('<tr>'+''.join('<td>'+cell(k,r[k])+'</td>' for k,t in cols)+'</tr>' for _,r in df.iterrows())+'</table></div>'
css=re.search(r'<style>(.*?)</style>',(D/'xhs-positive.html').read_text(),re.S).group(1)
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>沪电股份 · 网络方法筛选与做T退出检验</title><style>'+css+'</style></head><body><main><a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a> · <a href="xhs-positive.html">上一批正T研究</a><h1>学习网络方法，先验证亏损如何退出</h1><p>第二十二批 · 2026-10-09 · 完整历史截至10月8日 · 三条固定退出规则</p><div class="callout"><b>支撑失效退出减少了本段大亏，但胜率降低、平均增量仍为负，更早历史没有改善。</b>没有依据替换默认。网络资料提供的是规则线索，不是沪电股份80%胜率的证明。继续保留原现金达标门槛与前瞻冻结。</div>'
page+='''<section><h2>持续研究新增来源筛选</h2><p>原持续安排已加入网络方法学习：每次筛选少量明确规则，记录来源、适用市场、证据等级、成交和失败处置。先登记参数，再比较历史；广告胜率、评论截图和只展示盈利交易不直接入选。原盘前/盘后发布时间保持。</p><ul><li><a href="https://www.schwab.com/learn/story/how-to-use-volume-weighted-indicators-trading">Schwab：VWAP交易示例</a>介绍价格跌破后收回均价线，并考虑以前低作为风险位置。它是教学示例，没有提供沪电股份胜率；均价线收回入场留作下一轮固定比较。</li><li><a href="https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr">Fidelity：ATR</a>将ATR用于反映波动与设定退出距离，举出1.5倍的例子；ATR本身不判断涨跌方向。</li><li><a href="https://workplace.schwab.com/story/help-protect-your-position-using-stop-orders">Schwab：止损单执行</a>说明触发价与实际成交价不同，跳空、波动和限价都影响退出。本轮按A股既有约束模拟，不复制美股当日新股可卖的条件。</li></ul><p>本轮研究者自行明确了周期、收盘确认及倍数冻结方式；不声称逐字复刻资料中的完整策略。两个小红书视频仍未独立观看，之前仅依据用户摘要的结论不升级为已核实的原作者方法。</p></section>'''
page+='''<section><h2>买点完全固定，只改变退出</h2><p>沿用上一批“上涨趋势＋回升＋同时段缩量”买入，三年内相同167个买入日、相同买入数量、价格和费用；一天最多一轮，不重新买回。原弱量盈利退出和14:30起尾盘退出均保留，新规则只增加失败退出。</p><ol><li><b>近期低点：</b>买入时冻结此前3根已完成5分钟K线最低价减0.01元；之后完成收盘跌破，下一根开盘尝试卖同等股数的老仓。</li><li><b>固定ATR：</b>买入时冻结此前14根5分钟真实波幅的简单平均×1.5，实际买价减此距离作为退出线；完成收盘跌破后下一根开盘尝试。</li><li><b>跟踪ATR：</b>沿用相同固定距离，退出线随买入后最高已完成收盘上移，只升不降；不使用未来最高价。</li></ol><p>这里的ATR采用简单平均，和资料中的Wilder递推存在差别；昨日分时先按当日参考价映射价格基础，当前开盘缺口纳入真实波幅。0.01元和1.5倍为本轮预先固定参数，没有扫参选优。</p><p>每天独立假设100万元、约50%隔夜老股、30%做T买入预算、至少20%保留现金。保留T+1、5/10基点不利滑点、费用、100股、前根量1%上限和涨跌停约束。止损消耗老股可售数量，新买股票当天不可卖；未退出股数保留收盘估值，不删除失败样本。</p><p class="note">此处仍是独立当日账户诊断，不是连续三年账户。平均增量相对同日相同底仓但不做T的账户；不能当成总收益、最大回撤或与全仓持有的累计领先。不评估融资，也未声称原现金目标达标。</p></section>'''
page+='<section><h2>三年同样167个买入日，胜率与损失的取舍</h2>'+table(m[(m.period=='full')&(m.slip==.0005)])+'''<p>166天完成往返，1天未完成；胜率以完整往返为分母，平均增量和最差日包括未完成敞口估值。近期低点规则将最差日从−16,985元改善到−6,405元，但胜率从50.00%降至40.36%。35天改善、41天恶化，说明它经常把最终能反弹的交易提前止损。少数大亏被减少，使平均增量有所改善，却仍是每个买入日平均亏437元。</p><p>这不支持“只要加止损就提高胜率”。风险控制与命中率可能方向相反，最终必须看扣费后的平均收益与持续账户结果。</p></section>'''
page+='<section><h2>分段检验：较早选择不会选中新退出</h2>'
for p,t in [('train','2023年10月至2024年底'),('validation','2025年至2026年6月底'),('recent','2026年7月至10月8日'),('older','更早历史：2020年至2023年10月之前')]:page+='<h3>'+t+'</h3>'+table(m[(m.period==p)&(m.slip==.0005)])
page+='''<p>如果只按2024年底以前的平均增量选择，仍选原退出；不能在看完2025—2026后挑出近期低点规则，再宣称当时已经能选中。更早行情中三条新规则均恶化，近期仅6天，证据不足。所有历史此前已见，分段并非新盲测。本批未新增滚动择优或连续账户曲线。</p><details><summary>固定年度明细</summary>'''
for y in [1,2,3]:page+='<h3>年度'+str(y)+'</h3>'+table(m[(m.period=='year'+str(y))&(m.slip==.0005)])
page+='</details><details><summary>10基点滑点：全段结果</summary>'+table(m[(m.period=='full')&(m.slip==.001)])+'</details></section>'
page+='''<section><h2>改善与伤害的两个例子</h2><p>2026-07-01同一次买入，近期低点退出使当日增量亏损缩至−2,385元，比原规则改善约14,600元。2026-06-29却相反：提前退出亏−6,405元，比原规则恶化约8,981元。两例只是解释机制，不替代全部样本。</p><p>更早历史的最差单日也由原−10,159元变为新规则−12,782元。价格在下一根可能跳变，触发后也可能因成交量或跌停而卖不完，因此风险阈值从来不是保证成交价格或最大亏损金额。</p></section>'''
page+='''<section><h2>核验与下一步候选</h2><p>2,456组同买入检查；上一批基准6列账户结果逐项复现；5,993笔成交独立账本核对，现金误差0；386个实际触发场景修改未来价格，触发及首笔退出不变；另有5项合成检查覆盖低点确认、跳价、跟踪线不放宽、跌停和分批成交。</p><p>下一轮改为固定比较“回落即接”与“收回分时成交均价后再接”，考察买得更晚是否减少失败、又损失多少反弹空间。先固定价格确认和退出，再做逐日诊断；只有诊断与连续账户验证都通过，才考虑接入观察层或默认。保留之前失败规则，避免反复调参数找历史赢家。</p><p><a href="t-stop-review-evidence.zip">下载来源登记、完整每日对照、逐笔成交、计划和代码</a></p><p class="note">网络来源的发布市场、周期和交易制度不同，不直接迁移其宣传收益。没有真实订单；本页不产生过期实时信号。现有现金/融资默认和首页盘前盘后板块未改。</p></section></main></body></html>'''
(O/'report.html').write_text(page);(D/'t-stop-review.html').write_text(page)
with zipfile.ZipFile(D/'t-stop-review-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(O.iterdir()):
  if p.suffix in ['.csv','.json'] and p.name!='publication.json':z.write(p,p.name)
 for p in sorted((R/'work/t_stop_review').glob('*.py')):z.write(p,'source/'+p.name)
 z.write(R/'work/xhs_positive/study.py','source/previous_study.py')
a=D/'archive.html';t=a.read_text();item='<p><a href="t-stop-review.html">第二十二批：网络方法筛选，固定买点检验低点与ATR退出 ↗</a></p>'
if 't-stop-review.html' not in t:a.write_text(t.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+item,1))
print(json.dumps({'htmlBytes':len(page.encode()),'zipBytes':(D/'t-stop-review-evidence.zip').stat().st_size}))
