import fs from 'node:fs';import assert from 'node:assert/strict';
import {backtest} from '../hudian-backtest-dashboard/docs/engine.js';import {financeBacktest} from '../hudian-backtest-dashboard/docs/finance-engine.js';
const read=p=>JSON.parse(fs.readFileSync(p)),data=read('work/risk_priority/data.json'),gates=read('work/risk_priority/gates.json'),ctx=read('work/band_overlay/context.json'),out='outputs/tail_attribution/';
const idx=x=>{let n=data.dates.findIndex(d=>d>=x);return n<0?data.dates.length:n;},start=idx('2023-10-09'),n=data.dates.length;
const periods={full:[start,n],early:[start,idx('2025-01-01')],later:[idx('2025-01-01'),idx('2026-07-01')],julyOn:[idx('2026-07-01'),n],older:[0,start]};for(let y=0;y<3;y++)periods['year'+(y+1)]=[idx(`${2023+y}-10-09`),idx(`${2024+y}-10-09`)];
fs.writeFileSync(out+'plan.json',JSON.stringify({question:'Are worst account days primarily overnight, opening30min or later-session losses, and do fixed prior-close weak-market/trend conditions consistently isolate them?',scope:'Attribution only; no new execution/filter applied; all selected tails are retrospective',accounts:['D','D_all_full_1.5','D_trend_1.5'],periods,slip:[.0005,.001],tail:'worst ceil(5% of all trading days), each period independently',lagGroups:['marketMA60<=0','trend20<=0','both','neither'],tradeConstraints:'existing audited engines with stock commission0.0001 minimum5, T+1,volume1%,limits; buy_cap_only'},null,2));
const all=[],summary=[],groups=[],episodes=[];let checks=0,maxError=0;
const mean=(xs,k)=>xs.length?xs.reduce((s,x)=>s+x[k],0)/xs.length:null;
for(const name of ['D','D_all_full_1.5','D_trend_1.5'])for(const [period,[a,z]]of Object.entries(periods))for(const slip of [.0005,.001]){
 const rate=name==='D'?0:.06,r=name==='D'?backtest(data,'D',a,z,{slip}):financeBacktest(data,gates,a,z,{base:'D',gate:name==='D_trend_1.5'?'trend':'all_full',level:1.5,slip});
 let prior={cash:1e6,shares:0},prevEq=1e6,ep=null;const days=[];
 for(let d=a;d<z;d++){
  const i=d-a,carry=d>a?Math.max(0,(Date.parse(data.dates[d])-Date.parse(data.dates[d-1]))/86400000-1):0;
  const interest=Math.max(0,-prior.cash)*rate/365*carry;let cash=prior.cash-interest+prior.shares*data.dividend[d]*.8;const shares=data.bonus[d]>0?Math.round(prior.shares*(1+data.bonus[d])):prior.shares;
  const openEq=cash+shares*data.bars[d][0][0],eq30=r.curve[i*48+5],eq=r.nav[i],overnight=openEq-prevEq,morning=eq30-openEq,later=eq-eq30,delta=eq-prevEq;
  const error=Math.abs(overnight+morning+later-delta);maxError=Math.max(maxError,error);assert.ok(error<1e-6);checks++;
  // Independently replay cash/shares through first6bars to validate early equity (not only algebra).
  let ca=cash,sh=shares;for(const t of r.trades.filter(t=>t[0]===d&&t[1]<=5)){ca-=t[2]*t[3]*t[4]+t[5];sh+=t[2]*t[3];}
  assert.ok(Math.abs(ca+sh*data.bars[d][5][3]-eq30)<1e-6);checks++;
  const row={name,period,slip,date:data.dates[d],overnightHolding:prior.shares>0,priorExposure:prior.shares>0?(prevEq-prior.cash)/prevEq:0,gap:data.bars[d][0][0]/data.reference[d]-1,trend20:ctx[d].trend20,marketMA60:ctx[d].marketMA60,overnight:overnight/prevEq,first30:morning/prevEq,later:later/prevEq,dayReturn:delta/prevEq,overnightYuan:overnight,first30Yuan:morning,laterYuan:later,dayYuan:delta};days.push(row);
  if(!ep&&(prior.shares>0||r.daily[i].shares>0||Math.abs(delta)>1e-7))ep={name,period,slip,start:data.dates[d],initialEquity:prevEq,overnightYuan:0,first30Yuan:0,laterYuan:0};
  if(ep){ep.overnightYuan+=overnight;ep.first30Yuan+=morning;ep.laterYuan+=later;if(!r.daily[i].shares||d===z-1){ep.end=data.dates[d];ep.complete=!r.daily[i].shares;ep.net=eq-ep.initialEquity;ep.return_=ep.net/ep.initialEquity;assert.ok(Math.abs(ep.net-ep.overnightYuan-ep.first30Yuan-ep.laterYuan)<1e-5);episodes.push(ep);ep=null;}}
  prior=r.daily[i];prevEq=eq;
 }
 const tail=days.slice().sort((a,b)=>a.dayReturn-b.dayReturn).slice(0,Math.ceil(days.length*.05));
 summary.push({name,period,slip,...r.metrics,days:days.length,tailN:tail.length,tailMean:mean(tail,'dayReturn'),tailOvernight:mean(tail,'overnight'),tailFirst30:mean(tail,'first30'),tailLater:mean(tail,'later'),tailGapDown:tail.filter(x=>x.gap<0).length,tailHeldOvernight:tail.filter(x=>x.overnightHolding).length,tailMarketWeak:tail.filter(x=>x.marketMA60!==null&&x.marketMA60<=0).length,tailTrendWeak:tail.filter(x=>x.trend20!==null&&x.trend20<=0).length});
 for(const [group,f]of Object.entries({marketWeak:x=>x.marketMA60<=0,marketStrong:x=>x.marketMA60>0,trendWeak:x=>x.trend20<=0,trendStrong:x=>x.trend20>0,bothWeak:x=>x.marketMA60<=0&&x.trend20<=0,neitherWeak:x=>x.marketMA60>0&&x.trend20>0})){
 const xs=days.filter(x=>x.overnightHolding&&x.marketMA60!==null&&x.trend20!==null&&f(x));groups.push({name,period,slip,group,n:xs.length,losing:xs.filter(x=>x.dayReturn < -1e-10).length,lossRate:xs.length?xs.filter(x=>x.dayReturn < -1e-10).length/xs.length:null,meanReturn:mean(xs,'dayReturn'),meanOvernight:mean(xs,'overnight'),largeLossN:xs.filter(x=>x.dayReturn<=-.03).length,largeLossRate:xs.length?xs.filter(x=>x.dayReturn<=-.03).length/xs.length:null});
 }
 if((period==='full'||period==='older')&&slip===.0005)all.push(...days.map(x=>({...x,retrospectiveTail:tail.includes(x)})));
}
const save=(name,rows)=>{fs.writeFileSync(out+name+'.json',JSON.stringify(rows));const keys=Object.keys(rows[0]);fs.writeFileSync(out+name+'.csv',[keys.join(','),...rows.map(r=>keys.map(k=>JSON.stringify(r[k]??null)).join(','))].join('\n'));};save('daily',all);save('summary',summary);save('groups',groups);save('episodes',episodes);fs.writeFileSync(out+'audit.json',JSON.stringify({checks,maxError,accounts:3,comparisons:48,knownContext:'prior close only; gap at open only and not available previous close',defaultChanged:false,newStrategyTested:false,selection:'tail subset selected after outcomes, attribution not prediction'},null,2));console.log(JSON.stringify(summary.filter(x=>['full','older'].includes(x.period)&&x.slip===.0005).map(x=>({name:x.name,period:x.period,tailN:x.tailN,total:x.tailMean,overnight:x.tailOvernight,first30:x.tailFirst30,later:x.tailLater,marketWeak:x.tailMarketWeak,trendWeak:x.tailTrendWeak})),null,2));
