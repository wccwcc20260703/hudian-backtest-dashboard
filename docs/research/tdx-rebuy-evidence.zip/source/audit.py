# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/tdx_rebuy';sys.path.insert(0,str(R/'work/tdx_rebuy'));import rebuy_engine as eng
e=eng.e;data=np.load(R/'work/tdx_rebuy/full_results.npz');mapping={'base':0,'fixed':0,'stop05':1,'breakout':2,'time15':3,'rollingD':0,'rollingL':0};checks=0
def first_trigger(b,sellbar,sellprice,policy):
 barrier=max(b[max(0,sellbar-6):sellbar,3])
 for j in range(sellbar+1,min(len(b)+1,47)):
  known=b[j-1,3];vw=b[:j,5].sum()/max(b[:j,4].sum(),1)
  if known<=sellprice*.996:return j,1
  if policy==1 and known>=sellprice*1.005:return j,3
  if policy==2 and j>=sellbar+2 and min(b[j-2:j,3])>barrier and known>vw:return j,4
  if policy==3 and j>=sellbar+3 and known>sellprice and known>vw:return j,5
  if j>=42:return j,2
 return -1,0
for key in data.files:
 if not key.endswith('_trips'):continue
 name=key[:-6];policy=mapping[name.split('_',1)[1]];trades=data[name+'_trades']
 for t in data[key]:
  if t[9] or not t[13]:continue
  d=int(t[0]);j=int(t[1]);sale=trades[(trades[:,0]==d)&(trades[:,16]==1)][0];when,why=first_trigger(e.B[d],j,sale[4],policy);assert why==t[13]
  assert first_trigger(e.B[d,:when],j,sale[4],policy)==(when,why)
  poisoned=e.B[d].copy();poisoned[when:]*=7;assert first_trigger(poisoned,j,sale[4],policy)==(when,why)
  if t[6]>=0:assert t[6]>=when
  checks+=1
def fixture(policy):
 b=np.ones((2,48,6))*100;b[:,:,4]=1e7;b[:,:,5]=1e9;cl=np.full(2,100.);zero=np.zeros(2);ref=np.full(2,100.);sig=np.full((2,48),-1.);sig[0,1]=1.5;sig[1,6]=1.5;ent=np.zeros((2,48),bool);ent[:,12]=True
 return [b,cl,zero.copy(),zero.copy(),ref,np.full(2,.0005),np.full(2,.00001),np.array([20000,20001]),sig,0,2,np.full(2,2),ent,np.array([policy,policy])]
tests=[]
z=fixture(1);z[0][1,13,3]=100.6;z[0][1,14:,0:4]=101.;z[1][1]=101.;rr=eng.execute(*z);t=rr[7][0];assert t[13]==3 and t[6]==14;buy=rr[3][rr[3][:,16]==4][0];assert buy[4]>101 and buy[4]/rr[3][rr[3][:,16]==1][0,4]-1>.005;tests.append('0.5%iscompleted-price trigger,nextopenfillmayexceed0.5%loss')
z=fixture(2);z[0][1,13:15,3]=100.3;z[0][1,15:,0:4]=100.4;z[1][1]=100.4;rr=eng.execute(*z);assert rr[7][0,13]==4 and rr[7][0,6]==15;tests.append('breakout needs2completedcloses,no immediate samebar fill')
z=fixture(3);z[0][1,12:,0:4]=100.2;z[0][1,12,0]=100.;z[1][1]=100.2;rr=eng.execute(*z);assert rr[7][0,13]==5 and rr[7][0,6]==15;tests.append('timer waits3tradingbars,no15minfuturepeek')
z=fixture(1);z[8][1,14]=0.;z[0][1,13,3]=101.;rr=eng.execute(*z);assert rr[7][0,9]==1 and rr[7][0,4]==0;tests.append('neworiginalsignaloverrides invalidationbuyback')
z=fixture(1);z[0][1,13:,0:4]=110.;z[1][1]=110.;rr=eng.execute(*z);assert rr[7][0,13]==3 and rr[7][0,4]==0 and rr[7][0,8]>0;tests.append('limitupblocks earlybuy and recordswholemissingquantity')
p=pd.read_csv(O/'same_start_pairs.csv');summ=[]
for (base,rule),t in p.groupby(['base','rule']):
 changed=t[abs(t.navDelta)>1e-6];summ.append(dict(base=base,rule=rule,days=len(t),changedDays=len(changed),better=int((t.navDelta>1e-6).sum()),worse=int((t.navDelta< -1e-6).sum()),sumNavDelta=float(t.navDelta.sum()),meanNavDeltaFraction=float(t.navDeltaFraction.mean()),oldWorstMarked=float(t.oldNet.min()),newWorstMarked=float(t.newNet.min()),oldAverageMissing=float(t.oldMissing.mean()),newAverageMissing=float(t.newMissing.mean())))
pd.DataFrame(summ).to_csv(O/'paired_summary.csv',index=False)
examples=pd.concat([p[(p.base=='L')&(p.date=='2026-07-21')],p[(p.base=='L')&(p.date=='2026-07-03')]]);examples.to_csv(O/'paired_examples.csv',index=False)
m=pd.read_csv(O/'metrics.csv').set_index(['name','period']);cash={}
for n in ['D_stop05','D_breakout','D_time15']:
 def ok(period):return bool(m.loc[(n,period),'return_']>=m.loc[('hold',period),'return_'] and abs(m.loc[(n,period),'mdd5'])<=.75*abs(m.loc[('hold',period),'mdd5']))
 cash[n]=dict(fullReturnAndDD=ok('full'),annualPasses=sum(ok('year'+str(y)) for y in [1,2,3]),olderReturnAndDD=ok('older'),wealthRelativeToHold=float((1+m.loc[(n,'full'),'return_'])/(1+m.loc[('hold','full'),'return_'])),completePass=False,independentEvidence=False)
files=[R/'work/tdx_rebuy/rebuy_engine.py',R/'work/tdx_rebuy/study.py',R/'work/tdx_regime/entries.npz',R/'work/leverage/plans.npz',R/'outputs/reentry/forward_freeze.json'];audit=dict(triggerPrefixPoisonChecks=checks,syntheticTests=tests,originalCashCriteria=cash,files=[dict(path=str(p.relative_to(R)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]);(O/'additional_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2));print(json.dumps(audit));print(pd.DataFrame(summ).to_string(index=False))
