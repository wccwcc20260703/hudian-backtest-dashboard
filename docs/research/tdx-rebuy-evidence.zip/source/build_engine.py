from pathlib import Path
R=Path.cwd();s=(R/'work/tdx_regime/inventory_engine.py').read_text()
s=s.replace('modes,entries,rate=','modes,entries,policies,rate=')
s=s.replace('tr=np.zeros(((end-start)*48,17));trips=np.zeros((end-start,13))','tr=np.zeros(((end-start)*48,18));trips=np.zeros((end-start,14))')
s=s.replace('deadlinebuy=False\n  for j','deadlinebuy=False;trigger=0;entrybarrier=0.\n  for j')
s=s.replace('sellbar=j;active=True','sellbar=j;active=True;entrybarrier=np.max(b[d,max(0,j-6):j,3])')
s=s.replace('     if known<=sellprice*.996:buy_pending=True\n     if j>=42:buy_pending=True;deadlinebuy=True','''     if not buy_pending:
      if known<=sellprice*.996:buy_pending=True;trigger=1
      elif policies[d]>0:
       vwap=np.sum(b[d,:j,5])/max(np.sum(b[d,:j,4]),1.)
       invalid=(policies[d]==1 and known>=sellprice*1.005) or (policies[d]==2 and j>=sellbar+2 and b[d,j-2,3]>entrybarrier and known>entrybarrier and known>vwap) or (policies[d]==3 and j>=sellbar+3 and known>sellprice and known>vwap)
       if invalid:buy_pending=True;trigger=policies[d]+2
     if j>=42:
      if not buy_pending:trigger=2
      buy_pending=True;deadlinebuy=True''')
s=s.replace('tr[nt,16]=3 if j>=42 else 2;nt+=1','tr[nt,16]=4 if trigger>=3 else (3 if j>=42 else 2);tr[nt,17]=trigger;nt+=1')
s=s.replace('trips[ntrip,12]=1 if buy_pending else 0;ntrip+=1','trips[ntrip,12]=1 if buy_pending else 0;trips[ntrip,13]=trigger;ntrip+=1')
(R/'work/tdx_rebuy/rebuy_engine.py').write_text(s)
