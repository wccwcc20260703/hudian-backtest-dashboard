from pathlib import Path
import sys,math
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'round2'))
import engine as e
import numpy as np
from numba import njit
DAYNUM=e.DATES.astype('datetime64[D]').astype(np.int64)
@njit(cache=True)
def execute(b,cl,div,bonus,ref,stamp,transfer,dates,signals,start,end,modes,entries,rate=.06,slip=.0005,capital=1e6,maxlev=1.5,ddlimit=1.,maintenance=1.5,credit=np.inf):
 cash=capital;sh=0;fees=0.;interest=0.;tax=0.;t1=0;limits=0;caps=0;turnover=0.;riskorders=0;borrowdays=0;peak=capital;prev_eq=capital;minratio=1e9;maxex=0.;nt=0
 eq=np.zeros(end-start);exp=np.zeros(end-start);curve=np.zeros((end-start)*48);debts=np.zeros(end-start);intr=np.zeros(end-start);tr=np.zeros(((end-start)*48,17));trips=np.zeros((end-start,13));ntrip=0
 for d in range(start,end):
  carry=max(0,dates[d]-dates[d-1]-1) if d>start else 0
  cost=max(-cash,0)*rate/365*carry;cash-=cost;interest+=cost
  cash+=sh*div[d]*.8;tax+=sh*div[d]*.2
  if bonus[d]>0:sh=int(round(sh*(1+bonus[d])))
  avail=sh;pending=False;deadline=-1;target=0.;dayborrow=max(-cash,0);dayinterest=cost;forced=False
  used=False;active=False;buy_pending=False;cancelled=False;soldq=0;remain=0;proceeds=0.;buycost=0.;sellprice=0.;sellbar=-1;firstbuy=-1;deadlinebuy=False
  for j in range(48):
   sig=signals[d,j];isrisk=False;before_nt=nt
   if j>=1 and j<=46:
    if sig>=0:target=sig;pending=True;deadline=min(j+4,46);forced=False
    # Only completed-bar equity/price enters the discretionary deleveraging rule.
    known=b[d,j-1,3];known_eq=cash+sh*known;debt=max(-cash,0);ratio=(max(cash,0)+sh*known)/debt if debt>0 else 1e9
    if debt>0 and (ratio<maintenance or (modes[d]<2 and sh*known/max(known_eq,1)>1.6) or prev_eq/peak-1 < -ddlimit):
     target=0. if ratio<maintenance else 1.;pending=True;deadline=min(j+4,46);forced=True;isrisk=True
    if pending and j<=deadline:
     if prev_eq/peak-1 < -ddlimit:target=min(target,1.)
     px=b[d,j,0];equity=cash+sh*px;weight=sh*px/equity if equity>0 else 1e9
     tol=.004 if target>=1 else .035
     if abs(target-weight)>tol and not (modes[d]>=1 and not forced and target==1.5 and weight>target):
      desired=max(0,int(equity*target/px/100)*100);delta=desired-sh;side=1 if delta>0 else -1
      cap=int(b[d,j-1,4]*.01/100)*100
      if abs(delta)>cap:caps+=1
      qty=int(min(abs(delta),cap)/100)*100
      if side<0 and target==0 and sh<cap:qty=sh
      upper=math.floor(ref[d]*1.1*100+.5)/100;lower=math.floor(ref[d]*.9*100+.5)/100
      fill=math.ceil(px*(1+slip)*100-1e-8)/100 if side>0 else math.floor(px*(1-slip)*100+1e-8)/100
      if (side>0 and (px>=upper-.005 or fill>upper)) or (side<0 and (px<=lower+.005 or fill<lower)):
       if qty>0:limits+=1
       qty=0
      if side<0:
       if qty>avail:t1+=1
       qty=min(qty,avail)
      if side>0:
       allowed=min(maxlev,max(1.,target))
       if allowed<=1:aff=max(0,int((cash-5)/(fill*(1+.00025+transfer[d]))/100)*100)
       else:
        budget=allowed*cash+(allowed-1)*sh*px-allowed*5
        aff=max(0,int(budget/(px+allowed*(fill-px)+allowed*fill*(.00025+transfer[d]))/100)*100)
       if credit<1e18:aff=min(aff,max(0,int((cash+credit-5)/(fill*(1+.00025+transfer[d]))/100)*100))
       qty=min(qty,aff)
      if qty>0:
       gross=qty*fill;fee=max(5.,gross*.00025)+gross*(transfer[d]+(stamp[d] if side<0 else 0.));oldavail=avail;oldsh=sh
       cash-=side*gross+fee;sh+=side*qty
       if side<0:avail-=qty
       fees+=fee;turnover+=gross/max(equity,1.);dayborrow=max(dayborrow,-cash)
       if forced:riskorders+=1
       tr[nt,0]=d;tr[nt,1]=j;tr[nt,2]=side;tr[nt,3]=qty;tr[nt,4]=fill;tr[nt,5]=fee;tr[nt,6]=cash;tr[nt,7]=sh;tr[nt,8]=avail;tr[nt,9]=oldavail;tr[nt,10]=target;tr[nt,11]=cap;tr[nt,12]=oldsh;tr[nt,13]=sig;tr[nt,14]=max(-cash,0);tr[nt,15]=1 if forced else 0;nt+=1
      else:pending=False
     else:pending=False

    # The original/maintenance engine has priority; never refill after a new risk instruction.
    if active and (isrisk or sig>=0):cancelled=True;active=False
    if entries[d,j] and 12<=j<=36 and not used and target>0 and not forced and not (pending and j<=deadline):
     used=True
     px=b[d,j,0];equity=cash+sh*px;cap=int(b[d,j-1,4]*.01/100)*100
     wanted=int(avail*.2/100)*100;qty=min(wanted,cap)
     if wanted>cap:caps+=1
     lower=math.floor(ref[d]*.9*100+.5)/100;fill=math.floor(px*(1-slip)*100+1e-8)/100
     if px<=lower+.005 or fill<lower:
      if qty>0:limits+=1
      qty=0
     if qty>0 and nt==before_nt:
      fee=max(5.,qty*fill*.00025)+qty*fill*(transfer[d]+stamp[d]);oldavail=avail;oldsh=sh
      cash+=qty*fill-fee;sh-=qty;avail-=qty;fees+=fee;turnover+=qty*fill/max(equity,1.)
      soldq=qty;remain=qty;proceeds=qty*fill-fee;sellprice=fill;sellbar=j;active=True
      tr[nt,0]=d;tr[nt,1]=j;tr[nt,2]=-1;tr[nt,3]=qty;tr[nt,4]=fill;tr[nt,5]=fee;tr[nt,6]=cash;tr[nt,7]=sh;tr[nt,8]=avail;tr[nt,9]=oldavail;tr[nt,10]=target;tr[nt,11]=cap;tr[nt,12]=oldsh;tr[nt,13]=-1;tr[nt,14]=max(-cash,0);tr[nt,16]=1;nt+=1
    if active and j>sellbar and nt==before_nt and not (pending and j<=deadline):
     if known<=sellprice*.996:buy_pending=True
     if j>=42:buy_pending=True;deadlinebuy=True
     if buy_pending and remain>0:
      px=b[d,j,0];equity=cash+sh*px;cap=int(b[d,j-1,4]*.01/100)*100;qty=min(remain,cap)
      if remain>cap:caps+=1
      upper=math.floor(ref[d]*1.1*100+.5)/100;fill=math.ceil(px*(1+slip)*100-1e-8)/100
      if px>=upper-.005 or fill>upper:
       if qty>0:limits+=1
       qty=0
      allowed=min(maxlev,max(1.,target))
      if allowed<=1:aff=max(0,int((cash-5)/(fill*(1+.00025+transfer[d]))/100)*100)
      else:
       budget=allowed*cash+(allowed-1)*sh*px-allowed*5
       aff=max(0,int(budget/(px+allowed*(fill-px)+allowed*fill*(.00025+transfer[d]))/100)*100)
      if credit<1e18:aff=min(aff,max(0,int((cash+credit-5)/(fill*(1+.00025+transfer[d]))/100)*100))
      qty=min(qty,aff)
      if qty>0:
       gross=qty*fill;fee=max(5.,gross*.00025)+gross*transfer[d];oldavail=avail;oldsh=sh
       cash-=gross+fee;sh+=qty;remain-=qty;buycost+=gross+fee;fees+=fee;turnover+=gross/max(equity,1.);dayborrow=max(dayborrow,-cash)
       if firstbuy<0:firstbuy=j
       tr[nt,0]=d;tr[nt,1]=j;tr[nt,2]=1;tr[nt,3]=qty;tr[nt,4]=fill;tr[nt,5]=fee;tr[nt,6]=cash;tr[nt,7]=sh;tr[nt,8]=avail;tr[nt,9]=oldavail;tr[nt,10]=target;tr[nt,11]=cap;tr[nt,12]=oldsh;tr[nt,13]=-1;tr[nt,14]=max(-cash,0);tr[nt,16]=3 if j>=42 else 2;nt+=1
       if remain==0:active=False
   if j==47:
    charge=dayborrow*rate/365;cash-=charge;interest+=charge;dayinterest+=charge
   mark=cl[d] if j==47 else b[d,j,3];value=cash+sh*mark;curve[(d-start)*48+j]=value;prev_eq=value;peak=max(peak,value)
   if value>0:maxex=max(maxex,sh*mark/value)
   if cash<0:minratio=min(minratio,sh*mark/(-cash))
  eq[d-start]=cash+sh*cl[d];exp[d-start]=sh*cl[d]/eq[d-start];debts[d-start]=max(-cash,0);intr[d-start]=dayinterest
  if dayborrow>0:borrowdays+=1
  if soldq>0:
   trips[ntrip,0]=d;trips[ntrip,1]=sellbar;trips[ntrip,2]=soldq;trips[ntrip,3]=proceeds;trips[ntrip,4]=soldq-remain;trips[ntrip,5]=buycost;trips[ntrip,6]=firstbuy;trips[ntrip,7]=1 if deadlinebuy else 0;trips[ntrip,8]=remain;trips[ntrip,9]=1 if cancelled else 0;trips[ntrip,10]=proceeds-buycost-remain*cl[d];trips[ntrip,11]=proceeds-buycost;trips[ntrip,12]=1 if buy_pending else 0;ntrip+=1
 return eq,exp,curve,tr[:nt],np.array([fees,interest,tax,t1,limits,caps,turnover,riskorders,borrowdays,minratio,maxex]),debts,intr,trips[:ntrip]
