# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/tdx_regime';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
sys.path.insert(0,str(R/'work/drift'));import drift_engine as original
sys.path.insert(0,str(R/'work/tdx_regime'));import inventory_engine as engine
e=f.e;P=np.load(R/'work/leverage/plans.npz');modes=np.full(e.N,2);freeze=int(np.searchsorted(e.DATES,'2025-01-01'));cut=int(np.searchsorted(e.DATES,'2026-07-01'))
manifest={'at':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'Can causal trend-state gates improve a fixed-old-share sell/rebuy overlay compared with unfiltered fixed-share T and the current default?','rules':{'fixed':'Reuse previous TDX confirm sell signal, no new trend gate.','range':'Same sell signal only if abs(close-open)/(abs(firstclose-open)+sum(abs(closechanges))) <=0.35 using all completed session bars.','trend_veto':'Same signal but veto sale when close>VWAP AND fast EMA30 proxy>slow EMA900 proxy AND fastEMA now>fastEMA15min ago.'},'execution':'After original daily instruction window, sell10:30..14:00 only, one attempt/day;20%ofcurrentlyavailable overnight shares floored to100, cap1%prior5minvolume; fix ACTUAL SOLD SHARES as buyback quantity, never aNAV target. If acompletedclose<=actualsellfill*(1-0.004), start market buyback next open and continue subject constraints; at14:30 force attempt through14:50. Newmaintenance/risk/base instruction cancels overlay replenishment. Unfilled quantities retained explicitly, not falsely marked complete.','EMA':'alpha5=1-(1-2/(N+1))**5 for N30/900;initialize sessionopen, update with each5minclose. Correct elapsed smoothing underconstantwithinbar approximation, NOT exact TDX1min EMA.','constraints':'OriginalDcash andLallfull150buycaponly retained;T+1,costs,100share lots,priorvolume1%,5/10bpslip,tickrounding,6%calendarinterest,newbuydebt<=50%equity,passivedriftpermitted.','outcomes':'Completed equal-share trip net=saleproceeds-salefees-buycost-buyfees; incomplete marked separately including missinginventory atofficialclose, never discarded. Interest in account return not isolated trip. All portfolio fills also date/side close-hit.','selection':'Train2023Oct..2024Dec;eachbase independently max annual logwealth-1.5absDD;DD<=base+2pp; baseline eligible. Quarterly prior252same selection. Fixed gates and spread no search.','acceptance':'Incremental validation2025..2026Jun and recentJul..Oct8 must both beat original return andDD<=base+2pp;2/3fixedannual;older>=base;10bpbothlaterperiodsimprove. Originalcash return>=hold andDD<=75%hold,annual2/3,older,stress,independent unchanged;wealth1.20 separate.','data':'1637days5min2020..2026Oct8;earlierandalltrain/validationalreadyseenhistory;Oct9 extreme mismatch excluded; current webminute notnewblind evidence.','previousFailures':'tdx_t originalgoalminus25pp restoration failed; this batch fixed quantity and range/trend gate, not re-search same targets.','freezeSHA':hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(O/'plan_before_results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
src=(R/'work/tdx_t/study.py').read_text();exec(src[src.index('def features('):src.index('# Screenshot identity')])
def state(b):
 c=b[:,3];op=b[0,0];den=np.cumsum(np.abs(np.diff(np.r_[op,c])));er=np.abs(c-op)/np.maximum(den,1e-9);emas=[]
 for n in [30,900]:
  alpha=1-(1-2/(n+1))**5;v=op;arr=[]
  for p in c:v=alpha*p+(1-alpha)*v;arr.append(v)
  emas.append(np.array(arr))
 fast,slow=emas;vwap=np.cumsum(b[:,5])/np.maximum(np.cumsum(b[:,4]),1);rising=fast>np.r_[fast[:3],fast[:-3]] if len(fast)>=3 else np.zeros(len(fast),bool)
 return er,(c>vwap)&(fast>slow)&rising,fast,slow
raw=np.array([signals(e.B[d],e.REF[d],'confirm')<0 for d in range(e.N)]);entries={k:np.zeros((e.N,48),bool) for k in ['base']+list(manifest['rules'])};checks=0;states=[]
for d in range(e.N):
 er,strong,fast,slow=state(e.B[d])
 for j in range(12,37):
  entries['fixed'][d,j]=raw[d,j-1];entries['range'][d,j]=raw[d,j-1] and er[j-1]<=.35;entries['trend_veto'][d,j]=raw[d,j-1] and not strong[j-1]
  pe,ps,pf,pl=state(e.B[d,:j]);assert np.isclose(pe[-1],er[j-1]) and ps[-1]==strong[j-1] and np.isclose(pf[-1],fast[j-1]) and np.isclose(pl[-1],slow[j-1]);checks+=1
  if raw[d,j-1]:states.append(dict(date=str(e.DATES[d]),bar=j,efficiency=float(er[j-1]),strong=bool(strong[j-1]),fast=float(fast[j-1]),slow=float(slow[j-1])))
pd.DataFrame(states).to_csv(O/'signal_states.csv',index=False);np.savez_compressed(R/'work/tdx_regime/entries.npz',**entries)
def run(name,a,z,slip=.0005):
 base,rule=name.split('_',1);return engine.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,P['D' if base=='D' else 'D_all_full_1.5'],a,z,modes,entries[rule],slip=slip)
def met(r):return f.metrics(r[:7])
periods={'train':(e.START,freeze),'validation':(freeze,cut),'recent':(cut,e.N),'full':(e.START,e.N),'older':(0,e.START)}
for y in range(3):periods['year'+str(y+1)]=(int(np.searchsorted(e.DATES,f'{2023+y}-10-09')),int(np.searchsorted(e.DATES,f'{2024+y}-10-09')))
# Disabled-overlay parity across all fixed periods and both slip settings, all arrays not just final NAV.
parity=0
for b,k in [('D','D'),('L','D_all_full_1.5')]:
 for a,z in periods.values():
  for slip in [.0005,.001]:
   old=original.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,P[k],a,z,modes,slip=slip);new=run(b+'_base',a,z,slip)
   for i in range(7):assert np.allclose(old[i],new[i][:,:16] if i==3 else new[i],rtol=0,atol=1e-8);parity+=1
selection=[]
def select(base,a,z):
 bm=met(run(base+'_base',a,z));elig=[]
 for rule in ['base']+list(manifest['rules']):
  name=base+'_'+rule;m=met(run(name,a,z));ok=abs(m['mdd5'])<=abs(bm['mdd5'])+.02;score=np.log1p(m['return_'])/((z-a)/242)-1.5*abs(m['mdd5']);selection.append(dict(base=base,name=name,start=str(e.DATES[a]),end=str(e.DATES[z-1]),eligible=ok,score=score))
  if ok:elig.append((score,name))
 return max(elig)[1]
choices={b:select(b,e.START,freeze) for b in ['D','L']};quarters=pd.PeriodIndex(e.DATES,freq='Q');rolling=[]
for b in ['D','L']:
 ent=np.zeros((e.N,48),bool)
 for q in quarters[freeze:].unique():
  ix=np.flatnonzero(quarters==q);a=max(freeze,int(ix[0]));z=int(ix[-1]+1);name=select(b,max(0,a-252),a);ent[a:z]=entries[name.split('_',1)[1]][a:z];rolling.append(dict(base=b,start=str(e.DATES[a]),end=str(e.DATES[z-1]),choice=name))
 entries['rolling'+b]=ent
def stats(r):
 tr=r[7];done=tr[tr[:,8]==0];out={'tripDays':len(tr),'completeTrips':len(done),'completeWinRate':float(np.mean(done[:,11]>0)) if len(done) else np.nan,'completeNet':float(done[:,11].sum()),'incompleteTrips':int((tr[:,8]>0).sum()),'allTripMarkedNet':float(tr[:,10].sum()),'deadlineTrips':int(tr[:,7].sum()),'cancelledTrips':int(tr[:,9].sum())}
 for sign,label in [(1,'buy'),(-1,'sell')]:
  amounts={}
  for t in r[3][r[3][:,2]==sign]:d=int(t[0]);amounts[d]=amounts.get(d,0)+sign*t[3]*(e.C[d]-t[4])-t[5]
  out[label+'Days']=len(amounts);out[label+'Hit']=float(np.mean(np.array(list(amounts.values()))>1e-8)) if amounts else np.nan
 return out
def leads(nav,h):
 lag=longest=0
 for flag in nav<h:lag=lag+1 if flag else 0;longest=max(longest,lag)
 n=np.r_[1e6,nav];hh=np.r_[1e6,h];return dict(cumulativeLead=float(np.mean(nav>h)),rolling63Lead=float(np.mean(n[63:]/n[:-63]>hh[63:]/hh[:-63])),longestLag=longest)
names=[b+'_'+k for b in ['D','L'] for k in ['base']+list(manifest['rules'])]+['D_rollingD','L_rollingL'];full={};rows=[];stress=[];cont=[]
holds={p:e.run(np.ones((e.N,48)),a,z,hold=True,tax=0) for p,(a,z) in periods.items()}
for name in names:
 for p,(a,z) in periods.items():
  rr=run(name,a,z);rows.append(dict(name=name,period=p,**met(rr),**stats(rr),**leads(rr[0],holds[p][0])))
  if p=='full':full[name]=rr;nv=np.r_[1e6,rr[0]];cont.append(dict(name=name,preJuly=float(nv[cut-e.START]/nv[0]-1),postJuly=float(nv[-1]/nv[cut-e.START]-1)))
  if p in ['full','validation','recent','older']:st=run(name,a,z,.001);stress.append(dict(name=name,period=p,**met(st),**stats(st)))
for p,h in holds.items():rows.append(dict(name='hold',period=p,**e.metrics(h)))
metrics=pd.DataFrame(rows);stress=pd.DataFrame(stress);metrics.to_csv(O/'metrics.csv',index=False);stress.to_csv(O/'stress10bp.csv',index=False);pd.DataFrame(cont).to_csv(O/'continuous.csv',index=False);pd.DataFrame(selection).to_csv(O/'selection.csv',index=False);pd.DataFrame(rolling).to_csv(O/'rolling_choices.csv',index=False)
src=(R/'work/underperformance/study.py').read_text();ledgerCount=0;maxerr=0.;maxpnlerr=0.;exec(src[src.index('def accounting('):src.index('\nhc,ht=')]);pairchecks=0
tripcols=['day','sellBar','soldQty','saleProceeds','boughtQty','buyCost','firstBuyBar','deadline','missingQty','cancelled','markedNet','cashDifference','buyTriggered']
for name,rr in full.items():
 _,ts=accounting(rr[:7]);t=pd.DataFrame(ts);t['kind']=rr[3][:,16].astype(int);t.to_csv(O/(name+'_fills.csv'),index=False);tr=pd.DataFrame(rr[7],columns=tripcols);tr['date']=[str(e.DATES[int(d)]) for d in tr.day];tr.to_csv(O/(name+'_trips.csv'),index=False)
 for row in rr[7]:
  tx=rr[3][(rr[3][:,0]==row[0])&(rr[3][:,16]>0)];sell=tx[tx[:,2]<0];buy=tx[tx[:,2]>0];assert len(sell)==1 and sell[0,3]==row[2] and np.isclose(sell[0,3]*sell[0,4]-sell[0,5],row[3]);assert np.isclose(buy[:,3].sum(),row[4]) and row[4]+row[8]==row[2] and np.isclose((buy[:,3]*buy[:,4]+buy[:,5]).sum(),row[5]);assert sell[0,3]<=np.floor(sell[0,9]*.2/100)*100;assert np.all(buy[:,1]>sell[0,1]);pairchecks+=1
mi=metrics.set_index(['name','period']);si=stress.set_index(['name','period']);accept={}
for name in names:
 if 'base' in name or 'rolling' in name:continue
 b=name[0]+'_base';years=sum(mi.loc[(name,'year'+str(y)),'return_']>=mi.loc[(b,'year'+str(y)),'return_'] for y in [1,2,3]);ok=all(mi.loc[(name,p),'return_']>mi.loc[(b,p),'return_'] and abs(mi.loc[(name,p),'mdd5'])<=abs(mi.loc[(b,p),'mdd5'])+.02 for p in ['validation','recent']) and years>=2 and mi.loc[(name,'older'),'return_']>=mi.loc[(b,'older'),'return_'] and all(si.loc[(name,p),'return_']>si.loc[(b,p),'return_'] for p in ['validation','recent']);accept[name]={'incrementalPass':bool(ok),'annualWins':int(years),'independentEvidence':False}
audit=dict(prefixChecks=checks,baselineArrayChecks=parity,ledgerFills=ledgerCount,tripReconciliations=pairchecks,maxLedgerError=maxerr,maxPnLError=maxpnlerr,choices=choices,acceptance=accept,defaultChanged=False,independentEvidence=False,freezeSHA=manifest['freezeSHA']);(O/'audit.json').write_text(json.dumps(audit,indent=2));np.savez_compressed(R/'work/tdx_regime/full_results.npz',**{name+'_'+k:rr[i] for name,rr in full.items() for i,k in enumerate(['nav','exposure','curve','trades','extras','debt','interest','trips'])})
print(metrics[metrics.period=='full'][['name','return_','mdd5','tripDays','completeTrips','completeWinRate','completeNet','incompleteTrips','deadlineTrips']].to_string(index=False));print(metrics[metrics.period.isin(['validation','recent','older'])][['name','period','return_','mdd5']].to_string(index=False));print(json.dumps(audit))
