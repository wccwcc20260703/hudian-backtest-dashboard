# -*- coding: utf-8 -*-
from pathlib import Path
import json,sys,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/tdx_rebuy';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
sys.path.insert(0,str(R/'work/tdx_regime'));import inventory_engine as old
sys.path.insert(0,str(R/'work/tdx_rebuy'));import rebuy_engine as engine
e=f.e;P=np.load(R/'work/leverage/plans.npz');E=np.load(R/'work/tdx_regime/entries.npz')['fixed'];Z=np.zeros_like(E);modes=np.full(e.N,2);freeze=int(np.searchsorted(e.DATES,'2025-01-01'));cut=int(np.searchsorted(e.DATES,'2026-07-01'))
manifest={'at':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'Can predeclared early invalidation buybacks reduce sell-too-early losses without destroying profitable T trades?','rules':{'stop05':'After selling, if completed5minclose>=actualsellfill*1.005, start buyback next open. This is a trigger, not a guaranteed0.5%loss cap.','breakout':'Freeze maximum of6 completed closes BEFORE sale. After sale,2completedcloses above that barrier AND latestclose>currentVWAP starts nextopen buyback.','time15':'At least3completed5minbars aftersale, if latestclose>sellfill AND >currentVWAP,start nextopen buyback.'},'control':'Original D/L default(noT) and previous fixed-share T with0.4%price-improvement or14:30deadline. Same unfiltered confirm-sell entries for all T variants; no new entry gating.','execution':'OneT/day,10:30..14:00 entry,20%availableoldshares,min100lots andpriorbarvolume1%;actualsoldquantity governs buyback. Price-improvement0.4%kept for all,first trigger latches; otherwise14:30..14:50attempt. Neworiginal/maintenance instruction cancels replenishment. All partial/missing shares included.','costs':'5/10bp adverse slip,tickrounding,commission min5,stamp/transfer,T+1,6%calendarinterest,newbuydebt<=50%equity,passivedriftallowed. Original mark/account conventions unchanged.','comparison':'Continuous fullportfolio AND same-start paired day: reproduce entire prior fixedT history, change only that day buyback policy, compare dayending NAV/actualqty/fees/interest. No falsely attributing different future positions to execution timing.','selection':'Train through2024 then frozen2025..2026Jun/recentJul..Oct8; quarterly prior252days choose from noT,oldfixed,and3new byannual logwealth-1.5absDD withDD<=original+2pp.','acceptance':'Both laterperiodreturns>original,DD<=original+2pp,2/3fixedannual,older>=original,10bp bothlaterperiods improve; original cash return>=hold/DD<=75%hold/annual2of3/older/stress/independent unchanged;wealth1.20 separate.','data':'Historical5min2020..2026Oct8 alreadyseen; this is retrospective chronological evidence,not independent. Oct9 excluded for unresolved minute/daily extrema mismatch. No new thresholds afterresults.','freezeSHA':hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(O/'plan_before_results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
pols={'base':np.zeros(e.N,dtype=int),'fixed':np.zeros(e.N,dtype=int),'stop05':np.ones(e.N,dtype=int),'breakout':np.full(e.N,2),'time15':np.full(e.N,3)};ents={k:Z if k=='base' else E for k in pols}
def run(name,a,z,slip=.0005):
 b,k=name.split('_',1);return engine.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,P['D' if b=='D' else 'D_all_full_1.5'],a,z,modes,ents[k],pols[k],slip=slip)
def met(r):return f.metrics(r[:7])
src=(R/'work/tdx_regime/study.py').read_text();exec(src[src.index('def stats('):src.index('names=')])
periods={'train':(e.START,freeze),'validation':(freeze,cut),'recent':(cut,e.N),'full':(e.START,e.N),'older':(0,e.START)}
for y in range(3):periods['year'+str(y+1)]=(int(np.searchsorted(e.DATES,f'{2023+y}-10-09')),int(np.searchsorted(e.DATES,f'{2024+y}-10-09')))
parity=0
for b,key in [('D','D'),('L','D_all_full_1.5')]:
 for rule in ['base','fixed']:
  for a,z in periods.values():
   for slip in [.0005,.001]:
    rr=run(b+'_'+rule,a,z,slip);ro=old.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,P[key],a,z,modes,ents[rule],slip=slip)
    for i in range(8):assert np.allclose(ro[i],rr[i][:,:17] if i==3 else rr[i][:,:13] if i==7 else rr[i],atol=1e-8,rtol=0);parity+=1
selection=[]
def select(base,a,z):
 bm=met(run(base+'_base',a,z));eligible=[]
 for rule in ['base','fixed']+list(manifest['rules']):
  name=base+'_'+rule;m=met(run(name,a,z));ok=abs(m['mdd5'])<=abs(bm['mdd5'])+.02;score=np.log1p(m['return_'])/((z-a)/242)-1.5*abs(m['mdd5']);selection.append(dict(base=base,name=name,start=str(e.DATES[a]),end=str(e.DATES[z-1]),eligible=ok,score=score))
  if ok:eligible.append((score,name))
 return max(eligible)[1]
choices={b:select(b,e.START,freeze) for b in ['D','L']};quarters=pd.PeriodIndex(e.DATES,freq='Q');rolling=[]
for b in ['D','L']:
 ent=Z.copy();pol=np.zeros(e.N,dtype=int)
 for q in quarters[freeze:].unique():
  ix=np.flatnonzero(quarters==q);a=max(freeze,int(ix[0]));z=int(ix[-1]+1);name=select(b,max(0,a-252),a);k=name.split('_',1)[1];ent[a:z]=ents[k][a:z];pol[a:z]=pols[k][a:z];rolling.append(dict(base=b,start=str(e.DATES[a]),end=str(e.DATES[z-1]),choice=name))
 ents['rolling'+b]=ent;pols['rolling'+b]=pol
names=[b+'_'+k for b in ['D','L'] for k in ['base','fixed']+list(manifest['rules'])]+['D_rollingD','L_rollingL'];rows=[];stress=[];full={};continuous=[];holds={p:e.run(np.ones((e.N,48)),a,z,hold=True,tax=0) for p,(a,z) in periods.items()}
for name in names:
 for p,(a,z) in periods.items():
  rr=run(name,a,z);rows.append(dict(name=name,period=p,**met(rr),**stats(rr),**leads(rr[0],holds[p][0])))
  if p=='full':full[name]=rr;nv=np.r_[1e6,rr[0]];continuous.append(dict(name=name,preJuly=float(nv[cut-e.START]/nv[0]-1),postJuly=float(nv[-1]/nv[cut-e.START]-1)))
  if p in ['full','validation','recent','older']:rs=run(name,a,z,.001);stress.append(dict(name=name,period=p,**met(rs),**stats(rs)))
for p,h in holds.items():rows.append(dict(name='hold',period=p,**e.metrics(h)))
m=pd.DataFrame(rows);st=pd.DataFrame(stress);m.to_csv(O/'metrics.csv',index=False);st.to_csv(O/'stress10bp.csv',index=False);pd.DataFrame(continuous).to_csv(O/'continuous.csv',index=False);pd.DataFrame(selection).to_csv(O/'selection.csv',index=False);pd.DataFrame(rolling).to_csv(O/'rolling_choices.csv',index=False)
src=(R/'work/underperformance/study.py').read_text();ledgerCount=0;maxerr=0.;maxpnlerr=0.;exec(src[src.index('def accounting('):src.index('\nhc,ht=')]);tripchecks=0;prefixchecks=0
tripcols=['day','sellBar','soldQty','saleProceeds','boughtQty','buyCost','firstBuyBar','deadline','missingQty','cancelled','markedNet','cashDifference','buyTriggered','trigger']
for name,rr in full.items():
 _,ts=accounting(rr[:7]);t=pd.DataFrame(ts);t['kind']=rr[3][:,16].astype(int);t['trigger']=rr[3][:,17].astype(int);t.to_csv(O/(name+'_fills.csv'),index=False);tr=pd.DataFrame(rr[7],columns=tripcols);tr['date']=[str(e.DATES[int(d)]) for d in tr.day];tr.to_csv(O/(name+'_trips.csv'),index=False)
 for v in rr[7]:
  tx=rr[3][(rr[3][:,0]==v[0])&(rr[3][:,16]>0)];s=tx[tx[:,2]<0];bb=tx[tx[:,2]>0];assert len(s)==1 and s[0,3]==v[2] and bb[:,3].sum()==v[4] and v[2]==v[4]+v[8];assert np.isclose(s[0,3]*s[0,4]-s[0,5],v[3]) and np.isclose(np.sum(bb[:,3]*bb[:,4]+bb[:,5]),v[5]);tripchecks+=1

# Common inherited-account audit: change only one day, preserving all preceding fixed-T history.
paired=[]
for base,key in [('D','D'),('L','D_all_full_1.5')]:
 reference=full[base+'_fixed']
 for oldtrip in reference[7]:
  d=int(oldtrip[0]);dailyref=reference[0][d-e.START];openingnav=1e6 if d==e.START else reference[0][d-e.START-1]
  for rule in manifest['rules']:
   policy=np.zeros(e.N,dtype=int);policy[d]=pols[rule][d];rr=engine.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,P[key],e.START,d+1,modes,E,policy);assert np.array_equal(rr[0][:-1],reference[0][:d-e.START]);v=rr[7][-1];assert v[0]==d and np.array_equal(v[:4],oldtrip[:4]);prefixchecks+=1
   tx=rr[3][rr[3][:,0]==d];orig=reference[3][reference[3][:,0]==d];ot=orig[orig[:,16]>1];nt=tx[tx[:,16]>1]
   paired.append(dict(base=base,rule=rule,date=str(e.DATES[d]),sellBar=int(v[1]),oldFirstBuy=int(oldtrip[6]),newFirstBuy=int(v[6]),trigger=int(v[13]),soldQty=int(v[2]),oldBought=int(oldtrip[4]),newBought=int(v[4]),oldMissing=int(oldtrip[8]),newMissing=int(v[8]),oldNet=float(oldtrip[10]),newNet=float(v[10]),navDelta=float(rr[0][-1]-dailyref),navDeltaFraction=float((rr[0][-1]-dailyref)/openingnav),oldBuyAvg=float(np.sum(ot[:,3]*ot[:,4])/max(np.sum(ot[:,3]),1)),newBuyAvg=float(np.sum(nt[:,3]*nt[:,4])/max(np.sum(nt[:,3]),1))))
pd.DataFrame(paired).to_csv(O/'same_start_pairs.csv',index=False)
mi=m.set_index(['name','period']);si=st.set_index(['name','period']);accept={}
for b in ['D','L']:
 for rule in manifest['rules']:
  name=b+'_'+rule;base=b+'_base';years=sum(mi.loc[(name,'year'+str(y)),'return_']>=mi.loc[(base,'year'+str(y)),'return_'] for y in [1,2,3]);ok=all(mi.loc[(name,p),'return_']>mi.loc[(base,p),'return_'] and abs(mi.loc[(name,p),'mdd5'])<=abs(mi.loc[(base,p),'mdd5'])+.02 for p in ['validation','recent']) and years>=2 and mi.loc[(name,'older'),'return_']>=mi.loc[(base,'older'),'return_'] and all(si.loc[(name,p),'return_']>si.loc[(base,p),'return_'] for p in ['validation','recent']);accept[name]=dict(incrementalPass=bool(ok),annualWins=int(years),independentEvidence=False)
audit=dict(baselineArrayChecks=parity,sameStartPrefixChecks=prefixchecks,ledgerFills=ledgerCount,tripReconciliations=tripchecks,maxLedgerError=maxerr,maxPnLError=maxpnlerr,choices=choices,acceptance=accept,defaultChanged=False,independentEvidence=False,freezeSHA=manifest['freezeSHA']);(O/'audit.json').write_text(json.dumps(audit,indent=2));np.savez_compressed(R/'work/tdx_rebuy/full_results.npz',**{name+'_'+k:rr[i] for name,rr in full.items() for i,k in enumerate(['nav','exposure','curve','trades','extras','debt','interest','trips'])})
print(m[m.period=='full'][['name','return_','mdd5','completeTrips','completeWinRate','completeNet','incompleteTrips','allTripMarkedNet','longestLag']].to_string(index=False));print(m[m.period.isin(['validation','recent','older'])][['name','period','return_','mdd5']].to_string(index=False));print(json.dumps(audit))
