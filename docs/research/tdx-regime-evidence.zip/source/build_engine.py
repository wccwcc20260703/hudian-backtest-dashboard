from pathlib import Path
R=Path.cwd();src=(R/'work/drift/drift_engine.py').read_text()
src=src.replace('signals,start,end,modes,rate=', 'signals,start,end,modes,entries,rate=')
src=src.replace('tr=np.zeros(((end-start)*48,16))','tr=np.zeros(((end-start)*48,17));trips=np.zeros((end-start,13));ntrip=0')
src=src.replace('forced=False\n  for j', 'forced=False\n  used=False;active=False;buy_pending=False;cancelled=False;soldq=0;remain=0;proceeds=0.;buycost=0.;sellprice=0.;sellbar=-1;firstbuy=-1;deadlinebuy=False\n  for j')
src=src.replace('sig=signals[d,j];isrisk=False','sig=signals[d,j];isrisk=False;before_nt=nt')
insert='''
    # The original/maintenance engine has priority; never refill after a new risk instruction.
    if active and (isrisk or sig>=0):cancelled=True;active=False
    if entries[d,j] and 12<=j<=36 and not used and target>0 and not forced and not (pending and j<=deadline):
     used=True
     px=b[d,j,0];equity=cash+sh*px;cap=int(b[d,j-1,4]*.01/100)*100
     wanted=int(avail*.2/100)*100;qty=min(wanted,cap)
     if wanted>cap:caps+=1
     lower=math.floor(ref[d]*.9*100+.5)/100;fill=math.floor(px*(1-slip)*100+1e-8)/100
     if px<=lower+.005 or fill<lower:
      if qty>0:limits+=1
      qty=0
     if qty>0 and nt==before_nt:
      fee=max(5.,qty*fill*.00025)+qty*fill*(transfer[d]+stamp[d]);oldavail=avail;oldsh=sh
      cash+=qty*fill-fee;sh-=qty;avail-=qty;fees+=fee;turnover+=qty*fill/max(equity,1.)
      soldq=qty;remain=qty;proceeds=qty*fill-fee;sellprice=fill;sellbar=j;active=True
      tr[nt,0]=d;tr[nt,1]=j;tr[nt,2]=-1;tr[nt,3]=qty;tr[nt,4]=fill;tr[nt,5]=fee;tr[nt,6]=cash;tr[nt,7]=sh;tr[nt,8]=avail;tr[nt,9]=oldavail;tr[nt,10]=target;tr[nt,11]=cap;tr[nt,12]=oldsh;tr[nt,13]=-1;tr[nt,14]=max(-cash,0);tr[nt,16]=1;nt+=1
    if active and j>sellbar and nt==before_nt and not (pending and j<=deadline):
     if known<=sellprice*.996:buy_pending=True
     if j>=42:buy_pending=True;deadlinebuy=True
     if buy_pending and remain>0:
      px=b[d,j,0];equity=cash+sh*px;cap=int(b[d,j-1,4]*.01/100)*100;qty=min(remain,cap)
      if remain>cap:caps+=1
      upper=math.floor(ref[d]*1.1*100+.5)/100;fill=math.ceil(px*(1+slip)*100-1e-8)/100
      if px>=upper-.005 or fill>upper:
       if qty>0:limits+=1
       qty=0
      allowed=min(maxlev,max(1.,target))
      if allowed<=1:aff=max(0,int((cash-5)/(fill*(1+.00025+transfer[d]))/100)*100)
      else:
       budget=allowed*cash+(allowed-1)*sh*px-allowed*5
       aff=max(0,int(budget/(px+allowed*(fill-px)+allowed*fill*(.00025+transfer[d]))/100)*100)
      if credit<1e18:aff=min(aff,max(0,int((cash+credit-5)/(fill*(1+.00025+transfer[d]))/100)*100))
      qty=min(qty,aff)
      if qty>0:
       gross=qty*fill;fee=max(5.,gross*.00025)+gross*transfer[d];oldavail=avail;oldsh=sh
       cash-=gross+fee;sh+=qty;remain-=qty;buycost+=gross+fee;fees+=fee;turnover+=gross/max(equity,1.);dayborrow=max(dayborrow,-cash)
       if firstbuy<0:firstbuy=j
       tr[nt,0]=d;tr[nt,1]=j;tr[nt,2]=1;tr[nt,3]=qty;tr[nt,4]=fill;tr[nt,5]=fee;tr[nt,6]=cash;tr[nt,7]=sh;tr[nt,8]=avail;tr[nt,9]=oldavail;tr[nt,10]=target;tr[nt,11]=cap;tr[nt,12]=oldsh;tr[nt,13]=-1;tr[nt,14]=max(-cash,0);tr[nt,16]=3 if j>=42 else 2;nt+=1
       if remain==0:active=False
'''
src=src.replace('   if j==47:',insert+'   if j==47:')
src=src.replace('  if dayborrow>0:borrowdays+=1','''  if dayborrow>0:borrowdays+=1
  if soldq>0:
   trips[ntrip,0]=d;trips[ntrip,1]=sellbar;trips[ntrip,2]=soldq;trips[ntrip,3]=proceeds;trips[ntrip,4]=soldq-remain;trips[ntrip,5]=buycost;trips[ntrip,6]=firstbuy;trips[ntrip,7]=1 if deadlinebuy else 0;trips[ntrip,8]=remain;trips[ntrip,9]=1 if cancelled else 0;trips[ntrip,10]=proceeds-buycost-remain*cl[d];trips[ntrip,11]=proceeds-buycost;trips[ntrip,12]=1 if buy_pending else 0;ntrip+=1''')
src=src.replace('maxex]),debts,intr','maxex]),debts,intr,trips[:ntrip]')
(R/'work/tdx_regime/inventory_engine.py').write_text(src)
