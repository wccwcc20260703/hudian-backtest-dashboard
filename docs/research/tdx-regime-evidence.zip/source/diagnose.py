# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/tdx_regime';sys.path.insert(0,str(R/'work/tdx_regime'));import inventory_engine as eng
tests=[]
def fixture(mode=1.):
 b=np.ones((2,48,6))*100;b[:,:,4]=1e7;b[:,:,5]=1e9;cl=np.full(2,100.);div=np.zeros(2);bonus=np.zeros(2);ref=np.full(2,100.);stamp=np.full(2,.0005);transfer=np.full(2,.00001);dates=np.array([20000,20001]);sig=np.full((2,48),-1.);sig[0,1]=mode;sig[1,6]=mode;entries=np.zeros((2,48),bool);entries[:,12]=True
 return [b,cl,div,bonus,ref,stamp,transfer,dates,sig,0,2,np.full(2,2),entries]
z=fixture();z[0][1,20:,0:4]=99.;z[1][1]=99.;r=eng.execute(*z);assert not np.any((r[3][:,0]==0)&(r[3][:,16]>0));tests.append('same-day new stock cannot supply overlay sale')
assert len(r[7])==1 and r[7][0,8]==0 and r[7][0,11]>0;tests.append('equal actual quantity completes after lower-price confirmation')
z=fixture();z[0][1,12,0:4]=90.;r=eng.execute(*z);assert len(r[7])==0;tests.append('limit-down blocks discretionary sale')
z=fixture();z[0][1,11,4]=15000;r=eng.execute(*z);assert r[7][0,2]==100;tests.append('entry uses prior-bar1%volume cap and100-share lot')
z=fixture(1.5);z[0][1,20:,0:4]=90.;z[1][1]=90.;r=eng.execute(*z);assert r[7][0,8]>0 and r[7][0,4]>0
for t in r[3][r[3][:,2]>0]:
 eq=t[6]+t[7]*z[0][int(t[0]),int(t[1]),0];assert max(-t[6],0)<=.5*eq+1e-6
tests.append('borrow ceiling can prevent full buyback after decline; partial quantity retained')
z=fixture();z[8][1,20]=0.;r=eng.execute(*z);assert r[7][0,9]==1 and r[7][0,4]==0;tests.append('new original target cancels outstanding replenishment')
z=fixture();z[0][1,20:,0:4]=105.;z[1][1]=105.;r=eng.execute(*z);assert r[7][0,7]==1 and r[7][0,8]>0;tests.append('cash scarcity records incomplete late buyback rather than inventing shares')

groups=[];pa=[];examples=[];payoffs=[]
for base in ['D','L']:
 orig=pd.read_csv(O/(base+'_fixed_trips.csv'))
 for rule in ['fixed','range','trend_veto']:
  name=base+'_'+rule;t=pd.read_csv(O/(name+'_trips.csv'));full=t[t.missingQty==0]
  ret=full.cashDifference/full.saleProceeds;win=ret[ret>0];loss=ret[ret<=0]
  payoffs.append(dict(name=name,trips=len(full),wins=len(win),winRate=len(win)/len(full),meanReturn=float(ret.mean()),meanWin=float(win.mean()),meanLoss=float(loss.mean()),meanPayoffBreakEven=float(-loss.mean()/(win.mean()-loss.mean()))))
  for deadline in [0,1]:
   v=full[full.deadline==deadline];wins=v[v.cashDifference>0];loss=v[v.cashDifference<=0]
   groups.append(dict(name=name,type='price_target' if deadline==0 else 'deadline',trips=len(v),wins=len(wins),net=float(v.cashDifference.sum()),meanWin=float(wins.cashDifference.mean()) if len(wins) else None,meanLoss=float(loss.cashDifference.mean()) if len(loss) else None))
  miss=t[t.missingQty>0];groups.append(dict(name=name,type='incomplete',trips=len(miss),wins=int((miss.markedNet>0).sum()),net=float(miss.markedNet.sum()),meanWin=None,meanLoss=None))
  # Descriptive date comparison only: inherited portfolios differ, these are NOT additive causal effects.
  if rule!='fixed':
   tt=t.set_index('date');oo=orig.set_index('date')
   for date,r0 in oo.iterrows():
    status='removed' if date not in tt.index else 'same_time' if tt.loc[date,'sellBar']==r0.sellBar else 'different_time'
    pa.append(dict(name=name,date=date,status=status,oldSellBar=r0.sellBar,newSellBar=None if date not in tt.index else tt.loc[date,'sellBar'],oldMarkedNet=r0.markedNet,newMarkedNet=None if date not in tt.index else tt.loc[date,'markedNet']))
  if base=='L':
   fills=pd.read_csv(O/(name+'_fills.csv'))
   for _,row in t.nsmallest(3,'markedNet').iterrows():
    fs=fills[(fills.date==row.date)&(fills.kind>0)];buy=fs[fs.side>0];sell=fs[fs.side<0]
    examples.append(dict(name=name,date=row.date,sellBar=int(row.sellBar),firstBuyBar=int(row.firstBuyBar),sellPrice=float(sell.iloc[0].price),buyAverage=float((buy.qty*buy.price).sum()/buy.qty.sum()) if len(buy) else None,soldQty=int(row.soldQty),boughtQty=int(row.boughtQty),net=float(row.markedNet)))
pd.DataFrame(groups).to_csv(O/'trip_outcome_groups.csv',index=False);pd.DataFrame(pa).to_csv(O/'gate_date_comparison.csv',index=False);pd.DataFrame(examples).to_csv(O/'loss_examples.csv',index=False)
pd.DataFrame(payoffs).to_csv(O/'trip_payoffs.csv',index=False)
mi=pd.read_csv(O/'metrics.csv').set_index(['name','period']);cash={}
for n in ['D_fixed','D_range','D_trend_veto']:
 def ok(p):return bool(mi.loc[(n,p),'return_']>=mi.loc[('hold',p),'return_'] and abs(mi.loc[(n,p),'mdd5'])<=.75*abs(mi.loc[('hold',p),'mdd5']))
 cash[n]=dict(fullReturnAndDD=ok('full'),annualPasses=sum(ok('year'+str(y)) for y in [1,2,3]),olderReturnAndDD=ok('older'),wealthRelativeToHold=float((1+mi.loc[(n,'full'),'return_'])/(1+mi.loc[('hold','full'),'return_'])),completePass=False,independentEvidence=False)
files=[R/'work/tdx_regime/inventory_engine.py',R/'work/tdx_regime/study.py',R/'work/tdx_t/study.py',R/'work/leverage/plans.npz',R/'outputs/reentry/forward_freeze.json']
audit=dict(syntheticTests=tests,originalCashCriteria=cash,files=[dict(path=str(p.relative_to(R)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]);(O/'additional_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2));print(pd.DataFrame(groups).to_string(index=False));print(pd.DataFrame(pa).groupby(['name','status']).size().to_string());print(pd.DataFrame(examples).to_string(index=False));print(json.dumps(cash))
