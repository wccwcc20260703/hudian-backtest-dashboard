# -*- coding: utf-8 -*-
from pathlib import Path
import json,hashlib,sys
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/tdx_t'
src=(R/'work/tdx_t/study.py').read_text();ns={'np':np};exec(src[src.index('def features('):src.index('# Screenshot identity')],ns)
def bars(p):return np.array([[v,v,v,v,100000,v*100000] for v in p],float)
b=bars([100,100,100,97,90]);s,_,_=ns['features'](b,100)
# A past signal calculated at its arrival can disappear from the final whole-chart snapshot.
live=ns['signals'](b[:4],100,'edge')[3];final_snapshot=bool(b[3,3]<s[-1] and np.all(b[1:3,3]>s[-1]));assert live==1 and not final_snapshot
c=bars([100,90,91,92]);assert ns['signals'](c,100,'confirm')[3]==1;assert ns['signals'](c[:3],100,'confirm')[-1]!=1
m=pd.read_csv(O/'metrics.csv').set_index(['name','period']);cash={}
for n in ['D_edge','D_confirm','D_vwap']:
 def ok(p):return bool(m.loc[(n,p),'return_']>=m.loc[('hold',p),'return_'] and abs(m.loc[(n,p),'mdd5'])<=.75*abs(m.loc[('hold',p),'mdd5']))
 cash[n]={'fullReturnAndDD':ok('full'),'annualPasses':sum(ok('year'+str(y)) for y in [1,2,3]),'olderReturnAndDD':ok('older'),'wealthRelativeToHold':float((1+m.loc[(n,'full'),'return_'])/(1+m.loc[('hold','full'),'return_'])),'completePass':False,'independentEvidence':False}
paths=[R/'work/tdx_t/study.py',R/'work/drift/drift_engine.py',R/'work/leverage/plans.npz',R/'work/hudian-backtest-dashboard/tests/fixtures/opportunity-minutes.json',R/'outputs/reentry/forward_freeze.json']+list((R/'work/data').glob('minute_*.csv'))+list((R/'work/round2/data').glob('minute*.csv'))
audit={'syntheticTests':3,'repaintExample':{'prices':[100,100,100,97,90],'supportAt97':float(s[3]),'finalSupport':float(s[-1]),'buyAt97WhenLive':True,'buyAt97AfterFinalRedraw':False},'originalCashCriteria':cash,'files':[{ 'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]}
(O/'additional_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2));print(json.dumps(audit['originalCashCriteria']))
