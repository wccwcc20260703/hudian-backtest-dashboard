# -*- coding: utf-8 -*-
from pathlib import Path
import json,zipfile,html
import pandas as pd
R=Path.cwd();O=R/'outputs/tdx_t';D=R/'work/hudian-backtest-dashboard/docs/research'
m=pd.read_csv(O/'metrics.csv');st=pd.read_csv(O/'stress10bp.csv');hits=pd.read_csv(O/'opportunity_metrics.csv');a=json.loads((O/'audit.json').read_text());x=json.loads((O/'additional_audit.json').read_text());q=pd.read_csv(O/'oct9_formula_replay.csv',dtype={'time':str});identity=json.loads((O/'formula_identity.json').read_text())
names={'base':'原规则','edge':'跌穿买／突破卖','confirm':'返回区间确认','vwap':'确认＋VWAP','rolling':'季度滚动选择','hold':'全仓持有'}
def label(n):return names[n] if n in names else ('现金D · ' if n[0]=='D' else '融资L · ')+names[n.split('_',1)[1]]
def fmt(v):return '—' if pd.isna(v) else f'{v*100:.2f}%'
def table(frame,cols):
 def cell(k,v):return html.escape(label(v)) if k in ['name','rule'] else ('买' if v==1 else '卖') if k=='side' else ('—' if pd.isna(v) else str(int(v))) if k in ['days','signals','wins','longestLag'] else fmt(v)
 return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+title+'</th>' for k,title in cols)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+cell(k,r[k])+'</td>' for k,title in cols)+'</tr>' for _,r in frame.iterrows())+'</tbody></table></div>'
def chart():
 W=1160;H=355;left=60;right=25;top=30;bottom=35
 def xx(i):return left+i/(len(q)-1)*(W-left-right)
 def yy(p):return top+(116.1-p)/(116.1-106)*(H-top-bottom)
 def path(col):return ' '.join(('M' if i==0 else 'L')+f'{xx(i):.1f},{yy(v):.1f}' for i,v in enumerate(q[col]))
 lines=['<svg viewBox="0 0 1160 355" role="img" aria-label="10月9日价格与盘后支撑和因果分钟近似支撑对照"><rect width="1160" height="355" fill="white"/>']
 for p in [106,108,110,112,114,116]:lines.append(f'<path d="M60,{yy(p):.1f} H1135" stroke="#e5edf3" stroke-dasharray="4 4"/><text x="15" y="{yy(p)+4:.1f}" fill="#8393a3" font-size="13">{p}</text>')
 for col,color,dash in [('price','#16869c',''),('EMA900','#5976d7',''),('finalSupport','#bd9852','6 4'),('prefixPriceSupport','#ac6984','3 3')]:lines.append(f'<path d="{path(col)}" fill="none" stroke="{color}" stroke-width="2" stroke-dasharray="{dash}"/>')
 for i,r in q.iterrows():
  px=xx(i);py=yy(r.price);time=r.time[:2]+':'+r.time[2:]
  if r.snapshotB:lines.append(f'<circle cx="{px:.1f}" cy="{py:.1f}" r="6" fill="white" stroke="#c89630" stroke-width="2"><title>{time} 盘后重算B · 价格{r.price:.2f} · 并非当时记录</title></circle>')
  if r.causalProxyB:lines.append(f'<path d="M{px-6:.1f},{py+8:.1f} L{px+6:.1f},{py+8:.1f} L{px:.1f},{py-4:.1f} Z" fill="#c45e76"><title>{time} 分钟价格极值近似的当时B · 价格{r.price:.2f} · 缺少逐笔极值</title></path>')
 for t in ['0931','1000','1030','1100','1330','1400','1430','1500']:
  ix=q.index[q.time==t][0];lines.append(f'<text x="{xx(ix):.1f}" y="347" text-anchor="middle" fill="#8393a3" font-size="13">{t[:2]}:{t[2:]}</text>')
 return ''.join(lines)+'</svg><div class="legend">蓝绿线：价格　蓝线：EMA900　金虚线／空心圆：盘后支撑／B　紫虚线／实心三角：分钟极值近似的实时支撑／B</div>'
cols=[('name','方案'),('return_','收益'),('mdd5','最大回撤'),('buyHit','买入日成功率'),('sellHit','卖出日成功率'),('cumulativeLead','累计领先比例'),('rolling63Lead','63日滚动领先'),('longestLag','最长落后天数')]
sections=[]
for period,title in [('full','三年账户：2023-10-09 至 2026-10-08'),('validation','2025年1月至2026年6月'),('recent','2026年7月至10月8日'),('older','更早行情：2020年至2023年10月之前')]:sections.append('<section><h2>'+title+'</h2>'+table(m[m.period==period],cols)+'<p class="note">各区间从100万元现金独立起算。账户成功率合并同日同方向成交后计算，融资利息计入账户收益。已见历史上的时间顺序检验，非独立盲测。</p></section>')
opcols=[('rule','观察规则'),('side','方向'),('signals','点数'),('days','独立日期'),('dayHit','按日期合并成功率'),('pointHit','逐点成功率'),('meanNetReturn','逐点平均净方向优势')]
op=''.join('<h3>'+title+'</h3>'+table(hits[(hits.period==p)&(hits.slip==.0005)],opcols) for p,title in [('full','近三年'),('validation','2025年至2026年6月'),('recent','2026年7月以后'),('older','更早行情')])
annual=''.join('<h3>固定年度 '+str(y)+'</h3>'+table(m[m.period=='year'+str(y)],[('name','方案'),('return_','收益'),('mdd5','最大回撤')]) for y in [1,2,3])
stress=''.join('<h3>'+p+'</h3>'+table(st[st.period==p],[('name','方案'),('return_','收益'),('mdd5','最大回撤')]) for p in ['full','validation','recent','older'])
page='''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>沪电股份 · 通达信做T指标复现与检验</title><style>body{margin:0;background:#f3f6fa;color:#1c324b;font:15px/1.85 system-ui}main{max-width:1250px;margin:30px auto;padding:24px}section{background:white;border:1px solid #dce6ef;border-radius:12px;margin:24px 0;padding:25px}h1{font-size:30px}h2{font-size:22px}h3{font-size:17px}a{color:#128086}.callout{padding:20px;border-left:4px solid #c69b48;background:#faf5e9}.scroll{overflow:auto}table{width:100%;white-space:nowrap;border-collapse:collapse;font-size:13px}td,th{text-align:right;padding:10px;border-bottom:1px solid #e5edf3}td:first-child,th:first-child{text-align:left}.note,.legend{color:#7e8fa3;font-size:13px}svg{width:100%;min-width:600px}code{background:#edf2f6;padding:3px 6px}li{margin:10px 0}details{margin:15px 0}summary{cursor:pointer;color:#13818a}pre{overflow:auto;white-space:pre-wrap;background:#f5f7fa;padding:16px;font-size:13px}@media(max-width:650px){main{padding:12px}section{padding:16px}h1{font-size:25px}}</style></head><body><main><a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a><h1>通达信做T指标：复现得上，交易效果如何？</h1><p>第十八批 · 2026-10-09 · 三年检验截至10月8日 · 10月9日单独做公式复现</p><div class="callout"><b>截图的三个数已全部复现。</b>强弱110.96、支撑106.91、阻力114.68。原B/S偏向逆势：跌穿下沿买、突破上沿卖。去掉未来信息后的三种5分钟近似规则，加入原现金／融资账户后均未通过升级要求；本次不更换默认，不新增未经验证的“强买”提示。</div>
<section><h2>你提供的公式，实际在计算什么？</h2><p>OCR中的强5、强$、文挥等是变量识别错误，校正后与公开版本的核心运算一致。EMA30高于EMA900时填红带，低于时填绿带；红绿带本身没有参与B/S条件，也没有提供成功概率。</p><p>上沿=max(昨收,当日最高)，下沿=min(昨收,当日最低)。支撑=下沿＋区间宽度÷16；阻力=下沿＋区间宽度×7/8。它们是当日价格区间的固定分位，不是通过历史成交密集区识别出的支撑，也不是10个月均线。</p><p>10月9日：上沿115.88、下沿106.31、宽度9.57。所以支撑106.908125→<b>106.91</b>，阻力114.68375→<b>114.68</b>。取腾讯09:31—11:30、13:01—15:00共240个分钟价格，以09:31价格初始化EMA900，结果110.9562585→<b>110.96</b>；若把09:30开盘点也当作第一周期，结果不同。</p><p><b>B并不是“止跌后买入”。</b>LONGCROSS(支撑,现价,2)要求此前两个周期价格在支撑之上，此刻跌穿支撑。卖出标签则是价格向上突破阻力，并不要求冲高回落。函数方向依据<a href="https://help.tdx.com.cn/gspt/docs/markdown/redword/functionlist.html">通达信官方函数说明</a>，公式以用户提供文本为主，<a href="https://www.zhibiaow.com/10181.html">公开同式版本</a>作交叉核对。</p><p>通达信公式中的S代表卖出标签；本看板S1/S2代表支撑类买入观察、R代表风险。两套字母含义不同，不能直接对应强弱等级。</p></section>
<section><h2>为什么盘后看起来更容易抓住最低附近？</h2><p>DYNAINFO最高／最低是当前即时行情。在同一次整图重算时，最新高低价决定整条水平线，过去的交叉标记也可能移动或消失。举例：价格100、100、100、97时，支撑97.1875，会出现向下穿越；随后跌到90，支撑改为90.625，整图重画时之前97的交叉就消失了。这是公式的可复现性质，不代表软件虚构行情。</p><p>因此需要保存每个时刻当时产生的信号，不能拿盘后最终低点算出的整日B标记回测。下图金圈是按当日最终极值重算，三角是只用截至该分钟价格极值的近似。两者不是同一组时点。</p><div class="scroll">'''+chart()+'''</div><p class="note">金圈B：10:29、10:40、11:06；因果分钟近似B：09:40、09:56、09:59、10:05、10:14、10:39、10:46、11:05。此处为原交叉诊断，未加历史研究的30分钟冷却。分钟价格最低106.51，报价最低106.31；缺少当时逐笔极值，所以三角不声称是通达信当时准确推送。三个末值复现，也不等于全部盘中标记已精确复现。</p><p>当日最终阻力114.68高于当日最高113.50，原式盘后图不会给出突破阻力卖点。因此它无法替代看板09:39“早先买入观察失效”的R2风险逻辑；两者识别的事件不同。</p></section>
<section><h2>先固定规则，再看结果</h2><ol><li><b>跌穿买／突破卖：</b>按每根已完成5分钟的运行高低点计算当前上下沿；与当前阈值比较此前两根收盘，接近原式实时逻辑。两根5分钟不等于两根1分钟，明确作为近似。</li><li><b>返回区间确认：</b>触及上下沿时冻结该触及时的线，最多等后续3根。买入需连续两根回到支撑上，卖出需连续两根回到阻力下；再次触及则更新参考线和等待时间。</li><li><b>确认＋VWAP：</b>在第二条基础上，买入还需站上当时成交均价，卖出还需跌破当时成交均价。</li></ol><p>同方向冷却30分钟，使用已完成数据，下一根开盘加不利滑点；观察截止14:45。长期只有5分钟数据，未把EMA900直接错当成900根5分钟，也没有将当天最终日线最高最低补进分时。三种规则一次登记，未追加阈值搜索。</p><p>账户检验从原D现金和原L融资出发，每天最多做一轮：原计划时点之后遇到卖点，把原日目标降低最多25个百分点；后续买点恢复原目标，无买点则14:50尝试恢复。保留T+1和可售老仓限制，不允许卖空，也不保证买回股数刚好相同。融资每笔买后借款≤净资产50%，持有期间允许被动超仓。该实验检验“加入一层做T”的边际效果，不能据此断言所有做T策略无效。</p></section>
<section><h2>独立观察点：命中率与收益方向分开看</h2><p>每点试算1000股，受前根成交量1%及整手限制；买入净方向优势=股数×(收盘−含滑点买价)−买费；卖出=股数×(含滑点卖价−收盘)−卖费。表中按日期合并成功率将同日同方向净额合并；逐点统计每个提示。均非完整往返利润，未假定观察时一定有钱或可售持仓，更不是T+0可兑现收益。</p>'''+op+'''<p>原近似买点按日53.07%、卖点54.87%，但逐点只有45.61%和45.54%；逐点平均净方向优势为−0.041%和−0.281%。多次提示会改变统计权重，“过半日期方向正确”不能直接推成赚钱能力。确认没有稳定提高胜率，VWAP过滤只留下127个买入日，不能因全期均值变正就宣称稳定有效。</p></section>
'''+''.join(sections)+'''<section><h2>7月前后，原账户连续承接</h2>'''+table(pd.read_csv(O/'continuous.csv'),[('name','方案'),('preJuly','7月之前段收益'),('postJuly','7月起段收益')])+'''<p class="note">7月1日不重新建仓，两段复利相乘等于全期；与独立起算表口径不同。</p></section>
<section><h2>训练选择、年度及压力结果</h2><p>截至2024年底训练，两账户都选择“确认＋VWAP”。后续2025年至2026年6月、7月以后均落后原策略。逐季度只用此前252日选择后，现金全期509.28%低于514.17%，融资1174.21%低于1185.29%；已见历史上的滚动检验也没有提供升级依据。</p><details><summary>展开三个固定年度段</summary>'''+annual+'''</details><details><summary>展开10基点滑点全部结果</summary>'''+stress+'''</details><p>三种规则×两种账户，六个候选均未通过增量要求。原现金目标另算：三个新现金方案都只有1/3固定年度同时保住持有收益并将回撤相对降低25%；更早行情均不达标，也都未达到全期财富1.20倍持有。没有冻结后独立证据；不能用融资成绩替代现金达标。</p></section>
<section><h2>可复核证据与下一步</h2><p>'''+str(a['prefixChecks'])+'''次前缀检查确认已发生信号不读取后续K线；'''+str(a['ledgerFills'])+'''笔成交独立核对现金、股份、T+1、额度、费用和净值，账本误差0；3项小例子检查包括交叉方向、确认延后与盘后重画。原基线两账户收益逐值复现。原前瞻冻结文件未修改。</p><p>数据截至10月8日的完整历史；10月9日分钟与日线极值口径差异仍未解决，因此今天只做公式诊断。此前研究和本批历史全部已经见过，不能称为新盲测。</p><p>值得保留的是“价格相对日内区间的位置”这个因子。下一小批需先区分单边趋势与震荡，比较固定老仓做T和不做T；红绿带是否适合这种筛选需要另行登记和验证。EMA红绿状态在本批只复现，没有直接充当交易过滤器。当前默认及S/R观察提示保持原样。</p><p><a href="tdx-t-evidence.zip">下载公式说明、逐点明细、全部账户结果及研究脚本 ZIP</a></p></section></main></body></html>'''
(O/'report.html').write_text(page);(D/'tdx-t.html').write_text(page)
with zipfile.ZipFile(D/'tdx-t-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(O.iterdir()):
  if p.suffix in ['.csv','.json','.txt'] and p.name!='publication.json':z.write(p,p.name)
 for p in sorted((R/'work/tdx_t').glob('*.py')):z.write(p,'source/'+p.name)
 z.write(R/'work/drift/drift_engine.py','source/drift_engine.py')
archive=D/'archive.html';t=archive.read_text();item='<p><a href="tdx-t.html">第十八批：通达信做T公式复现、盘后重画与因果检验 ↗</a></p>'
if 'tdx-t.html' not in t:t=t.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+item,1);archive.write_text(t)
print(json.dumps({'htmlBytes':len(page.encode()),'zipBytes':(D/'tdx-t-evidence.zip').stat().st_size,'archiveLinked':'tdx-t.html' in archive.read_text()}))
