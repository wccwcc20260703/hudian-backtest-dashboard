# -*- coding: utf-8 -*-
from pathlib import Path
import json,sys,hashlib,math
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/tdx_t';O.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
sys.path.insert(0,str(R/'work/drift'));import drift_engine as engine
e=f.e;P=np.load(R/'work/leverage/plans.npz');modes=np.full(e.N,2)
freeze=int(np.searchsorted(e.DATES,'2025-01-01'));cut=int(np.searchsorted(e.DATES,'2026-07-01'))
manifest={'at':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'Does the user-supplied TDX intraday range indicator remain useful without final-day extrema, and can confirmation improve existing-inventory trading?','source':'User supplied OCR formula, independently matched public repost; source formula EMA30/900 and range fractions 1/16,7/8. Official TDX DYNAINFO and LONGCROSS semantics checked.','rules':{'edge':'Live-time formula approximation: current running high/low including ex-div reference; price crosses below current support after prior2 completed closes above that SAME current support, or above resistance after prior2 below SAME current resistance. Two5min bars != original two1min bars.','confirm':'Touch support/resistance arms its then-current level for3 subsequent5min bars. Further touch renews/replaces level. Require latest2 completed closes strictly back inside that frozen level; execute next open.','vwap':'Same confirm, plus price above contemporaneous VWAP for buys/below VWAP for sells.'},'fixed':'5min data, completed bars only, first possible next-open09:45, last14:45. Per direction30min cooldown. No EMA30/900 filter because original is1minute; no naive900x5minute conversion.','portfolio':'For each original D cash/L150 financing daily goal, after original daily signal only: at first sell reduce DAILY GOAL by min(25percentage points,goal); first subsequent buy restores original goal; at14:50 restore if no buy. Max one attempt per day. No increasing above original goal, no naked short, original/maintenance execution constraints apply. This is target-based old-inventory overlay, not exact fixed-share roundtrip.','costs':'5bp and10bp adverse slip, tick rounding, commissions,min5yuan,stamp/transfer,T+1,priorbarvolume1%,100share lots,interest6%,newbuy debt<=50%netequity; passive drift allowed.','selection':'Train through2024, choose separately cash/financing by annual logwealth-1.5absDD subject DD<=base+2pp; base eligible. Quarterly trailing252same rule. Holdout-labelled periods are previously seen history, NOT independent tests.','acceptance':'Incremental validation2025..2026Jun and recentJul..Oct8 returns must both exceed base with DD<=base+2pp; >=2/3fixedannual; older>=base; 10bp both later periods improve. Original cash goal unchanged incl preserve hold return and25%relative DD reduction, annual2/3,earlier,stress,independent; wealth1.20 separate.','limits':'Historical5min extreme mismatch vs daily exists. No finaldaily extrema spliced into intraday. Oct9 quote/1min used only formula diagnostics, excluded performance. Signal close-hit is mark-to-close not executable T+0 return.','freezeSHA':hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(O/'plan_before_results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))

def features(b,ref):
 c=b[:,3];lo=np.minimum.accumulate(np.r_[ref,b[:,2]])[1:];hi=np.maximum.accumulate(np.r_[ref,b[:,1]])[1:]
 return lo+(hi-lo)/16,lo+(hi-lo)*7/8,np.cumsum(b[:,5])/np.maximum(np.cumsum(b[:,4]),1)

def signals(b,ref,rule):
 s,r,vw=features(b,ref);c=b[:,3];out=np.zeros(len(b),dtype=int);last={1:-99,-1:-99};arms={};armbar={}
 for i in range(len(b)):
  side=0
  if rule=='edge' and i>=2:
   if c[i]<s[i] and np.all(c[i-2:i]>s[i]):side=1
   elif c[i]>r[i] and np.all(c[i-2:i]<r[i]):side=-1
  elif rule!='edge':
   for direction,level,touched in [(1,s[i],c[i]<=s[i]),(-1,r[i],c[i]>=r[i])]:
    if touched:arms[direction]=level;armbar[direction]=i
    elif direction in arms:
     age=i-armbar[direction]
     if age>3:del arms[direction];continue
     ok=age>=2 and np.all(direction*(c[i-1:i+1]-arms[direction])>0)
     if ok and (rule=='confirm' or direction*(c[i]-vw[i])>0):side=direction;del arms[direction]
  # Only completed bars through14:45; bar end indices correspond09:35..15:00.
  if side and 1<=i<=44 and i-last[side]>=6:out[i]=side;last[side]=i
 return out

# Screenshot identity and causal replay using regular continuous-auction minutes.
raw=json.loads((R/'work/hudian-backtest-dashboard/tests/fixtures/opportunity-minutes.json').read_text())['data']['sz002463']['data']['data']
mr=[x.split() for x in raw];mr=[x for x in mr if '0931'<=x[0]<='1130' or '1301'<=x[0]<='1500'];prices=np.array([float(x[1]) for x in mr]);ref=115.88
ema=lambda n:pd.Series(prices).ewm(alpha=2/(n+1),adjust=False).mean().to_numpy()
support=106.31+(115.88-106.31)/16;resist=106.31+(115.88-106.31)*7/8
assert round(support,2)==106.91 and round(resist,2)==114.68 and round(ema(900)[-1],2)==110.96
lo=np.minimum.accumulate(np.r_[ref,113.14,prices])[2:];hi=np.maximum.accumulate(np.r_[ref,113.14,prices])[2:];ls=lo+(hi-lo)/16;lr=lo+(hi-lo)*7/8
def minute_cross(level,side,live=False):
 return [i for i in range(2,len(prices)) if side*(prices[i]-level[i])<0 and np.all(side*(prices[i-2:i]-(level[i] if live else level[i-2:i]))>0)]
sb=minute_cross(np.full(len(prices),support),1);lb=minute_cross(ls,1,True)
diag={'strong':float(ema(900)[-1]),'support':support,'resistance':resist,'regularMinutes':len(mr),'emaInitialization':'09:31 first continuous-auction minute; omit09:30 and13:00 records; matches110.96 after rounding','snapshotB':[mr[i][0] for i in sb],'causalMinuteProxyB':[mr[i][0] for i in lb],'minutePriceMin':float(min(prices)),'quoteLow':106.31,'warning':'Causal minute proxy misses intra-minute extremes; cannot claim exact historical TDX live signals. Snapshot uses verified end-day extrema and intentionally demonstrates look-ahead.'}
minute_frame=pd.DataFrame({'time':[x[0] for x in mr],'price':prices,'EMA30':ema(30),'EMA900':ema(900),'finalSupport':support,'finalResistance':resist,'prefixPriceSupport':ls,'prefixPriceResistance':lr,'snapshotB':[i in sb for i in range(len(mr))],'causalProxyB':[i in lb for i in range(len(mr))]});minute_frame.to_csv(O/'oct9_formula_replay.csv',index=False);(O/'formula_identity.json').write_text(json.dumps(diag,ensure_ascii=False,indent=2))

rules=list(manifest['rules']);sg={k:np.array([signals(e.B[d],e.REF[d],k) for d in range(e.N)]) for k in rules};checks=0
# Exhaustive prefix invariance; no signal at i can depend on bars i+1 onward.
for d in range(e.N):
 for n in range(2,46):
  for k in rules:
   assert signals(e.B[d,:n],e.REF[d],k)[-1]==sg[k][d,n-1];checks+=1

# Fixed-size opportunity diagnostics: hypothetical independent1000shares capped by priorbar volume.
# No portfolio/holdings assumed; these are NOT actual fills, even though one-leg trading costs are charged.
events=[]
for rule in rules:
 for d in range(e.N):
  for i in np.flatnonzero(sg[rule][d]):
   side=int(sg[rule][d,i]);j=int(i+1);q=min(1000,int(e.B[d,i,4]*.01/100)*100)
   for slip in [.0005,.001]:
    p=e.B[d,j,0];px=math.ceil(p*(1+slip)*100-1e-8)/100 if side>0 else math.floor(p*(1-slip)*100+1e-8)/100
    upper=math.floor(e.REF[d]*1.1*100+.5)/100;lower=math.floor(e.REF[d]*.9*100+.5)/100
    eligible=q>0 and lower<=px<=upper and not (side>0 and p>=upper-.005 or side<0 and p<=lower+.005)
    fee=max(5,q*px*.00025)+q*px*(e.TRANSFER[d]+(e.STAMP[d] if side<0 else 0)) if q else 0
    net=side*q*(e.C[d]-px)-fee if eligible else np.nan
    events.append(dict(rule=rule,date=str(e.DATES[d]),bar=j,side=side,slip=slip,qty=q,price=px,fee=fee,eligible=eligible,net=net,netReturn=net/(q*px) if eligible else np.nan))
ev=pd.DataFrame(events);ev.to_csv(O/'opportunity_events.csv',index=False)
periods={'train':(e.START,freeze),'validation':(freeze,cut),'recent':(cut,e.N),'full':(e.START,e.N),'older':(0,e.START)}
for y in range(3):periods['year'+str(y+1)]=(int(np.searchsorted(e.DATES,f'{2023+y}-10-09')),int(np.searchsorted(e.DATES,f'{2024+y}-10-09')))
hits=[]
for rule in rules:
 for p,(a,z) in periods.items():
  for side in [1,-1]:
   for slip in [.0005,.001]:
    t=ev[(ev.rule==rule)&(ev.date>=e.DATES[a])&(ev.date<=e.DATES[z-1])&(ev.side==side)&(ev.slip==slip)&ev.eligible];daily=t.groupby('date').net.sum()
    hits.append(dict(rule=rule,period=p,side=side,slip=slip,signals=len(t),days=len(daily),wins=int((daily>0).sum()),dayHit=float((daily>0).mean()),pointHit=float((t.net>0).mean()),meanNetReturn=float(t.netReturn.mean())))
pd.DataFrame(hits).to_csv(O/'opportunity_metrics.csv',index=False)

plans={};overlays=[]
for base,key in [('D','D'),('L','D_all_full_1.5')]:
 original=P[key];plans[base+'_base']=original.copy()
 for rule in rules:
  name=base+'_'+rule;s=original.copy()
  for d in range(e.N):
   j0=int(np.flatnonzero(original[d]>=0)[0]);goal=original[d,j0]
   if goal<=0:continue
   sell=-1;buy=-1
   for i in range(j0,45):
    j=i+1
    if sell<0 and sg[rule][d,i]<0:sell=j;s[d,j]=max(0,goal-.25)
    elif sell>=0 and sg[rule][d,i]>0:buy=j;s[d,j]=goal;break
   if sell>=0:
    if buy<0:buy=46;s[d,46]=goal
    overlays.append(dict(name=name,date=str(e.DATES[d]),sellBar=sell,restoreBar=buy,restoreReason='deadline' if buy==46 else 'buy_confirmation',goal=goal))
  plans[name]=s

def run(name,a,z,slip=.0005):return engine.execute(e.B,e.C,e.DIV,e.BONUS,e.REF,e.STAMP,e.TRANSFER,f.DAYNUM,plans[name],a,z,modes,slip=slip)
selection=[]
def select(base,a,z):
 bm=f.metrics(run(base+'_base',a,z));choices=[]
 for rule in ['base']+rules:
  name=base+'_'+rule;m=f.metrics(run(name,a,z));ok=abs(m['mdd5'])<=abs(bm['mdd5'])+.02;score=np.log1p(m['return_'])/((z-a)/242)-1.5*abs(m['mdd5']);selection.append(dict(name=name,fromDate=str(e.DATES[a]),toDate=str(e.DATES[z-1]),eligible=ok,score=score))
  if ok:choices.append((score,name))
 return max(choices)[1]
choices={b:select(b,e.START,freeze) for b in ['D','L']};rolling=[];quarters=pd.PeriodIndex(e.DATES,freq='Q')
for b in ['D','L']:
 sig=plans[b+'_base'].copy()
 for q in quarters[freeze:].unique():
  ix=np.flatnonzero(quarters==q);a=max(freeze,int(ix[0]));z=int(ix[-1]+1);name=select(b,max(0,a-252),a);sig[a:z]=plans[name][a:z];rolling.append(dict(base=b,start=str(e.DATES[a]),end=str(e.DATES[z-1]),choice=name))
 plans[b+'_rolling']=sig
np.savez_compressed(R/'work/tdx_t/plans.npz',**plans)

def lead(nav,h):
 lag=longest=0
 for flag in nav<h:lag=lag+1 if flag else 0;longest=max(longest,lag)
 n=np.r_[1e6,nav];hh=np.r_[1e6,h];return dict(cumulativeLead=float(np.mean(nav>h)),rolling63Lead=float(np.mean(n[63:]/n[:-63]>hh[63:]/hh[:-63])),longestLag=longest)
def fill_hit(r):
 out={}
 for sign,label in [(1,'buy'),(-1,'sell')]:
  amounts={}
  for t in r[3][r[3][:,2]==sign]:
   d=int(t[0]);amounts[d]=amounts.get(d,0)+sign*t[3]*(e.C[d]-t[4])-t[5]
  out[label+'Days']=len(amounts);out[label+'Hit']=float(np.mean(np.array(list(amounts.values()))>1e-8)) if amounts else None
 return out
holds={p:e.run(np.ones((e.N,48)),a,z,hold=True,tax=0) for p,(a,z) in periods.items()};rows=[];stress=[];full={};continuous=[]
for name in plans:
 for p,(a,z) in periods.items():
  rr=run(name,a,z);rows.append(dict(name=name,period=p,**f.metrics(rr),**fill_hit(rr),**lead(rr[0],holds[p][0])))
  if p=='full':
   full[name]=rr;n=np.r_[1e6,rr[0]];continuous.append(dict(name=name,preJuly=float(n[cut-e.START]/n[0]-1),postJuly=float(n[-1]/n[cut-e.START]-1)))
  if p in ['full','validation','recent','older']:stress.append(dict(name=name,period=p,**f.metrics(run(name,a,z,.001))))
for p,h in holds.items():rows.append(dict(name='hold',period=p,**e.metrics(h)))
m=pd.DataFrame(rows);st=pd.DataFrame(stress);m.to_csv(O/'metrics.csv',index=False);st.to_csv(O/'stress10bp.csv',index=False);pd.DataFrame(continuous).to_csv(O/'continuous.csv',index=False);pd.DataFrame(selection).to_csv(O/'selection.csv',index=False);pd.DataFrame(rolling).to_csv(O/'rolling_choices.csv',index=False);pd.DataFrame(overlays).to_csv(O/'overlay_schedules.csv',index=False)
src=(R/'work/underperformance/study.py').read_text();ledgerCount=0;maxerr=0.;maxpnlerr=0.;exec(src[src.index('def accounting('):src.index('\nhc,ht=')])
for name,rr in full.items():
 _,ts=accounting(rr);pd.DataFrame(ts).to_csv(O/(name+'_trades.csv'),index=False)
assert np.isclose(f.metrics(full['D_base'])['return_'],5.141711216279998);assert np.isclose(f.metrics(full['L_base'])['return_'],11.852893569539711)
mi=m.set_index(['name','period']);si=st.set_index(['name','period']);accept={}
for b in ['D','L']:
 for rule in rules:
  name=b+'_'+rule;base=b+'_base';annual=sum(mi.loc[(name,'year'+str(y)),'return_']>=mi.loc[(base,'year'+str(y)),'return_'] for y in range(1,4))
  ok=all(mi.loc[(name,p),'return_']>mi.loc[(base,p),'return_'] and abs(mi.loc[(name,p),'mdd5'])<=abs(mi.loc[(base,p),'mdd5'])+.02 for p in ['validation','recent']) and annual>=2 and mi.loc[(name,'older'),'return_']>=mi.loc[(base,'older'),'return_'] and all(si.loc[(name,p),'return_']>si.loc[(base,p),'return_'] for p in ['validation','recent'])
  accept[name]={'incrementalPass':bool(ok),'annualWins':int(annual),'independentEvidence':False}
audit={'prefixChecks':checks,'ledgerFills':ledgerCount,'maxLedgerError':maxerr,'maxPnLError':maxpnlerr,'choices':choices,'acceptance':accept,'defaultChanged':False,'independentEvidence':False,'freezeSHA':manifest['freezeSHA']};(O/'audit.json').write_text(json.dumps(audit,indent=2));np.savez_compressed(R/'work/tdx_t/full_results.npz',**{name+'_'+k:rr[i] for name,rr in full.items() for i,k in enumerate(['nav','exposure','curve','trades'])})
print(json.dumps(diag,ensure_ascii=False));print(m[m.period=='full'][['name','return_','mdd5','buyHit','sellHit','longestLag']].to_string(index=False));print(pd.DataFrame(hits).query("period=='full' and slip==0.0005").to_string(index=False));print(json.dumps(audit))
