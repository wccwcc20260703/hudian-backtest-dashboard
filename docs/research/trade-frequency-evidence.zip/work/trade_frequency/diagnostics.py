from pathlib import Path
import json,pandas as pd
O=Path('outputs/trade_frequency');m=pd.read_json(O/'metrics.json');e=pd.read_json(O/'episodes.json');out=[];guardchecks=0
for stock in ['hudian','shenghong']:
 for name in ['D','L','DB','LB','DC','LC']:
  ts=json.loads((O/(stock+'-'+name+'-trades.json')).read_text());d=json.load(open('work/'+('risk_priority' if stock=='hudian' else 'shenghong')+'/data.json'));idx={s:i for i,s in enumerate(d['dates'])};lastSell=-10000
  for t in ts:
   if name.endswith('C') and t[2]>0 and not t[15]:assert t[0]-lastSell>2;guardchecks+=1
   if t[2]<0:lastSell=t[0]
  for ep in e[(e.stock==stock)&(e.name==name)].to_dict('records'):
   start=str(ep['start'])[:10];i=idx[start];priorSells=[t[0] for t in ts if t[0]<i and t[2]<0];gap=i-max(priorSells) if priorSells else None
   out.append({**ep,'start':start,'recentSale':gap is not None and gap<=2,'daysSinceSale':gap})
ep=pd.DataFrame(out);ep.to_csv(O/'episode-frequency.csv',index=False)
groups=[]
for (stock,name,recent),g in ep[ep.complete].groupby(['stock','name','recentSale']):
 groups.append(dict(stock=stock,name=name,recentSale=bool(recent),closed=len(g),wins=int((g.pnl>0).sum()),winRate=(g.pnl>0).mean(),medianDays=g.days.median(),meanReturn=g.return_.mean(),medianReturn=g.return_.median()))
pd.DataFrame(groups).to_csv(O/'cycle-diagnostic.csv',index=False)
for name in ['metrics','daily','episodes','quarters']:pd.read_json(O/(name+'.json')).to_csv(O/(name+'.csv'),index=False)
checks=0
for (stock,name),g in e.groupby(['stock','name']):
 row=m[(m.stock==stock)&(m.name==name)&(m.period=='full')&(m.slip==.0005)].iloc[0];assert abs(g.pnl.sum()-row.return_*1e6)<1e-4;checks+=1
au=json.loads((O/'audit.json').read_text());au.update(cooldownTradeChecks=guardchecks,cyclePnlChecks=checks);(O/'audit.json').write_text(json.dumps(au,indent=2))
print(pd.DataFrame(groups).query("name in ['D','L']").to_string(index=False))
print(m[(m.stock=='hudian')&(m.name.isin(['L','LB','LC']))&(m.slip==.0005)][['name','period','return_','mdd5','episodeWinRate','episodeWins','closedEpisodes']].to_string(index=False))
