# -*- coding: utf-8 -*-
from pathlib import Path
import json,datetime
import pandas as pd,numpy as np
R=Path.cwd();O=R/'outputs/trend_exit';s=pd.read_csv(O/'signal-ledger.csv');daily=pd.read_json(O/'daily.json');out=[]
(O/'diagnostic-scope.json').write_text(json.dumps({'registeredAt':datetime.datetime.now().astimezone().isoformat(),'purpose':'Descriptive check before proposing any new veto: priorweakMA20+originalfull dates versus nonweak+originalfull. Compute raw market gap andopen-to-close outcomes, not hypothetical full-strategyprofit. Same history, observational and overlapping regimes, no causalclaim/no extra strategy test.','metrics':'Count, positive/negative counts,mean open-to-close,mean gap to exreference,drop>=3%frequency, bottom5%mean. Periodfull/early/later/julyOn/older.'},indent=2))
for stock,path in [('hudian','work/risk_priority/data.json'),('shenghong','work/shenghong/data.json')]:
 d=json.loads((R/path).read_text());f=s[s.stock==stock].set_index('date').copy();f['gap']=[b[0][0]/r-1 for b,r in zip(d['bars'],d['reference'])];f['openToClose']=[c/b[0][0]-1 for c,b in zip(d['close'],d['bars'])]
 for period,a,z in [('full','2023-10-09','2026-10-08'),('older','2020-01-02','2023-09-28'),('early','2023-10-09','2024-12-31'),('later','2025-01-01','2026-06-30'),('julyOn','2026-07-01','2026-10-08')]:
  for weak in [True,False]:
   v=f[(f.index>=a)&(f.index<=z)&(f.baseTarget==1)&(f.weakMA20==weak)]
   n=len(v);t=v.openToClose.sort_values().iloc[:max(1,int(np.ceil(n*.05)))];out.append({'stock':stock,'period':period,'weakMA20':weak,'days':n,'upDays':int((v.openToClose>0).sum()),'upFraction':(v.openToClose>0).mean(),'meanGap':v.gap.mean(),'meanOpenToClose':v.openToClose.mean(),'down3pctDays':int((v.openToClose<=-.03).sum()),'down3pctFraction':(v.openToClose<=-.03).mean(),'tailMean':t.mean()})
 f.reset_index().to_csv(O/(stock+'-diagnostic-days.csv'),index=False)
pd.DataFrame(out).to_csv(O/'weakness-diagnostic.csv',index=False);print(pd.DataFrame(out).query('period=="full"').to_string(index=False))
