# -*- coding: utf-8 -*-
from pathlib import Path
import json,datetime,hashlib,zipfile,html
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path.cwd();O=R/'outputs/trend_exit';repo=R/'work/hudian-backtest-dashboard';rows=json.loads((O/'metrics.json').read_text());a=json.loads((O/'audit.json').read_text());a.update(json.loads((O/'signal-audit.json').read_text()));episodes=pd.read_json(O/'episodes.json');daily=pd.read_json(O/'daily.json');quarters=pd.read_json(O/'quarters.json');diag=pd.read_csv(O/'weakness-diagnostic.csv');signals=pd.read_csv(O/'signal-ledger.csv')
names={'B':'全仓持有','D':'原现金','L':'原融资默认','F50':'固定50%','DF':'上轮趋势底仓·现金','LF':'上轮趋势底仓·融资','DX':'增加MA20退出·现金','LX':'增加MA20退出·融资'};stocks={'hudian':'沪电','shenghong':'胜宏'};pct=lambda x:'—' if x is None or pd.isna(x) else f'{x*100:.2f}%'
get=lambda stock,name,period='full',slip=.0005:next(x for x in rows if (x['stock'],x['name'],x['period'],x['slip'])==(stock,name,period,slip))
for stock in stocks:
 for name in names:
  e=episodes[(episodes.stock==stock)&(episodes.name==name)];closed=e[e.complete];m=get(stock,name);assert len(closed)==m['closedEpisodes'];assert int((closed.return_>0).sum())==m['episodeWins'];assert abs(e.pnl.sum()-m['return_']*1e6)<1e-5
for stock,path in [('hudian','work/risk_priority/data.json'),('shenghong','work/shenghong/data.json')]:
 d=json.loads((R/path).read_text());q=pd.read_csv(R/'work/shenghong/data/daily_raw.csv',index_col='date') if stock=='shenghong' else pd.concat([pd.read_csv(R/'work/round2/data/daily_raw_early.csv',index_col='date'),pd.read_csv(R/'work/data/daily_raw.csv',index_col='date')]);q=q.loc[~q.index.duplicated(keep='last')].reindex(d['dates']);assert np.max(np.abs(q.open.to_numpy()-[x[0][0] for x in d['bars']]))<1e-8
 for r in diag[diag.stock==stock].itertuples():
  f=pd.read_csv(O/(stock+'-diagnostic-days.csv'));v=f[(f.date>= {'full':'2023-10-09','older':'2020-01-02','early':'2023-10-09','later':'2025-01-01','julyOn':'2026-07-01'}[r.period])&(f.date<= {'full':'2026-10-08','older':'2023-09-28','early':'2024-12-31','later':'2026-06-30','julyOn':'2026-10-08'}[r.period])&(f.baseTarget==1)&(f.weakMA20==r.weakMA20)];assert len(v)==r.days;actual=q.loc[v.date].close/q.loc[v.date].open-1;assert abs(actual.mean()-r.meanOpenToClose)<1e-10
main=signals[signals.date>='2023-10-09'];a.update({'episodeReconciliations':16,'officialDailyOpenParity':3274,'independentDiagnosticGroups':20});(O/'audit.json').write_text(json.dumps(a,indent=2))
for file,df in [('all-results.csv',pd.DataFrame(rows)),('episodes.csv',episodes),('quarters.csv',quarters),('daily.csv',daily)]:df.to_csv(O/file,index=False)
fig,axs=plt.subplots(2,1,figsize=(11,6),sharex=True)
for ax,stock in zip(axs,stocks):
 x=daily[(daily.stock==stock)&(daily.name=='LX')].sort_values('date')
 for bname,color in [('LF','#168a92'),('L','#b37b2c')]:
  b=daily[(daily.stock==stock)&(daily.name==bname)].sort_values('date');ax.plot(x.date,x.nav.to_numpy()/b.nav.to_numpy(),label='LX / '+bname,color=color)
 ax.axhline(1,color='#8a96a2',ls='--',lw=1);ax.axvline(pd.Timestamp('2026-07-01'),color='#aaa',ls=':',lw=1);ax.set_title(stock.title());ax.set_ylabel('Relative account wealth');ax.legend(loc='upper left');ax.grid(alpha=.15)
fig.suptitle('LX: MA20 exit | LF: prior trend floor | L: original margin | 5bps');fig.tight_layout();fig.savefig(O/'comparison.svg');fig.savefig(O/'comparison.png',dpi=140);plt.close(fig)
def table(h,rs):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(v))+'</th>' for v in h)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in rs)+'</tbody></table></div>'
def metrics(rs):return table(['股票／方案','净收益','5分钟最大回撤','平均仓位','完整周期胜率','盈利日／全部日','最差5%日均收益'],[[stocks[x['stock']]+'／'+names[x['name']],pct(x['return_']),pct(-x['mdd5']),pct(x['exposure']),f"{x['episodeWins']}/{x['closedEpisodes']}={pct(x['episodeWinRate'])}" if x['closedEpisodes'] else '无已结束周期',f"{x['winningDays']}/{x['days']}={pct(x['winningDayFraction'])}",pct(x['worst5pctDayMean'])] for x in rs])
body='''<a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a><h1>趋势底仓加退出条件：MA20能减少下跌损失吗？</h1><p class="muted">固定一条退出条件 · 256组完整账户 · 不改默认 · 历史证据，不是独立盲测</p>
<section><h2>结论：局部改善很小，还不能替换原方案</h2><p>沪电融资的上轮趋势底仓方案，加入退出条件后，净收益从1140.69%提高至1225.41%，最大回撤从26.71%降至26.70%，只减少约0.015个百分点。完整周期胜率从24/30（80%）变为30/39（76.92%）。更重要的对照是原默认方案：净收益1226.51%、回撤25.20%，新版本并未提供更低回撤。</p><p>胜宏融资净收益从550.44%降至509.38%，回撤从49.63%降至48.93%，但仍高于原方案48.39%。收益下降本身不构成淘汰理由；本轮主要问题是回撤改善微弱、尾部和更早历史表现不一致。新增退出条件可保留为研究证据，暂不更换默认。</p></section>
<section><h2>固定规则与作用范围</h2><p>沿用上轮规则：前日收盘高于MA60且MA120较20日前上升，财报增长为正、RSI(2)&gt;60时，将原本清仓的目标改为50%。本轮只增加一条：<strong>若前日收盘低于前日已完成的20日均线，取消这部分新增50%目标，恢复原清仓目标。</strong>前日重新站上MA20且其他底仓条件仍成立时可恢复。</p><p>只使用前日完成数据，按原计划09:45或10:00尝试成交，不能在今天跌破均线的一刻立即退出。其他原D目标不变：RSI低位要求的100%现金或150%融资目标仍保留。这个版本只约束新增底仓，不是整个账户的止损规则。新增50%底仓本身不加杠杆。</p><p>20日参数采用此前已使用、用户也提出过的常见观察周期，本轮没有搜索5／10／20日赢家，也没有根据7月跌势重选阈值。复用原成交引擎，仅修改目标日程；没有更改买入参数、执行时刻或默认方案。</p></section>
<section><h2>三年完整账户：2023-10-09至2026-10-08</h2>'''
body+=metrics([x for x in rows if x['period']=='full' and x['slip']==.0005])
body+='''<p class="muted">各账户100万元独立起步，单边滑点5基点。最大回撤按5分钟采样及日收盘，未覆盖真实逐笔极值。完整周期指空仓到再次空仓，不能称作日内做T胜率。未结束持仓按市值计入净值与回撤。</p><img src="trend-exit-chart.svg" alt="新增退出条件融资账户相对上轮底仓及原默认的账户资产"><p>L为原融资，LF为上轮趋势底仓，LX为本轮增加MA20退出。相对资产高于1，表示当日累计账户资产更高；不代表风险更小。</p></section>
<section><h2>退出规则为什么没有覆盖主要风险</h2>'''
body+=table(['股票','前日低于MA20的交易日','其中原策略目标满仓','本轮真正取消新增底仓的日期'],[[stocks[s],int(main[main.stock==s].weakMA20.sum()),int(main[main.stock==s].baseFullDespiteWeak.sum()),int(main[main.stock==s].removedFloor.sum())] for s in stocks])
body+='''<p>沪电三年有282个交易日前日低于MA20，其中157天原策略仍要求满仓；本轮只取消了18天的新增底仓。原因来自规则覆盖范围：新增底仓出现在RSI偏高的原清仓日，而较明显的短期下跌常会使RSI降低，重新落入原反转买入规则。以上是目标日期数量，不是实际成交笔数，也不能把所有“低于MA20”的日子都认定为应该卖出。</p></section>
<section><h2>反证检查：低于MA20，也可能是反弹环境</h2><p>在提出“低于MA20就禁止原策略买入”之前，先按事前状态分组观察行情。限定原策略目标满仓的日期，比较前日低于／不低于MA20时，当天官方开盘到收盘的表现。这是描述性行情统计，不是按09:45或10:00成交的扣费收益，也不是可执行胜率。</p>'''
body+=table(['股票／区间','前日低于MA20','日期数','收盘高于开盘','平均开盘至收盘','日内跌≥3%的天数','最差5%日内均值'],[[stocks[x.stock]+'／'+x.period,'是' if x.weakMA20 else '否',x.days,f'{x.upDays}/{x.days}={pct(x.upFraction)}',pct(x.meanOpenToClose),f'{x.down3pctDays}/{x.days}={pct(x.down3pctFraction)}',pct(x.tailMean)] for x in diag[diag.period.isin(['full','older'])].itertuples()])
body+='''<p>沪电三年“前日低于MA20且原目标满仓”的157天，95天收盘高于开盘，平均日内上涨0.79%；非低于MA20组87天平均约0.05%。但更早历史的相同低于MA20组201天只有91天日内上涨，平均日内收益接近0%。这支持继续区分反弹环境与持续弱势，而不支持单凭一条均线统一禁止买入。</p><p>胜宏的均值和尾部关系又不同；两组市场阶段、隔夜缺口和持仓背景并不相同，不能把差异当作MA20的因果效果。所有分段和原始日期均附在下载文件，没有把2026年7月单独挑成新的交易规则。</p></section>
<section><h2>7月前后连续账户与领先比例</h2>'''
body+=table(['方案','截至6月30日收益','7月起收益','累计领先全仓','最长落后全仓','63日滚动领先全仓'],[[stocks[x['stock']]+'／'+names[x['name']],pct(x['preJuly']),pct(x['postJuly']),pct(x['leadFraction']),str(x['longestBehind'])+'日',pct(x['rolling63Lead'])] for x in rows if x['period']=='full' and x['slip']==.0005 and x['name'] in ['D','L','DF','LF','DX','LX']])
body+='''<p>沪电融资7月后收益从上轮17.16%恢复至34.08%，仍低于原默认50.82%；7月前收益则从958.93%降至888.54%。这是连续账户承接前段持仓的分段结果，复利相乘，不能直接相加。季度和滚动结果也承接持仓，不能与重新起步的分段混用。</p></section>
<section><h2>三个固定年度：必须同时比较上轮与原默认</h2>'''
annual=[]
for stock in stocks:
 for name in ['DX','LX']:
  v=[get(stock,name,'year'+str(i)) for i in [1,2,3]];floor=[get(stock,name[0]+'F','year'+str(i)) for i in [1,2,3]];base=[get(stock,name[0],'year'+str(i)) for i in [1,2,3]]
  annual.append([stocks[stock]+'／'+names[name],f"{sum(x['mdd5']>y['mdd5']+1e-10 for x,y in zip(v,floor))}/3",f"{sum(x['mdd5']>y['mdd5']+1e-10 for x,y in zip(v,base))}/3"])
body+=table(['新增退出方案','年度回撤优于上轮底仓','年度回撤优于原策略'],annual)
body+=table(['股票','年度','方案','净收益','最大回撤','完整周期胜率'],[[stocks[x['stock']],x['period'],names[x['name']],pct(x['return_']),pct(-x['mdd5']),f"{x['episodeWins']}/{x['closedEpisodes']}={pct(x['episodeWinRate'])}" if x['closedEpisodes'] else '没有完整周期'] for x in rows if x['period'] in ['year1','year2','year3'] and x['slip']==.0005 and x['name'] in ['DF','LF','DX','LX']])
body+='''<p>固定年度从2023、2024、2025年10月9日起至次年10月8日，各以100万元重新开始。相对上轮底仓多数年度有所改善，并不代表超过原策略；相对原策略没有任何一组达到2/3年度回撤改善。</p></section>
<section><h2>更早历史与时间分段</h2><p>older为2020-01-02至2023-09-28；early为2023-10-09至2024年底；later为2025年初至2026-06-30；julyOn为2026年7月起。每段重新起步。参数先固定，没有在early训练出最优阈值；全部历史已见，以下只能称时间分段核验。</p>'''
body+=table(['股票','区间','方案','净收益','最大回撤','周期胜率'],[[stocks[x['stock']],x['period'],names[x['name']],pct(x['return_']),pct(-x['mdd5']),pct(x['episodeWinRate'])] for x in rows if x['period'] in ['older','early','later','julyOn'] and x['slip']==.0005 and x['name'] in ['DF','LF','DX','LX']])
body+='''<p>更早沪电融资净收益从−26.46%恶化至−30.76%，回撤从73.58%扩大至73.83%。胜宏较早历史改善有限；在2025年至2026年6月的分段中，新增退出反而使现金、融资回撤都扩大。不能凭三年总指标的微小改善宣称稳定。</p></section>
<section><h2>10基点滑点、完整周期及尾部</h2>'''
body+=metrics([x for x in rows if x['period']=='full' and x['slip']==.001 and x['name'] in ['D','L','DF','LF','DX','LX']])
body+='''<p>沪电融资10基点时，新增退出的回撤27.45%反而略高于上轮27.36%。同一固定规则在较高滑点下没有保持回撤改善，说明5基点时0.015个百分点的差距不宜作为决策依据。</p>'''
body+=table(['方案','盈利日／非平盘日','完整周期盈亏比¹','未结束周期市值损益（元）','交易费用／融资利息（元）'],[[stocks[x['stock']]+'／'+names[x['name']],f"{x['winningDays']}/{x['winningDays']+x['losingDays']}={pct(x['nonflatDayWinRate'])}",f"{x['episodeProfitFactor']:.2f}" if x['episodeProfitFactor'] is not None else '—',f"{x['openEpisodeMarked']:,.0f}",f"{x['fees']:,.0f} / {x.get('interest',0):,.0f}"] for x in rows if x['period']=='full' and x['slip']==.0005 and x['name'] in ['DF','LF','DX','LX']])
body+='''<p class="muted">¹ 此处为已结束周期盈利金额合计÷亏损金额绝对值合计，受不同阶段账户规模影响。并非平均单笔盈利÷平均单笔亏损。新旧周期边界不同，未结束周期不能一一比较；其全部损益已进入净值。日内T往返没有单独定义，不报告做T胜率；平盘和空仓不算盈利日。</p></section>
<section><h2>连续账户季度与滚动检查</h2><p>季度以日收盘计算区间回撤，与主表5分钟口径不同；只汇总至少40个交易日的季度，排除仅1天的2026Q4。63日窗口相互重叠，不是独立样本。</p>'''
qs=[]
for stock in stocks:
 for name in ['DX','LX']:
  q=quarters[(quarters.stock==stock)&(quarters.name==name)&(quarters.slip==.0005)&(quarters.days>=40)];m=get(stock,name);qs.append([stocks[stock]+'／'+names[name],f'{sum(q.return_>q.comparisonReturn+1e-10)}/{len(q)}',f'{sum(q.dd<q.comparisonDD-1e-10)}/{len(q)}',pct(m['rolling63VsComparison'])])
body+=table(['方案','季度收益优于上轮底仓','季度回撤小于上轮底仓','63日滚动收益优于上轮底仓'],qs)
body+='''</section><section><h2>执行核验与下一步</h2>'''
body+=f"<p>{a['scenarios']}组回测；{a['originalMetricParity']}项基准指标与上一批精确一致；{a['ledger']}笔完整区间账本、{a['loanChecks']}笔买入额度通过检查。{a['independentPriorOnlyMA20Checks']}个交易日按截断至前日的行情独立复算MA20，全部执行时刻保持原样。16组完整区间周期损益与账户收益一致；行情诊断使用的开盘价与官方日线逐日一致。</p>"
body+='''<p>佣金万1、最低5元，按日期印花税和过户费，5／10基点单边滑点，T+1、整手、前根5分钟量1%及每笔30万股上限、涨跌停和融资年息6%均保持原口径。借款买入后不超过当前净资产50%，持有期间允许被动超过150%，不代表真实融资交易授权。策略分红税仍按20%简化，长期全仓基准按0%；不是个人税务精算。普通股票交收前不得回转卖出的制度依据可查<a href="https://www.szse.cn/lawrules/rule/repeal/rules/P020231230545235004039.pdf">深交所历史交易规则第3.1.4条</a>；本次引用用于历史模型依据，不将旧版文件冒充完整现行规则。</p><p>数据仍截至2026-10-08，10月9日分钟与日线极值差异未解决，未加入已核验回测。复用此前行情、财报与日历核验记录；10月10日休市，无新增冻结后交易证据。历史分钟质量、财报修订版本、融资资格及真实成交延迟仍是限制。</p><p>后续问题应收窄为：同属RSI低位，哪些当时可知的早盘路径能区分反弹与继续下跌？已有早盘跌幅、均价与量能研究的失败记录必须复用，先做条件诊断，再决定是否值得修改完整账户规则。本轮没有追加第二套参数搜索。</p><p>默认不变；原现金保留全仓收益并降回撤25%、财富1.20倍只作为历史对照，本轮不宣称原目标或冻结后验证达标。<a href="trend-exit-evidence.zip">下载完整结果、逐笔账本、信号和复现脚本</a> · <a href="trend-floor.html">上一轮趋势底仓研究</a></p></section>'''
style='body{font:16px/1.75 system-ui,sans-serif;background:#f3f6fa;color:#1b304a;margin:0}main{max-width:1260px;margin:32px auto;padding:20px}section{background:white;border:1px solid #dce5ee;border-radius:14px;padding:24px;margin:22px 0}h1{font-size:30px}h2{font-size:22px}a{color:#147f85}.muted{font-size:14px;color:#6b7889}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:14px}th,td{white-space:nowrap;text-align:left;padding:11px;border-bottom:1px solid #e2e9ef}th{background:#f4f7fa}img{width:100%;height:auto}'
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MA20退出与反弹环境｜沪电研究</title><style>'+style+'</style></head><body><main>'+body+'</main></body></html>'
(O/'report.html').write_text(page.replace('src="trend-exit-chart.svg"','src="comparison.svg"'));(repo/'docs/research/trend-exit.html').write_text(page);(repo/'docs/research/trend-exit-chart.svg').write_bytes((O/'comparison.svg').read_bytes())
f=repo/'docs/research/archive.html';s=f.read_text();entry='<p><a href="trend-exit.html">MA20退出检验：局部减险为何仍不如原方案，低于均线是否应禁买？ ↗</a></p>'
if 'href="trend-exit.html"' not in s:f.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+entry))
inputs=['work/trend_floor/plans.json','outputs/trend_floor/metrics.json','outputs/trend_floor/signal-ledger.csv','work/risk_priority/data.json','work/shenghong/data.json','work/shenghong/finance.mjs','work/shenghong/benchmark.mjs','work/opening_guard/metrics.mjs','work/hudian-backtest-dashboard/docs/fees.js','work/hudian-backtest-dashboard/docs/attribution.js','work/round2/data/daily_qfq_early.csv','work/data/daily_qfq.csv','work/shenghong/data/daily_qfq.csv','work/round2/data/daily_raw_early.csv','work/data/daily_raw.csv','work/shenghong/data/daily_raw.csv']
(O/'manifest.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in inputs},indent=2));(O/'README.txt').write_text('Node22: node work/trend_exit/run.mjs reproduces256scenarios from frozen plans. Python build.py regenerates fixed plans; diagnostics.py derives descriptive market groups; report.py requires publication workspace. All history previously seen, no new blindtest. No default changes.\n')
with zipfile.ZipFile(repo/'docs/research/trend-exit-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in list(O.glob('*'))+list((R/'work/trend_exit').glob('*'))+[R/p for p in inputs]:
  if p.is_file() and p.name not in ['publication.json','deployment.log']:z.write(p,str(p.relative_to(R)))
f=R/'work/research-checkpoint.json';c=json.loads(f.read_text());c['trendExit']={'updatedAt':datetime.datetime.now().astimezone().isoformat(),'outputs':'outputs/trend_exit','status':'locally verified, publication pending','rule':'If priorclose<MA20 remove only incremental50floor; baseRSIfull targets untouched; original time kept. One fixed filter.','finding':'HudianLfloor1140.69/DD26.7116->exit1225.41/DD26.6966,vsoriginal1226.51/DD25.20.10bpsDD27.3635->27.4524 worse. Shenghong550.44/DD49.6293->509.38/DD48.9312. EarlierHmargin-30.76/DD73.83. Main18removedfloor dates eachstock;157H/132SweakMA20 originalfull days remain. Hudian157weakfull days95open-closepositive,mean+.7937%;older201days91positive mean~0,nottrade winrate.','audit':a,'defaultChanged':False,'newBlindTest':False,'nextQuestion':'Reuse previous opening-guard failure evidence; diagnose priorRSIlow rebound versus continuation using prefix-known early path, not unconditionalMA20 veto.'};c['updatedAt']=c['trendExit']['updatedAt'];f.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print('report and checkpoint saved')
