# -*- coding: utf-8 -*-
from pathlib import Path
import json,datetime
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/trend_floor';W=R/'work/trend_floor'
plan={'registeredAt':datetime.datetime.now().astimezone().isoformat(),'question':'Can prior-known trend support a cash50% floor on profitable-company high-RSI exit days, reducing missed trends without unacceptable drawdown and tail deterioration?','oneFixedRule':'If original D target=0, lagRSI2>60, latest strictly prior published growth>0, previous adjusted close>previous MA60 and previous MA120>MA120 20 sessions earlier: replace target0 with0.5. Otherwise keep D. Original scheduled order time preserved. New0.5 targets never leveraged; original1 targets keep cash100 or margin150. This can buy back from cash as well as retain shares.','parameters':[60,120,20,0.5],'priorResearch':'Reuse trend gate from work/leverage/research.py. Not a new discovery of MA trend. Unlike old G broad core-satellite, change only RSI high exit; unlike underperformance retain previous allocation, use fixed50 and no MA20/volume conditions. No grid, neighbor selection or optimal claim.','evaluation':'2stocks; B,D,L,F50,DF,LF; full/older/3annual/early/later/Julyon;5/10bps. Each segment restarts1m. Full continuous NAV also quarterly and rolling63-session comparisons with baseline. Early/later descriptive temporal splits, all history already seen, not new out-of-sample. No fitted parameters or candidate selector.','riskPriority':'Compare DD,tail,completed holding episodes and winningdays with distinct denominators; participation/netreturn/open holdings included. Preserve oldreturn standards as historical reference only. No default change. No intraday T win claim.','execution':'Existing exchange-adapted engine unchanged: commission1bp min5, stamp/transfer,date-specific limits,T1,100lots,prior5mvol1%,300kshares/fill,6%interest,loan<=50%currentnet onbuy only. Existing dividend tax assumption retained.','limits':'Minute-v-daily discrepancies, historicalfinancialvintage, financingeligibility, no postfreeze evidence; through2026-10-08. No newprice interpolation.'}
(O/'plan-before-results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
h=pd.read_csv(R/'outputs/round2/fundamental_point_in_time_map.csv',index_col='date').rename(columns={'yoy_netprofit':'YOYNI'})
q=pd.concat([pd.read_csv(R/'work/round2/data/daily_qfq_early.csv',index_col='date'),pd.read_csv(R/'work/data/daily_qfq.csv',index_col='date')]).sort_index();q=q.loc[~q.index.duplicated(keep='last')]
delta=q.close.diff();gain=delta.clip(lower=0).ewm(alpha=.5,adjust=False).mean();loss=(-delta.clip(upper=0)).ewm(alpha=.5,adjust=False).mean();h['rsi2lag']=(100-100/(1+gain/loss.replace(0,np.nan))).fillna(50).shift().reindex(h.index)
s=pd.read_csv(R/'outputs/shenghong/signal-ledger.csv',index_col='date');sq=pd.read_csv(R/'work/shenghong/data/daily_qfq.csv',index_col='date').sort_index()
plans={};ledgers=[];checks=0
for stock,df,Q,path in [('hudian',h,q,'work/risk_priority/data.json'),('shenghong',s,sq,'work/shenghong/data.json')]:
 d=json.loads((R/path).read_text());df=df.reindex(d['dates']);p=Q.close;ma60=p.rolling(60).mean();ma120=p.rolling(120).mean();trend=((p>ma60)&(ma120>ma120.shift(20))).shift().reindex(df.index).fillna(False)
 weights=np.where(df.YOYNI<=0,0,np.where(df.rsi2lag<35,1,np.where(df.rsi2lag>60,0,.5)))
 original=[[3 if i>0 and v<weights[i-1] else 6,float(v)] for i,v in enumerate(weights)];assert original==d['signals']['D']
 mask=(df.rsi2lag>60)&(df.YOYNI>0)&trend
 sig=[[x[0],.5 if mask.iloc[i] else x[1]] for i,x in enumerate(original)];plans[stock]=sig
 for i,date in enumerate(df.index):
  j=Q.index.get_loc(date);known=Q.iloc[:j].close
  independent=len(known)>=140 and known.iloc[-1]>known.iloc[-60:].mean() and known.iloc[-120:].mean()>known.iloc[-140:-20].mean()
  assert bool(trend.iloc[i])==independent;assert df.iloc[i].pubDate<date;checks+=1
  ledgers.append({'stock':stock,'date':date,'knownThrough':Q.index[j-1],'rsi2lag':df.iloc[i].rsi2lag,'growth':df.iloc[i].YOYNI,'publication':df.iloc[i].pubDate,'trend':bool(trend.iloc[i]),'changed':bool(mask.iloc[i]),'originalTarget':weights[i],'newTarget':sig[i][1],'bar':sig[i][0]})
(W/'plans.json').write_text(json.dumps(plans,separators=(',',':')));pd.DataFrame(ledgers).to_csv(O/'signal-ledger.csv',index=False)
(O/'signal-audit.json').write_text(json.dumps({'priorOnlyIndependentRebuild':checks,'originalSchedulesExact':2,'changedDays':pd.DataFrame(ledgers).groupby('stock').changed.sum().to_dict()},indent=2));print((O/'signal-audit.json').read_text())
