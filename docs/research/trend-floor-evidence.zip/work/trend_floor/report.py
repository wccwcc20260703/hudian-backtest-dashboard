# -*- coding: utf-8 -*-
from pathlib import Path
import json,datetime,hashlib,zipfile,html
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path.cwd();O=R/'outputs/trend_floor';repo=R/'work/hudian-backtest-dashboard'
rows=json.loads((O/'metrics.json').read_text());a=json.loads((O/'audit.json').read_text());episodes=pd.read_json(O/'episodes.json');daily=pd.read_json(O/'daily.json');quarters=pd.read_json(O/'quarters.json');signals=pd.read_csv(O/'signal-ledger.csv');names={'B':'全仓持有','D':'原现金','L':'原融资','F50':'固定50%','DF':'趋势底仓·现金','LF':'趋势底仓·融资'};stocks={'hudian':'沪电','shenghong':'胜宏'}
pct=lambda x:'—' if x is None or pd.isna(x) else f'{x*100:.2f}%'
get=lambda stock,name,period='full',slip=.0005:next(x for x in rows if (x['stock'],x['name'],x['period'],x['slip'])==(stock,name,period,slip))
for stock in stocks:
 for name in names:
  es=episodes[(episodes.stock==stock)&(episodes.name==name)];closed=es[es.complete];m=get(stock,name)
  assert len(closed)==m['closedEpisodes'];assert (closed.return_>0).sum()==m['episodeWins'];assert abs(es.pnl.sum()-m['return_']*1e6)<1e-5
  assert len(es[~es.complete])==int(m['openEpisode'])
a['independentEpisodeReconciliations']=12;a.update(json.loads((O/'signal-audit.json').read_text()));(O/'audit.json').write_text(json.dumps(a,indent=2))
for file,content in [('all-results.csv',pd.DataFrame(rows)),('episodes.csv',episodes),('quarters.csv',quarters),('daily.csv',daily)]:content.to_csv(O/file,index=False)
fig,axs=plt.subplots(2,1,figsize=(11,6),sharex=True)
for ax,stock in zip(axs,stocks):
 for name,base,color in [('DF','D','#168a92'),('LF','L','#bd7e36')]:
  x=daily[(daily.stock==stock)&(daily.name==name)].sort_values('date');b=daily[(daily.stock==stock)&(daily.name==base)].sort_values('date');v=x.nav.to_numpy()/b.nav.to_numpy();ax.plot(x.date,v,label=name+' / '+base,color=color)
 ax.axhline(1,color='#8a96a2',ls='--',lw=1);ax.axvline(pd.Timestamp('2026-07-01'),color='#aaa',ls=':',lw=1);ax.set_title(stock.title());ax.set_ylabel('Relative account wealth');ax.legend(loc='upper left');ax.grid(alpha=.15)
fig.suptitle('Prior-known trend + 50% floor versus original | 5bps each side');fig.tight_layout();fig.savefig(O/'comparison.svg');fig.savefig(O/'comparison.png',dpi=140);plt.close(fig)
def table(h,rs):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(v))+'</th>' for v in h)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in rs)+'</tbody></table></div>'
def metrics(rs):return table(['股票／方案','净收益','最大回撤¹','平均仓位','完整周期胜率²','盈利日／全部日','最差5%日均收益'],[[stocks[x['stock']]+'／'+names[x['name']],pct(x['return_']),pct(-x['mdd5']),pct(x['exposure']),f"{x['episodeWins']}/{x['closedEpisodes']}={pct(x['episodeWinRate'])}" if x['closedEpisodes'] else '没有已结束周期',f"{x['winningDays']}/{x['days']}={pct(x['winningDayFraction'])}",pct(x['worst5pctDayMean'])] for x in rs])
body='''<a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a><h1>趋势中保留50%底仓：胜率80%就更好吗？</h1><p class="muted">一条固定规则 · 192组完整账户对照 · 沪电与胜宏 · 不更换默认</p>
<section><h2>结论：改善部分踏空，但没有满足回撤优先的要求</h2><p>沪电近三年融资方案，保留趋势底仓后，完整持仓周期胜率从74/102（72.55%）升至24/30（80%），累计领先全仓的交易日比例也提高；但净收益从1226.51%降至1140.69%，最大回撤从25.20%扩大至26.71%，最差5%交易日平均亏损从6.05%扩大至6.31%。<strong>这个80%不能解释成日内做T胜率，更不能据此直接启用。</strong></p><p>胜宏的趋势踏空确实得到改善：融资净收益从300.94%提高至550.44%，但最大回撤也从48.39%扩大至49.63%。更早历史中，两只股票、现金与融资四组的回撤均恶化。按当前优先胜率与控制回撤的目标，这条规则尚不具备替换默认的证据。</p></section>
<section><h2>先固定规则，再算结果</h2><p>只读取前一交易日收盘前已知行情，以及严格早于交易日披露的财报。在原D策略因为RSI(2)&gt;60、同时利润同比增长为正而计划清仓的日期，若前日收盘高于60日均线，且前日120日均线高于20个交易日前的120日均线，则把目标0%改为50%；其他目标保持原样。</p><p>沿用原计划的09:45或10:00执行时间，只隔离检验目标仓位这一处改动。新增50%目标不放大为融资仓位，只有原来的100%目标仍可按原规则放大至150%。这并非“永不再买的底仓”：当账户已空仓而条件满足时，也会尝试买回50%。目标与真实模拟成交后的仓位不同，仍受整手、费用、成交量和T+1限制。</p><p>趋势条件复用此前融资研究，未在本轮挑选最优均线。此前G方案同时改了多种状态的仓位，旧保仓方案还混合MA20及成交量；本轮只改一个高RSI退出条件。没有网格调参，没有根据沪电或胜宏结果重选参数。</p></section>
<section><h2>三年完整账户：2023-10-09至2026-10-08</h2>'''
body+=metrics([x for x in rows if x['period']=='full' and x['slip']==.0005])
body+='''<p class="muted">¹ 最大回撤按5分钟采样及官方日收盘计量，不能当作逐笔极值回撤。² 完整周期指空仓到再次空仓，含费用与融资利息；固定50%及全仓仍未结束，不计算周期胜率。各账户100万元独立起步，主表单边滑点5基点。</p><img src="trend-floor-chart.svg" alt="两只股票新增底仓相对各自原方案的账户资产"><p>曲线高于1表示新增底仓方案当日累计资产高于原方案；它是同一本金连续账户之比。竖虚线为2026年7月1日。主结果显示：提高上涨参与度与降低回撤不是同一件事。</p></section>
<section><h2>80%的分母变了，不能说买卖点变准了</h2><p>减少清仓把原本独立的多次交易合并成更长持仓，周期之间不能一一配对。已完成亏损周期占比可能下降，但持仓中间的亏损仍然存在；未结束周期也不会进入胜率分母。必须同时看账户回撤和未平仓损益。</p>'''
eps=[]
for stock in stocks:
 for name in ['D','DF','L','LF']:
  e=episodes[(episodes.stock==stock)&(episodes.name==name)&episodes.complete];m=get(stock,name)
  eps.append([stocks[stock]+'／'+names[name],f"{m['episodeWins']}/{len(e)}",f'{e.days.median():.1f} / {e.days.max()}',pct(e[e.return_>0].return_.mean()),pct(e[e.return_<0].return_.mean()),f"{m['openEpisodeMarked']:,.0f}",pct(m['nonflatDayWinRate'])])
body+=table(['方案','盈利／完整周期','周期中位／最长交易日','盈利周期平均收益','亏损周期平均收益','未结束周期市值损益（元）','盈利日／非平盘日'],eps)
body+='''<p>所有未结束周期均按市值计入累计净值、回撤与损益，上表单列其损益。周期平均收益是不加权平均，不能与复利总收益直接相加。没有定义独立日内往返，所以本批不报告“做T成功率”。空仓和平盘也没有算成盈利日。</p></section>
<section><h2>7月前后：保住前半段上涨，也多承担后半段风险</h2>'''
body+=table(['方案','截至2026-06-30连续收益','7月1日起连续收益','累计领先全仓','最长落后全仓','63日滚动领先全仓'],[[stocks[x['stock']]+'／'+names[x['name']],pct(x['preJuly']),pct(x['postJuly']),pct(x['leadFraction']),str(x['longestBehind'])+'日',pct(x['rolling63Lead'])] for x in rows if x['period']=='full' and x['slip']==.0005 and x['name'] in ['D','DF','L','LF']])
body+='''<p>沪电融资7月前收益从779.53%提高至958.93%，但7月后从50.82%降至17.16%。累计领先比例从61.90%升至76.62%，最长落后由235日缩至151日，却并未带来更低回撤。以上两段承接之前持仓，复利相乘，不能直接相加；下载文件中另有各段重新起步的结果，二者不能混用。</p></section>
<section><h2>按时间顺序检验：早期改善不能预测后期稳定</h2><p>early为2023-10-09至2024年底，later为2025年初至2026-06-30，julyOn为2026-07-01至数据末日；每段从100万元重新起步。规则没有在early拟合，表格是时间分段检验；这些行情早已被研究过，不能称为新盲测。</p>'''
body+=table(['股票','区间','方案','净收益','最大回撤','周期胜率'],[[stocks[x['stock']],x['period'],names[x['name']],pct(x['return_']),pct(-x['mdd5']),f"{x['episodeWins']}/{x['closedEpisodes']}={pct(x['episodeWinRate'])}" if x['closedEpisodes'] else '无完整周期'] for x in rows if x['period'] in ['early','later','julyOn'] and x['slip']==.0005 and x['name'] in ['D','DF','L','LF']])
body+='''</section><section><h2>三个固定年度及更早历史</h2><p>year1、year2、year3分别从2023、2024、2025年10月9日开始，至次年10月8日止；older为2020-01-02至2023-09-28，每段独立起步。</p>'''
body+=table(['股票','区间','方案','净收益','最大回撤','完整周期／胜率'],[[stocks[x['stock']],x['period'],names[x['name']],pct(x['return_']),pct(-x['mdd5']),str(x['closedEpisodes'])+' / '+pct(x['episodeWinRate'])] for x in rows if x['period'] in ['older','year1','year2','year3'] and x['slip']==.0005 and x['name'] in ['D','DF','L','LF']])
annual=[]
for stock in stocks:
 for name in ['DF','LF']:
  dd=sum(get(stock,name,'year'+str(i))['mdd5']>get(stock,name[0],'year'+str(i))['mdd5']+1e-10 for i in [1,2,3]);annual.append([stocks[stock]+'／'+names[name],f'{dd}/3'])
body+=table(['方案','年度回撤改善数'],annual)
body+='''<p>沪电现金与融资各只有1/3年度回撤改善；胜宏现金0/3，融资1/3，没有跨过至少2/3年度的稳定性检查。胜宏第二年度新增底仓方案一直没有完成清仓，完整周期胜率留空，不能因高收益记为100%胜率。</p></section>
<section><h2>滚动与季度检查</h2><p>下面从三年连续账户按季度切片，季度回撤按日收盘、以季初资产为起点，故与主表5分钟最大回撤口径不同。只汇总至少40个交易日的季度，排除只有1天的2026Q4；这不是重新训练或独立样本。</p>'''
qs=[]
for stock in stocks:
 for name in ['DF','LF']:
  q=quarters[(quarters.stock==stock)&(quarters.name==name)&(quarters.slip==.0005)&(quarters.days>=40)];m=get(stock,name)
  qs.append([stocks[stock]+'／'+names[name],f'{sum(q.return_>q.originalReturn+1e-10)}/{len(q)}',f'{sum(q.dd<q.originalDD-1e-10)}/{len(q)}',pct(m['rolling63VsOriginal'])])
body+=table(['方案','季度收益优于原方案','季度回撤小于原方案','63日滚动收益优于原方案'],qs)
body+='''<p>增加底仓后，沪电现金在这些季度中没有一次回撤更小。滚动收益改善比例高于一半，仍不能抵消少数大幅落后的区间；重叠窗口高度相关，不应视为独立的多次成功验证。</p></section>
<section><h2>单边10基点滑点：结论没有逆转</h2>'''
body+=metrics([x for x in rows if x['period']=='full' and x['slip']==.001 and x['name'] in ['D','DF','L','LF']])
body+='''<p>沪电融资底仓方案完整周期胜率降为25/33（75.76%），回撤仍比原融资更大。手续费、整数股和成交容忍区间会改变交易路径，不能把5基点的80%固定套到其他执行条件。</p></section>
<section><h2>执行核验、证据边界及后续方向</h2>'''
body+=f"<p>共{a['scenarios']}组完整账户；{a['originalMetricParity']}项原基准指标精确复现，{a['ledger']}笔完整区间账本、{a['loanChecks']}笔买入额度通过检查；{a['priorOnlyIndependentRebuild']}个交易日用截断到前日的价格重新验证趋势条件。全部12组完整区间持仓周期损益与账户收益核对一致。</p>"
body+='''<p>沿用实际佣金万1、最低5元，按日期的印花税和过户费，T+1、100股、前根5分钟成交量1%及每笔30万股上限、交易所涨跌停，融资年息6%。每笔融资买入后欠款不得超过当前净资产50%；按已授权规则允许持有期被动超仓，但真实担保约束仍保留。策略分红税按20%简化，长期全仓基准按0%，不是个人税务精算；固定50%使用与策略一致的税率。</p><p>行情复用至2026-10-08；10月9日分钟极值与日线不一致，尚未纳入已核验回测。原有分钟数据质量、历史财报修订版本及融资资格问题仍在，本轮未解决。今日休市，没有冻结后新增交易样本。交易规则来源沿用此前深交所公开资料的核验回执，本次再次打开链接超时，未冒称重新核验成功。</p><p>目前能支持的判断是：长期趋势条件有助于解释踏空，但单靠均线状态不足以控制趋势结束时的损失。下一批应只检验一个预先固定的失效条件能否减少新增底仓的尾部损失，并重新检查是否只是恢复清仓、牺牲此前参与度；不能围绕已见7月跌势反复挑阈值。</p><p>原现金“保留全仓收益并降低回撤25%”及财富1.20倍仍留作历史对照，不宣称本批达标。按最新风险优先偏好，本轮判为“参与度有改善，风险改善证据不足”，默认保持不变。</p><p><a href="trend-floor-evidence.zip">下载全部结果、信号、逐笔账本及复现脚本</a> · <a href="exposure-control.html">上一批：固定仓位对照</a> · <a href="https://www.szse.cn/aboutus/trends/news/t20200821_580924.html">深交所创业板交易机制说明</a></p></section>'''
style='body{font:16px/1.75 system-ui,sans-serif;background:#f3f6fa;color:#1b304a;margin:0}main{max-width:1260px;margin:32px auto;padding:20px}section{background:white;border:1px solid #dce5ee;border-radius:14px;padding:24px;margin:22px 0}h1{font-size:30px}h2{font-size:22px}a{color:#147f85}.muted{font-size:14px;color:#6b7889}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:14px}th,td{white-space:nowrap;text-align:left;padding:11px;border-bottom:1px solid #e2e9ef}th{background:#f4f7fa}img{width:100%;height:auto}'
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>趋势底仓与80%胜率｜沪电研究</title><style>'+style+'</style></head><body><main>'+body+'</main></body></html>'
(O/'report.html').write_text(page.replace('src="trend-floor-chart.svg"','src="comparison.svg"'));(repo/'docs/research/trend-floor.html').write_text(page);(repo/'docs/research/trend-floor-chart.svg').write_bytes((O/'comparison.svg').read_bytes())
f=repo/'docs/research/archive.html';s=f.read_text();entry='<p><a href="trend-floor.html">趋势底仓检验：周期胜率80%，为何回撤反而扩大？ ↗</a></p>'
if 'href="trend-floor.html"' not in s:f.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+entry))
inputs=['work/risk_priority/data.json','work/shenghong/data.json','work/shenghong/finance.mjs','work/shenghong/benchmark.mjs','work/opening_guard/metrics.mjs','work/hudian-backtest-dashboard/docs/fees.js','work/hudian-backtest-dashboard/docs/attribution.js','outputs/exposure_control/metrics.json','outputs/round2/fundamental_point_in_time_map.csv','work/round2/data/daily_qfq_early.csv','work/data/daily_qfq.csv','outputs/shenghong/signal-ledger.csv','work/shenghong/data/daily_qfq.csv']
(O/'manifest.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in inputs},indent=2));(O/'README.txt').write_text('Reproduction: Node22 node work/trend_floor/run.mjs uses preregistered work/trend_floor/plans.json; python build.py requires pandas/numpy and regenerates fixed signals. Output main metrics, trades, episodes, quarters. report.py writes publication workspace. All history previously seen; no new blind test. Prior-quality limitations persist.\n')
with zipfile.ZipFile(repo/'docs/research/trend-floor-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in list(O.glob('*'))+list((R/'work/trend_floor').glob('*'))+[R/p for p in inputs]:
  if p.is_file() and p.name not in ['publication.json','deployment.log']:z.write(p,str(p.relative_to(R)))
f=R/'work/research-checkpoint.json';c=json.loads(f.read_text());c['trendFloor']={'updatedAt':datetime.datetime.now().astimezone().isoformat(),'outputs':'outputs/trend_floor','status':'locally verified, publication pending','rule':'Existing prior close>MA60 and risingMA12020; growth>0&RSI>60&basezero ->50cashfloor; original schedule,original full-only leverage. Onefixedcondition.','finding':'HudianLwin74/10272.55->24/3080% butreturn1226.51->1140.69,DD25.20->26.71; cycles merged,notintraday accuracy. ShenghongLreturn300.94->550.44 butDD48.39->49.63. EarlierDDworse4/4. AnnualDDimproveHcash1/3,Hmargin1/3,Scash0/3,Smargin1/3.10bpsHmarginwin75.76,DDstillworse.','audit':a,'defaultChanged':False,'newBlindTest':False};c['updatedAt']=c['trendFloor']['updatedAt'];f.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print('report, evidence and checkpoint saved')
