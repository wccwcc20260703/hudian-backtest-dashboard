# -*- coding: utf-8 -*-
import json,hashlib
from pathlib import Path
from datetime import datetime
r=Path.cwd();p={'createdAt':datetime.now().astimezone().isoformat(),'question':'Keep09:45 price+VWAP risk unchanged; does removing highvolume gate improve risk/win outcomes?','variants':['off','volume: priorbatchexact','price: remove only volume>=1.2*previous20same-time mean'],'unchanged':'09:45 close<=dayopen*.99, last2completedcloses<theirVWAP*.999, same20daywarmup; cashcap50%, margincap100%, resetsnextday. Existingguardengine unchanged inclfees,interest,T+1,volume1%execution,limits,passivedrift andafterbuydebt<=50%net. No threshold search.','accounts':['D','L','T'],'evidence':'Allhistoryseen. Compare3annual,earlier/later,Julyon,older,5/10bps,independentrollingtogglesusingprevious252sessions exactlyasbatch30; no newblindtest.','sameDay':'Reuse pairedbaselineprefix method; addedtriggerdays analyzedseparately; notTwinrate or continuousstrategyreturn','returnPriority':'Risk/win first, nohardfloorvsoriginalreturn','engineSHA256':hashlib.sha256((r/'work/opening_guard/engine.mjs').read_bytes()).hexdigest()}
(r/'outputs/volume_ablation/plan-before-results.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
s=(r/'work/opening_guard/run.mjs').read_text().replace("'./engine.mjs'","'../opening_guard/engine.mjs'").replace("'./metrics.mjs'","'../opening_guard/metrics.mjs'").replace("outputs/opening_guard/","outputs/volume_ablation/")
old='&&vol>=priorVolume*1.2';assert old in s;s=s.replace(old,'')
(r/'work/volume_ablation/run.mjs').write_text(s)
print('One-condition ablation frozen; execution engine unchanged')
