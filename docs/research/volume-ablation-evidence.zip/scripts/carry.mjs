import fs from 'node:fs';import assert from 'node:assert/strict';import {guardBacktest} from '../opening_guard/engine.mjs';
const read=p=>JSON.parse(fs.readFileSync(p)),data=read('work/risk_priority/data.json'),gates=read('work/risk_priority/gates.json'),events=read('outputs/volume_ablation/events.json'),old=read('outputs/opening_guard/events.json'),n=data.dates.length,start=data.dates.indexOf('2023-10-09'),out='outputs/volume_ablation/';
fs.writeFileSync(out+'carry-diagnostic-plan.json',JSON.stringify({createdAt:new Date().toISOString(),reason:'Same-day effect can be positive while continuousportfolio suffers; diagnose nextday carry beforechangingexecution.',measure:'Original identicalprefix state; riskcap onlyone eventday, compare dayclose,nextsession10:00beforeoriginalorder,nextsessionclose. Normalize all by original equity beforeeventday. Futureprices only label outcomes, never gate signal. Allhistoryseen.',noNewStrategy:true},null,2));
const cfg={D:{level:1,rate:0,riskCap:.5},L:{level:1.5,rate:.06,riskCap:1},T:{level:1.5,rate:.06,riskCap:1,gate:'trend'}};
const rows=[];for(const [name,c]of Object.entries(cfg)){
 const base=guardBacktest(data,gates,start,n,c);
 for(let d=start;d<n;d++)if(events[d].trigger){
 const mask=Array(n).fill(false);mask[d]=true;const r=guardBacktest(data,gates,start,Math.min(d+2,n),{...c,riskMask:mask}),i=d-start,den=i===0?1e6:base.nav[i-1];assert.deepEqual(r.nav.slice(0,i),base.nav.slice(0,i));
 const openEquity=(result)=>{if(d+1>=n)return null;const prev=result.daily[i],next=d+1,days=Math.max(0,(Date.parse(data.dates[next])-Date.parse(data.dates[d]))/86400000-1),cash=prev.cash-Math.max(-prev.cash,0)*c.rate/365*days+prev.shares*data.dividend[next]*.8,sh=data.bonus[next]>0?Math.round(prev.shares*(1+data.bonus[next])):prev.shares;return cash+sh*data.bars[next][0][0];};
 const nextOpen=d+1<n?(openEquity(r)-openEquity(base))/den:null;
 const day=(r.nav[i]-base.nav[i])/den,at10=d+1<n?(r.curve[(i+1)*48+5]-base.curve[(i+1)*48+5])/den:null,nextClose=d+1<n?(r.nav[i+1]-base.nav[i+1])/den:null;
 rows.push({name,date:data.dates[d],added:!old[d].trigger,dayEffect:day,nextDay:data.dates[d+1]??null,nextOpenEffect:nextOpen,next10Effect:at10,nextCloseEffect:nextClose,carryTo10:at10===null?null:at10-day,carryToClose:nextClose===null?null:nextClose-day});
 }
}
const summaries=[];for(const name of Object.keys(cfg))for(const group of ['all','added','oldVolume']){
 const xs=rows.filter(x=>x.name===name&&(group==='all'||group==='added'&&x.added||group==='oldVolume'&&!x.added)&&x.nextCloseEffect!==null);
 const mean=k=>xs.reduce((s,x)=>s+x[k],0)/xs.length;
 summaries.push({name,group,n:xs.length,day:mean('dayEffect'),nextOpen:mean('nextOpenEffect'),next10:mean('next10Effect'),nextClose:mean('nextCloseEffect'),carryTo10:mean('carryTo10'),dayBetter:xs.filter(x=>x.dayEffect>1e-10).length,betterThenWorse:xs.filter(x=>x.dayEffect>1e-10&&x.nextCloseEffect< -1e-10).length});
}
for(const [file,xs]of [['carry',rows],['carry-summary',summaries]]){fs.writeFileSync(out+file+'.json',JSON.stringify(xs));const k=Object.keys(xs[0]);fs.writeFileSync(out+file+'.csv',[k.join(','),...xs.map(x=>k.map(v=>JSON.stringify(x[v])).join(','))].join('\n'));}
console.log(JSON.stringify(summaries,null,2));
