# -*- coding: utf-8 -*-
from pathlib import Path
import json,numpy as np,hashlib
r=Path.cwd();out=r/'outputs/volume_ablation';d=json.load(open(r/'work/risk_priority/data.json'));b=np.array(d['bars']);new=json.loads((out/'events.json').read_text());old=json.load(open(r/'outputs/opening_guard/events.json'));vol=np.cumsum(b[:,:3,4],axis=1);vw=np.cumsum(b[:,:3,5],axis=1)/vol
for i,row in enumerate(new):
 flag=bool(i>=20 and b[i,2,3]<=b[i,0,0]*.99 and b[i,1,3]<vw[i,1]*.999 and b[i,2,3]<vw[i,2]*.999)
 assert flag==row['trigger'];assert not old[i]['trigger'] or flag
 assert row['date']==old[i]['date']
oldrows=json.load(open(r/'outputs/opening_guard/metrics.json'));rows=json.loads((out/'metrics.json').read_text());count=0
for x in rows:
 if x['mode']=='off':
  prior=next(y for y in oldrows if all(x[k]==y[k] for k in ['name','mode','period','slip']))
  for k in ['return_','mdd5','episodeWinRate','worstDay','worst5pctDayMean','orders','fees','interest']:assert x[k]==prior[k];count+=1
p1={(x['name'],x['date']):x for x in json.load(open(r/'outputs/opening_guard/paired.json'))};p2={(x['name'],x['date']):x for x in json.loads((out/'paired.json').read_text())}
for k,v in p1.items():assert v==p2[k]
carry=json.loads((out/'carry.json').read_text())
for x in carry:assert abs(x['dayEffect']-p2[x['name'],x['date']]['effect'])<1e-12
p=json.loads((out/'plan-before-results.json').read_text());assert p['engineSHA256']==hashlib.sha256((r/'work/opening_guard/engine.mjs').read_bytes()).hexdigest()
a=json.loads((out/'audit.json').read_text());a.update(independentPythonTriggers=len(new),baselineBatch30MetricParity=count,sharedPairedDays=len(p1),carryDayReconciliations=len(carry),executionEngineUnchanged=True,reusedSyntheticChecks=7);(out/'audit.json').write_text(json.dumps(a,indent=2));print(a)
