import fs from 'node:fs';import {guardBacktest} from '../opening_guard/engine.mjs';import {barTime} from '../hudian-backtest-dashboard/docs/engine.js';
const read=p=>JSON.parse(fs.readFileSync(p)),d=read('work/risk_priority/data.json'),g=read('work/risk_priority/gates.json'),a=d.dates.indexOf('2023-10-09');let rows=[];
for(const [mode,path]of [['off',null],['volume','outputs/opening_guard/events.json'],['price','outputs/volume_ablation/events.json']]){
 const r=guardBacktest(d,g,a,d.dates.length,{riskCap:1,riskMask:path?read(path).map(x=>x.trigger):[]});let peak=1e6,peakIndex=-1,worst=0,item=null;
 r.curve.forEach((v,i)=>{if(v>peak){peak=v;peakIndex=i;}const dd=v/peak-1;if(dd<worst){worst=dd;item={mode,drawdown:dd,peak,low:v,peakIndex,lowIndex:i}}});
 const stamp=i=>i<0?'初始资金':d.dates[a+Math.floor(i/48)]+' '+(i%48===47?'15:00':barTime(i%48)+'对应5分钟收盘');item.peakTime=stamp(item.peakIndex);item.lowTime=stamp(item.lowIndex);rows.push(item);
}
fs.writeFileSync('outputs/volume_ablation/drawdown-paths.json',JSON.stringify(rows,null,2));console.log(rows);
