import fs from 'node:fs';import assert from 'node:assert/strict';
import {guardBacktest} from '../opening_guard/engine.mjs';import {stats} from '../opening_guard/metrics.mjs';
import {financeBacktest} from '../hudian-backtest-dashboard/docs/finance-engine.js';import {backtest} from '../hudian-backtest-dashboard/docs/engine.js';import {attribution} from '../hudian-backtest-dashboard/docs/attribution.js';
const read=p=>JSON.parse(fs.readFileSync(p)),data=read('work/risk_priority/data.json'),gates=read('work/risk_priority/gates.json'),out='outputs/volume_ablation/',n=data.dates.length;
const index=x=>{let i=data.dates.findIndex(d=>d>=x);return i<0?n:i},start=index('2023-10-09'),freeze=index('2025-01-01'),cut=index('2026-07-01');
const periods={full:[start,n],early:[start,freeze],later:[freeze,cut],julyOn:[cut,n],older:[0,start]};for(let y=0;y<3;y++)periods['year'+(y+1)]=[index(`${2023+y}-10-09`),index(`${2024+y}-10-09`)];
export function trigger(b,priorVolume){if(!(priorVolume>0)||b.length<3)return false;let amt=0,vol=0,vw=[];for(let j=0;j<3;j++){vol+=b[j][4];amt+=b[j][5];vw.push(amt/vol)}return b[2][3]<=b[0][0]*.99&&b[1][3]<vw[1]*.999&&b[2][3]<vw[2]*.999;}
const mask=[],events=[];let prefix=0;
for(let d=0;d<n;d++){
 const prior=d<20?null:data.bars.slice(d-20,d).reduce((s,b)=>s+b.slice(0,3).reduce((q,v)=>q+v[4],0),0)/20;
 mask[d]=trigger(data.bars[d],prior);assert.equal(mask[d],trigger(data.bars[d].slice(0,3),prior));const poisoned=data.bars[d].map((x,j)=>j<3?x:x.map(v=>v*1234));assert.equal(mask[d],trigger(poisoned,prior));prefix+=2;
 events.push({date:data.dates[d],trigger:mask[d],priorVolume:prior,volume:data.bars[d].slice(0,3).reduce((s,b)=>s+b[4],0),openingReturn:data.bars[d][2][3]/data.bars[d][0][0]-1});
}
const cfg={D:{level:1,rate:0,riskCap:.5},L:{level:1.5,rate:.06,riskCap:1},T:{level:1.5,rate:.06,riskCap:1,gate:'trend'}};
const run=(name,a,z,slip=.0005,riskMask=[])=>guardBacktest(data,gates,a,z,{...cfg[name],slip,riskMask});
let parity=0,ledger=0,loanChecks=0;
function audit(r){let cash=r.capital,shares=0;for(let d=r.start;d<r.end;d++){
 const carry=d>r.start?Math.max(0,(Date.parse(data.dates[d])-Date.parse(data.dates[d-1]))/86400000-1):0;cash-=Math.max(-cash,0)*r.config.rate/365*carry;cash+=shares*data.dividend[d]*.8;if(data.bonus[d]>0)shares=Math.round(shares*(1+data.bonus[d]));let av=shares,maxDebt=Math.max(-cash,0);
 for(const t of r.trades.filter(x=>x[0]===d)){assert.equal(t[12],shares);assert.equal(t[9],av);const gross=t[3]*t[4],fee=Math.max(5,gross*.0001)+gross*(data.transfer[d]+(t[2]<0?data.stamp[d]:0));assert.ok(Math.abs(fee-t[5])<1e-6);cash-=t[2]*gross+fee;shares+=t[2]*t[3];if(t[2]<0)av-=t[3];assert(av>=0&&t[3]<=t[11]);assert.ok(Math.abs(cash-t[6])<1e-6);assert.equal(shares,t[7]);if(t[16]===1)assert(t[2]<0);if(t[2]>0){const eq=cash+shares*data.bars[d][t[1]][0];assert.ok(-cash<=(r.config.level===1?0:.5*eq)+1e-6);loanChecks++;}maxDebt=Math.max(maxDebt,-cash);ledger++;}
 cash-=maxDebt*r.config.rate/365;assert.ok(Math.abs(cash+shares*data.close[d]-r.nav[d-r.start])<1e-5);
}}
const rows=[],full={};function summarize(name,mode,period,slip,a,z,r){const b=backtest(data,'B',a,z,{slip}),attr=attribution(r,b,data.dates.slice(a,z));delete attr.relative;const rv=[r.capital,...r.nav],bv=[b.capital,...b.nav];let win=0,total=0;for(let i=63;i<rv.length;i++){total++;win+=rv[i]/rv[i-63]>bv[i]/bv[i-63]?1:0;}return {name,mode,period,slip,...r.metrics,...stats(r),...attr,rolling63Lead:total?win/total:null,triggerDays:mask.slice(a,z).filter(Boolean).length};}
for(const name of Object.keys(cfg))for(const [period,[a,z]]of Object.entries(periods))for(const slip of [.0005,.001])for(const mode of ['off','guard']){
 const r=run(name,a,z,slip,mode==='off'?[]:mask);if(mode==='off'){
 const orig=name==='D'?backtest(data,'D',a,z,{slip}):financeBacktest(data,gates,a,z,{...cfg[name],slip});for(const k of ['nav','curve','exposure']){assert.deepEqual(r[k],orig[k]);parity+=r[k].length;}assert.deepEqual(r.trades.map(t=>t.slice(0,name==='D'?14:16)),orig.trades);
 }
 rows.push(summarize(name,mode,period,slip,a,z,r));if(period==='full'&&slip===.0005){full[name+'_'+mode]=r;audit(r);}
}
const paired=[];for(const name of Object.keys(cfg))for(let d=start;d<n;d++)if(mask[d]){
 const one=Array(n).fill(false);one[d]=true;const r=run(name,start,d+1,.0005,one),b=full[name+'_off'];assert.deepEqual(r.nav.slice(0,-1),b.nav.slice(0,d-start));const prev=d===start?1e6:b.nav[d-start-1],effect=(r.nav.at(-1)-b.nav[d-start])/prev;
 paired.push({name,date:data.dates[d],effect,baseReturn:b.nav[d-start]/prev-1,guardReturn:r.nav.at(-1)/prev-1,baselineEnd:b.nav[d-start],guardEnd:r.nav.at(-1),guardTrades:r.trades.filter(t=>t[0]===d).length,baseTrades:b.trades.filter(t=>t[0]===d).length});
}
const rolling=[];for(const name of Object.keys(cfg)){
 const allowed=Array(n).fill(false);for(let y=2025;y<=2026;y++)for(let q=1;q<=4;q++){
 const a=index(`${y}-${String((q-1)*3+1).padStart(2,'0')}-01`),z=q===4?index(`${y+1}-01-01`):index(`${y}-${String(q*3+1).padStart(2,'0')}-01`);if(a>=n)continue;const t=Math.max(0,a-252),b=run(name,t,a),c=run(name,t,a,.0005,mask),sb=stats(b),sc=stats(c),count=mask.slice(t,a).filter(Boolean).length;
 const enable=count>=10&&Math.abs(c.metrics.mdd5)<Math.abs(b.metrics.mdd5)&&sc.episodeWinRate>=sb.episodeWinRate&&c.metrics.return_>0;for(let d=a;d<z;d++)allowed[d]=enable&&mask[d];rolling.push({name,quarter:`${y}Q${q}`,trainingThrough:data.dates[a-1],triggers:count,enable,baseDD:b.metrics.mdd5,guardDD:c.metrics.mdd5,baseWin:sb.episodeWinRate,guardWin:sc.episodeWinRate});
 }
 for(const slip of [.0005,.001]){const r=run(name,start,n,slip,allowed);rows.push(summarize(name,'rolling','full',slip,start,n,r));audit(r);}
}
const save=(name,rows)=>{fs.writeFileSync(out+name+'.json',JSON.stringify(rows));if(!rows.length)return;const ks=Object.keys(rows[0]);fs.writeFileSync(out+name+'.csv',[ks.join(','),...rows.map(r=>ks.map(k=>JSON.stringify(r[k]??null)).join(','))].join('\n'));};save('metrics',rows);save('paired',paired);save('events',events);save('rolling',rolling);
for(const [key,r]of Object.entries(full))save(key+'_fills',r.trades.map(t=>({date:data.dates[t[0]],bar:t[1],side:t[2],quantity:t[3],price:t[4],fee:t[5],cash:t[6],shares:t[7],available:t[8],beforeShares:t[12],target:t[10],riskReason:t[16]})));
const comparisons={};for(const name of Object.keys(cfg)){const get=(mode,p)=>rows.find(x=>x.name===name&&x.mode===mode&&x.period===p&&x.slip===.0005);comparisons[name]={annualLowerDD:[1,2,3].filter(y=>Math.abs(get('guard','year'+y).mdd5)<Math.abs(get('off','year'+y).mdd5)).length,annualHigherWin:[1,2,3].filter(y=>get('guard','year'+y).episodeWinRate>get('off','year'+y).episodeWinRate).length};}
fs.writeFileSync(out+'audit.json',JSON.stringify({prefix,parity,ledger,loanChecks,pairedCount:paired.length,comparisons,defaultChanged:false,independentForwardEvidence:false},null,2));console.log(JSON.stringify({full:rows.filter(x=>x.period==='full'&&x.slip===.0005).map(x=>({name:x.name,mode:x.mode,return:x.return_,dd:x.mdd5,win:x.episodeWinRate,worst:x.worstDay,tail:x.worst5pctDayMean})),triggers:mask.slice(start).filter(Boolean).length,comparisons},null,2));
