import fs from 'node:fs';import assert from 'node:assert/strict';import {guardBacktest} from './engine.mjs';
const b0=Array.from({length:48},()=>[100,100,100,100,1e6,1e8]);const weak=[[100,100,99,99,1e6,99.7e6],[99,99.5,98.9,98.9,1e6,99.2e6],[98.9,99,98.5,98.5,1e6,98.8e6],...Array.from({length:45},()=>[98.4,98.5,98.3,98.5,1e6,98.45e6])];
const make=(bars=[b0,weak],s=[[6,1],[6,1]])=>({dates:['2026-09-01','2026-09-02'],bars,close:bars.map(b=>b.at(-1)[3]),dividend:[0,0],bonus:[0,0],reference:[100,100],stamp:[.0005,.0005],transfer:[.00001,.00001],signals:{D:s}});const g={D:{all_full:[1,1]}};let checks=[];
for(const [level,riskCap,rate]of [[1,.5,0],[1.5,1,.06]]){
 const d=make(),r=guardBacktest(d,g,0,2,{level,rate,riskCap,riskMask:[false,true]});const early=r.trades.filter(t=>t[0]===1&&t[1]===3);assert(early.length&&early.every(t=>t[2]===-1&&t[16]===1));assert(r.trades.filter(t=>t[0]===1).every(t=>t[10]<=riskCap));checks.push(`level${level}:09:45reducesonly and lateroriginaltargetcapped`);
}
let d=make(undefined,[[6,0],[6,0]]),r=guardBacktest(d,g,0,2,{riskCap:1,riskMask:[false,true]});assert.equal(r.trades.length,0);checks.push('flataccount risk creates no purchases');
d=make(undefined,[[6,1],[3,0]]);r=guardBacktest(d,g,0,2,{riskCap:1,riskMask:[false,true]});assert(r.trades.filter(t=>t[0]===1).every(t=>t[10]===0));checks.push('simultaneous genuinezero target is preserved');
d=make(undefined,[[6,1],[6,1]]);d.bars=structuredClone(d.bars);d.bars[1][2][4]=1e4;r=guardBacktest(d,g,0,2,{riskCap:1,riskMask:[false,true]});let risk=r.trades.find(t=>t[0]===1&&t[1]===3);assert.equal(risk[3],100);assert(r.trades.some(t=>t[0]===1&&t[1]===4));checks.push('volume cap partial100 shares, laterbarcontinuation');
d=make(undefined,[[6,1],[6,1]]);d.bars=structuredClone(d.bars);for(let j=3;j<48;j++)d.bars[1][j]=[90,90,90,90,1e6,90e6];d.close[1]=90;r=guardBacktest(d,g,0,2,{riskCap:1,riskMask:[false,true]});assert(!r.trades.some(t=>t[0]===1));assert(r.daily[1].shares>0);checks.push('limitdown no pretend sale, retainedloss at close');
// Same-day shares unavailable: original buy09:35, later risk can only reduce old zero inventory.
d=make(undefined,[[6,0],[1,1]]);r=guardBacktest(d,g,0,2,{riskCap:1,riskMask:[false,true]});assert(r.metrics.t1_blocks>0);assert(!r.trades.some(t=>t[2]<0));checks.push('T+1 newshares cannot fund risk exit');
const p='outputs/opening_guard/audit.json',a=JSON.parse(fs.readFileSync(p));a.synthetic=checks;fs.writeFileSync(p,JSON.stringify(a,null,2));console.log(checks);
