# -*- coding: utf-8 -*-
from pathlib import Path
import json,hashlib
import pandas as pd,numpy as np
R=Path.cwd();O=R/'outputs/volume_regime';m=pd.read_csv(O/'metrics.csv');c=pd.read_csv(O/'confusion.csv');checks=0;extra=[]
for p,h in json.loads((O/'manifest.json').read_text()).items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==h,p
periods={'full':('2023-10-09','2026-10-08'),'older':('2020-01-02','2023-09-28'),'early':('2023-10-09','2024-12-31'),'later':('2025-01-01','2026-06-30'),'julyOn':('2026-07-01','2026-10-08'),'year1':('2023-10-09','2024-10-08'),'year2':('2024-10-09','2025-10-08'),'year3':('2025-10-09','2026-10-08')}
data={s:pd.read_csv(O/f'{s}-daily.csv')for s in ['hudian','shenghong']}
for x in m.itertuples():
 v=c[(c.stock==x.stock)&(c.period==x.period)&(c.horizon==x.horizon)&(c.sampling==x.sampling)&(c.model==x.model)]
 assert v['count'].sum()==x.n
 assert v[v.predicted!=1]['count'].sum()==x.issued
 assert v[(v.actual==v.predicted)&(v.predicted!=1)]['count'].sum()==x.strongHits
 f=data[x.stock];a,z=periods[x.period];t=f[(f.date>=a)&(f.date<=z)&f['label'+str(x.horizon)].notna()&(f['end'+str(x.horizon)]<=z)]
 if x.sampling=='nonoverlap':t=t.iloc[::x.horizon]
 if t.empty:continue
 pred=t[x.model];r=t['return'+str(x.horizon)];up=pred==2;down=pred==0;issued=up|down
 hit=(up&(r>0))|(down&(r<0));assert hit.sum()==x.signHits
 hUp=float((r[up]>0).mean())if up.any()else np.nan;hDown=float((r[down]<0).mean())if down.any()else np.nan
 balanced=(hUp+hDown)/2 if up.any()and down.any()else np.nan
 # Descriptive controls only. Added to prevent aggregate-rate/class-mix confusion, not new gates.
 extra.append({'stock':x.stock,'period':x.period,'horizon':x.horizon,'sampling':x.sampling,'model':x.model,'upSignAccuracy':hUp,'downSignAccuracy':hDown,'balancedSignPrecision':balanced,'alwaysUpSameDates':float((r[issued]>0).mean())if issued.any()else np.nan})
 checks+=1
p=pd.DataFrame(extra);p.to_csv(O/'direction-controls.csv',index=False)
audit=json.loads((O/'audit.json').read_text());audit.update({'confusionAndSignReconciliations':checks,'manifestMatches':True,'extraDiagnostics':'After aggregate results, added equal weighting of up/down issued-sign precision and always-up same-date baseline; descriptive no new thresholds/rules/selection.'});(O/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(p[(p.period=='full')&(p.horizon==20)&(p.sampling=='all')].round(4).to_string(index=False))
