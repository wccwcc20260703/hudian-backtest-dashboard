# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
import json,html,zipfile,shutil
import pandas as pd
R=Path.cwd();O=R/'outputs/volume_regime';repo=R/'work/hudian-backtest-dashboard';m=pd.read_csv(O/'metrics.csv');c=pd.read_csv(O/'conditional.csv');p=pd.read_csv(O/'direction-controls.csv');a=json.loads((O/'audit.json').read_text())
names={'MA3':'原均线分区MA3','VMA':'MA3＋5/20日量均线确认','OBV':'MA3＋20日OBV方向确认'};stocks={'hudian':'沪电','shenghong':'胜宏'};pct=lambda x:'—'if pd.isna(x)else f'{x*100:.2f}%'
def table(head,rows):return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>'for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>'for x in row)+'</tr>'for row in rows)+'</tbody></table></div>'
body='''<nav><a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a></nav><h1>量能能否让区间判断更准确？</h1><p class="muted">两个固定确认因子 · 沪电与胜宏原规则迁移 · 192组方向评估，不是192组交易回测 · 截至2026-10-08</p>
<section><h2>先回答：现有区间还没有被证明准确、通用</h2><p>前面的检查确认了分区按历史信息计算，没有把未来涨跌用于当天分类；它没有证明分区能准确预告趋势延续或转折。<a href="regime-policy.html">上一轮完整账户测试</a>也没有支持把均线上行直接绑定满仓、均线下行直接绑定空仓。</p><p>跨股票验证是必要检验，但“通用”应指不针对每只股票反复调参，仍有稳定区分能力；不能要求每只股票的胜率和收益相同。成交量应相对自身历史比较，而不是用同一个绝对股数阈值。当前只有两只PCB同业股票，尚不是覆盖不同行业、流动性和市场阶段的广泛证据。</p><p>还要先固定期限：中期上行中可以出现短期下跌。我们将既有5日与20日评分分别保留，不事后挑命中率更高的期限作为唯一答案。</p></section>
<section><h2>这次加入哪两种量能信息？</h2>'''
body+=table(['候选','截至前一日的固定计算','如何确认原MA3状态'],[['成交量均线VMA','5日平均成交量 ÷ 20日平均成交量','比值≥1时保留上行或下行判断，否则暂不判断'],['OBV方向','过去20日：上涨日成交量相加、下跌日成交量相减，再除以20日总量','结果>0确认上行，<0确认下行；不一致时暂不判断']])
body+='''<p>MA3定义不动：前收盘＞MA20＞MA60且MA20上升，反向则下行；新原始状态连续3个已完成交易日才切换。量能条件分别测试，不叠加两个因子，也不搜索5、10、20等大量参数组合。</p><p>这里的量均线是<strong>成交量的移动平均</strong>，不是价格的成交量加权均线VWMA。OBV把一整天成交量按收盘涨跌记正负，只是量价方向代理，不能说成已查明“主力资金净流入”。对数据内已知送转股作相对股数调整；比率仍只用当时可知信息。</p><p>依据：券商原始教育资料<a href="https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/volume-oscillator">Fidelity成交量振荡指标</a>介绍短长量均线之差；<a href="https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/obv">Fidelity OBV</a>介绍涨跌日成交量累加及方向关系。它们提供指标定义，不是沪电有效性或80%交易胜率的证据。访问日期2026-10-10，5/20及20日规则为本研究固定实现。</p></section>
<section><h2>怎样计分，避免“少判断就变准确”的错觉？</h2><p><strong>方向命中率：</strong>判断上涨后，从当天复权开盘到未来第5／20个交易日收盘上涨，或判断下跌后下跌，记为命中；平盘不算。分母仅为实际给出方向的日期。<strong>覆盖率：</strong>这些日期占所有有完整后续结果日期的比例。量能不确认只是“暂不判断”，不能把这些日期当成成功判断震荡。</p><p><strong>明显反向率：</strong>不仅猜错，而且反向涨跌幅超过前20日波动率×√持有天数。该阈值沿用上轮，后续价格只用于评分。另将上涨判断与下跌判断的命中率分别列出，并用两者等权平均检查类别偏差；这与之前三类标签的“平衡准确率”不是同一指标，不能混用。</p><p>所有结果是后续价格方向，未扣交易成本，也未定义卖出、止损与实际配对成交，<strong>不称做T胜率，不推导融资收益或账户回撤</strong>。如果因子不能先稳定区分价格走势，就没有理由直接改默认交易。</p></section>
<section><h2>近三年20日结果：小幅改善没有跨股票延续</h2>'''
v=m[(m.period=='full')&(m.horizon==20)&(m.sampling=='all')]
body+=table(['股票／规则','命中／给出方向日期','方向命中率','覆盖率','明显反向／给出方向日期'],[[stocks[x.stock]+'／'+names[x.model],f'{x.signHits}/{x.issued}',pct(x.signAccuracy),f'{x.issued}/{x.n} · '+pct(x.coverage),f'{x.oppositeStrong}/{x.issued} · '+pct(x.oppositeStrongRate)]for x in v.itertuples()])
body+='''<p>沪电加入量均线后，59.63%→61.62%，但判断日期379→185，明显反向率10.29%→13.51%；胜宏同一规则50.71%→46.04%，明显反向率也上升。OBV在沪电减少明显反向，但在胜宏没有同样改善。不能仅凭沪电那2个百分点就说区间更准确。</p></section>
<section><h2>拆开上涨和下跌判断，问题更清楚</h2>'''
v=p[(p.period=='full')&(p.horizon==20)&(p.sampling=='all')]
body+=table(['股票／规则','上涨判断命中率','下跌判断命中率','两类等权命中率','同日期全部猜上涨'],[[stocks[x.stock]+'／'+names[x.model],pct(x.upSignAccuracy),pct(x.downSignAccuracy),pct(x.balancedSignPrecision),pct(x.alwaysUpSameDates)]for x in v.itertuples()])
body+='''<p>沪电量均线确认后的上行判断107/147＝72.79%命中，但下行判断仅7/38＝18.42%命中；两类等权平均从51.07%降至45.61%。在它所挑出的同一批185个日期，简单全部猜上涨也有74.59%的价格方向命中率，因此61.62%不能单独作为方向预测有优势的证据。这个“总猜上涨”是同日期描述性对照，没有用它建立新交易策略。</p><p>对胜宏，上行＋量均线确认后仅76/136＝55.88%命中。当前未发现两个量能确认规则在两只股票上都稳定改善原分区。</p></section>
<section><h2>量能更可能需要与所处位置交互，而不是机械确认原方向</h2>'''
v=c[(c.period=='full')&(c.horizon==20)&(c.model=='VMA')]
body+=table(['股票／原状态','量均线状态','日期数','原方向命中率','后20日平均股价涨幅'],[[stocks[x.stock]+'／'+('上行'if x.state==2 else '下行'),'5日均量≥20日均量'if x.kept else '5日均量<20日均量',x.n,pct(x.signAccuracy),pct(x.meanPriceReturn)]for x in v.itertuples()])
body+='''<p>值得进一步检验的线索是：下行结构中，量能扩大后的沪电38个日期有31个后20日上涨，胜宏66个日期有49个后20日上涨。它可能混合了下跌末端换手与反弹，不能自动解释成“放量下跌必将继续”。这些前瞻窗口高度重叠，也处于相近行业行情，不能当成31次和49次独立盈利交易，更不能据此直接反向买入或加杠杆。</p><p>本轮只记录这一条件关系；尚未检验入场、失败退出、仓位和成本，也未证明原因。任何“放量下行后反弹”的新规则，都需要先冻结，再用完整账户和不同历史阶段验证。</p></section>
<section><h2>固定年度、更早行情与不重叠检查</h2>'''
v=m[(m.horizon==20)&(m.sampling=='all')&m.period.isin(['older','year1','year2','year3'])]
rows=[]
for stock in ['hudian','shenghong']:
 for period in ['older','year1','year2','year3']:
  w=v[(v.stock==stock)&(v.period==period)].set_index('model');rows.append([stocks[stock]+'／'+period,*[f'{w.loc[k,"signHits"]}/{w.loc[k,"issued"]} · '+pct(w.loc[k,'signAccuracy'])for k in ['MA3','VMA','OBV']]])
body+=table(['股票／时段','原MA3','量均线确认','OBV确认'],rows)
body+='''<p>量均线规则在沪电年度1、2的方向命中率下降，年度3改善；胜宏也不是一致改善。更早沪电约43.59%→43.55%，胜宏38.39%→33.50%。这些结果不满足跨阶段稳定性要求。older为2020-01-02至2023-09-28；三个年度从2023／2024／2025年10月9日起，各至次年10月8日。每段末尾缺少完整结果的日期不评分。</p><p>从同一时段第一日每隔20个交易日抽一次，先选样本再做量能过滤，避免每个规则选择不同抽样起点：</p>'''
v=m[(m.period=='full')&(m.horizon==20)&(m.sampling=='nonoverlap')]
body+=table(['股票／规则','方向命中／发出判断','全部抽样起点','命中率'],[[stocks[x.stock]+'／'+names[x.model],f'{x.signHits}/{x.issued}',x.n,pct(x.signAccuracy)]for x in v.itertuples()])
body+='''<p>量均线过滤后只有沪电8、胜宏10个不重叠方向判断，证据太少，不能从几个百分点差异宣称胜出。全部历史已见，不是新的盲测；每个时期均按同样冻结规则评估，没有训练后再挑一个最好时期。</p></section>
<section><h2>5日与7月前后结果也保留</h2>'''
v=m[(m.sampling=='all')&(((m.period=='full')&(m.horizon==5))|((m.horizon==20)&m.period.isin(['early','later','julyOn'])))]
body+=table(['股票／时段／期限','规则','方向判断日期','方向命中率','明显反向率'],[[stocks[x.stock]+'／'+x.period+f'／{x.horizon}日',names[x.model],x.issued,pct(x.signAccuracy),pct(x.oppositeStrongRate)]for x in v.itertuples()])
body+='''<p>early为2023-10-09至2024-12-31；later为2025-01-01至2026-06-30；julyOn为2026-07-01至2026-10-08。这里检验价格预测，没有账户累计净值、滚动领先比例或回撤的新结果；那些应在因子进一步合格后，现金与融资完整账户分别复验，不能用方向准确率代替。</p></section>
<section><h2>本轮结论与下一步</h2><p>量能有明确经济含义，但本轮两条简单确认规则没有证明分区准确、跨股票通用；主看板默认及实时信号保持原状。接下来应检验量价所处位置和承接：例如同样放量，是突破后持续承接，还是已经大幅下跌后的成交集中。新的位置条件要单独登记，不能在看过本轮结果后随意挑最佳门槛。</p><p>研究应允许输出“未知／过渡”。真正适合交易的分区应同时有方向、波动风险和转折概率，而不是只要求每个日期必须落入上行、震荡、下行三个名字。原始状态计算正确，是必要条件；未来风险和策略收益稳定改善，才是交易价值。</p>'''
body+=f'<p>核验：{a["dailyPrefixChecks"]}个股票日期的量均线和OBV由严格历史前缀独立重算；{a["confusionAndSignReconciliations"]}组混淆计数与价格符号命中对账；包含已知送转股的20个观测窗口已按相对股数调整。已见历史、当前版本前复权、有限股票数量及重叠窗口仍限制推断。单日数据截止2026-10-08，未把未完全核验的10月9日分钟数据用于本轮。</p>'
body+='''<p><a href="volume-regime-evidence.zip">下载192组结果、条件分组、逐日因子、来源登记及可复跑脚本</a> · <a href="regime-policy.html">前轮：各区间账户策略对照</a></p></section>'''
style='body{font:16px/1.8 system-ui,sans-serif;color:#1b304a;background:#f3f6fa;margin:0}main{max-width:1220px;margin:30px auto;padding:20px}section{background:white;border:1px solid #dce5ee;border-radius:14px;padding:26px;margin:22px 0}h1{font-size:30px}h2{font-size:22px}a{color:#147f85}.muted{color:#697b8c;font-size:14px}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:11px;white-space:nowrap;text-align:left;border-bottom:1px solid #e2eaf1}th{background:#f4f7fa}'
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>量能与区间定义检验｜沪电研究</title><style>'+style+'</style></head><body><main>'+body+'</main></body></html>'
(O/'report.html').write_text(page);(repo/'docs/research/volume-regime.html').write_text(page)
ar=repo/'docs/research/archive.html';s=ar.read_text();link='<p><a href="volume-regime.html">量能能否让分区更准确：5/20日量均线与OBV的跨股票、跨阶段检验 ↗</a></p>'
if 'href="volume-regime.html"'not in s:ar.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+link))
(O/'README.txt').write_text('From workspace root run python work/volume_regime/register.py then research.py, check.py and report.py. pandas/numpy required. Priorfuture labels evaluation only; allprice/volume inputs prefixshifted. Noaccounttrades, no defaultchange. MA3middle andgatedunknown notdefinedsideways. Direction-control equalweights/alwaysup are post-aggregate diagnostics, not new rules.\n')
inputs=list(json.loads((O/'manifest.json').read_text()))
with zipfile.ZipFile(O/'volume-regime-evidence.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in list(O.glob('*'))+list((R/'work/volume_regime').glob('*.py'))+[R/f for f in inputs]:
  if f.is_file()and f.suffix!='.zip'and f.name not in ['publication.json','deployment.log']:z.write(f,str(f.relative_to(R)))
shutil.copyfile(O/'volume-regime-evidence.zip',repo/'docs/research/volume-regime-evidence.zip')
cp=R/'work/research-checkpoint.json';q=json.loads(cp.read_text());now=datetime.now().astimezone().isoformat();q['volumeRegime']={'updatedAt':now,'outputs':'outputs/volume_regime','status':'verified locally; publication pending','audit':a,'finding':'SimpleVMA5>=20 gate does not generalize: H20day sign59.63->61.62 with379->185 issued,Sh50.71->46.04. H up/down equalweight51.07->45.61. OBV no crossstock improvement. Down+volume expansion followed bypositive20return31/38H49/66Sh, overlapping posterior hypothesis notT80%or newbuyrule. Earlier and annual unstable.','defaultChanged':False,'newBlindTest':False,'nextQuestion':'Test one preregistered price-location/acceptance condition to distinguish volume expansion continuation vs exhaustion; no ex-post gate grid. Broaden sectors only with certified data, same normalized rules; twoPCBstocks cannot establish universal validity.'};q['updatedAt']=now;cp.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n');print('Volume report and checkpoint saved.')
