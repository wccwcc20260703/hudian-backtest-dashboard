# -*- coding: utf-8 -*-
from pathlib import Path
import json,math
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/volume_regime';assert(O/'plan-before-results.json').exists()
periods={'full':('2023-10-09','2026-10-08'),'older':('2020-01-02','2023-09-28'),'early':('2023-10-09','2024-12-31'),'later':('2025-01-01','2026-06-30'),'julyOn':('2026-07-01','2026-10-08'),'year1':('2023-10-09','2024-10-08'),'year2':('2024-10-09','2025-10-08'),'year3':('2025-10-09','2026-10-08')}
metrics=[];conditional=[];confusions=[];retained=[];checks=0;bonusWindows=0
def score(t,model,h):
 p=t[model].astype(int);y=t['label'+str(h)].astype(int);r=t['return'+str(h)];issued=p!=1;hit=(p==y)&issued;strongOpp=((p==0)&(y==2))|((p==2)&(y==0));signhit=((p==2)&(r>0))|((p==0)&(r<0));N=int(issued.sum());recalls=[float(((p==k)&(y==k)).sum()/(y==k).sum())for k in [0,2]if (y==k).any()]
 return {'n':len(t),'issued':N,'upSignals':int((p==2).sum()),'downSignals':int((p==0).sum()),'coverage':N/len(t) if len(t)else None,'strongHits':int(hit.sum()),'strongPrecision':float(hit.sum()/N)if N else None,'signHits':int(signhit.sum()),'signAccuracy':float(signhit.sum()/N)if N else None,'oppositeStrong':int(strongOpp.sum()),'oppositeStrongRate':float(strongOpp.sum()/N)if N else None,'balancedStrongRecall':float(np.mean(recalls))if recalls else None,'recallClasses':len(recalls)}
for stock,path in [('hudian','risk_priority'),('shenghong','shenghong')]:
 d=json.loads((R/f'work/{path}/data.json').read_text());f=pd.read_csv(R/f'outputs/regime_definition/{stock}-daily.csv');dates=d['dates'];assert f.date.tolist()==dates
 if stock=='hudian':q=pd.concat([pd.read_csv(R/'work/round2/data/daily_qfq_early.csv'),pd.read_csv(R/'work/data/daily_qfq.csv')]).sort_values('date').drop_duplicates('date',keep='last').set_index('date')
 else:q=pd.read_csv(R/'work/shenghong/data/daily_qfq.csv').sort_values('date').set_index('date')
 q=q.loc[:dates[-1]];bonus=pd.Series(dict(zip(dates,d['bonus']))).reindex(q.index).fillna(0);factor=(1+bonus).cumprod();v=q.volume/factor
 assert (v>0).all() and v.notna().all();signed=np.sign(q.close.diff())*v
 vratio=(v.rolling(5).mean()/v.rolling(20).mean()).shift();obv=(signed.rolling(20).sum()/v.rolling(20).sum()).shift()
 f['knownThrough']=[q.index[q.index.get_loc(dt)-1]for dt in dates];f['V5V20']=vratio.reindex(dates).to_numpy();f['OBV20norm']=obv.reindex(dates).to_numpy();assert f[['V5V20','OBV20norm']].notna().all().all()
 f['VMA']=np.where((f.MA3!=1)&(f.V5V20>=1),f.MA3,1).astype(int);f['OBV']=np.where(((f.MA3==2)&(f.OBV20norm>0))|((f.MA3==0)&(f.OBV20norm<0)),f.MA3,1).astype(int)
 f['bonusInVolumeWindow']=bonus.rolling(20).sum().shift().reindex(dates).gt(0).to_numpy();bonusWindows+=int(f.bonusInVolumeWindow.sum())
 for i,dt in enumerate(dates):
  prefix=q.loc[q.index<dt];vs=(prefix.volume/factor.loc[prefix.index]);ratio=vs.iloc[-5:].mean()/vs.iloc[-20:].mean();sign=np.sign(prefix.close.diff());balance=(sign*vs).iloc[-20:].sum()/vs.iloc[-20:].sum();assert abs(ratio-f.V5V20.iloc[i])<1e-10;assert abs(balance-f.OBV20norm.iloc[i])<1e-10;assert f.knownThrough.iloc[i]<dt;checks+=1
 f.to_csv(O/f'{stock}-daily.csv',index=False)
 for period,(a,z)in periods.items():
  for h in [5,20]:
   w=f[(f.date>=a)&(f.date<=z)&f['label'+str(h)].notna()&(f['end'+str(h)]<=z)]
   for sampling in ['all','nonoverlap']:
    t=w if sampling=='all' else w.iloc[::h]
    for model in ['MA3','VMA','OBV']:
     metrics.append(dict(stock=stock,period=period,horizon=h,sampling=sampling,model=model,**score(t,model,h)))
     for actual in [0,1,2]:
      for predicted in [0,1,2]:confusions.append(dict(stock=stock,period=period,horizon=h,sampling=sampling,model=model,actual=actual,predicted=predicted,count=int(((t['label'+str(h)]==actual)&(t[model]==predicted)).sum())))
    if sampling=='all':
     for model in ['VMA','OBV']:
      for state in [0,2]:
       for keep in [False,True]:
        t1=t[(t.MA3==state)&((t[model]!=1)==keep)];n=len(t1);r=t1['return'+str(h)];y=t1['label'+str(h)];hits=(y==state).sum();directional=r if state==2 else -r
        conditional.append(dict(stock=stock,period=period,horizon=h,model=model,state=state,kept=keep,n=n,strongHits=int(hits),strongPrecision=float(hits/n)if n else None,signHits=int((directional>0).sum()),signAccuracy=float((directional>0).mean())if n else None,meanPriceReturn=float(r.mean())if n else None,meanDirectionalReturn=float(directional.mean())if n else None,worst5pctDirectionalMean=float(directional.nsmallest(max(1,math.ceil(n*.05))).mean())if n else None,oppositeStrong=int((y==2-state).sum())))
   # Full daily evidence, kept/rejected dates independently reproducible.
   for model in ['VMA','OBV']:
    kept=(w.MA3!=1)&(w[model]!=1);rejected=(w.MA3!=1)&(w[model]==1)
    assert int(kept.sum()+rejected.sum())==int((w.MA3!=1).sum());retained.append({'stock':stock,'period':period,'horizon':h,'model':model,'base':int((w.MA3!=1).sum()),'kept':int(kept.sum()),'rejected':int(rejected.sum())})
pd.DataFrame(metrics).to_csv(O/'metrics.csv',index=False);pd.DataFrame(conditional).to_csv(O/'conditional.csv',index=False);pd.DataFrame(confusions).to_csv(O/'confusion.csv',index=False);pd.DataFrame(retained).to_csv(O/'retained.csv',index=False)
assert len(metrics)==192
audit={'dailyPrefixChecks':checks,'evaluations':len(metrics),'knownBonusWindows':bonusWindows,'priceRulesChanged':False,'newBlindTest':False,'defaultChanged':False,'noAccountBacktest':True,'samplingPhaseBeforeGating':True}
(O/'audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit));print(pd.DataFrame(metrics).query("period=='full' and sampling=='all'").round(4).to_string(index=False))
