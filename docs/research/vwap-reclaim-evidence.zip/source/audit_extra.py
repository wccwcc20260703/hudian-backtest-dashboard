# -*- coding: utf-8 -*-
from pathlib import Path
import ast,json,math,types
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/vwap_reclaim';t=ast.parse((R/'work/vwap_reclaim/study.py').read_text());ns={'np':np,'math':math};exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='confirmation'],type_ignores=[]),'confirmation','exec'),ns);c=ns['confirmation'];checks=[]
def bars():
 b=np.zeros((48,6));b[:,:4]=99;b[:,4]=10000;b[:,5]=1000000;return b
b=bars();b[6,3]=101;assert c(b,6)==7;checks.append('Cross from below after arm buys nextopen, not crossingbar')
b=bars();b[11,3]=101;assert c(b,6)==12;b[11,3]=99;b[12,3]=101;assert c(b,6)==-1;checks.append('Sixbar maximum includes last allowed confirmation, excludes seventh')
b=bars();b[36,3]=101;assert c(b,36)==-1;checks.append('No buying after14:00 even if later cross')
b=bars();b[6,3]=101;b[7:,3]=150;assert c(b[:8],6)==c(b,6)==7;checks.append('Later prices cannot shift first confirmed signal')
exec((R/'work/t_stop_review/generated_simulator.py').read_text(),ns)
b=bars()[None,:,:];b[:,:,:4]=100;b[:,:,4]=1e6;b[:,:,5]=1e8;b[0,7,0]=110
e=types.SimpleNamespace(B=b,REF=np.array([100.]),C=np.array([100.]),TRANSFER=np.array([.00001]),STAMP=np.array([.0005]),DATES=np.array(['2026-01-05']))
s=np.zeros((1,48,3),bool);s[0,6,1]=True;ns.update(e=e,sig=s,trend=np.array([True]),rv=np.full((1,48),1.5),a5=np.ones((1,48)))
r,f=ns['simulate_stop'](0,'volume',.0005,'base');assert not f and not r['bought'];checks.append('Confirmed but nextopen limitup means nofill; no silent retry later')
b[0,7,0]=100;b[0,6,4]=20000;r,f=ns['simulate_stop'](0,'volume',.0005,'base');assert f[0]['qty']==200 and f[0]['cash']>=200000 and f[-1]['available']==4800;checks.append('Delayed size recomputed using priorvolume; oldstock sale andcashreserve preserved')
(O/'additional_audit.json').write_text(json.dumps({'syntheticChecks':checks,'count':len(checks)},indent=2))
m=pd.read_csv(O/'metrics.csv');print(m[(m.period=='full')&(m.slip==.001)].to_string(index=False));print(json.dumps({'checks':len(checks)}))
