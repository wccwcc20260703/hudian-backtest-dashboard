# -*- coding: utf-8 -*-
def simulate_stop(d,rule,slip,mode):
 stop_level=-np.inf;distance=np.nan;peak=-np.inf;stop_bar=-1;stop_hit=False
 b=e.B[d];base=int(500000/e.REF[d]/100)*100;cash=1e6-base*e.REF[d];startcash=cash;avail=base;sh=base;working=0;buygross=0.;buycost=0.;sellnet=0.;nentry=0;lastentry=-99;exiting=False;deadline=False;fills=[];first=-1;last=-1
 lower=math.floor(e.REF[d]*.9*100+.5)/100;upper=math.floor(e.REF[d]*1.1*100+.5)/100;ix={'rebound':0,'volume':1,'support':2,'split334':1}[rule]
 for j in range(1,47):
  side=0;qty=0;cap=int(b[j-1,4]*.01/100)*100;op=b[j,0]
  if working>0:
   c=b[j-1,3];weak=c>buygross/max(sum(t['qty'] for t in fills if t['side']==1),1) and c>b[j-2,3] and rv[d,j-1]<1 and rv[d,j-1]<rv[d,j-2]
   if mode=="trail15":
    peak=max(peak,c);stop_level=max(stop_level,peak-distance)
   if mode!="base" and c<stop_level and not exiting:
    exiting=True;stop_hit=True;stop_bar=j-1
   if weak:exiting=True
   if j>=42:exiting=True;deadline=True
  if exiting and working>0:
   side=-1;fill=math.floor(op*(1-slip)*100+1e-8)/100;qty=min(working,avail,cap)
   if op<=lower+.005 or fill<lower:qty=0
  elif not exiting and trend[d] and 6<=j<=36 and sig[d,j-1,ix] and j-lastentry>=2 and nentry<(3 if rule=='split334' else 1):
   side=1;fill=math.ceil(op*(1+slip)*100-1e-8)/100;budget=300000*([.3,.3,.4][nentry] if rule=='split334' else 1);budget=min(budget,300000-buycost,cash-200000)
   qty=min(cap,int(max(0,budget-5)/(fill*(1+.00025+e.TRANSFER[d]))/100)*100,avail-working)
   qty=max(0,int(qty/100)*100)
   if op>=upper-.005 or fill>upper:qty=0
  if qty>0:
   fee=max(5,qty*fill*.00025)+qty*fill*(e.TRANSFER[d]+(e.STAMP[d] if side<0 else 0));before=sh*op/(cash+sh*op);cash-=side*qty*fill+fee;sh+=side*qty;working+=side*qty
   if side>0 and nentry==0:
    distance=1.5*a5[d,j-1];peak=fill
    stop_level=min(b[j-3:j,2])-.01 if mode=="swing" else fill-distance
   if side>0:buygross+=qty*fill;buycost+=qty*fill+fee;nentry+=1;lastentry=j;first=j if first<0 else first
   else:avail-=qty;sellnet+=qty*fill-fee;last=j
   fills.append(dict(date=str(e.DATES[d]),rule=rule,slip=slip,bar=j,side=side,qty=qty,price=fill,fee=fee,before=before,after=sh*op/(cash+sh*op),cash=cash,shares=sh,available=avail,working=working))
   assert avail>=0 and sh>=base and cash>=200000-1e-6 and buycost<=300000+1e-6 and working<=avail
  if exiting and working==0:break
 grossmark=sellnet+working*e.C[d]-buycost;control=startcash+base*e.C[d];nav=cash+sh*e.C[d];assert abs(nav-control-grossmark)<1e-6
 return dict(date=str(e.DATES[d]),rule=rule,slip=slip,mode=mode,stopHit=stop_hit,stopBar=stop_bar,eligible=bool(trend[d]),bought=buycost>0,complete=buycost>0 and working==0,deadline=deadline,buyCost=buycost,sellNet=sellnet,remaining=working,markedNet=grossmark,returnOnBought=grossmark/buycost if buycost else np.nan,firstBuy=first,lastSell=last,nav=nav,controlNav=control),fills
