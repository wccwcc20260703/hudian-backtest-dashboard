# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,math,hashlib,ast
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/t_stop_review';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
e=f.e
plan={'createdAt':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'Hold batch21 volume entry dates and quantities fixed: do swinglow/ATR stops improve net expectancy without selection bias?','sourceURLs':['https://www.schwab.com/learn/story/how-to-use-volume-weighted-indicators-trading','https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr','https://workplace.schwab.com/story/help-protect-your-position-using-stop-orders'],'sourceClaim':'Educational examples, NOT verified high win rate; our A-share adaptation is not an author exact system','rules':{'base':'Exact priorbatch volume entry and weakvolume profitexit/deadline','swing':'Freeze lowest low of3completed bars at entry minus0.01; completedclose below -> nextopen sell oldshares','atr15':'Freeze1.5 times simplemean of last14completed5mTR at entry; close below actualfill-distance -> nextopen sell oldshares','trail15':'Same frozen ATR distance, trailing highest completedclose sinceentry; floor actualentry minusdistance; never lowers; close below -> nextopen'},'controls':'Same entry only, no reentry and no parameter sweep; startdaily1m/50%oldstock/30%Tbudget/20%cashreserve. 5/10bps,fees,T+1,volume,limits unchanged. Stop is trigger not guaranteed fill. Notcontinuous portfolio, nofinancing noroldgoalclaim. Allseenhistory. Noexecution/default change.','ATR':'Simplemean14TR (not Fidelity exactWilder). Previousday bars rescaled by todayREF/previousofficialclose; todayfirstbar reference todayREF; usecompletedbars only.','freezeSHA':hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(O/'plan_before_results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
# Reuse prior signal construction and original simulator without its batch run.
p=R/'work/xhs_positive/study.py';src=p.read_text();tree=ast.parse(src)
selected=[]
for n in tree.body:
 if isinstance(n,ast.FunctionDef):selected.append(n)
ns={'np':np,'pd':pd,'math':math,'e':e};exec(compile(ast.Module(body=selected,type_ignores=[]),'prior_functions','exec'),ns)
v=e.B[:,:,4];expect=pd.DataFrame(v).rolling(20,min_periods=20).mean().shift().to_numpy();rv=v/expect
ma={n:e.Q.close.rolling(n).mean() for n in [5,10,20]};trend=((ma[5]>ma[10])&(ma[10]>ma[20])&(ma[20]>ma[20].shift(5))).shift().reindex(e.DATES).fillna(False).to_numpy(bool)
atr=(e.ATR/e.Q.close).shift().reindex(e.DATES).to_numpy()*e.REF;levels=np.stack([(ma[n]/e.Q.close).shift().reindex(e.DATES).to_numpy()*e.REF for n in [5,10,20]],axis=1)
sig=np.array([ns['observed'](e.B[d],rv[d],levels[d],atr[d]) for d in range(e.N)])
a5=np.zeros((e.N,48))
for d in range(e.N):
 b=e.B[d];pr=np.r_[e.REF[d],b[:-1,3]];tr=np.maximum.reduce([b[:,1]-b[:,2],abs(b[:,1]-pr),abs(b[:,2]-pr)])
 if d:
  old=e.B[d-1];op=np.r_[e.REF[d-1],old[:-1,3]];otr=np.maximum.reduce([old[:,1]-old[:,2],abs(old[:,1]-op),abs(old[:,2]-op)])*e.REF[d]/e.C[d-1];a5[d]=pd.Series(np.r_[otr[-14:],tr]).rolling(14).mean().to_numpy()[-48:]
 else:a5[d]=pd.Series(tr).expanding().mean()
ns.update(rv=rv,trend=trend,sig=sig)
fn=ast.get_source_segment(src,next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='simulate'))
fn=fn.replace('def simulate(d,rule,slip):','def simulate_stop(d,rule,slip,mode):').replace(' b=e.B[d];',' stop_level=-np.inf;distance=np.nan;peak=-np.inf;stop_bar=-1;stop_hit=False\n b=e.B[d];',1)
fn=fn.replace('   if weak:exiting=True','   if mode=="trail15":\n    peak=max(peak,c);stop_level=max(stop_level,peak-distance)\n   if mode!="base" and c<stop_level and not exiting:\n    exiting=True;stop_hit=True;stop_bar=j-1\n   if weak:exiting=True')
fn=fn.replace("   if side>0:buygross",'   if side>0 and nentry==0:\n    distance=1.5*a5[d,j-1];peak=fill\n    stop_level=min(b[j-3:j,2])-.01 if mode=="swing" else fill-distance\n   if side>0:buygross')
fn=fn.replace('eligible=bool(trend[d]),','mode=mode,stopHit=stop_hit,stopBar=stop_bar,eligible=bool(trend[d]),')
ns['a5']=a5;exec(fn,ns);(R/'work/t_stop_review/generated_simulator.py').write_text('# -*- coding: utf-8 -*-\n'+fn+'\n')
rows=[];fills=[];matched=0
for d in range(e.N):
 for slip in [.0005,.001]:
  prior,pfill=ns['simulate'](d,'volume',slip)
  for mode in plan['rules']:
   row,ff=ns['simulate_stop'](d,'volume',slip,mode)
   for t in ff:t['mode']=mode
   buys=[t for t in ff if t['side']==1];pb=[t for t in pfill if t['side']==1]
   assert len(buys)==len(pb)
   if buys:
    for key in ['bar','qty','price','fee','cash','shares','available']:assert buys[0][key]==pb[0][key]
    matched+=1
   if mode=='base':
    for k in prior:assert row[k]==prior[k] or (isinstance(row[k],float) and np.isnan(row[k]) and np.isnan(prior[k])),k
   row['delta']=row['markedNet']-prior['markedNet'];rows.append(row);fills.extend(ff)
df=pd.DataFrame(rows);ff=pd.DataFrame(fills);df.to_csv(O/'daily_episodes.csv',index=False);ff.to_csv(O/'fills.csv',index=False)
periods={'full':('2023-10-09','2026-10-09'),'train':('2023-10-09','2025-01-01'),'validation':('2025-01-01','2026-07-01'),'recent':('2026-07-01','2026-10-09'),'older':('1900','2023-10-09')}
for y in range(3):periods['year'+str(y+1)]=(f'{2023+y}-10-09',f'{2024+y}-10-09')
metrics=[]
for period,(a,z) in periods.items():
 for slip in [.0005,.001]:
  for mode in plan['rules']:
   q=df[(df.date>=a)&(df.date<z)&(df.slip==slip)&(df['mode']==mode)&df.bought];done=q[q.complete];win=q[q.markedNet>0];loss=q[q.markedNet<=0]
   metrics.append(dict(period=period,slip=slip,mode=mode,buyDays=len(q),completeDays=len(done),completeHit=(done.markedNet>0).mean(),allMarkedHit=(q.markedNet>0).mean(),averageNet=q.markedNet.mean(),meanWin=win.markedNet.mean(),meanLoss=loss.markedNet.mean(),worst=q.markedNet.min(),sumNet=q.markedNet.sum(),meanDelta=q.delta.mean(),improved=int((q.delta>1e-6).sum()),worse=int((q.delta< -1e-6).sum()),stopDays=int(q.stopHit.sum())))
mm=pd.DataFrame(metrics);mm.to_csv(O/'metrics.csv',index=False)
# Prior output parity, not just function reuse.
old=pd.read_csv(R/'outputs/xhs_positive/daily_episodes.csv');o=old[old.rule=='volume'].sort_values(['date','slip']);b=df[df['mode']=='base'].sort_values(['date','slip'])
for k in ['buyCost','sellNet','remaining','markedNet','nav','controlNav']:assert np.allclose(o[k],b[k],equal_nan=True)
ledger=0;maxerr=0
for (date,slip,mode),g in ff.groupby(['date','slip','mode']):
 d=int(np.searchsorted(e.DATES,date));base=int(500000/e.REF[d]/100)*100;cash=1e6-base*e.REF[d];shares=base;avail=base
 for _,t in g.iterrows():
  qty=int(t.qty);side=int(t.side);fee=max(5,qty*t.price*.00025)+qty*t.price*(e.TRANSFER[d]+(e.STAMP[d] if side<0 else 0));cash-=side*qty*t.price+fee;shares+=side*qty
  if side<0:avail-=qty
  err=abs(cash-t.cash);maxerr=max(maxerr,err);assert err<1e-6 and shares==t.shares and avail==t.available and avail>=0 and qty<=int(e.B[d,int(t.bar)-1,4]*.01/100)*100
  ledger+=1
# Re-run actual stop days with future bars poisoned; first actual sell unchanged.
prefix=0
for r in df[(df.stopHit)&(df.slip==.0005)].itertuples():
 d=int(np.searchsorted(e.DATES,r.date));orig=e.B[d].copy();last=int(r.stopBar)+1;original,of=ns['simulate_stop'](d,'volume',r.slip,r.mode)
 e.B[d,last+1:,:4]*=.5
 test,tf=ns['simulate_stop'](d,'volume',r.slip,r.mode);e.B[d]=orig
 a=[(t['bar'],t['side'],t['qty'],t['price']) for t in of if t['bar']<=last];b=[(t['bar'],t['side'],t['qty'],t['price']) for t in tf if t['bar']<=last];assert a==b;prefix+=1
# Select only on old training mean net; independent day diagnostics, NOT continuous wealth.
train=mm[(mm.period=='train')&(mm.slip==.0005)];selected=train.sort_values('averageNet',ascending=False).iloc[0]['mode']
audit={'sameEntryChecks':matched,'ledgerFills':ledger,'maxLedgerError':maxerr,'futurePoisonChecks':prefix,'priorBatchColumnsReproduced':6,'trainChosenMode':selected,'notContinuousPortfolio':True,'defaultChanged':False,'freezeSHA':plan['freezeSHA']};(O/'audit.json').write_text(json.dumps(audit,indent=2));print(mm[(mm.period.isin(['full','train','validation','recent','older']))&(mm.slip==.0005)].to_string(index=False));print(json.dumps(audit))
