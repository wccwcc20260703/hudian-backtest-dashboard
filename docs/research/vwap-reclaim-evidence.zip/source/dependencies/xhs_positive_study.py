# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,math,hashlib
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/xhs_positive';O.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
e=f.e;freeze=int(np.searchsorted(e.DATES,'2025-01-01'));cut=int(np.searchsorted(e.DATES,'2026-07-01'))
manifest={'at':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'Under an explicitly supplied50/30/20day-start account, does uptrend positiveT and shrinking relative volume improve net trade expectancy?','sources':[{'url':'https://xhslink.cn/o/8E7JyXIPjx8','access':'redirects tologin; video not independently watched; user summary only'},{'url':'https://xhslink.cn/o/1Z5ip97mLgj','access':'redirects tologin; video not independently watched; user summary only'}],'scope':'Independent daily controlled episodes, NOT a continuous3year portfolio. Each day owns500k prior-close-value oldshares and500k cash (rounding retainedcash), oldsharesT+1available; workingbudget300k; reserve200k. Dates are independent hypothetical setups, no compoundedNAV orfinance claim.','rules':{'rebound':'Priorcompleted adjustedSMA5>SMA10>SMA20 andSMA20 rising vs5daysago. At completed5minclose: previousclose lowest ofpreceding3 closes, nowhigher butstillbelowdayVWAP. Nextopenbuy10:00..14:00.','volume':'Rebound plus currentbarvolume/prior20daysSAMETIMEbarmean<0.8 and less thanmeanofpreceding3such ratios.','support':'Volume plus currentclose within0.5prior-dayATR ofnearest priorcompletedSMA5/10/20 mapped tocurrentrawbasis.','split334':'Volume entries at most3tranches withatleast10tradingminspacing;workingbudget split30/30/40. Sell after allentriesfinish or anyexitsignal, no furtherentry. This operationalizes splitBUY only, not exact vlogger3:3:4sell ladder (prices unspecified).'},'exit':'Completedclose aboveactualbuyVWAP andabovepreviousclose, current relativevolume<1 andbelowpreviousrelativevolume -> nextopensell oldshares equal toworkingbuyquantity. Otherwise14:30startforcedattemptthrough14:50. Allpartials/remaining inventory markedatclose; neverclaim100%byexcludingforcedexits.','costs':'No borrowing;5/10bpadverse tickroundedslip,commission min5,stamp/transfer,priorbarvolume1%,100shares;oldsharesavailablelimit;cash>=200k;workingbuycost<=300k. Borrowing has no authorization from socialmedia and is not tested in this pilot.','limitations':'No auction queue data,limitbook or1minhistory;no realpreauction limitorder backtest,no nine-turnclaim,percenttargets undefined pendinguseranswer. Explicit research variants,notauthororiginalexactreplication. Minute/dailyextrema mismatch: usecompletedclose,nextopenonly. Oct9excluded.','evaluation':'Trainthrough2024,validation2025..2026Jun,recentJuly..Oct8,older;allseenhistory. Compare variants onindependentepisodes only, maxoneworkingcycle/day; reportfilleddays,complete/partial,deadlinecosts,volumeimpact,netmarkedadvantage againstsame50%corecashsetup. Cannot inferbeatsfullyinvesteddefault oraccept originalgoals fromthispilot.','freezeSHA':hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(O/'plan_before_results.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
v=e.B[:,:,4];expect=pd.DataFrame(v).rolling(20,min_periods=20).mean().shift().to_numpy();rv=v/expect;vw=np.cumsum(e.B[:,:,5],axis=1)/np.maximum(np.cumsum(v,axis=1),1)
ma={n:e.Q.close.rolling(n).mean() for n in [5,10,20]};trend=((ma[5]>ma[10])&(ma[10]>ma[20])&(ma[20]>ma[20].shift(5))).shift().reindex(e.DATES).fillna(False).to_numpy(bool)
atr=(e.ATR/e.Q.close).shift().reindex(e.DATES).to_numpy()*e.REF;levels=np.stack([(ma[n]/e.Q.close).shift().reindex(e.DATES).to_numpy()*e.REF for n in [5,10,20]],axis=1)
def observed(b,ratios,maLevels,priorATR):
 c=b[:,3];n=len(b);out=np.zeros((n,3),bool);vv=np.cumsum(b[:,5])/np.maximum(np.cumsum(b[:,4]),1)
 for i in range(3,n):
  rebound=c[i]>c[i-1] and c[i-1]<=min(c[i-3:i]) and c[i]<vv[i]
  volume=rebound and ratios[i]<.8 and ratios[i]<np.mean(ratios[i-3:i])
  support=volume and min(abs(c[i]-maLevels))<=.5*priorATR
  out[i]=[rebound,volume,support]
 return out
sig=np.array([observed(e.B[d],rv[d],levels[d],atr[d]) for d in range(e.N)]);checks=0
for d in range(e.N):
 for j in range(6,37):
  assert np.array_equal(sig[d,j-1],observed(e.B[d,:j],rv[d,:j],levels[d],atr[d])[-1]);checks+=1
 if d>=20:assert np.allclose(expect[d],e.B[d-20:d,:,4].mean(axis=0));checks+=1

def simulate(d,rule,slip):
 b=e.B[d];base=int(500000/e.REF[d]/100)*100;cash=1e6-base*e.REF[d];startcash=cash;avail=base;sh=base;working=0;buygross=0.;buycost=0.;sellnet=0.;nentry=0;lastentry=-99;exiting=False;deadline=False;fills=[];first=-1;last=-1
 lower=math.floor(e.REF[d]*.9*100+.5)/100;upper=math.floor(e.REF[d]*1.1*100+.5)/100;ix={'rebound':0,'volume':1,'support':2,'split334':1}[rule]
 for j in range(1,47):
  side=0;qty=0;cap=int(b[j-1,4]*.01/100)*100;op=b[j,0]
  if working>0:
   c=b[j-1,3];weak=c>buygross/max(sum(t['qty'] for t in fills if t['side']==1),1) and c>b[j-2,3] and rv[d,j-1]<1 and rv[d,j-1]<rv[d,j-2]
   if weak:exiting=True
   if j>=42:exiting=True;deadline=True
  if exiting and working>0:
   side=-1;fill=math.floor(op*(1-slip)*100+1e-8)/100;qty=min(working,avail,cap)
   if op<=lower+.005 or fill<lower:qty=0
  elif not exiting and trend[d] and 6<=j<=36 and sig[d,j-1,ix] and j-lastentry>=2 and nentry<(3 if rule=='split334' else 1):
   side=1;fill=math.ceil(op*(1+slip)*100-1e-8)/100;budget=300000*([.3,.3,.4][nentry] if rule=='split334' else 1);budget=min(budget,300000-buycost,cash-200000)
   qty=min(cap,int(max(0,budget-5)/(fill*(1+.00025+e.TRANSFER[d]))/100)*100,avail-working)
   qty=max(0,int(qty/100)*100)
   if op>=upper-.005 or fill>upper:qty=0
  if qty>0:
   fee=max(5,qty*fill*.00025)+qty*fill*(e.TRANSFER[d]+(e.STAMP[d] if side<0 else 0));before=sh*op/(cash+sh*op);cash-=side*qty*fill+fee;sh+=side*qty;working+=side*qty
   if side>0:buygross+=qty*fill;buycost+=qty*fill+fee;nentry+=1;lastentry=j;first=j if first<0 else first
   else:avail-=qty;sellnet+=qty*fill-fee;last=j
   fills.append(dict(date=str(e.DATES[d]),rule=rule,slip=slip,bar=j,side=side,qty=qty,price=fill,fee=fee,before=before,after=sh*op/(cash+sh*op),cash=cash,shares=sh,available=avail,working=working))
   assert avail>=0 and sh>=base and cash>=200000-1e-6 and buycost<=300000+1e-6 and working<=avail
  if exiting and working==0:break
 grossmark=sellnet+working*e.C[d]-buycost;control=startcash+base*e.C[d];nav=cash+sh*e.C[d];assert abs(nav-control-grossmark)<1e-6
 return dict(date=str(e.DATES[d]),rule=rule,slip=slip,eligible=bool(trend[d]),bought=buycost>0,complete=buycost>0 and working==0,deadline=deadline,buyCost=buycost,sellNet=sellnet,remaining=working,markedNet=grossmark,returnOnBought=grossmark/buycost if buycost else np.nan,firstBuy=first,lastSell=last,nav=nav,controlNav=control),fills
rows=[];allfills=[]
for d in range(e.N):
 for rule in manifest['rules']:
  for slip in [.0005,.001]:rr,ff=simulate(d,rule,slip);rows.append(rr);allfills.extend(ff)
df=pd.DataFrame(rows);df.to_csv(O/'daily_episodes.csv',index=False);pd.DataFrame(allfills).to_csv(O/'fills.csv',index=False)
periods={'train':(e.START,freeze),'validation':(freeze,cut),'recent':(cut,e.N),'full':(e.START,e.N),'older':(0,e.START)}
for y in range(3):periods['year'+str(y+1)]=(int(np.searchsorted(e.DATES,f'{2023+y}-10-09')),int(np.searchsorted(e.DATES,f'{2024+y}-10-09')))
metrics=[]
for p,(a,z) in periods.items():
 for rule in manifest['rules']:
  for slip in [.0005,.001]:
   t=df[(df.date>=e.DATES[a])&(df.date<=e.DATES[z-1])&(df.rule==rule)&(df.slip==slip)];b=t[t.bought];done=b[b.complete]
   metrics.append(dict(rule=rule,period=p,slip=slip,totalDays=len(t),trendDays=int(t.eligible.sum()),buyDays=len(b),completeDays=len(done),missingDays=len(b)-len(done),deadlineDays=int(b.deadline.sum()),allMarkedHit=float((b.markedNet>0).mean()) if len(b) else np.nan,completeHit=float((done.markedNet>0).mean()) if len(done) else np.nan,averageNet=float(b.markedNet.mean()) if len(b) else np.nan,meanReturnOnBought=float(b.returnOnBought.mean()) if len(b) else np.nan,sumExtraNet=float(t.markedNet.sum()),worstExtra=float(t.markedNet.min())))
mm=pd.DataFrame(metrics);mm.to_csv(O/'metrics.csv',index=False)
# Perfect future knowledge opportunity ceiling, explicitly NOT a strategy or attainable winrate.
ceilings=[]
for p,(a,z) in periods.items():
 best=[]
 for d in range(a,z):
  prices=e.B[d,1:47,0];future=np.maximum.accumulate(prices[::-1])[::-1];best.append(float(np.max(future[1:]/prices[:-1]-1)))
 for threshold in [.02,.05,.07,.10]:ceilings.append(dict(period=p,target=threshold,days=z-a,possibleDays=int((np.array(best)>=threshold).sum()),fraction=float(np.mean(np.array(best)>=threshold))))
pd.DataFrame(ceilings).to_csv(O/'perfect_knowledge_ceiling.csv',index=False)
# Independent ledger reconciliation of every episode with fills.
filldf=pd.DataFrame(allfills);ledger=0;maxerror=0
for (date,rule,slip),ts in filldf.groupby(['date','rule','slip']):
 d=int(np.searchsorted(e.DATES,date));base=int(500000/e.REF[d]/100)*100;sh=base;cash=1e6-base*e.REF[d];av=base;working=0
 for _,t in ts.iterrows():
  q=int(t.qty);sgn=int(t.side);j=int(t.bar);fee=max(5,q*t.price*.00025)+q*t.price*(e.TRANSFER[d]+(e.STAMP[d] if sgn<0 else 0));assert q<=int(e.B[d,j-1,4]*.01/100)*100 and abs(fee-t.fee)<1e-7
  sh+=sgn*q;working+=sgn*q;cash-=sgn*q*t.price+fee
  if sgn<0:av-=q
  err=abs(cash-t.cash);maxerror=max(maxerror,err);assert err<1e-6 and sh==t.shares and av==t.available and av>=0 and working>=0;ledger+=1
audit=dict(prefixAndVolumeChecks=checks,ledgerFills=ledger,maxLedgerError=maxerror,independentDailyEpisodes=True,notContinuousPortfolio=True,notAuthorExactReplication=True,originalCashGoalEvaluated=False,financingEvaluated=False,defaultChanged=False,freezeSHA=manifest['freezeSHA']);(O/'audit.json').write_text(json.dumps(audit,indent=2))
print(mm[(mm.period=='full')&(mm.slip==.0005)].to_string(index=False));print(mm[(mm.period.isin(['train','validation','recent','older']))&(mm.slip==.0005)][['rule','period','buyDays','completeHit','allMarkedHit','meanReturnOnBought','sumExtraNet']].to_string(index=False));print(pd.DataFrame(ceilings).query("period=='full'").to_string(index=False));print(json.dumps(audit))
