# -*- coding: utf-8 -*-
from pathlib import Path
import re,json,zipfile
import pandas as pd
R=Path.cwd();O=R/'outputs/vwap_reclaim';D=R/'work/hudian-backtest-dashboard/docs/research';m=pd.read_csv(O/'metrics.csv');pp=pd.read_csv(O/'paired_decomposition.csv');roll=pd.read_csv(O/'rolling_selection.csv');a=json.loads((O/'audit.json').read_text())
labels={'immediate_base':'即买 · 原退出','reclaim_base':'等VWAP确认 · 原退出','immediate_swing':'即买 · 低点退出','reclaim_swing':'等VWAP确认 · 低点退出','none':'不追加做T'}
def table(df,cols):
 def cell(k,v):
  if pd.isna(v):return '—'
  if k in ['variant','chosen']:return labels[v]
  if k in ['quarter','trainLastDate']:return str(v)
  if k=='completeHit':return f'{v*100:.2f}%'
  if k in ['averagePerOpportunity','averagePerBuy','netSum','worst']:return f'{v:,.2f}'
  return str(int(v))
 return '<div class="scroll"><table><tr>'+''.join('<th>'+t+'</th>' for k,t in cols)+'</tr>'+''.join('<tr>'+''.join('<td>'+cell(k,r[k])+'</td>' for k,t in cols)+'</tr>' for _,r in df.iterrows())+'</table></div>'
cols=[('variant','方案'),('opportunities','原机会'),('buyDays','买入日'),('completeDays','完整往返'),('skipped','放弃'),('completeHit','完整胜率'),('averagePerOpportunity','每个原机会增量/元'),('averagePerBuy','每次买入增量/元')]
css=re.search(r'<style>(.*?)</style>',(D/'xhs-positive.html').read_text(),re.S).group(1)
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>沪电股份 · 等待站回分时均价的代价</title><style>'+css+'</style></head><body><main><a href="../index.html">← 返回看板</a> · <a href="archive.html">研究归档</a> · <a href="t-stop-review.html">上一批退出检验</a><h1>站回分时均价再买：过滤了坏机会，也买贵了</h1><p>第二十三批 · 2026-10-09 · 已核验历史截至10月8日 · 等待窗口预先固定30个交易分钟</p><div class="callout"><b>发现了过滤作用，尚未找到可稳定接入的新策略。</b>原167个机会中60个完成均价线确认，完整往返胜率50.00%→51.67%，5基点滑点下平均净增量转正；但2025年至2026年6月、更早历史及10基点滑点均为负。默认不变，不能据此声称达到高胜率或原现金标准。</div>'
page+='''<section><h2>同一个机会，比较现在买与等确认</h2><p>依据<a href="https://www.schwab.com/learn/story/how-to-use-volume-weighted-indicators-trading">Schwab关于价格收回VWAP的教学示例</a>，本轮把确认条件明确为：完成的5分钟收盘从均价线下方穿至上方，下一根开盘才尝试买入。原文未证明沪电股份胜率；30分钟等待和退出方式是本研究的固定实现。</p><p>先复现上一批可执行的缩量回升机会。当原买单在当时开盘、现金、可售老仓、前根成交量及涨跌停限制下可执行时，两个方案才共同开始比较。立即方案沿用原单；等待方案从此观察最多6根5分钟，首个均价线上穿出现后，下一根开盘仅尝试一次，最晚14:00买入。未确认或无法成交则当天不做这一轮，不在未来挑一个更好的交点。</p><p>累计均价用当时累计成交额÷累计成交量，不用收盘后整日均价。午休不计入30个交易分钟。等待后买入数量按当时预算、价格和量重新计算；不是强行买原来同样股数。四个固定组合仅为两入场×两退出，未经结果选择条件或调参。</p><ul><li>主比较：立即买与等确认，都使用原来的弱量盈利退出／14:30起尾盘退出。</li><li>辅助比较：两入场都再加上一批相同“买入时冻结前3根最低价减1分”的退出规则，检查结论是否依赖退出方式。</li></ul><p>起始账户仍是每天独立100万元、约50%隔夜底仓、30%做T预算及至少20%现金保留；T+1卖老股、整数股、费用、5/10基点滑点、量与涨跌停约束不变。没有当天买入新股可直接卖出的假设。</p><p class="note">这是逐日独立账户诊断，不是连续三年账户、融资研究或总收益回测。每个原机会都保留；没买的增量记0。所有历史此前已见，不称作新盲测，也没有原现金达标或财富1.20倍结论。</p></section>'''
page+='<section><h2>167个原机会，只有60个确认</h2>'+table(m[(m.period=='full')&(m.slip==.0005)],cols)+'''<p>107个机会在等待窗口内没有确认；本样本没有“已确认但成交失败”的日期，程序仍保留该类计数和约束。确认样本均完成往返。主比较中167个机会平均净增量由−586元变成+59元；只看实际买入的60天，则平均+165元。两个分母都列出，不能只报后者隐藏大量未交易日期。</p><p>50.00%原胜率是166个完成往返中的83个盈利；等待后是60个中的31个盈利，51.67%只增加约1.67个百分点，样本更少，不能据此称为高胜率或显著提高。</p></section>'''
page+='''<section><h2>收益改善究竟从哪里来？</h2><div class="grid"><div class="metric">放弃73个原亏损/持平机会<b>少亏 186,643元</b></div><div class="metric">放弃34个原盈利机会<b>少赚 24,161元</b></div><div class="metric">双方都买入的60天，等确认的变化<b>少赚 54,721元</b></div><div class="metric">全部167个机会的变化合计<b>改善 107,760元</b></div></div><p>在最后都会确认的60天中，立即买合计增量+64,605元，等确认只有+9,884元。等待平均12.25个交易分钟，实际买入价平均比原方案高约0.72%，而数量也会随价格和时段量变化。因此不能把全部差异都归因于价格，但可以确认：本轮改善主要来自不做107个机会，而不是把买价优化得更低。</p><p><b>这个拆分是事后归因，不能据此提前只买那60天。</b>原买点时还不知道未来是否会站回均价线；若用后来确认的日期反过来过滤原先低价买单，就引入未来信息。上面的金额是各独立日增量之和，不是可连续复利的账户收益。</p></section>'''
page+='<section><h2>后续行情与更高滑点没有站稳</h2>'
for p,t in [('train','较早段：2023年10月至2024年底'),('validation','后续段：2025年至2026年6月底'),('recent','近期：2026年7月至10月8日'),('older','更早历史：2020年至2023年10月之前')]:page+='<h3>'+t+'</h3>'+table(m[(m.period==p)&(m.slip==.0005)],cols)
page+='''<p>主方案较早段28次买入合计+28,269元，后续段31次变成−17,422元，近期唯一一次亏962元。三年微利主要由较早阶段贡献，不能说在后续行情也持续赚钱。更早47次买入亦亏19,042元。</p><h3>滑点加大到10基点：三年结果</h3>'''+table(m[(m.period=='full')&(m.slip==.001)],cols)+'''<p>主确认方案从每次买入平均+165元变为−88元、合计−5,275元，说明这点历史利润很容易被执行成本吃掉。辅助低点退出组合也转负，没有形成稳健替代。</p><details><summary>三个固定年度明细</summary>'''
for y in [1,2,3]:page+='<h3>年度'+str(y)+'</h3>'+table(m[(m.period=='year'+str(y))&(m.slip==.0005)],cols)
page+='</details></section>'
page+='<section><h2>只用过去选择，能否避免后段失效？</h2><p>按2024年底以前的原机会平均净增量，四组候选加“不追加做T”中选到“等待确认＋原退出”；但随后2025年至2026年上半年依然亏损。每季度只用之前252个交易日再选择，前两季分别选择两个确认方案并亏损，随后六季选择不追加做T。</p>'+table(roll,[('quarter','执行季度'),('trainLastDate','训练截至'),('chosen','选择'),('days','执行交易日'),('netSum','独立日增量合计/元')])+'''<p class="note">季度选择合计约−13,741元；这是独立每日场景的顺序选择检验，不是连续账户收益率、回撤或累计/滚动领先。2026年第四季当前只覆盖1个已核验交易日。每次训练只到季度前，已见历史仍非新独立证据。</p></section>'''
page+='''<section><h2>核验、时效与下一步</h2><p>两条立即买基线12列结果复现上一批；1,228次原买单核对；12,066项确认点前缀检查；4,148笔成交独立账本核对误差0；6项合成场景覆盖下一根成交、30分钟边界、14:00截止、未来价格不改信号、涨停不补成交以及等待后的量能与老股约束。原前瞻冻结文件未改。</p><p>本轮重新读取腾讯报价，源时间仍为2026-10-09 16:14:03、112.29元。报价不能补齐10月9日分时极值差异，所以已核验历史仍只到10月8日；本研究不发出过期实时交易提示。</p><p>下一步先复核后续段31次确认买入为何仍亏：分别检查失败是否源于越过均价线后迅速跌回、确认过晚、或原退出不适合确认入场。优先解释逐笔失败，再登记少量可在当时执行的新规则，不继续调整等待分钟数寻找历史赢家。</p><p><a href="vwap-reclaim-evidence.zip">下载预登记规则、所有机会及未交易明细、逐笔成交、归因、代码和核验</a></p></section></main></body></html>'''
(O/'report.html').write_text(page);(D/'vwap-reclaim.html').write_text(page)
with zipfile.ZipFile(D/'vwap-reclaim-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(O.iterdir()):
  if p.suffix in ['.csv','.json'] and p.name!='publication.json':z.write(p,p.name)
 for p in sorted((R/'work/vwap_reclaim').glob('*.py')):z.write(p,'source/'+p.name)
 for parent,name in [('xhs_positive','study.py'),('t_stop_review','study.py'),('t_stop_review','generated_simulator.py')]:z.write(R/'work'/parent/name,'source/dependencies/'+parent+'_'+name)
a=D/'archive.html';s=a.read_text();item='<p><a href="vwap-reclaim.html">第二十三批：等待站回分时均价，过滤坏机会与买贵的代价 ↗</a></p>'
if 'vwap-reclaim.html' not in s:a.write_text(s.replace('<h1>研究归档</h1>','<h1>研究归档</h1>'+item,1))
print(json.dumps({'htmlBytes':len(page.encode()),'zipBytes':(D/'vwap-reclaim-evidence.zip').stat().st_size}))
