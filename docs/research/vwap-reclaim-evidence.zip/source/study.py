# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,math,hashlib,ast
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/vwap_reclaim';sys.path.insert(0,str(R/'work/leverage'));import finance_engine as f
e=f.e
plan={'createdAt':pd.Timestamp.now(tz='Asia/Shanghai').isoformat(),'question':'For the same baseline executable rebound setup, does waiting up to30 tradingminutes to reclaim VWAP improve net expectancy after skipped opportunities?','sourceURL':'https://www.schwab.com/learn/story/how-to-use-volume-weighted-indicators-trading','sourceEvidence':'Educational example, not Hudian winrate proof. Thirtyminute timeout and our exits are researcher adaptations.','rules':{'immediate':'Priorbatch volume setup, exact first executable buy; onecycle/day','reclaim':'Arm when first baseline buy would be executable using known signal,currentopen,cash,limits,priorvolume. After arm, wait at most6completed5mbars and no later14:00execution for first cross completedclose>cumulativeVWAP with previousclose<=previousVWAP. Nextopenattempt ONCE, no other filters and no retry. Never retroactively replace an earlier buy by the future lowestprice.'},'exits':'Primary retains batch21 weak-volume profit exit or14:30deadline. Secondary applies batch22 frozenprevious3barlow-stop identically to both entry rules, explicitly a 2x2 check; no choosebestexit afterresults.','sizing':'Same initial daily1m,50%oldstock,30%workingbudget,20%reserve; delayed quantity recalculated to budget and priorvolume at execution, not force original shares. Completefixedcapitaldiagnostics; reportprice/quantityeffects separately.','comparison':'All baseline executable opportunity days retained, skipped trades zero incrementalPNL; decompose change into skipped winning/losing baseline vs delay onbothfilled. Include no-Tzero comparator. Markunfinished shares;notcontinuousportfolio orfinance.','selection':'Train through2024 selects maximum mean net peropportunity among four variants plus noTzero; reportlaterperiods and quarterly252tradingday rolling selection, including noT; no thresholdsweep. Allhistoryalreadyseen, notblindtest.','costs':'T+1 oldshares only,100shares,commissionsminimum5,stamp/transfer,5/10bps,1%priorbarvolume,price limits. No guarantee stop/quote fills.','freezeSHA':hashlib.sha256((R/'outputs/reentry/forward_freeze.json').read_bytes()).hexdigest()}
(O/'plan_before_results.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
p=R/'work/research-checkpoint.json';ck=json.loads(p.read_text());ck['activeBatch']='23_vwap_reclaim';ck['currentQuestion']=plan['question'];p.write_text(json.dumps(ck,ensure_ascii=False,indent=2))
old=R/'work/xhs_positive/study.py';src=old.read_text();tree=ast.parse(src);ns={'np':np,'pd':pd,'math':math,'e':e};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'prior_functions','exec'),ns)
# Reuse exact signal and volatility construction from the prior batch, without running its study.
s22=(R/'work/t_stop_review/study.py').read_text();exec(s22[s22.index('v=e.B'):s22.index('fn=ast.get')],globals());ns['a5']=a5;exec((R/'work/t_stop_review/generated_simulator.py').read_text(),ns)
vwap=np.cumsum(e.B[:,:,5],axis=1)/np.maximum(np.cumsum(e.B[:,:,4],axis=1),1)
def confirmation(b,seed):
 if seed<0:return -1
 vw=np.cumsum(b[:,5])/np.maximum(np.cumsum(b[:,4]),1)
 for j in range(seed+1,min(seed+6,36,len(b)-1)+1):
  k=j-1
  if b[k,3]>vw[k] and b[k-1,3]<=vw[k-1]:return j
 return -1
rows=[];fills=[];seedchecks=0;prefix=0
for d in range(e.N):
 for slip in [.0005,.001]:
  original,of=ns['simulate_stop'](d,'volume',slip,'base');seed=original['firstBuy'];confirm=confirmation(e.B[d],seed)
  if seed>=0:
   for j in range(seed+1,37):
    # A truncated prefix knows only bars through j-1; append dummy current-open bar.
    b=e.B[d,:j+1].copy();b[j,1:]=0
    got=confirmation(b,seed);assert got==(confirm if 0<=confirm<=j else -1);prefix+=1
  saved=ns['sig'][d].copy()
  for entry in ['immediate','reclaim']:
   ns['sig'][d]=saved if entry=='immediate' else np.zeros_like(saved)
   if entry=='reclaim' and confirm>=0:ns['sig'][d,confirm-1,1]=True
   for exitmode in ['base','swing']:
    rr,ff=ns['simulate_stop'](d,'volume',slip,exitmode);variant=entry+'_'+exitmode
    for t in ff:t['variant']=variant
    rr.update(entry=entry,variant=variant,opportunity=seed>=0,seed=seed,confirmation=confirm,waitBars=(confirm-seed) if confirm>=0 else -1,baselineNet=original['markedNet'])
    buy=[t for t in ff if t['side']==1];ob=[t for t in of if t['side']==1]
    rr['buyQty']=buy[0]['qty'] if buy else 0;rr['buyPrice']=buy[0]['price'] if buy else np.nan
    rr['baselineQty']=ob[0]['qty'] if ob else 0;rr['baselinePrice']=ob[0]['price'] if ob else np.nan
    if entry=='immediate' and buy:
     assert buy[0]['qty']==ob[0]['qty'] and buy[0]['price']==ob[0]['price'] and buy[0]['bar']==ob[0]['bar'];seedchecks+=1
    if entry=='reclaim' and buy:assert buy[0]['bar']==confirm and confirm>seed
    rows.append(rr);fills.extend(ff)
  ns['sig'][d]=saved
df=pd.DataFrame(rows);ff=pd.DataFrame(fills);df.to_csv(O/'daily_episodes.csv',index=False);ff.to_csv(O/'fills.csv',index=False)
prior=pd.read_csv(R/'outputs/t_stop_review/daily_episodes.csv')
for mode in ['base','swing']:
 a=prior[prior['mode']==mode].sort_values(['date','slip']);b=df[df.variant=='immediate_'+mode].sort_values(['date','slip'])
 for k in ['buyCost','sellNet','remaining','markedNet','nav','controlNav']:assert np.allclose(a[k],b[k],equal_nan=True)
periods={'full':('2023-10-09','2026-10-09'),'train':('2023-10-09','2025-01-01'),'validation':('2025-01-01','2026-07-01'),'recent':('2026-07-01','2026-10-09'),'older':('1900','2023-10-09')}
for y in range(3):periods['year'+str(y+1)]=(f'{2023+y}-10-09',f'{2024+y}-10-09')
metrics=[];paired=[]
for period,(a,z) in periods.items():
 for slip in [.0005,.001]:
  for variant in df.variant.unique():
   t=df[(df.date>=a)&(df.date<z)&(df.slip==slip)&(df.variant==variant)&df.opportunity];b=t[t.bought];done=b[b.complete]
   metrics.append(dict(period=period,slip=slip,variant=variant,opportunities=len(t),buyDays=len(b),completeDays=len(done),skipped=int((~t.bought).sum()),noConfirm=int((t.confirmation<0).sum()) if variant.startswith('reclaim') else 0,unfilled=int(((t.confirmation>=0)&(~t.bought)).sum()) if variant.startswith('reclaim') else 0,completeHit=(done.markedNet>0).mean(),averagePerOpportunity=t.markedNet.mean(),averagePerBuy=b.markedNet.mean(),netSum=t.markedNet.sum(),worst=t.markedNet.min(),meanWaitMinutes=b.waitBars.mean()*5 if variant.startswith('reclaim') else 0))
  for mode in ['base','swing']:
   x=df[(df.date>=a)&(df.date<z)&(df.slip==slip)&(df.variant=='immediate_'+mode)&df.opportunity].set_index('date');y=df[(df.date>=a)&(df.date<z)&(df.slip==slip)&(df.variant=='reclaim_'+mode)&df.opportunity].set_index('date');both=y.bought;skip=~both
   delay=(y.loc[both,'markedNet']-x.loc[both,'markedNet']).sum();avoid=-x.loc[skip&(x.markedNet<=0),'markedNet'].sum();miss=-x.loc[skip&(x.markedNet>0),'markedNet'].sum();total=y.markedNet.sum()-x.markedNet.sum();assert abs(total-delay-avoid-miss)<1e-6
   paired.append(dict(period=period,slip=slip,exit=mode,bothDays=int(both.sum()),skippedWins=int((skip&(x.markedNet>0)).sum()),skippedLosses=int((skip&(x.markedNet<=0)).sum()),avoidedLoss=avoid,missedProfit=miss,delayChange=delay,totalDelta=total,bothOriginalNet=x.loc[both,'markedNet'].sum(),bothNewNet=y.loc[both,'markedNet'].sum(),meanPricePremium=(y.loc[both,'buyPrice']/x.loc[both,'buyPrice']-1).mean()))
mm=pd.DataFrame(metrics);mm.to_csv(O/'metrics.csv',index=False);pp=pd.DataFrame(paired);pp.to_csv(O/'paired_decomposition.csv',index=False)
# Chronological selection uses per-opportunity net including skipped/flat; no-Tzero is selectable.
wide=df[(df.slip==.0005)].pivot(index='date',columns='variant',values='markedNet').reindex(e.DATES);wide['none']=0
training=wide.loc['2023-10-09':'2024-12-31'].sum();choice=training.idxmax();selection=[]
for q in pd.period_range('2025Q1','2026Q4',freq='Q'):
 start=str(q.start_time.date());end=str(q.end_time.date());ix=int(np.searchsorted(e.DATES,start));past=wide.iloc[max(0,ix-252):ix];chosen=past.sum().idxmax();current=wide.loc[start:end];selection.append(dict(quarter=str(q),trainLastDate=str(past.index[-1]),chosen=chosen,days=len(current),netSum=current[chosen].sum()))
pd.DataFrame(selection).to_csv(O/'rolling_selection.csv',index=False)
ledger=0
for (date,slip,variant),g in ff.groupby(['date','slip','variant']):
 d=int(np.searchsorted(e.DATES,date));base=int(500000/e.REF[d]/100)*100;cash=1e6-base*e.REF[d];sh=base;av=base
 for _,t in g.iterrows():
  qty=int(t.qty);side=int(t.side);fee=max(5,qty*t.price*.00025)+qty*t.price*(e.TRANSFER[d]+(e.STAMP[d] if side<0 else 0));cash-=side*qty*t.price+fee;sh+=side*qty
  if side<0:av-=qty
  assert abs(cash-t.cash)<1e-6 and sh==t.shares and av==t.available and av>=0 and qty<=int(e.B[d,int(t.bar)-1,4]*.01/100)*100;ledger+=1
audit={'priorBaselineColumnChecks':12,'sameImmediateBuyChecks':seedchecks,'confirmationPrefixChecks':prefix,'ledgerFills':ledger,'maxLedgerError':0,'trainingSelection':choice,'selectionScores':training.to_dict(),'notContinuousPortfolio':True,'defaultChanged':False,'freezeSHA':plan['freezeSHA']};(O/'audit.json').write_text(json.dumps(audit,indent=2));print(mm[(mm.period.isin(['full','train','validation','recent','older']))&(mm.slip==.0005)].to_string(index=False));print(pp[(pp.period=='full')&(pp.slip==.0005)].to_string(index=False));print(json.dumps(audit));print(pd.DataFrame(selection).to_string(index=False))
