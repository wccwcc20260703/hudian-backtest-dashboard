# -*- coding: utf-8 -*-
import ast,json,types,math,hashlib
from pathlib import Path
import numpy as np,pandas as pd
R=Path.cwd();O=R/'outputs/xhs_positive'
tree=ast.parse((R/'work/xhs_positive/study.py').read_text());module=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[])
ns={'np':np,'math':math};exec(compile(module,'functions_only','exec'),ns)
def setup():
 b=np.zeros((1,48,6));b[:,:,:4]=100;b[:,:,4]=1000000;b[:,:,5]=100000000
 b[0,5,3]=99;b[0,6,3]=101;b[0,7:,0]=101
 e=types.SimpleNamespace(B=b,REF=np.array([100.]),TRANSFER=np.array([.00001]),STAMP=np.array([.0005]),C=np.array([101.]),DATES=np.array(['2026-01-05']))
 sig=np.zeros((1,48,3),bool);sig[0,5]=True
 rv=np.full((1,48),.6);rv[0,6]=.5
 ns.update(e=e,sig=sig,rv=rv,trend=np.array([True]));return e
checks=[]
e=setup();r,t=ns['simulate'](0,'rebound',.0005)
assert len(t)==2 and [x['bar'] for x in t]==[6,7] and r['complete'] and t[-1]['shares']==5000 and t[-1]['available']==5000-t[0]['qty'] and t[0]['cash']>=200000
assert t[0]['price']==100.05 and t[1]['price']==100.94
checks.append('Signal at completed bar5 buys bar6; completed bar6 exit sells old shares at bar7; adverse slip and cash reserve enforced')
e=setup();ns['rv'][:]=1.5;r,t=ns['simulate'](0,'rebound',.0005);assert r['complete'] and t[-1]['bar']==42 and r['deadline'];checks.append('No early exit forces first exit attempt at14:30')
e=setup();e.B[0,6,4]=10000;r,t=ns['simulate'](0,'rebound',.0005);assert t[1]['qty']==100 and len(t)==3 and t[2]['bar']==8 and r['complete'];checks.append('Sell volume cap gives partial sale then nextbar remainder; no samebar complete assumption')
e=setup();e.B[0,7:,0]=90;r,t=ns['simulate'](0,'rebound',.0005);assert len(t)==1 and not r['complete'] and r['remaining']==t[0]['qty'] and abs(r['markedNet']-(r['remaining']*e.C[0]-r['buyCost']))<1e-6;checks.append('Limit-down prevents every exit; unfinished position is kept and close-marked')
e=setup();ns['trend'][0]=False;r,t=ns['simulate'](0,'rebound',.0005);assert not t and r['markedNet']==0;checks.append('Prior trend gate rejects entry')
e=setup();ns['rv'][:]=1.5;ns['sig'][0,7]=True;ns['sig'][0,9]=True;r,t=ns['simulate'](0,'split334',.0005);buys=[x for x in t if x['side']==1];assert [x['bar'] for x in buys]==[6,8,10] and r['buyCost']<=300000 and min(x['cash'] for x in t)>=200000;checks.append('Three30/30/40buy budgets use separate signals and10tradingminute spacing')
m=pd.read_csv(O/'metrics.csv');d=pd.read_csv(O/'daily_episodes.csv');extra=[]
for rule in m.rule.unique():
 q=d[(d.date>='2023-10-09')&(d.slip==.0005)&(d.rule==rule)&d.bought];win=q[q.markedNet>0];loss=q[q.markedNet<=0]
 extra.append({'rule':rule,'wins':len(win),'lossesOrFlat':len(loss),'meanWin':win.markedNet.mean(),'meanLoss':loss.markedNet.mean(),'deadlineNet':q[q.deadline].markedNet.sum(),'earlyExitNet':q[~q.deadline].markedNet.sum()})
pd.DataFrame(extra).to_csv(O/'profit_diagnostics.csv',index=False)
a={'syntheticChecks':checks,'count':len(checks),'sourceSHA':hashlib.sha256((R/'work/xhs_positive/study.py').read_bytes()).hexdigest(),'warning':'Independent daily episodes, not a continuous account; incomplete trades include close valuation, not realizedprofit'}
(O/'additional_audit.json').write_text(json.dumps(a,indent=2));print(json.dumps(a));print(pd.DataFrame(extra).to_string(index=False));print(m[(m.period=='full')&(m.slip==.001)][['rule','buyDays','completeHit','averageNet']].to_string(index=False))
